# Stage 8 — Floating Toolbars (0.21.22)

- Reader content now fills the available reading area; toolbar and footer space is not reserved.
- Top and bottom controls are overlays above the reading content.
- Toggling controls does not change the reader layout dimensions or pagination height.
- Reading-position persistence and chapter/page navigation logic remain unchanged.
- Existing left/right and above/below padding controls remain available.
- Sliders remain continuous, with no ticks or marker dots.

This is based on the supplied Stage 8 Slider Markers Removed source archive.
