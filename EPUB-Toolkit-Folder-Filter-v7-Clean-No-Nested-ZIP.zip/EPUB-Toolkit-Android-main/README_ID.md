# EPUB All-in-One Toolkit — Android

Project Android ini membungkus mesin Python dari file `IN_ONE_TOOLKIT_8_TOOLS.py` ke dalam aplikasi Android dengan WebView. Delapan alat dan backend Python dipertahankan.

## Cara mendapatkan APK (tanpa Android Studio)

1. Buat repository GitHub baru.
2. Ekstrak seluruh isi ZIP ini, lalu upload semua file dan folder ke repository.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Android APK**, lalu tekan **Run workflow** (atau tunggu build selesai setelah push).
5. Buka hasil workflow yang selesai, lalu unduh artifact **EPUB-Toolkit-APK**.
6. Ekstrak artifact ZIP dan install `app-debug.apk` di ponsel Android.

## Izin penyimpanan

Saat pertama dibuka, aplikasi meminta izin **All files access** agar dapat membaca dan menulis EPUB/TXT di folder `Download`. Semua alat pengeditan memperbarui file sumber secara langsung setelah hasil sementara lolos validasi. Sebelum perubahan diterapkan, aplikasi membuat salinan backup bernama `nama.epub.backup` (atau nomor berikutnya jika backup sudah ada). Rename berdasarkan metadata tetap mengganti nama file.

## Catatan

- Ini adalah APK debug untuk instalasi pribadi, bukan rilis Play Store.
- Build memerlukan koneksi internet di GitHub Actions untuk mengambil Android SDK, Gradle, Chaquopy, dan Pillow.
- Image Compressor memakai Pillow.
- Jika ingin menerbitkan di Play Store, target SDK, izin penyimpanan, dan proses signing perlu disesuaikan.


## Penyimpanan hasil

Alat pengeditan EPUB/TXT menimpa file yang dipilih setelah pemrosesan pada file sementara selesai dan validasi berhasil. Backup otomatis disimpan di folder Download dengan akhiran `.backup`. Simpan backup tersebut jika ingin memulihkan versi sebelumnya.
