# EPUB Toolkit V5.0.1 — Native Library Milestone

## This milestone
This is the next native Android milestone built with Kotlin and Jetpack Compose. The UI remains native; WebView, JavaScript UI, and Python are not used.

Included:
- Native Compose app shell and dark theme
- Bottom navigation for Library, Single Feature, and Batch Feature
- Native Library folder picker using Android's Storage Access Framework
- Persisted folder permission and selected-folder preference
- Recursive EPUB scan including subfolders
- EPUB metadata parsing for title and creator/author from container.xml and OPF
- Compact book list with title, author (when available), and filename
- Refresh/rescan button
- Toggle sorting by title or filename
- Scan errors displayed in the Library UI
- Existing Single and Batch feature catalogs retained

Not yet implemented:
- Actual EPUB reader/open-book flow
- Cover extraction and display (placeholder book icons remain)
- Reading history/progress
- Single-feature processing implementations
- Batch processing engine
- ZIP extraction/password workflow

## Stack
- Kotlin / Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- Jetpack Compose BOM 2024.12.01
- Compose Material 3
- AndroidX DocumentFile for SAF folder traversal
- minSdk 24, targetSdk 35, compileSdk 35
- applicationId: com.rdustt21.epubtoolkit.v5
- versionName 5.0.1 / versionCode 501

## Build
Open this folder in Android Studio and sync Gradle. Gradle wrapper is not included in this archive.
