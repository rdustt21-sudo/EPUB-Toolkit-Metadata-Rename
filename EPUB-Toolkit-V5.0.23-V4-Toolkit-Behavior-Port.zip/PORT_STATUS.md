# Native EPUB Toolkit — V4 Toolkit Behavior Port

## Changes in 0.21.0
- Single Feature now uses the V4-style two-column feature grid.
- Batch Processing uses the V4 operation order, including Batch Unzip before the two Bulk Find & Replace actions.
- Added folder filtering to Toolkit selection and batch selection.
- Batch processing continues per file and presents individual success/failure result cards.
- EPUB rewrite operations now stage a new archive, fully read its entries for ZIP validation, and transactionally replace the original with a rollback file during commit. The rollback file is temporary and is not retained as a backup.
- Bulk Find & Replace on TXT now stages and replaces the original TXT, matching V4 in-place behavior.
- ZIP extraction retains safe path checks and duplicate-name handling.

## Preserved
- Native Library, reader, pagination/search behavior, and app identity.
- Single Feature and Batch Processing operation implementations.
- No unrelated reader or library code changed.

## Verification
- ZIP packaging/integrity checks and source-level checks performed.
- Full Android Gradle build was not run because this environment has no Android SDK/Gradle installation. Confirm build through GitHub Actions before installing.
