RED-DUST EPUB Toolkit V29.5.6 – Restore Internal EPUB Link Appearance

Fix:
- Internal EPUB links retain their href attribute in the reader HTML, in addition to the data-rd-href used for chapter-aware navigation.
- This restores anchor link styling/semantics so internal links no longer appear as ordinary text.
- The reader's click handler still intercepts internal links and prevents WebView file navigation.
- Chapter and fragment navigation logic remains unchanged.

No full Android build was performed in this environment.
