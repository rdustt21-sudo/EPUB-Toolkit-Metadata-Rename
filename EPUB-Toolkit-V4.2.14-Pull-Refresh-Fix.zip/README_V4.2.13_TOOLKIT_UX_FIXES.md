# V4.2.13 — Toolkit Layout, Pull Refresh Threshold, Back Navigation

Base: V4.2.11 (App version 2.0.2)
App version: 2.0.4 (version code 13)

Changes:
- Single Feature grid indicator spans both columns so it does not consume a feature tile slot.
- Pull-to-refresh requires a longer downward pull (130 px) and indicator appears after 35 px, reducing accidental scans while scrolling.
- Android Back from Single Feature or Batch Feature returns to Toolkit home instead of My Library.
- Search history remains pinned beneath search box outside scrolling results.
- No toolkit operation logic changed.

Validation: Python syntax and ZIP integrity checked. Android build/device test not performed.
