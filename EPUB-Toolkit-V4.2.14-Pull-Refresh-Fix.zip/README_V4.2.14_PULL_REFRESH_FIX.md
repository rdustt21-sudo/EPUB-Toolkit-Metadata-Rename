V4.2.14: Fix toolkit pull-to-refresh. Corrected unreachable threshold, added visible indicator dynamically, increased gesture threshold to 150px and required screen/panel top.
