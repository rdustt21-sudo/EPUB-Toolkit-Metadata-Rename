# V29.5 Pagination Measurement Prototype

This milestone adds an isolated JavaScript prototype (`app/src/main/python/pagination_measurement_prototype.js`) for measuring a chapter in a hidden DOM and mapping normalized text offsets to CSS-column page positions.

**Experimental only:** It is not wired into the reader or search results. The live reader's pagination/navigation is unchanged. The prototype needs validation against real EPUB chapters and Android WebView before integration; page mapping may need refinement for nested markup, whitespace normalization, images, tables, font metrics, and chapter-boundary numbering.
