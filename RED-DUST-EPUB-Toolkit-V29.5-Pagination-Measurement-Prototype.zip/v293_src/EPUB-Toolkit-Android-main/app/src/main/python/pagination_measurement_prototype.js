/* V29.5 experimental page-mapping prototype.
 * This module intentionally does not hook into the live reader yet.
 * It measures a chapter in an isolated DOM using the reader's column geometry,
 * and maps normalized plain-text offsets to rendered column/page numbers.
 */
(function (global) {
  'use strict';
  function normalizeText(s) { return String(s || '').replace(/\\s+/g, ' ').trim(); }
  function collectNormalizedTextMap(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const parts = [], entries = [];
    let normalized = '', pendingSpace = false;
    while (walker.nextNode()) {
      const node = walker.currentNode, value = node.nodeValue || '';
      for (let i = 0; i < value.length; i++) {
        const ch = value[i];
        if (/\\s/.test(ch)) { pendingSpace = normalized.length > 0; continue; }
        if (pendingSpace) { normalized += ' '; parts.push({node, start:i, end:i, normalizedIndex:normalized.length-1}); pendingSpace = false; }
        entries.push({node, nodeOffset:i, normalizedIndex:normalized.length});
        normalized += ch;
      }
    }
    return {text: normalized, entries};
  }
  function rangeForNormalizedOffset(root, map, offset) {
    if (!map.entries.length) return null;
    const idx = Math.max(0, Math.min(map.entries.length - 1, Number(offset) || 0));
    const entry = map.entries[idx];
    const range = document.createRange();
    range.setStart(entry.node, entry.nodeOffset);
    range.setEnd(entry.node, Math.min(entry.nodeOffset + 1, entry.node.nodeValue.length));
    return range;
  }
  function measureChapterPages(options) {
    const opts = options || {}, html = String(opts.html || ''), offsets = Array.isArray(opts.offsets) ? opts.offsets : [];
    const width = Math.max(120, Number(opts.width) || 360), height = Math.max(200, Number(opts.height) || 640);
    const fontSize = Math.max(8, Number(opts.fontSize) || 18), lineHeight = opts.lineHeight || 1.5;
    const paddingLeft = Math.max(0, Number(opts.paddingLeft) || 20), paddingRight = Math.max(0, Number(opts.paddingRight) || 20);
    const columnWidth = Math.max(120, width - paddingLeft - paddingRight), gap = paddingLeft + paddingRight;
    const host = document.createElement('div');
    host.setAttribute('aria-hidden', 'true');
    Object.assign(host.style, {position:'fixed',left:'-100000px',top:'0',width:width+'px',height:height+'px',overflow:'hidden',visibility:'hidden',contain:'layout style paint'});
    const content = document.createElement('article');
    Object.assign(content.style, {boxSizing:'border-box',width:width+'px',height:height+'px',overflow:'visible',padding:paddingLeft+'px '+paddingRight+'px',columnWidth:columnWidth+'px',webkitColumnWidth:columnWidth+'px',columnGap:gap+'px',webkitColumnGap:gap+'px',columnFill:'auto',webkitColumnFill:'auto',fontSize:fontSize+'px',lineHeight:String(lineHeight),whiteSpace:'normal'});
    content.innerHTML = html; host.appendChild(content); document.body.appendChild(host);
    const map = collectNormalizedTextMap(content), pageWidth = Math.max(1, width);
    const totalPages = Math.max(1, Math.ceil(content.scrollWidth / pageWidth));
    const results = offsets.map(offset => {
      const range = rangeForNormalizedOffset(content, map, offset);
      if (!range) return {offset, page:null};
      const rect = range.getBoundingClientRect(), base = content.getBoundingClientRect();
      const relativeX = rect.left - base.left;
      return {offset, page:Math.max(1, Math.floor(relativeX / pageWidth) + 1)};
    });
    host.remove();
    return {totalPages, pages:results, normalizedLength:map.text.length};
  }
  global.RedDustPaginationPrototype = {normalizeText, collectNormalizedTextMap, rangeForNormalizedOffset, measureChapterPages};
})(window);
