# RED DUST - EPUB Toolkit V12

V12 adds a separate **EPUB Reader** tab. It opens EPUB files locally from the existing file list and reads chapters in spine order.

Reader controls:
- Font size: 14–32 px
- Line spacing: 1.3–2.1
- Paragraph spacing: 0.4–2 em
- Themes: Light, Sepia, Night
- Chapter picker and Previous/Next navigation

The reader does not modify the source EPUB. Reading content is extracted on demand by the local Python/WebView bridge. Existing toolkit features are retained.
