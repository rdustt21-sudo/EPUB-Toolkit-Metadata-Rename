# EPUB Toolkit V5.0.12 — Native Reader Phase

V5.0.12 adds an Android-native EPUB reader entry point from the Library (tap an EPUB to open). The reader uses direct storage file paths and a WebView chapter renderer for EPUB XHTML content.

Reader capabilities in this phase:
- EPUB container/OPF manifest and spine parsing
- Lazy chapter content loading from the EPUB ZIP
- Horizontal page/column navigation by tap buttons or swipe
- Chapter navigation and table of contents
- Search across chapter text with snippets and highlight on open
- Restore chapter/page position per book
- Font size, line spacing, paragraph spacing, font spacing, font weight and font family controls
- Light, sepia and night themes
- Embed local EPUB images into chapter HTML and handle chapter-local links
- Reader back navigation returns to Library

This is a native V5 implementation of the core V4 reader workflow, not yet verified for complete one-to-one V4 feature parity. This environment does not contain the Android SDK/Gradle build environment; Kotlin syntax and ZIP structure were checked, but an Android build must still be run in CI before installation.
