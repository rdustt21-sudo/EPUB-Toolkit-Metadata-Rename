package com.example.epubtoolkit

import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.JavascriptInterface
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Base64
import java.util.Locale

private fun loadReaderSearchHistory(prefs: android.content.SharedPreferences): List<String> {
    return runCatching {
        val arr = JSONArray(prefs.getString("reader_search_history", "[]"))
        (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { value -> value.isNotBlank() } }
    }.getOrDefault(emptyList())
}

private data class ReaderChapter(val title: String, val href: String, val zipPath: String)
private data class ReaderBookData(val title: String, val chapters: List<ReaderChapter>, val opfPath: String)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun EpubReaderScreen(filePath: String, displayTitle: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val file = remember(filePath) { File(filePath) }
    val prefs = remember(filePath) { context.getSharedPreferences("reader_v5_${filePath.hashCode()}", Context.MODE_PRIVATE) }
    val initialChapter = remember(filePath) { prefs.getInt("chapter", 0) }
    val initialPage = remember(filePath) { prefs.getInt("page", 0) }
    var chapters by remember(filePath) { mutableStateOf<List<String>>(emptyList()) }
    var chapter by remember(filePath) { mutableIntStateOf(initialChapter) }
    var page by remember(filePath) { mutableIntStateOf(initialPage) }
    var fontSize by remember(filePath) { mutableFloatStateOf(prefs.getFloat("font", 19f)) }
    var lineSpacing by remember(filePath) { mutableFloatStateOf(prefs.getFloat("line", 1.65f)) }
    var paraSpacing by remember(filePath) { mutableFloatStateOf(prefs.getFloat("para", 1f)) }
    var letterSpacing by remember(filePath) { mutableFloatStateOf(prefs.getFloat("letter", 0f)) }
    var fontWeight by remember(filePath) { mutableIntStateOf(prefs.getInt("weight", 400)) }
    var fontFamily by remember(filePath) { mutableStateOf(prefs.getString("family", "Georgia,serif") ?: "Georgia,serif") }
    var theme by remember(filePath) { mutableStateOf(prefs.getString("theme", "light") ?: "light") }
    var settingsOpen by remember { mutableStateOf(false) }
    var tocOpen by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var searchHistory by remember(filePath) { mutableStateOf(loadReaderSearchHistory(prefs)) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var bridge by remember { mutableStateOf<NativeReaderBridge?>(null) }
    var loaded by remember(filePath) { mutableStateOf(false) }
    var controlsVisible by remember(filePath) { mutableStateOf(prefs.getBoolean("controls_visible", true)) }
    BackHandler(enabled = true) { if (searchOpen || settingsOpen || tocOpen) { searchOpen = false; settingsOpen = false; tocOpen = false } else if (!controlsVisible) { controlsVisible = true; prefs.edit().putBoolean("controls_visible", true).apply() } else onBack() }

    LaunchedEffect(filePath) {
        val native = NativeReaderBridge(file, prefs, { names -> Handler(Looper.getMainLooper()).post { chapters = names } }, { c, p -> Handler(Looper.getMainLooper()).post { chapter = c; page = p } }, { visible -> Handler(Looper.getMainLooper()).post { controlsVisible = visible; if (!visible) { settingsOpen = false; tocOpen = false; searchOpen = false } } })
        bridge = native
    }
    fun performBookSearch(q: String) {
        val query = q.trim()
        if (query.isBlank()) return
        searchResults = bridge?.search(query)?.let { arr -> (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } } ?: emptyList()
        searchHistory = listOf(query) + searchHistory.filterNot { it.equals(query, true) }.take(19)
        prefs.edit().putString("reader_search_history", JSONArray(searchHistory).toString()).apply()
    }
    val bg = when(theme) { "night" -> Color(0xFF101719); "sepia" -> Color(0xFFF0E4C9); else -> Color(0xFFF7F2E8) }
    val fg = when(theme) { "night" -> Color(0xFFE5E8E8); else -> Color(0xFF28251F) }
    Column(Modifier.fillMaxSize().background(bg)) {
        if (controlsVisible) Row(Modifier.fillMaxWidth().background(if (theme == "night") Color(0xFF202A2B) else Color(0xFF075B70)).padding(horizontal = 4.dp, vertical = 5.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text(displayTitle, modifier = Modifier.weight(1f), maxLines = 1, color = Color.White, style = MaterialTheme.typography.titleSmall)
            IconButton(onClick = { searchOpen = !searchOpen; settingsOpen = false; tocOpen = false }) { Icon(Icons.Default.Search, "Find in book", tint = Color.White) }
            IconButton(onClick = { settingsOpen = !settingsOpen; tocOpen = false; searchOpen = false }) { Icon(Icons.Default.Settings, "Reader settings", tint = Color.White) }
            IconButton(onClick = { tocOpen = !tocOpen; settingsOpen = false; searchOpen = false }) { Icon(Icons.Default.MenuBook, "Contents", tint = Color.White) }
        }
        if (controlsVisible && settingsOpen) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).background(if(theme=="night") Color(0xFF202A2B) else Color(0xFF17353C)).padding(horizontal=14.dp, vertical=8.dp)) {
                Text("Display settings", color=Color.White, style=MaterialTheme.typography.titleSmall)
                Text("Font size: ${fontSize.toInt()} px", color=Color.White)
                Slider(value=fontSize, onValueChange={fontSize=it; prefs.edit().putFloat("font",it).apply(); webView?.evaluateJavascript("setFont(${it.toInt()})",null)}, valueRange=14f..32f)
                Text("Line spacing: ${String.format(Locale.US,"%.2f",lineSpacing)}",color=Color.White)
                Slider(value=lineSpacing,onValueChange={lineSpacing=it;prefs.edit().putFloat("line",it).apply();webView?.evaluateJavascript("setLine($it)",null)},valueRange=1.2f..2.4f)
                Text("Paragraph spacing: ${String.format(Locale.US,"%.1f",paraSpacing)} em",color=Color.White)
                Slider(value=paraSpacing,onValueChange={paraSpacing=it;prefs.edit().putFloat("para",it).apply();webView?.evaluateJavascript("setPara($it)",null)},valueRange=0f..2.5f)
                Text("Font spacing: ${String.format(Locale.US,"%.1f",letterSpacing)} px",color=Color.White)
                Slider(value=letterSpacing,onValueChange={letterSpacing=it;prefs.edit().putFloat("letter",it).apply();webView?.evaluateJavascript("setLetter($it)",null)},valueRange=(-0.5f)..2f)
                Text("Font weight: $fontWeight",color=Color.White)
                Slider(value=fontWeight.toFloat(),onValueChange={fontWeight=it.toInt();prefs.edit().putInt("weight",fontWeight).apply();webView?.evaluateJavascript("setWeight($fontWeight)",null)},valueRange=300f..900f,steps=5)
                Text("Font family",color=Color.White)
                var familyMenu by remember { mutableStateOf(false) }
                Box { TextButton(onClick={familyMenu=true}) { Text(fontFamily,color=Color.White) }; DropdownMenu(expanded=familyMenu,onDismissRequest={familyMenu=false}) { listOf("Georgia,serif","Noto Serif,serif","Noto Sans,Arial,sans-serif","Roboto,Arial,sans-serif","Arial,sans-serif","Verdana,sans-serif","Times New Roman,serif","monospace").forEach { family -> DropdownMenuItem(text={Text(family)},onClick={fontFamily=family;prefs.edit().putString("family",family).apply();webView?.evaluateJavascript("setFamily(${JSONObject.quote(family)})",null);familyMenu=false}) } } }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("light","sepia","night").forEach { t -> TextButton(onClick={theme=t;prefs.edit().putString("theme",t).apply();webView?.evaluateJavascript("setTheme('$t')",null)}) { Text(t.replaceFirstChar { it.uppercase() }, color=Color.White) } } }
            }
        }
        if (controlsVisible && tocOpen) {
            Column(Modifier.fillMaxWidth().heightIn(max=240.dp).background(if(theme=="night") Color(0xFF202A2B) else Color(0xFF17353C)).verticalScroll(rememberScrollState()).padding(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                    TextButton(onClick={webView?.evaluateJavascript("chapterPrev()",null)}) { Text("Previous chapter",color=Color.White) }
                    TextButton(onClick={webView?.evaluateJavascript("chapterNext()",null)}) { Text("Next chapter",color=Color.White) }
                }
                chapters.forEachIndexed { i, title -> TextButton(onClick={chapter=i;page=0;prefs.edit().putInt("chapter",i).putInt("page",0).apply();webView?.evaluateJavascript("loadChapter($i,0)",null);tocOpen=false}, modifier=Modifier.fillMaxWidth()) { Text("${i+1}. $title", color=Color.White) } }
            }
        }
        if (controlsVisible && searchOpen) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(value=searchText,onValueChange={searchText=it},modifier=Modifier.weight(1f),singleLine=true,placeholder={Text("Search in this book")})
                Button(onClick={ performBookSearch(searchText) }) { Text("Find") }
            }
            if (searchResults.isEmpty() && searchHistory.isNotEmpty()) {
                Column(Modifier.fillMaxWidth().heightIn(max=110.dp).verticalScroll(rememberScrollState()).padding(horizontal=8.dp)) {
                    searchHistory.forEach { oldQuery -> TextButton(onClick={searchText=oldQuery;performBookSearch(oldQuery)}, modifier=Modifier.fillMaxWidth()) { Text(oldQuery, color=if(theme=="night") Color.White else Color.DarkGray) } }
                }
            }
            Column(Modifier.fillMaxWidth().heightIn(max=180.dp).verticalScroll(rememberScrollState())) {
                searchResults.forEach { item -> TextButton(onClick={val idx=item.optInt("chapter");chapter=idx;page=0;webView?.evaluateJavascript("loadChapter($idx,0,${JSONObject.quote(searchText)})",null);searchOpen=false},modifier=Modifier.fillMaxWidth()) { Text("${item.optString("title")}\n${item.optString("snippet")}", color=if(theme=="night")Color.White else Color.DarkGray) } }
            }
        }
        AndroidView(modifier=Modifier.weight(1f).fillMaxWidth(), factory={ ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled=true
                settings.domStorageEnabled=true
                settings.allowFileAccess=false
                settings.allowContentAccess=false
                isVerticalScrollBarEnabled=false
                isHorizontalScrollBarEnabled=false
                webChromeClient=WebChromeClient()
                val native=bridge ?: NativeReaderBridge(file,prefs, { names -> Handler(Looper.getMainLooper()).post { chapters=names } }, { c, p -> Handler(Looper.getMainLooper()).post { chapter=c; page=p } }, { visible -> Handler(Looper.getMainLooper()).post { controlsVisible=visible; if (!visible) { settingsOpen=false; tocOpen=false; searchOpen=false } } })
                bridge=native
                addJavascriptInterface(native,"NativeReader")
                webView=this
                webViewClient=object:WebViewClient(){ override fun onPageFinished(view:WebView,url:String?){ if(!loaded){ loaded=true; view.evaluateJavascript("boot(${initialChapter},${initialPage},${fontSize},${lineSpacing},'${theme}',${paraSpacing},${letterSpacing},${fontWeight},${JSONObject.quote(fontFamily)})",null) } } }
                loadDataWithBaseURL("https://reader.local/", readerHtml, "text/html", "UTF-8", null)
            }
        }, update={ webView=it })
        if (controlsVisible) Row(Modifier.fillMaxWidth().background(if(theme=="night") Color(0xFF202A2B) else Color(0xFF17353C)).padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
            IconButton(onClick={webView?.evaluateJavascript("pagePrev()",null)}) { Icon(Icons.Default.NavigateBefore,"Previous page",tint=Color.White) }
            Column(Modifier.weight(1f), horizontalAlignment=androidx.compose.ui.Alignment.CenterHorizontally) {
                Text("Chapter ${chapter+1}",color=Color.White,style=MaterialTheme.typography.labelSmall)
                Text("Page ${page+1}",color=Color.White,style=MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick={webView?.evaluateJavascript("pageNext()",null)}) { Icon(Icons.Default.NavigateNext,"Next page",tint=Color.White) }
        }
    }
}


private class NativeReaderBridge(
    private val file: File,
    private val prefs: android.content.SharedPreferences,
    private val onChapters: (List<String>) -> Unit,
    private val onProgress: (Int, Int) -> Unit,
    private val onControls: (Boolean) -> Unit
) {
    private var data: ReaderBookData? = null
    private fun book(): ReaderBookData {
        data?.let { return it }
        val parsed = parseReaderBook(file)
        data = parsed
        onChapters(parsed.chapters.map { it.title })
        return parsed
    }
    @JavascriptInterface fun chapterNames(): String = JSONArray(book().chapters.map { it.title }).toString()
    @JavascriptInterface fun toggleControls() { onControls(!prefs.getBoolean("controls_visible", true)); prefs.edit().putBoolean("controls_visible", !prefs.getBoolean("controls_visible", true)).apply() }
    @JavascriptInterface fun chapterCount(): Int = book().chapters.size
    @JavascriptInterface fun getChapter(index: Int): String {
        val b = book()
        if (b.chapters.isEmpty()) return JSONObject().put("index", 0).put("title", "").put("content", "<p>No readable chapters found.</p>").toString()
        val safe = index.coerceIn(0, b.chapters.lastIndex)
        val c = b.chapters[safe]
        return JSONObject().put("index", safe).put("title", c.title).put("content", chapterHtml(file, c.zipPath)).put("href", c.href).toString()
    }
    @JavascriptInterface fun saveProgress(chapter: Int, page: Int) {
        prefs.edit().putInt("chapter", chapter).putInt("page", page).apply()
        onProgress(chapter, page)
    }
    @JavascriptInterface fun chapterForLink(href: String): Int {
        val b = book()
        val currentHref = b.chapters.getOrNull(prefs.getInt("chapter", 0))?.zipPath ?: ""
        val target = resolveRelative(currentHref, href.substringBefore('#'))
        return b.chapters.indexOfFirst { it.zipPath == target }.coerceAtLeast(-1)
    }
    @JavascriptInterface fun search(query: String): String {
        val q = query.trim()
        if (q.isBlank()) return "[]"
        val b = book()
        val out = JSONArray()
        ZipFile(file).use { zip ->
            b.chapters.forEachIndexed { idx, c ->
                val raw = zip.getEntry(c.zipPath)?.let { entry -> zip.getInputStream(entry).use { stream -> stream.readBytes().toString(Charsets.UTF_8) } }.orEmpty()
                val text = raw.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
                    .replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ")
                var at = 0
                var count = 0
                while (count < 5) {
                    at = text.indexOf(q, at, ignoreCase = true)
                    if (at < 0) break
                    val start = (at - 90).coerceAtLeast(0)
                    val end = (at + q.length + 110).coerceAtMost(text.length)
                    out.put(JSONObject().put("chapter", idx).put("title", c.title).put("snippet", text.substring(start, end)).put("offset", at))
                    at += q.length.coerceAtLeast(1)
                    count++
                }
            }
        }
        return out.toString()
    }
}

private fun parseReaderBook(file: File): ReaderBookData = ZipFile(file).use { zip ->
    val container = zip.getEntry("META-INF/container.xml")?.let { entry -> zip.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) } } ?: error("EPUB container not found")
    val opf = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(container)?.groupValues?.get(1) ?: error("OPF path missing")
    val opfText = zip.getEntry(opf)?.let { entry -> zip.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) } } ?: error("OPF not found")
    val items = Regex("<item\\b([^>]*?)/?>", RegexOption.IGNORE_CASE).findAll(opfText).map { match ->
        val attrs = match.groupValues[1]
        Regex("([\\w:-]+)\\s*=\\s*['\"]([^'\"]*)['\"]").findAll(attrs).associate { it.groupValues[1] to it.groupValues[2] }
    }.toList()
    val byId = items.associateBy { it["id"].orEmpty() }
    val spineIds = Regex("<itemref\\b([^>]*?)/?>", RegexOption.IGNORE_CASE).findAll(opfText).mapNotNull { match ->
        Regex("idref\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(match.groupValues[1])?.groupValues?.get(1)
    }.toList()
    val chapters = spineIds.mapNotNull { id ->
        val item = byId[id] ?: return@mapNotNull null
        val href = item["href"] ?: return@mapNotNull null
        val media = item["media-type"].orEmpty().lowercase()
        if (media !in setOf("application/xhtml+xml", "text/html", "application/xml", "text/xml") && !href.lowercase().endsWith(".xhtml") && !href.lowercase().endsWith(".html") && !href.lowercase().endsWith(".htm")) return@mapNotNull null
        val path = resolveRelative(opf, href)
        val entry = zip.getEntry(path) ?: return@mapNotNull null
        val raw = zip.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
        val chapterTitle = Regex("(?is)<h[1-3][^>]*>(.*?)</h[1-3]>").find(raw)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), " ")?.trim()?.takeIf { it.isNotBlank() }
            ?: href.substringAfterLast('/').substringBeforeLast('.')
        ReaderChapter(chapterTitle, href, path)
    }
    val title = Regex("(?is)<dc:title[^>]*>(.*?)</dc:title>").find(opfText)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), "")?.trim()?.takeIf { it.isNotBlank() } ?: file.nameWithoutExtension
    ReaderBookData(title, chapters, opf)
}

private fun resolveRelative(base: String, href: String): String {
    return try {
        val baseUri = URI("https://epub.local/" + base.trimStart('/'))
        URLDecoder.decode(baseUri.resolve(URI(href)).path.trimStart('/'), "UTF-8").replace("\\", "/")
    } catch (_: Throwable) {
        (base.substringBeforeLast('/', "") + "/" + href).replace(Regex("(^|/)\\./"), "")
    }
}


private fun chapterHtml(file:File,path:String):String=ZipFile(file).use{zip->
    val raw=zip.getEntry(path)?.let{zip.getInputStream(it).use{it.readBytes().toString(Charsets.UTF_8)}}?:return@use "<p>Chapter unavailable.</p>"
    val body=Regex("(?is)<body\\b[^>]*>(.*?)</body>").find(raw)?.groupValues?.get(1) ?: raw
    val cleanBody=body.replace(Regex("(?is)<script\\b[^>]*>.*?</script>|<iframe\\b[^>]*>.*?</iframe>"),"").replace(Regex("(?i)\\s+on\\w+\\s*=\\s*'[^']*'"),"").replace(Regex("(?i)\\s+on\\w+\\s*=\\s*\\\"[^\\\"]*\\\""),"")
    val withImages=Regex("(?i)(src\\s*=\\s*['\"])([^'\"]+)(['\"])").replace(cleanBody){m-> val src=m.groupValues[2]; if(src.startsWith("data:")||src.startsWith("http:")||src.startsWith("https:"))m.value else { val asset=resolveRelative(path,src); val bytes=zip.getEntry(asset)?.let{zip.getInputStream(it).use{it.readBytes()}}; if(bytes==null)m.value else {val mime=when(asset.substringAfterLast('.',"").lowercase()){ "jpg","jpeg"->"image/jpeg";"png"->"image/png";"gif"->"image/gif";"webp"->"image/webp";"svg"->"image/svg+xml";else->"application/octet-stream"};m.groupValues[1]+"data:$mime;base64,"+Base64.getEncoder().encodeToString(bytes)+m.groupValues[3] } } }
    Regex("(?i)(href\\s*=\\s*['\"])([^'\"]+)(['\"])").replace(withImages){m->val href=m.groupValues[2];if(href.startsWith("#")||href.startsWith("http:")||href.startsWith("https:")||href.startsWith("mailto:"))m.value else m.groupValues[1]+"#rdlink=" + URLEncoder.encode(href,"UTF-8")+m.groupValues[3] }
}

private val readerHtml = """<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><style>
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden}#book{height:100%;width:100%;overflow-x:auto;overflow-y:hidden;column-width:calc(100vw - 38px);column-gap:24px;column-fill:auto;padding:22px 19px 92px;font:19px/1.65 Georgia,serif;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch}#book::-webkit-scrollbar{display:none}#book>*{break-inside:auto}p{margin:0 0 1em;text-indent:1.5em}h1,h2,h3,h4{break-after:avoid;line-height:1.25;margin:1em 0 .6em}img,svg,table{max-width:100%}img{max-height:45vh;object-fit:contain;break-inside:avoid}a{color:inherit}body.light{background:#f7f2e8;color:#28251f}body.sepia{background:#f0e4c9;color:#453728}body.night{background:#101719;color:#e5e8e8}#book mark{background:#ffe36b;color:#231c05}
</style></head><body class="light"><article id="book"></article><script>
let chapterTitles=[],cur=0,pg=0,font=19,line=1.65,para=1,query='';const book=document.getElementById('book');function pages(){return Math.max(1,Math.round(book.scrollWidth/Math.max(1,book.clientWidth)))}function save(){pg=Math.max(0,Math.round(book.scrollLeft/book.clientWidth));NativeReader.saveProgress(cur,pg)}function setFont(v){font=v;book.style.fontSize=v+'px'}function setLine(v){line=v;book.style.lineHeight=v}function setPara(v){para=v;book.querySelectorAll('p').forEach(p=>p.style.marginBottom=v+'em')}function setLetter(v){book.style.letterSpacing=v+'px'}function setWeight(v){book.style.fontWeight=v}function setFamily(v){book.style.fontFamily=v}function setTheme(t){document.body.className=t}function loadChapter(i,p=0,q=''){cur=Math.max(0,Math.min(i,chapterTitles.length-1));let d=JSON.parse(NativeReader.getChapter(cur));book.innerHTML=d.content;setPara(para);query=q||'';if(query)highlight(query);book.scrollLeft=0;requestAnimationFrame(()=>{pg=Math.min(p,pages()-1);book.scrollLeft=pg*book.clientWidth;save()});}function boot(i,p,f,l,t,ps,ls,w,fam){try{chapterTitles=JSON.parse(NativeReader.chapterNames());setFont(f);setLine(l);setPara(ps);setLetter(ls);setWeight(w);setFamily(fam);setTheme(t);loadChapter(i,p)}catch(e){book.innerHTML='<p>Could not open this EPUB: '+String(e).replace(/[&<>]/g,'')+'</p>'}}function chapterPrev(){if(cur>0)loadChapter(cur-1,999999,query)}function chapterNext(){if(cur<chapterTitles.length-1)loadChapter(cur+1,0,query)}function pageNext(){if(book.scrollLeft+book.clientWidth>=book.scrollWidth-4){if(cur<chapterTitles.length-1)loadChapter(cur+1,0,query);return}book.scrollLeft=Math.min(book.scrollWidth-book.clientWidth,book.scrollLeft+book.clientWidth);save()}function pagePrev(){if(book.scrollLeft<=4){if(cur>0)loadChapter(cur-1,999999,query);return}book.scrollLeft=Math.max(0,book.scrollLeft-book.clientWidth);save()}function highlight(q){if(!q)return;let walker=document.createTreeWalker(book,NodeFilter.SHOW_TEXT),nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(n=>{let text=n.nodeValue,idx=text.toLowerCase().indexOf(q.toLowerCase());if(idx>=0){let span=document.createElement('span');span.appendChild(document.createTextNode(text.slice(0,idx)));let mark=document.createElement('mark');mark.textContent=text.slice(idx,idx+q.length);span.appendChild(mark);span.appendChild(document.createTextNode(text.slice(idx+q.length)));n.parentNode.replaceChild(span,n)}})}book.addEventListener('scroll',save);book.addEventListener('click',e=>{let a=e.target.closest('a');if(!a){NativeReader.toggleControls();return;}let h=a.getAttribute('href')||a.getAttribute('data-rd-href');if(h&&h.startsWith('#rdlink=')){e.preventDefault();let link=decodeURIComponent(h.slice(8).replace(/\+/g,' '));let idx=NativeReader.chapterForLink(link);let f=link.split('#')[1];if(idx>=0){loadChapter(idx,0);if(f)setTimeout(()=>{let el=document.getElementById(f);if(el)book.scrollLeft=el.offsetLeft},100)}else{if(f)setTimeout(()=>{let el=document.getElementById(f);if(el)book.scrollLeft=el.offsetLeft},100)}}else if(h&&h.startsWith('#')){e.preventDefault();let target=document.getElementById(h.slice(1));if(target)book.scrollLeft=target.offsetLeft}});let sx=0;book.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});book.addEventListener('touchend',e=>{let dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>60){dx<0?pageNext():pagePrev()}},{passive:true});</script></body></html>"""
