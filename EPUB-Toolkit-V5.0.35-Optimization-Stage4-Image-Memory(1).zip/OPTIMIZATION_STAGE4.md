# EPUB Toolkit V5.0.35 — Optimization Stage 4


Base: Optimization Stage 3 (version 0.21.15).

## Change
- Hardened reader image decoding: invalid image dimensions are rejected before decode.
- Decode exceptions are contained and return null instead of propagating into the reader UI.
- Kept the existing bounded power-of-two sampling target (longest side ~1400 px) and original bitmap configuration to preserve transparency and image quality characteristics.

## Not changed
- Image extraction/cache paths, reader pagination/layout, reading position restore, chapter navigation, search, controls, library scanning, ZIP extraction, package ID, permissions, and signing configuration.

## Verification
- Source-level review and ZIP integrity check performed.
- Android Gradle build and runtime memory profiling were not available in this environment; no build or measured memory-reduction claim is made.
