package com.rdust.epubtoolkit

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import kotlin.math.floor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.rdust.epubtoolkit.data.BookLibrary
import com.rdust.epubtoolkit.data.EpubBook
import com.rdust.epubtoolkit.reader.ReaderBook
import com.rdust.epubtoolkit.reader.EpubSearchResult
import com.rdust.epubtoolkit.reader.ReaderChapter
import com.rdust.epubtoolkit.reader.EpubReaderEngine
import com.rdust.epubtoolkit.tools.EpubToolsEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.yield
import java.io.File

private val AppBg = Color(0xFF101719)
private val Panel = Color(0xFF1A343A)
private val Panel2 = Color(0xFF275E6B)
private val Accent = Color(0xFF21B6A6)
private val TextMain = Color(0xFFF2F5F5)
private val TextMuted = Color(0xFFA9BDC1)

/** A small, memory-bounded cache for sampled library cover thumbnails. */
private object CoverImageCache {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024L / 12L).toInt().coerceAtLeast(1024)
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    fun clear() { cache.evictAll() }

    fun load(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
        val bitmap = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply {
            inSampleSize = sample
        }) ?: return null
        cache.put(path, bitmap)
        return bitmap
    }
}

private data class ReaderSettings(
    val fontSize: Float = 19f,
    val lineSpacing: Float = 1.65f,
    val paragraphSpacing: Float = 1.0f,
    val letterSpacing: Float = 0f,
    val fontFamily: String = "Georgia / Serif",
    val fontWeight: Int = 400,
    val theme: String = "Sepia",
    val horizontalPadding: Float = 20f,
    val verticalPadding: Float = 8f
)

private val readerFontChoices = listOf(
    "Georgia / Serif", "Noto Serif", "Noto Sans", "Roboto",
    "Arial", "Verdana", "Times New Roman", "Monospace"
)

private fun readerFontFamily(name: String): FontFamily = when (name) {
    "Noto Sans", "Roboto", "Arial", "Verdana" -> FontFamily.SansSerif
    "Monospace" -> FontFamily.Monospace
    else -> FontFamily.Serif
}

class MainActivity : ComponentActivity() {
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Cover thumbnails are disposable; release them when Android signals memory pressure
        // or when the app UI is no longer visible. They are decoded again on demand.
        if (level >= TRIM_MEMORY_UI_HIDDEN) CoverImageCache.clear()
    }

    private fun hasStorageAccess(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStorageAccess() {
        if (hasStorageAccess()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            }
            try { startActivity(intent) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(arrayOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ), 4102)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 33, 38)
        window.navigationBarColor = android.graphics.Color.rgb(7, 26, 30)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, onPrimary = Color.Black, background = AppBg,
                surface = Panel, onSurface = TextMain, secondary = Accent
            )) {
                ToolkitApp()
            }
        }
    }

    @Composable
    private fun ToolkitApp() {
        var books by remember { mutableStateOf<List<EpubBook>>(emptyList()) }
        var isLoading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf("") }
        var tab by remember { mutableStateOf("Read Book") }
        var selectedBook by remember { mutableStateOf<EpubBook?>(null) }
        var reader by remember { mutableStateOf<ReaderBook?>(null) }
        var loadedChapter by remember { mutableStateOf<ReaderChapter?>(null) }
        var chapterIndex by remember { mutableIntStateOf(0) }
        var restoredPage by remember { mutableIntStateOf(0) }
        var searchText by remember { mutableStateOf("") }
        var searchResults by remember { mutableStateOf<List<EpubSearchResult>>(emptyList()) }
        var selectedSearchResultIndex by remember { mutableIntStateOf(-1) }
        var selectedSearchOccurrence by remember { mutableIntStateOf(1) }
        var pageHighlightQuery by remember { mutableStateOf("") }
        var searchMode by remember { mutableStateOf(false) }
        var sort by remember { mutableStateOf("Name A-Z") }
        var folderFilter by remember { mutableStateOf("All folders") }
        var showSearch by remember { mutableStateOf(false) }
        var isSearching by remember { mutableStateOf(false) }
        val searchScope = rememberCoroutineScope()
        var showSearchResults by remember { mutableStateOf(false) }
        var showChapters by remember { mutableStateOf(false) }
        var selectionMode by remember { mutableStateOf(false) }
        var selectedUris by remember { mutableStateOf(setOf<String>()) }
        val context = LocalContext.current
        val settingsStore = remember { context.getSharedPreferences("v4_reader_settings", android.content.Context.MODE_PRIVATE) }
        var readerSettings by remember {
            mutableStateOf(ReaderSettings(
                fontSize = settingsStore.getFloat("fontSize", 19f),
                lineSpacing = settingsStore.getFloat("lineSpacing", 1.65f),
                paragraphSpacing = settingsStore.getFloat("paragraphSpacing", 1.0f),
                letterSpacing = settingsStore.getFloat("letterSpacing", 0f),
                fontFamily = settingsStore.getString("fontFamily", "Georgia / Serif") ?: "Georgia / Serif",
                fontWeight = settingsStore.getInt("fontWeight", 400),
                theme = settingsStore.getString("theme", "Sepia") ?: "Sepia",
                horizontalPadding = settingsStore.getFloat("horizontalPadding", 20f),
                verticalPadding = settingsStore.getFloat("verticalPadding", 8f)
            ))
        }
        fun updateReaderSettings(updated: ReaderSettings) {
            readerSettings = updated
            settingsStore.edit()
                .putFloat("fontSize", updated.fontSize)
                .putFloat("lineSpacing", updated.lineSpacing)
                .putFloat("paragraphSpacing", updated.paragraphSpacing)
                .putFloat("letterSpacing", updated.letterSpacing)
                .putString("fontFamily", updated.fontFamily)
                .putInt("fontWeight", updated.fontWeight)
                .putString("theme", updated.theme)
                .putFloat("horizontalPadding", updated.horizontalPadding)
                .putFloat("verticalPadding", updated.verticalPadding)
                .apply()
        }

        var libraryScanJob by remember { mutableStateOf<Job?>(null) }
        fun refresh() {
            if (!hasStorageAccess()) {
                books = emptyList()
                error = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    "Allow All files access to scan your EPUB library."
                else "Allow storage permission to scan your EPUB library."
                return
            }
            // Prevent simultaneous recursive storage scans triggered by resume and manual refresh.
            if (libraryScanJob?.isActive == true) return
            isLoading = true; error = ""
            libraryScanJob = lifecycleScope.launch {
                try { books = withContext(Dispatchers.IO) { BookLibrary.scan(this@MainActivity) } }
                catch (e: Exception) { error = e.message ?: "Unable to scan library" }
                finally { isLoading = false; libraryScanJob = null }
            }
        }
        val openEpub = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                val doc = DocumentFile.fromSingleUri(this@MainActivity, uri)
                val pickedName = doc?.name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "book.epub"
                val item = EpubBook(uri, pickedName, pickedName.removeSuffix(".epub"), "", "")
                selectedBook = item
                isLoading = true
                lifecycleScope.launch {
                    try {
                        reader = withContext(Dispatchers.IO) { EpubReaderEngine.open(contentResolver, uri, item.displayName) }
                        val positionPrefs = getSharedPreferences("v5_reader_positions", android.content.Context.MODE_PRIVATE)
                        chapterIndex = positionPrefs.getInt("chapter:${uri}", 0).coerceAtLeast(0)
                        restoredPage = positionPrefs.getInt("page:${uri}", 0).coerceAtLeast(0)
                        tab = "Reader"
                    } catch (e: Exception) { error = e.message ?: "Unable to open EPUB" }
                    isLoading = false
                }
            }
        }

        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME && hasStorageAccess()) refresh()
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        LaunchedEffect(Unit) {
            // Initial library refresh is handled by the lifecycle ON_RESUME observer.
            // Avoid running the recursive storage scan twice during app startup.
            if (!hasStorageAccess()) requestStorageAccess()
            val incoming = intent?.data
            if (incoming != null && (intent?.action == Intent.ACTION_VIEW)) {
                val name = DocumentFile.fromSingleUri(this@MainActivity, incoming)?.name ?: incoming.lastPathSegment?.substringAfterLast('/') ?: "book.epub"
                selectedBook = EpubBook(incoming, name, name.removeSuffix(".epub"), "", "")
                isLoading = true
                try {
                    reader = withContext(Dispatchers.IO) { EpubReaderEngine.open(contentResolver, incoming, name) }
                    tab = "Reader"
                } catch (e: Exception) { error = e.message ?: "Unable to open EPUB" }
                isLoading = false
            }
        }

        val activeReader = reader
        fun performBookSearch() {
            val bookSnapshot = activeReader ?: return
            val querySnapshot = searchText.trim()
            if (isSearching || querySnapshot.isBlank()) return
            isSearching = true
            searchScope.launch {
                try {
                    val results = withContext(Dispatchers.Default) { EpubReaderEngine.search(bookSnapshot, querySnapshot) }
                    searchResults = results
                    selectedSearchResultIndex = -1
                    selectedSearchOccurrence = 1
                    searchMode = true
                    showSearch = false
                    showSearchResults = true
                } catch (e: Exception) {
                    error = e.message ?: "Book search failed"
                } finally {
                    isSearching = false
                }
            }
        }
        LaunchedEffect(activeReader?.archivePath, chapterIndex) {
            val snapshot = activeReader
            if (snapshot == null || chapterIndex !in snapshot.chapters.indices) {
                loadedChapter = null
            } else {
                loadedChapter = null
                loadedChapter = runCatching {
                    withContext(Dispatchers.IO) { EpubReaderEngine.loadChapter(snapshot, chapterIndex) }
                }.getOrElse {
                    error = it.message ?: "Unable to load chapter"
                    null
                }
            }
        }

        // Back from the Toolkit tab returns to the Library tab instead of
        // finishing the Activity. This keeps Toolkit navigation inside the app.
        BackHandler(enabled = tab == "Tool") {
            tab = "Read Book"
        }


        // Keep the activity alive when the user presses the device Back button
        // while reading. Dialogs retain priority and dismiss themselves first.
        BackHandler(enabled = tab == "Reader" && !showSearch && !showSearchResults && !showChapters) {
            if (searchMode) {
                // First Back exits in-book search mode, clears the page highlight,
                // and keeps the reader open. A second Back returns to the Library.
                searchMode = false
                pageHighlightQuery = ""
                searchText = ""
                searchResults = emptyList()
                selectedSearchResultIndex = -1
            } else {
                EpubReaderEngine.close(activeReader)
                reader = null
                loadedChapter = null
                tab = "Read Book"
                refresh()
            }
        }

        Box(Modifier.fillMaxSize().background(AppBg)) {
            Column(Modifier.fillMaxSize()) {
                if (tab == "Reader" && activeReader != null) {
                    ReaderScreen(
                        book = activeReader, index = chapterIndex, initialPage = restoredPage,
                        positionKey = selectedBook?.uri?.toString() ?: activeReader.archivePath,
                        chapterData = loadedChapter?.takeIf { it.href == activeReader.chapters.getOrNull(chapterIndex)?.href },
                        settings = readerSettings,
                        searchText = searchText, searchResults = searchResults, highlightQuery = pageHighlightQuery, highlightOccurrence = selectedSearchOccurrence,
                        onBack = {
                            EpubReaderEngine.close(activeReader)
                            reader = null
                            loadedChapter = null
                            tab = "Read Book"
                            refresh()
                        },
                        onPrevious = { if (chapterIndex > 0) chapterIndex-- },
                        onNext = { if (chapterIndex < activeReader.chapters.lastIndex) chapterIndex++ },
                        onSearch = {
                            if (searchMode) showSearchResults = true
                            else showSearch = true
                        },
                        onChapters = { showChapters = true },
                        onSettingsChange = { updateReaderSettings(it) },
                        onSelectSearchResult = { chapterNo, occurrence -> chapterIndex = chapterNo; selectedSearchOccurrence = occurrence; pageHighlightQuery = searchText.trim() },
                        onProgress = { value -> selectedBook?.let { BookLibrary.saveProgress(this@MainActivity, it.uri, value) } }
                    )
                } else {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                        "Read Book" -> LibraryScreen(
                            books = books, loading = isLoading, error = error,
                            sort = sort, folder = folderFilter,
                            onSort = { sort = it }, onFolder = { folderFilter = it },
                            selectionMode = selectionMode, selectedUris = selectedUris,
                            onToggleSelection = { book ->
                                selectedUris = if (book.uri.toString() in selectedUris) selectedUris - book.uri.toString() else selectedUris + book.uri.toString()
                                selectionMode = selectedUris.isNotEmpty()
                            },
                            onDeleteSelected = {
                                val targets = books.filter { it.uri.toString() in selectedUris }
                                lifecycleScope.launch(Dispatchers.IO) { targets.forEach { BookLibrary.delete(this@MainActivity, it.uri) }; withContext(Dispatchers.Main) { selectedUris = emptySet(); selectionMode = false; refresh() } }
                            },
                            onChooseFolder = { requestStorageAccess(); if (hasStorageAccess()) refresh() },
                            onRefresh = { refresh() }, onOpen = { book ->
                                selectedBook = book; BookLibrary.markOpened(this@MainActivity, book.uri); isLoading = true
                                lifecycleScope.launch {
                                    try {
                                        val loadedBook = withContext(Dispatchers.IO) { EpubReaderEngine.open(contentResolver, book.uri, book.displayName) }
                                        reader = loadedBook
                                        val positionPrefs = getSharedPreferences("v5_reader_positions", android.content.Context.MODE_PRIVATE)
                                        val savedChapter = positionPrefs.getInt("chapter:${book.uri}", -1)
                                        if (savedChapter >= 0) {
                                            chapterIndex = savedChapter.coerceIn(0, loadedBook.chapters.lastIndex)
                                            restoredPage = positionPrefs.getInt("page:${book.uri}", 0).coerceAtLeast(0)
                                        } else {
                                            chapterIndex = if (book.progress > 0f) (book.progress / 100f * loadedBook.chapters.size).toInt().coerceIn(0, loadedBook.chapters.lastIndex) else 0
                                            restoredPage = 0
                                        }
                                        tab = "Reader"
                                    } catch (e: Exception) { error = e.message ?: "Unable to open EPUB" }
                                    isLoading = false
                                }
                            }, onOpenFile = { openEpub.launch(arrayOf("application/epub+zip", "application/octet-stream")) }
                        )
                        else -> ToolsLanding(books = books, onRefresh = { refresh() })
                        }
                    }
                    NavigationBar(containerColor = Color(0xFF050505), contentColor = TextMain) {
                        NavigationBarItem(selected = tab == "Read Book", onClick = { tab = "Read Book" }, icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("Read Book") })
                        NavigationBarItem(selected = tab == "Tool", onClick = { tab = "Tool" }, icon = { Icon(Icons.Default.Build, null) }, label = { Text("Tool") })
                    }
                }
            }
            if (isLoading) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Accent)
        }

        if (showSearch && activeReader != null) {
            AlertDialog(onDismissRequest = { showSearch = false }, containerColor = Panel,
                title = { Text("Search in book", color = TextMain) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            label = { Text("Search text") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { performBookSearch() })
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Search finds every occurrence in the book (up to 1,000 results).", color = TextMuted, fontSize = 12.sp)
                    }
                }, confirmButton = { TextButton(
                    enabled = !isSearching && searchText.isNotBlank(),
                    onClick = { performBookSearch() }
                ) { Text(if (isSearching) "Searching…" else "Search") } }, dismissButton = { TextButton(enabled = !isSearching, onClick = { showSearch = false }) { Text("Cancel") } })
        }
        if (showSearchResults && activeReader != null) {
            AlertDialog(onDismissRequest = { showSearchResults = false }, containerColor = Panel,
                title = { Text("Search results (${searchResults.size})", color = TextMain) },
                text = {
                    val resultListState = rememberLazyListState(
                        initialFirstVisibleItemIndex = if (selectedSearchResultIndex >= 0) selectedSearchResultIndex else 0
                    )
                    LazyColumn(Modifier.heightIn(max = 420.dp), state = resultListState) {
                        if (searchResults.isEmpty()) item { Text("No matches found.", color = TextMuted) }
                        itemsIndexed(searchResults) { resultIndex, result ->
                            val chapterNo = result.chapterIndex
                            val snippet = result.snippet
                            val isLastOpened = resultIndex == selectedSearchResultIndex
                            Column(
                                Modifier.fillMaxWidth()
                                    .background(if (isLastOpened) Panel2.copy(alpha = 0.45f) else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedSearchResultIndex = resultIndex
                                        selectedSearchOccurrence = result.occurrenceInChapter
                                        searchMode = true
                                        pageHighlightQuery = searchText.trim()
                                        chapterIndex = chapterNo
                                        showSearchResults = false
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "${activeReader.chapters[chapterNo].title} · Match ${result.occurrenceInChapter}",
                                    color = if (isLastOpened) Accent else TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                                Text(
                                    highlightSearchSnippet(snippet, searchText),
                                    color = TextMain,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    lineHeight = 15.sp
                                )
                            }
                            Divider(color = Panel2.copy(alpha = 0.55f), thickness = 0.5.dp)
                        }
                    }
                }, confirmButton = { TextButton(onClick = { showSearchResults = false }) { Text("Close") } })
        }
        if (showChapters && activeReader != null) {
            AlertDialog(onDismissRequest = { showChapters = false }, containerColor = Panel,
                title = { Text("Chapters", color = TextMain) },
                text = { LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(activeReader.chapters.indices.toList()) { i ->
                        Text("${i + 1}. ${activeReader.chapters[i].title}", Modifier.fillMaxWidth().clickable { chapterIndex = i; showChapters = false }.padding(10.dp), color = if (i == chapterIndex) Accent else TextMain)
                    }
                } }, confirmButton = { TextButton(onClick = { showChapters = false }) { Text("Close") } })
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryScreen(
    books: List<EpubBook>, loading: Boolean, error: String, sort: String, folder: String,
    onSort: (String) -> Unit, onFolder: (String) -> Unit, onChooseFolder: () -> Unit,
    selectionMode: Boolean, selectedUris: Set<String>, onToggleSelection: (EpubBook) -> Unit,
    onDeleteSelected: () -> Unit,
    onRefresh: () -> Unit, onOpen: (EpubBook) -> Unit, onOpenFile: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var sortExpanded by remember { mutableStateOf(false) }
    var folderExpanded by remember { mutableStateOf(false) }
    val folders = listOf("All folders") + books.map { it.folder.ifBlank { "Internal storage" } }.distinct().sorted()
    val shown = books.filter { it.title.contains(query, true) || it.author.contains(query, true) }
        .filter { folder == "All folders" || it.folder.ifBlank { "Internal storage" } == folder }
        .let { list -> when (sort) { "Recently opened" -> list.sortedByDescending { it.lastOpenedAt }; "Date added" -> list.sortedByDescending { it.addedAt }; else -> list.sortedBy { it.title.lowercase() } } }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (selectionMode) "${selectedUris.size} selected" else "My Library", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (selectionMode) IconButton(onClick = onDeleteSelected) { Icon(Icons.Default.Delete, "Delete selected", tint = Color(0xFFFF8A80)) }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = Accent) }
            Box {
                TextButton(onClick = { folderExpanded = true }, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(0.dp)) {
                    Text(folder, maxLines = 1, fontSize = 12.sp); Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = folderExpanded, onDismissRequest = { folderExpanded = false }) {
                    folders.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onFolder(it); folderExpanded = false }) }
                    DropdownMenuItem(text = { Text("Choose folder…") }, onClick = { folderExpanded = false; onChooseFolder() })
                }
            }
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Search books…", color = TextMuted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = TextMuted) })
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9B8F), fontSize = 12.sp, modifier = Modifier.padding(6.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${shown.size} books", color = TextMuted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Box {
                TextButton(onClick = { sortExpanded = true }, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(0.dp)) {
                    Text(sort, maxLines = 1, fontSize = 12.sp); Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                    listOf("Name A-Z", "Date added", "Recently opened").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onSort(it); sortExpanded = false }) }
                }
            }
        }
        if (books.isEmpty()) {
            Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.MenuBook, null, tint = Accent, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp))
                Text("No EPUB books found", color = TextMain, fontWeight = FontWeight.SemiBold)
                Text("Grant storage access to scan your EPUB library, or open a book directly.", color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onChooseFolder) { Text("Grant Storage Access") }
            }
        } else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(shown, key = { it.uri.toString() }) { book ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).combinedClickable(
                    onClick = { if (selectionMode) onToggleSelection(book) else onOpen(book) },
                    onLongClick = { onToggleSelection(book) }
                ).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    val coverBitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, book.coverPath) {
                        val path = book.coverPath
                        value = if (path.isNullOrBlank()) null else withContext(Dispatchers.IO) {
                            runCatching { CoverImageCache.load(path)?.asImageBitmap() }.getOrNull()
                        }
                    }
                    val displayedCover = coverBitmap
                    Box(Modifier.size(width = 58.dp, height = 76.dp).background(Panel2, RoundedCornerShape(5.dp)), contentAlignment = Alignment.Center) {
                        if (displayedCover != null) Image(displayedCover, contentDescription = "${book.title} cover", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Icon(Icons.Default.MenuBook, null, tint = Accent, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(book.title, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        if (book.author.isNotBlank()) Text(book.author, color = TextMuted, fontSize = 12.sp, maxLines = 1)
                        Text(book.folder.ifBlank { "Internal storage" }, color = TextMuted, fontSize = 11.sp, maxLines = 1)
                        if (book.progress > 0f) {
                            Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF496168), RoundedCornerShape(4.dp))) {
                                Box(Modifier.fillMaxWidth(book.progress / 100f).fillMaxHeight().background(Accent, RoundedCornerShape(4.dp)))
                            }
                        }
                    }
                    if (selectionMode) Checkbox(checked = book.uri.toString() in selectedUris, onCheckedChange = { onToggleSelection(book) })
                    else Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
            }
        }
    }
}

@Composable
private fun ToolsLanding(books: List<EpubBook>, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tools = EpubToolsEngine.singleTools
    var selectedTool by remember { mutableStateOf(tools.first()) }
    var selectedUri by remember { mutableStateOf(books.firstOrNull()?.uri?.path.orEmpty()) }
    var extraTargets by remember { mutableStateOf<List<File>>(emptyList()) }
    var selectedBatch by remember { mutableStateOf(setOf<String>()) }
    var batchMode by remember { mutableStateOf(false) }
    var folderFilter by remember { mutableStateOf("All folders") }
    var folderExpanded by remember { mutableStateOf(false) }
    var resultCards by remember { mutableStateOf<List<Pair<String, Boolean>>>(emptyList()) }
    var expanded by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var find by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf("") }
    var caseSensitive by remember { mutableStateOf(false) }
    var wholeWord by remember { mutableStateOf(false) }
    var regex by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("taiwanandnorthkorea") }
    var destination by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Pilih fitur dan file untuk memulai.") }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(books) {
        extraTargets = withContext(Dispatchers.IO) {
            val root = Environment.getExternalStorageDirectory()
            val found = mutableListOf<File>()
            fun walk(dir: File, depth: Int) {
                if (depth > 12 || !dir.canRead()) return
                dir.listFiles()?.forEach { f ->
                    if (f.isDirectory) { if (f.name !in setOf("Android", ".thumbnails") && !f.name.startsWith(".")) walk(f, depth + 1) }
                    else if (f.isFile && (f.extension.equals("zip", true) || f.extension.equals("txt", true))) found += f
                }
            }
            runCatching { walk(root, 0) }; found
        }
    }
    val allTargets = (books.mapNotNull { it.uri.path?.let(::File) } + extraTargets).distinctBy { it.absolutePath }
    val storageRoot = Environment.getExternalStorageDirectory().absolutePath.trimEnd('/')
    fun folderLabel(file: File): String {
        val parent = file.parentFile?.absolutePath.orEmpty()
        return if (parent == storageRoot) "Root" else parent.removePrefix(storageRoot + "/").ifBlank { parent }
    }
    val folderOptions = listOf("All folders") + allTargets.map(::folderLabel).distinct().sorted()
    val filteredTargets = allTargets.filter { folderFilter == "All folders" || folderLabel(it) == folderFilter }
    val selectedFile = filteredTargets.firstOrNull { it.absolutePath == selectedUri }
    val needsBulkText = selectedTool.startsWith("Bulk Find")
    val toolDescription = when (selectedTool) {
        "Rename File" -> "Mengganti nama EPUB berdasarkan metadata judul (dc:title)."
        "Remove Cover" -> "Menghapus gambar cover dan metadata cover dari EPUB."
        "Add Cover" -> "Membuat cover SVG dan halaman cover dari judul serta penulis metadata."
        "Remove All Images" -> "Menghapus aset gambar dan referensinya dari EPUB."
        "Add Paragraph" -> "Memisahkan paragraf panjang menjadi paragraf yang lebih terbaca, mengikuti aturan V4."
        "Remove Blank Spacing" -> "Menghapus paragraf kosong tanpa menghapus CSS jarak paragraf."
        "Compact Line Spacing" -> "Membersihkan jeda kosong dan menerapkan line-height 1.35 serta margin paragraf 0.4em."
        "Compress Image" -> "Mengoptimalkan JPEG/PNG/WebP yang didukung Android; gambar yang tidak bisa diproses dipertahankan."
        "Bulk Find & Replace" -> "Cari dan hitung atau ganti teks di EPUB/TXT dengan opsi case, whole word, dan regex."
        "Unzip File" -> "Ekstrak ZIP dengan dukungan password AES/ZipCrypto dan penamaan aman untuk file duplikat."
        else -> "Operasi file lokal secara offline."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Toolkit", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Native tools from V4", color = Accent, fontSize = 12.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh library", tint = Accent) }
        }
        Box(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
            OutlinedButton(onClick = { folderExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Folder: $folderFilter", modifier = Modifier.weight(1f), textAlign = TextAlign.Start, maxLines = 1)
                Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded = folderExpanded, onDismissRequest = { folderExpanded = false }) {
                folderOptions.forEach { folder -> DropdownMenuItem(text = { Text(folder) }, onClick = { folderFilter = folder; folderExpanded = false; selectedBatch = selectedBatch.filter { path -> allTargets.any { it.absolutePath == path && (folder == "All folders" || folderLabel(it) == folder) } }.toSet() }) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = !batchMode, onClick = { batchMode = false; if (selectedTool !in tools) selectedTool = tools.first() }, label = { Text("Single Feature") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = batchMode, onClick = { batchMode = true; if (selectedTool !in EpubToolsEngine.batchTools) selectedTool = EpubToolsEngine.batchTools.first() }, label = { Text("Batch Processing") })
        }
        if (!batchMode) {
            LazyVerticalGrid(GridCells.Fixed(2), Modifier.heightIn(max = 230.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                gridItems(tools, key = { it }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().height(48.dp).clickable { selectedTool = item; resultCards = emptyList(); status = "Pilih file lalu jalankan $item." },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = if (selectedTool == item) Panel2 else Panel)
                    ) {
                        Box(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 1.dp), contentAlignment = Alignment.Center) {
                            Text(item, color = TextMain, fontSize = 14.sp, fontWeight = if (selectedTool == item) FontWeight.SemiBold else FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        } else {
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedTool, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    EpubToolsEngine.batchTools.forEach { item ->
                        DropdownMenuItem(text = { Text(item) }, onClick = { selectedTool = item; expanded = false; resultCards = emptyList(); status = "Pilih file lalu jalankan $item." })
                    }
                }
            }
        }
        Text(toolDescription, color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(vertical = 4.dp))
        if (!batchMode) {
            Text("Pilih file", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            var fileExpanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { fileExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedFile?.name ?: "Select file", modifier = Modifier.weight(1f), maxLines = 1)
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = fileExpanded, onDismissRequest = { fileExpanded = false }) {
                    filteredTargets.filter { f -> when { selectedTool.contains("Unzip") -> f.extension.equals("zip", true); needsBulkText -> f.extension.equals("epub", true) || f.extension.equals("txt", true); else -> f.extension.equals("epub", true) } }.forEach { f -> DropdownMenuItem(text = { Text(f.name, maxLines = 1) }, onClick = { selectedUri = f.absolutePath; fileExpanded = false }) }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${selectedBatch.size} selected", color = TextMuted, modifier = Modifier.weight(1f))
                TextButton(onClick = { selectedBatch = filteredTargets.filter { f -> if (selectedTool.startsWith("Batch Unzip")) f.extension.equals("zip", true) else if (selectedTool.contains("Bulk")) f.extension.equals("epub", true) || f.extension.equals("txt", true) else f.extension.equals("epub", true) }.map { it.absolutePath }.toSet() }) { Text("Select all") }
                TextButton(onClick = { selectedBatch = emptySet() }) { Text("Clear") }
            }
            val batchFiles = filteredTargets.filter { f -> if (selectedTool.startsWith("Batch Unzip")) f.extension.equals("zip", true) else if (selectedTool.contains("Bulk")) f.extension.equals("epub", true) || f.extension.equals("txt", true) else f.extension.equals("epub", true) }
            LazyColumn(Modifier.heightIn(max = 220.dp).background(Panel, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp)) {
                items(batchFiles, key = { it.absolutePath }) { f ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = f.absolutePath in selectedBatch, onCheckedChange = { checked -> selectedBatch = if (checked) selectedBatch + f.absolutePath else selectedBatch - f.absolutePath })
                        Text(f.name, color = TextMain, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
        if (selectedTool == "Add Cover") {
            OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cover title (optional)") }, singleLine = true)
        }
        if (needsBulkText) {
            OutlinedTextField(value = find, onValueChange = { find = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Find") }, singleLine = true)
            OutlinedTextField(value = replace, onValueChange = { replace = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Replace with") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(caseSensitive, { caseSensitive = it }); Text("Case sensitive", color = TextMuted, fontSize = 12.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(wholeWord, { wholeWord = it }); Text("Whole word", color = TextMuted, fontSize = 12.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(regex, { regex = it }); Text("Regular expression", color = TextMuted, fontSize = 12.sp) }
            if (selectedTool == "Bulk Find & Replace") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { selectedTool = "Bulk Find & Replace Count" }, modifier = Modifier.weight(1f)) { Text("Count matches") }
                    Button(onClick = { selectedTool = "Bulk Find & Replace Execute" }, modifier = Modifier.weight(1f)) { Text("Replace all") }
                }
            }
        }
        if (selectedTool.contains("Unzip")) {
            OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("ZIP password") }, singleLine = true)
            OutlinedTextField(value = destination, onValueChange = { destination = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Destination folder (blank = same folder)") }, singleLine = true)
            Text("Password default V4 dapat diganti jika arsip menggunakan password lain.", color = TextMuted, fontSize = 11.sp)
        }
        Button(onClick = {
            if (busy) return@Button
            val targets = if (batchMode) filteredTargets.filter { it.absolutePath in selectedBatch } else listOfNotNull(selectedFile)
            if (targets.isEmpty()) { status = "Pilih minimal satu file."; return@Button }
            if (needsBulkText && find.isBlank()) { status = "Isi teks yang ingin dicari."; return@Button }
            busy = true; resultCards = emptyList(); status = "Memproses ${targets.size} file…"
            scope.launch {
                val opts = mapOf("title" to title, "find" to find, "replace" to replace, "case_sensitive" to caseSensitive.toString(), "whole_word" to wholeWord.toString(), "regex" to regex.toString(), "password" to password, "destination" to destination)
                val results = withContext(Dispatchers.IO) {
                    targets.map { f ->
                        runCatching { EpubToolsEngine.run(context, f, selectedTool, opts) }.fold(
                            { Pair("✓ ${f.name}: ${it.message}${it.output?.let { p -> "\n$p" }.orEmpty()}", true) },
                            { Pair("✗ ${f.name}: ${it.message}", false) }
                        )
                    }
                }
                resultCards = results
                val succeeded = results.count { it.second }
                status = "$succeeded berhasil · ${results.size - succeeded} gagal"
                busy = false
                onRefresh()
            }
        }, enabled = !busy && selectedTool != "Bulk Find & Replace", modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(8.dp)); Text(if (selectedTool == "Bulk Find & Replace") "Choose Count or Replace" else if (batchMode) "Run Batch" else "Run Tool")
        }
        Text(status, color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        if (resultCards.isNotEmpty()) {
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                items(resultCards.size) { index ->
                    val (detail, ok) = resultCards[index]
                    Card(Modifier.fillMaxWidth().padding(vertical = 1.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Text(detail, color = if (ok) Color(0xFF8FE0B3) else Color(0xFFFF9B8F), fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(6.dp))
                    }
                }
            }
        }
        if (allTargets.isEmpty()) Text("Tidak ada file yang didukung. Tambahkan EPUB, TXT, atau ZIP ke penyimpanan lalu refresh.", color = TextMuted, fontSize = 12.sp)
    }
}

private fun highlightSearchSnippet(snippet: String, query: String): AnnotatedString {
    if (query.isBlank()) return AnnotatedString(snippet)
    val matchStart = snippet.indexOf(query, ignoreCase = true)
    if (matchStart < 0) return AnnotatedString(snippet)
    val matchEnd = matchStart + query.length
    return buildAnnotatedString {
        append(snippet.substring(0, matchStart))
        withStyle(SpanStyle(background = Color(0xFFFFD54F), color = Color(0xFF202020), fontWeight = FontWeight.Bold)) {
            append(snippet.substring(matchStart, matchEnd))
        }
        append(snippet.substring(matchEnd))
    }
}

private fun highlightReaderPage(page: String, query: String): AnnotatedString {
    if (query.isBlank()) return AnnotatedString(page)
    return buildAnnotatedString {
        var cursor = 0
        while (cursor < page.length) {
            val found = page.indexOf(query, startIndex = cursor, ignoreCase = true)
            if (found < 0) {
                append(page.substring(cursor))
                break
            }
            append(page.substring(cursor, found))
            pushStyle(SpanStyle(background = Color(0xFFFFD54F), color = Color(0xFF202020), fontWeight = FontWeight.Bold))
            append(page.substring(found, found + query.length))
            pop()
            cursor = found + query.length
        }
    }
}

/** Small LRU cache for already-paginated chapters. Keeps revisiting chapters and
 * toggling settings from triggering the same expensive text measurement repeatedly.
 * Approximate payload budget: 4 MiB, at most 8 chapter/layout variants.
 */
private object ReaderPaginationCache {
    private const val MAX_ENTRIES = 8
    private const val MAX_BYTES = 4 * 1024 * 1024
    private const val MAX_ENTRY_BYTES = 1024 * 1024
    private val pages = LinkedHashMap<String, List<String>>(16, 0.75f, true)
    private var bytes = 0

    @Synchronized fun get(key: String): List<String>? = pages[key]

    @Synchronized fun put(key: String, value: List<String>) {
        val snapshot = value.toList()
        val size = snapshot.sumOf { it.length * 2 }
        if (size <= 0 || size > MAX_ENTRY_BYTES) return
        pages.remove(key)?.let { old -> bytes -= old.sumOf { it.length * 2 } }
        pages[key] = snapshot
        bytes += size
        val iterator = pages.entries.iterator()
        while ((pages.size > MAX_ENTRIES || bytes > MAX_BYTES) && iterator.hasNext()) {
            val old = iterator.next().value
            bytes -= old.sumOf { it.length * 2 }
            iterator.remove()
        }
    }
}

private fun decodeReaderImage(path: String): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1400) sample *= 2
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
}


@Composable
private fun ReaderScreen(
    book: ReaderBook, index: Int, initialPage: Int, positionKey: String, chapterData: ReaderChapter?, settings: ReaderSettings, searchText: String, highlightQuery: String, highlightOccurrence: Int,
    searchResults: List<EpubSearchResult>, onBack: () -> Unit, onPrevious: () -> Unit,
    onNext: () -> Unit, onSearch: () -> Unit, onChapters: () -> Unit,
    onSettingsChange: (ReaderSettings) -> Unit, onSelectSearchResult: (Int, Int) -> Unit,
    onProgress: (Float) -> Unit
) {
    var settingsOpen by remember { mutableStateOf(false) }
    BackHandler(enabled = settingsOpen) { settingsOpen = false }
    var controlsVisible by remember { mutableStateOf(true) }
    var pageIndex by remember(book.archivePath) { mutableIntStateOf(initialPage.coerceAtLeast(0)) }
    val readerContext = LocalContext.current
    val positionPrefs = remember(readerContext) { readerContext.getSharedPreferences("v5_reader_positions", android.content.Context.MODE_PRIVATE) }
    val savedChapter = remember(book.archivePath) { positionPrefs.getInt("chapter:$positionKey", -1) }
    var enterAtEnd by remember { mutableStateOf(false) }
    val chapter = chapterData ?: book.chapters[index].copy(plainText = "Loading chapter…")
    val pageBg = when (settings.theme) { "Light" -> Color.White; "Night" -> Color(0xFF171717); else -> Color(0xFFF2E4C9) }
    val pageText = when (settings.theme) { "Light" -> Color(0xFF242424); "Night" -> Color(0xFFDDDDDD); else -> Color(0xFF5B4632) }
    val fontFamily = readerFontFamily(settings.fontFamily)
    val fontWeight = FontWeight(settings.fontWeight.coerceIn(300, 900))
    val style = TextStyle(fontSize = settings.fontSize.sp, lineHeight = (settings.fontSize * settings.lineSpacing).sp,
        letterSpacing = settings.letterSpacing.sp, fontFamily = fontFamily, fontWeight = fontWeight, color = pageText)
    val measurer = rememberTextMeasurer()
    Box(Modifier.fillMaxSize().background(pageBg)) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            // Paginate against the full available reading area, with only user padding reserved.
            val widthPx = with(density) { (maxWidth - (settings.horizontalPadding.dp * 2)).roundToPx().coerceAtLeast(100) }
            // Symmetric vertical padding: both edges move inward together. Increasing
            // the value pushes the first line down and reduces available page height,
            // so pagination also moves the last line upward.
            val verticalInset = settings.verticalPadding.coerceIn(0f, 50f)
            val verticalTop = verticalInset
            val verticalBottom = verticalInset
            val heightPx = with(density) { (maxHeight - (verticalInset.dp * 2)).roundToPx().coerceAtLeast(120) }
            val maxLines = with(density) { floor(heightPx / (settings.fontSize.sp.toPx() * settings.lineSpacing).coerceAtLeast(1f)).toInt().coerceAtLeast(1) }
            // The signature includes every input that can change line wrapping or page size.
            // An unchanged signature reuses the cached page breaks instead of measuring again.
            val paginationKey = remember(
                book.archivePath, chapter.href, chapter.plainText, widthPx, heightPx, maxLines,
                settings.fontSize, settings.lineSpacing, settings.letterSpacing,
                settings.fontFamily, settings.fontWeight, settings.paragraphSpacing
            ) {
                listOf(book.archivePath, chapter.href, "${chapter.plainText.length}:${chapter.plainText.hashCode()}",
                    widthPx.toString(), heightPx.toString(), maxLines.toString(),
                    settings.fontSize.toString(), settings.lineSpacing.toString(),
                    settings.letterSpacing.toString(), settings.fontFamily,
                    settings.fontWeight.toString(), settings.paragraphSpacing.toString()).joinToString("|")
            }
            // Paginate away from the UI thread and retain a bounded cache for chapter revisits.
            val computedPages by produceState(initialValue = emptyList<String>(), paginationKey) {
                val cached = ReaderPaginationCache.get(paginationKey)
                if (cached != null) {
                    value = cached
                } else value = withContext(Dispatchers.Default) {
                    val rawSource = chapter.plainText.ifBlank { chapter.title }
                    // Preserve paragraph boundaries; spacing is applied as a real layout gap below.
                    val source = rawSource.replace(Regex("\\n{3,}"), "\\n\\n")
                    val output = mutableListOf<String>()
                    if (source.isNotEmpty()) {
                        currentCoroutineContext().ensureActive()
                        // Measure the chapter once. The previous loop measured the entire
                        // remaining suffix again for every page, causing quadratic work on
                        // long chapters. One layout lets us split by line ranges in linear time.
                        val layout = measurer.measure(
                            AnnotatedString(source), style,
                            constraints = Constraints(maxWidth = widthPx),
                            maxLines = source.length.coerceAtLeast(1), overflow = TextOverflow.Clip
                        )
                        var firstLine = 0
                        while (firstLine < layout.lineCount) {
                            currentCoroutineContext().ensureActive()
                            val lastLine = (firstLine + maxLines - 1).coerceAtMost(layout.lineCount - 1)
                            val start = layout.getLineStart(firstLine).coerceIn(0, source.length)
                            val end = layout.getLineEnd(lastLine, visibleEnd = true).coerceIn(start, source.length)
                            val page = source.substring(start, end).trim()
                            if (page.isNotEmpty()) output += page
                            firstLine = lastLine + 1
                            // Yield periodically so cancellation and other background work
                            // are serviced while a very long chapter is being split.
                            if (firstLine % (maxLines * 8).coerceAtLeast(8) == 0) yield()
                        }
                    }
                    if (output.isEmpty()) output += source
                    output.toList()
                }.also { ReaderPaginationCache.put(paginationKey, it) }
            }
            val textPages = computedPages.ifEmpty { listOf("") }
            val imagePages = chapter.imagePaths
            val totalPages = textPages.size + imagePages.size
            LaunchedEffect(index, textPages, imagePages, highlightQuery, highlightOccurrence) {
                val targetPage = if (highlightQuery.isNotBlank()) {
                    var seen = 0
                    textPages.indexOfFirst { page ->
                        var cursor = 0
                        while (cursor <= page.length - highlightQuery.length) {
                            val found = page.indexOf(highlightQuery, startIndex = cursor, ignoreCase = true)
                            if (found < 0) break
                            seen++
                            if (seen == highlightOccurrence.coerceAtLeast(1)) return@indexOfFirst true
                            cursor = found + highlightQuery.length
                        }
                        false
                    }
                } else -1
                pageIndex = when {
                    targetPage >= 0 -> targetPage
                    enterAtEnd -> totalPages - 1
                    index == savedChapter -> initialPage.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
                    else -> 0
                }
                enterAtEnd = false
            }
            val currentPage = pageIndex.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
            LaunchedEffect(index, currentPage, totalPages, positionKey) {
                positionPrefs.edit().putInt("chapter:$positionKey", index).putInt("page:$positionKey", currentPage).apply()
                onProgress(((index + (currentPage + 1f) / totalPages.coerceAtLeast(1)) / book.chapters.size * 100f).coerceIn(0f, 100f))
            }
            Column(Modifier.fillMaxSize().background(pageBg).padding(start = settings.horizontalPadding.dp, end = settings.horizontalPadding.dp, top = verticalTop.dp, bottom = verticalBottom.dp)) {
                Column(Modifier.weight(1f).fillMaxWidth()) {
                    if (currentPage < textPages.size) {
                        val pageParagraphs = textPages[currentPage].split("\n\n").filter { it.isNotBlank() }
                        pageParagraphs.forEachIndexed { paragraphIndex, paragraph ->
                            if (paragraphIndex > 0) Spacer(Modifier.height((settings.fontSize * settings.paragraphSpacing.coerceIn(0f, 2.5f)).dp))
                            Text(
                                highlightReaderPage(paragraph, highlightQuery),
                                modifier = Modifier.fillMaxWidth(), style = style,
                                maxLines = maxLines, overflow = TextOverflow.Clip
                            )
                        }
                    } else {
                        val imagePath = imagePages.getOrNull(currentPage - textPages.size)
                        val imageBitmap by produceState<Bitmap?>(initialValue = null, imagePath) {
                            value = imagePath?.let { withContext(Dispatchers.IO) { decodeReaderImage(it) } }
                        }
                        if (imageBitmap != null) {
                            Image(imageBitmap!!.asImageBitmap(), contentDescription = "Chapter illustration", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        } else if (imagePath != null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
                        }
                    }
                }
            }
            Box(Modifier.fillMaxSize().pointerInput(totalPages, pageIndex, controlsVisible, index) {
                detectTapGestures { pos ->
                    val fraction = pos.x / size.width.coerceAtLeast(1)
                    when { fraction >= .65f -> { if (pageIndex < totalPages - 1) pageIndex++ else if (index < book.chapters.lastIndex) onNext() }
                        fraction <= .35f -> { if (pageIndex > 0) pageIndex-- else if (index > 0) { enterAtEnd = true; onPrevious() } }
                        else -> { controlsVisible = !controlsVisible; if (!controlsVisible) settingsOpen = false }
                    }
                }
            }.pointerInput(totalPages, pageIndex, index) {
                var drag = 0f
                detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = {
                    if (drag < -55f) { if (pageIndex < totalPages - 1) pageIndex++ else if (index < book.chapters.lastIndex) onNext() }
                    else if (drag > 55f) { if (pageIndex > 0) pageIndex-- else if (index > 0) { enterAtEnd = true; onPrevious() } }
                    drag = 0f
                }, onDragCancel = { drag = 0f })
            })

        if (controlsVisible) {
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(56.dp).background(Color(0xFF101719)).padding(horizontal = 7.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Accent) }
                Column(Modifier.weight(1f)) {
                    Text(book.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("${index + 1}/${book.chapters.size} · ${chapter.title}", color = TextMuted, fontSize = 11.sp, maxLines = 1)
                }
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "Find in book", tint = Accent) }
                IconButton(onClick = { settingsOpen = !settingsOpen }) { Icon(Icons.Default.Settings, "Display settings", tint = Accent) }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous chapter", tint = Accent) }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next chapter", tint = Accent) }
                IconButton(onClick = onChapters) { Icon(Icons.Default.List, "Table of contents", tint = Accent) }
            }
        }
        if (settingsOpen && controlsVisible) {
            AlertDialog(
                onDismissRequest = { settingsOpen = false },
                containerColor = Panel,
                title = { Text("Display settings", color = TextMain) },
                text = {
                    Column(
                        Modifier.heightIn(max = 520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                    ReaderSettingSlider("Font size", "${settings.fontSize.toInt()} px", settings.fontSize, 14f..32f, 1f) { onSettingsChange(settings.copy(fontSize = it)) }
                    ReaderSettingSlider("Line spacing", String.format("%.2f", settings.lineSpacing), settings.lineSpacing, 1.2f..2.4f, 0.01f) { onSettingsChange(settings.copy(lineSpacing = it)) }
                    ReaderSettingSlider("Left & Right", "${settings.horizontalPadding.toInt()} dp", settings.horizontalPadding, 8f..40f, 1f) { onSettingsChange(settings.copy(horizontalPadding = it)) }
                    ReaderSettingSlider("Above & Below", "${settings.verticalPadding.coerceIn(0f, 50f).toInt()} dp", settings.verticalPadding.coerceIn(0f, 50f), 0f..50f, 1f) { onSettingsChange(settings.copy(verticalPadding = it)) }
                    ReaderSettingSlider("Paragraph", String.format("%.2f em", settings.paragraphSpacing), settings.paragraphSpacing, 0f..2.5f, 0.01f) { onSettingsChange(settings.copy(paragraphSpacing = it)) }
                    ReaderSettingSlider("Letter spacing", String.format("%.2f px", settings.letterSpacing), settings.letterSpacing, -0.5f..2f, 0.01f) { onSettingsChange(settings.copy(letterSpacing = it)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Font type", color = TextMain, fontSize = 11.sp)
                        var fontMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(
                                onClick = { fontMenu = true },
                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text(settings.fontFamily, modifier = Modifier.weight(1f), textAlign = TextAlign.Start, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Icon(Icons.Default.ArrowDropDown, null, modifier = Modifier.size(18.dp))
                            }
                            DropdownMenu(expanded = fontMenu, onDismissRequest = { fontMenu = false }) {
                                readerFontChoices.forEach { name -> DropdownMenuItem(text = { Text(name, fontSize = 13.sp) }, onClick = { onSettingsChange(settings.copy(fontFamily = name)); fontMenu = false }) }
                            }
                        }
                    }
                    ReaderSettingSlider("Font thickness", settings.fontWeight.toString(), settings.fontWeight.toFloat(), 300f..900f, 100f, Modifier.weight(1f)) { onSettingsChange(settings.copy(fontWeight = it.toInt())) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Theme", color = TextMain, fontSize = 11.sp)
                    listOf("Light", "Sepia", "Night").forEach { theme ->
                        FilterChip(
                            selected = settings.theme == theme,
                            onClick = { onSettingsChange(settings.copy(theme = theme)) },
                            label = { Text(theme, fontSize = 11.sp) },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
                    }
                },
                confirmButton = { TextButton(onClick = { settingsOpen = false }) { Text("Done", color = Accent) } }
            )
        }
        if (controlsVisible) {
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${currentPage + 1} / ${totalPages}", color = pageText.copy(alpha = .65f), fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text("${index + 1} / ${book.chapters.size}", color = pageText.copy(alpha = .65f), fontSize = 11.sp)
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(24.dp).background(Color(0xFF101719)), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text("Tap left/right or swipe to turn page · Tap center to hide controls", color = TextMuted, fontSize = 10.sp)
            }
        }

    }
}
}

@Composable
private fun ReaderSettingSlider(
    title: String, valueLabel: String, value: Float, range: ClosedFloatingPointRange<Float>, step: Float,
    modifier: Modifier = Modifier, onValue: (Float) -> Unit
) {
    Column(modifier.padding(top = 1.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = TextMain, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text(valueLabel, color = Accent, fontSize = 10.sp, maxLines = 1)
        }
        Slider(
            value = value.coerceIn(range), onValueChange = onValue, valueRange = range,
            modifier = Modifier.fillMaxWidth().height(34.dp),
            // Continuous slider: no discrete tick markers or dot indicators.
            steps = 0,
            colors = SliderDefaults.colors(
                thumbColor = Color.Transparent,
                activeTrackColor = Color(0xFF005650),
                inactiveTrackColor = Accent,
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
    }
}

