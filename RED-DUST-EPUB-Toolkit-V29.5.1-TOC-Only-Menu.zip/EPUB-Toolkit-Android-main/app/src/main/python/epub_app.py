#!/usr/bin/env python3
# EPUB Toolkit V11 - Offline Android Edition
# Batch processing is performed locally through the Android WebView bridge.
import os, re, json, zipfile, tempfile, io, contextlib, builtins, shutil, html
import base64, zlib, mimetypes, posixpath
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

DOWNLOAD_DIR = "/storage/emulated/0/Download"  # Android Download directory, retained for module compatibility.
STORAGE_ROOT = "/storage/emulated/0"  # Shared internal storage root for EPUB discovery.
MODULES_B64 = "eNrtfQt72zay6F9h3M2RmMi0JD+SyJb9OanT9dk8fBO3263t6tAiZXMtkVqSiu0q+u93HgAI8CXZabf33G/b3ZoigcEAGAwG88J87dPR+48/HQ2OTn58PXgDT5+c6f1az1oLJtMoTq0oOQ/FY+yrx+R6lgZj9fO3YDoKxtnnaZQEd1M3vVZvUn9iFrmbjB0/jX3fORr7Ez9MT+HZchPr6PQ8/P7j3z+8+3j4/eD7409W32psJGkUu1f+hj+Zjd3U9zbaG99Ht+E4cr3GeXgeev7IGkdDdzwI3YnfTN0ru3ceWvBP7KezOLTgjRMn03GQNhuLRsvq2GfrnQsrGFnw0wqogOWPEx8fJMQwGUSjcmBnnd6FY8JrEzhsKEndOE1ug/S62Zg3bIbbUIgOr4Ox15y6MfS6ZSHCEv4oiqEwojMOklQUkR/xn8Dopj92EDmr3ycoWjkNWX9s4P4hCn2JyHXsjwY4Tc1oyg8teidbxGcYfvwj+/qd7Kt8cSBfGK0oAnDCKJ5QE9mrf0ZBqP30gph6I3GwBRK2RDP2J9EXf+BPZ5eDITzFzSSaxUOfSwtcL93Eb1n+XQoIR4lDkAlFeGWU5+LRLJ3OUnoDFbCy9dxqDMKIW3CwsYaEPLyZTWVRDRTWcPirKArTI9v272AGk6bWjj6P0zgIYfA+0lfLHce+691bXKfXsPMFdSjZNzdMbv0YcApC+NpsfPKnY3foW0F6YDXvN0K7ZzVsIMY4mDZtZxxB4aZt0JKA8ASW2H0jRz4CxTduOPTHY99zdLSyqeZ3SOuSCzi/BNO38Fcf9ZbViGEhwPL+LQi1hnDiExxVP23CFwd/E+nbWmPDKEzdIPRjonrkB++PTg/Xjz+83VCfHOAnDaNvuVphlOK6ogbzC8UNYPp/cscz/yiOo7jZOL0OgBEBR7SuAeUwssobNIYkay+OIqTCo1NnFEcTHP/winqHs9w08dL7ifVwAKEur1L5IWMLZiMOUDdMaa47lTyiIRvIT3Wucckx9H8uAfcbY3xVBRgqRNcCJHGQ5XvnCua0MZqNx+tIAQ176ai/iWZjj2CMgtCz0muf52AKSwyYv9X8ePLWtgi2PvCSbwDmlW0bmKsKD6QJ3wIEFDay75MgSWCCYa0BP1A8zETPc1MX0FM0UFKslGhkXZ0hcPODEJcNb1BECjjJWal/wcexO7n0XN4ZLNiHAD2t8nPa+J7TZxwU7RNtV/g+gzdxw2DkJ4gh717YJixq+V4f4WQKBJovSC/1UlezwCuUope52VJNCzpbaaIMuhFrWAIyiEe+HMBSmuCQnt3RcrtTm7AsYecW1l22rrBu40LD2hukEUEEgPM7psbAgyVgadBzTQN0reRCowze/gJPMkq78A1pseQrbWVAaFcVtREVwrKATWEviKZYv4kfGUl85cdp4CfA1wFOo6G2GCEa5LaLie8FrgmDXq2n91O/AKPA0hrUmfVgAr0hgY1wKmNkargc1/O01nBYi3Dd8L7ZbKTXs8ll6AZjBk0jM1Wt2PY3tDPxU1esf3PpiPd5cpfFg4T4UwnJ56REWaMMybHYMYsbQvlAy/2Dq/UZy7LtQm7eOKEAkTqOv5dMpE5QelVBTfcrVgcUFYZEFw2YR8+S0HCXBMG5YVcgXjJ9harVLeeIhRBBpHM0BD2qaV5OmsN4QPslDYIopM/FOAhvquYiBoLQxhN+rj6UOcyh7mMRB2DM1+uJF48VknqpfNlEmdwWjyCZHOOPfDgZDX2edkkCAJLK0QiUchXJmSr6J847Cgb+blSPG36uGSnJfUkyqTxqVddfmTuXoJZxI+4DjVMZDvmCNMAZ5ktaKrRGm9zyOsXNaTmvLlm8tO1RzQzjilpEZpJmzXFHZgK0auJTQrUrz8UkfeQ2p9FgYQKpXrE4DoHgw9mJGo+ztGqIwmo5/YQk4GbDncLKGLppEIUbd9fpZPwcD1SwTeH5eQNfCCJSDVI1PixTBSzMP+WvNEjHPg5oViB7xSB7lYtrZZp6LB0VaKhyidplspgzmwIb9Jtm8znhSrxWzC5XOC9l0XuWGjMRkjoiqhTFF6TcrJ44gqkXOgWVDCFudkE480vQqGFbpdCLmGVgKo5Y+E8a31dMLVWvP0mrFqqmmAp4QWwsDqluymqXVx7RYHpE6AqZ8hP3EokLoSyRuQqyF62uYHKFi4Zl3mV8NYmHeCLEtmhe4DezjezV/DpNp72NjdvbW+d204niq43Oq1evNu5QsljU7XYafgB3BQ5fWF0raATFbLWwCbtsTv27oT9NrSP6A5yqknSSJK+qymNTMfk5qbC47FbeCAosjEUrdZRDXrrCEl2JSxUW4x95pChVL0nKXnpmEPI1aZlyEnflViDrGAP4WBFVn0DzfF+rRqMhNg/8uSksznGZaCB1EAI1rG5OFmtP6mcKa+kyNNVZPleimtkNJBjVEyX5Bh5LHasMObWud6ggXmW6pRwIYOyxfwVdENrQBEr6zUajpVXJb6kAPbhrWbM4ICbZbHhDZJKCtU1n8ZgYmzfc8NmwlGx0nM5Gw24BR4U1oxVGPhh40xFV6LbbLzbwOxX0hoDTJKmATN8ApL1SfzSUtc6E/u0AmuPtLY3E5sbKATjbRB787Ddm6Wj9JWAB0tjA84djNyYZrX8az3wNGOnfpY3N+QBNe6c+Gtrc+J508R4MRur337pjNJMksxFg1G+wmaNlAdftS8OF3B91mwlp7tNJ/kCLDUpJAb46ps6wuLeXWgkUEBjqW2EjiGZpOTU3JgGsbpSk66QKKhyOIqFyBYrGX82scgWvwXad2xhoGGajiXVamc5Wq90CljSBWU2SAb7oqy4dnww+n378dPR9SQO0cBEpQByB4jObOurVK1jOkVL3cnWIwrJWZC6T+/LQsrVPu8+j4Qnll6R3DVmliCeNsxppsousPkM5BflKhCaMUcNrf3hT0rFL1yN1HXx1sKnf0IJWSpBQskojU6qYhlFg5fTIBZyQ6yYWkA0MdupfQb/uBU5kTQDg5RJ/zsioWSjLiImN9c4wmt53TaOcXtGsJ+oQT9cGrtwQOQpCdzy+L26gOTwVoDIsoazYQ7JiXEpYIs/Pw7dBGCTXmi1SfPogRrXXKENRGlvj4AoRVZabWTi8dsOrIrjXNCwIrDhAYgZyklxTe0erpcTY+yFK/R5s6VBuGF2FwW/uJeBBR0JLY+2JBZKUD+xiFnq7mRFs4t4rO/G1+wUNmlxXIY+LqNjqJ0LK47IbStO3HvvkSAFbDWw8sLqhs8Bimlm/bCBA7Q33yl5rWWtvj38efPg4OPl09NPx0d+Fu8g5/UuonkBPrmJ3em29De6gc8j5Tu69OIKT8Ka1YR2G9OxwlTL3krw/Sc7dJI1hW8Wpyd5c48jAjpm9CZBb4rHRwtkbB5eW+HKi+6Xc+peXcXSb+LH0NiAV4YDcBvA/ciJTdi3AP0CnZGhHkoyBKlFIwD+28UG9NerHvpPMLrHA+flss91uPxflGA61KNwOQHK7SUQV9rXASiH+J3lGj6KCNPHb0gUjmY1TsmVdZG4lBA55OsPVCIW/9PmvhFVQj9HX3LIt8n0JS3azebD35Fcb/0sI280eow+v+mcw97NuuzO8sHkMzs87qofYNwJm1wCXELwLm8A+R6iH679cnLnrvz0eqvPkAMF2d3SwD0WWZNXAH4p9tGYKuWZeF0RV+/y3OClSsMavpadGIgHHnU79EI6xWMw2HHRECUn00zgaojhDirqmfvQzpbhI8tA+bbsO8K3IA3pnMVUyIj6m/xgG+PF7KkJbYE9XpBEa1FTLakv+66YgOoc8Gyhj4b7daO5Ncawuz37dv3i2bzedZwd2c29jysO4jxMCxY+tr/jnswAlWDuAap8LJxX2JeIVOnHTobENhVFIRyVZUTfg+yFwlpY8h8LDOEKTP8AmMM5VHM2mSW7RNPYa0mMDD6+ov93Pv0H+Kn7a1p612S534dJaabYNX4CY1rnGsiQ002XMR+0KlIVG+lbnYY3IgXwONQvzRxyO1TdNMU7kZgCc9bkaJtaExilr0hANAZ5VqDhHYuJpBYopailiMym3KWo5dEjKaK8lMVV+YyD3s9MYqUvkZPOu8xY9TFgQI9s5nHr8YTq+RxzF/tRILOljCF0Ye7CTwTYPa25448e22r2IsmS5Pu0uzXqHRVOSkHWdIEHtl3EcGIFYhfucgOtcR3Aws2ELbQj4DXyWEBLTAUpWLgOcQ1oWzQrkhAnTIQzRdofIMEg+yY0SihIStl0K4nA8jm41kUDCisRkZHNgffZT2GKukha2FCI3stwrF04K5d5omuPUZRTR9pnANu97zaZm1M+GHIiOhoaYKQ4UItBkS8fU4WOyodviEzMQ241/3xceNtOexWdfWdKcYEKkTBy0CJjocyb0AYYVQ8g1z9feg0Bm3YMgzxQMLyOaiOk19L6EbLE38SwUI3e+ZhfWcTZsmbCtrQ4YMwlTeSfyedbz71rUQyzjh7OJH6NVhPqMjqGFfo8aljWnegvHmmM5GrqFtiqQXREAGvJOcegAuR+Js2CngW/fi5WMo0dSO1ZGH9XcSVJ0Vn4WrovXeBxAfUpPZ3pRMPSVa+WIxgM4K4ylBZ28RF7QWZ9nmC5s5FdWG4l4SC6TuvOl6ZgoYAM1tRu9JVRs1AEC9YAlpoJAO8jNcUD4KzH3DKNyyNx3vdK61bkojPDJ2EeXWJ+6TM59IxpsVFgAw+YhSGgRZrxWnLyY6HL89jMeWYDLKOnUHUewrNFXAOHyqVSSsyI2g8mKHqzCYPGUQr7s1vvDv9V4tKO0U+2ivtyr/X+DEzuIdleoqmoOZzF7nKdR6o7huOde+uN+4/UsGOPJiQYfgN4GXnrd32wrARBLk6hz1xQ1O3JHxgMrfoLtHz+LFmBPEgXbdlb40kU7XOO7hvWMiJbagWcCgofNxjp+Eu/XS8rk1QHxfGGdzRcX1ry37XRGi6cNB5gSyDFN6hqe3uOWQPKZ1WkjNiAO91G/PBrPkmtdi4qLTKC/32f8C4xHUTv6p6Iyq/mb8pU3PJlHRUdmnKQKt+UyVWa55XMkVJEVgOzc+UOaL1f1FVaGyqXewkLpm5kWS31tDRNAvSFYjx2gFSZboXNsyN1RAGhrVU49MKci2MIh/f2Fsf0SEH1kC3o508kYYdjshYz7iRI0NOx485DBCa43kBYn4+RUOoWaspJ8IaCAO0uvI1objWxnrZ86XOermpi/YE/RIYXLoBpC+KCUbU4EuS8cNdgwxACUlou+5OlI9oXK6lKkBnIIQwUcsBQoj0EeqhoZDayYVWqwdlZfo1DCeGVe2hYphFihJq2EuQluUp2WbBzH6sfwJgRGbR3SKzxuwqwoZnAbu9PBbRR7SZPwBM4aTAKlOKIvsg+ma+wYVm7Soj84QWcXLZyXjAiwKhIBgegVjnT42rb2ubmShR2EZboBalRqBvCHXV5GI0izKlAQVqXmz4JegHpCxOCCRUKiWjyINdutDE05KHmzflGFBNKTF+AJD4eEEIGtgdThBKiUaqkYEhMdqCWAqrFZNgKi99hc7YFIlFPtZQKsOfJV7QmCo89IZ2eNhmIrE/fG51CkQfLlyqRJU7L6xFBc1CFHuNl9gYIoncCSSNd5Q7Q+//SD0BbrEhW33NcpWDTUeWmK41QSx/NFvl/Ih/DvWW/nAuboDKaK9QH8dqd3YSstZJgOkuA3HLNOZycHGmTXTZZdXnWLn7b504sdjXUOKMwOgbVftYXA0NSqgWBrw76fNfvMajs7OvMdIEvMK0oDsSCN8wyD1DlwVl/ObGOPmOtd/3yts90+X7Pu4Wm+gIfh2E0S+EGVztf254u9DSy7rwQWvUPPqSdBDvWO0+1iZFyKImcydKeMlFpQTBqDkinlLy0LRLqzXvfCKK4GwEB+qwx5rlGKfefVyzaiDWjubJXhWD2wOtqSUKRaC5AC2kchO0QEis5L3Xa7vQFFAEuWWgH5nTYO/bUfXF2n8Lu7vYO/vwT+7esIe9eGMxoWssQXNOP68Rf/MJn6w/QTCotQ6u594P0D/g+7hJ9Cn1HnuwfrMuEnRNeNf4hdLyDHFA+qXCIadx1sAodPPtx1ESt8Ix4YApwFpnCoGoG4KArim/VhNI5iePFd50Vnuwu0slFW3Nl6Waiw6W12trcrKnQKxd2d7dFOVxXfMHtU3csrONyt0M/2qv0cvfRGrrcy2t6rV5cvXtWjjT/ccQ5tEItWRcl/dfny5Qv5OgLBMEhxNTibWyvjWQWjnaFuoskvpf6bcPaiNNEom1alomv6JYr/GAYpLpAZEPJn9Dj5GP6Y+LK7wyAeop0RiR8rDe/FAyIKFIAqnjFNxWgEv7T+djRsRVOy9/djnx4d/95H+9kcWdX6yJ0E4/veYQwdayVumKwDRsFolz4iH+tttqd3u2MfYa2jcwwGznU24R0i0ftutO29dL0FQSaWaMD9wYdFH7gtDegtjUfvEqhSa+Wpl0EcjV76l/kmne3pHZyYn2YcFltkXrRqV7Y0tIGIL718I9QGwk0m7ni8KtjuVnGEXqqWfHe4+cpd8JzwNOxtZHwJddjLWKGY7lk8bn53eWWrKX5oXSTPrLZOZZ3uq7YktG2Cg6S2081DwEX5EAhbLzQIIarIcH3F0Y1P5Asc0N1Rr9ZlVzZNot58+YAWN189psWu2WI348p0Csa1/R42oe1O23oDLVidzW7beglbUufFlticOpubbeud2qesd/z3F225yh2ionNZUyCMWNvQzF87W9ttvQM8CbB07GIfMlZXIhfwAEnBQLAA4DeHFno//UOKB/p2Lk8Nmtxkl3w+MxHfgiFBzLdfrYz4DiF+UQZcl3kqGi/pbLe7rfeWFjP01ZK9VGsHq22/lEP0UhdKtl4azLu7tUUMWLLkbyTp7TICg2HDkdsEIhPPP9EzkV0XlhLQA9C8/uIn0dWHorNtovMiQweFs2wyijZDtgbmLXnyDDQLg3/N0BdFeEViWIuUwWGvQ8PVPNNAkf9theqEtQZ6yYXuK9GSOn04cXIeia6tGwe4FMLEZg0rNn2Ak/J8sT5fKIGYgTBQ3eWTW8ksqYYxXnbb9TyR5kL4XCk/bx4GPhWWnggpXrwi3iEXc17qIleXqgGd7RLhUZn5Lj4wlQOFMkiX0Zz/v0Aew8D9kE4H3jqfWYGKGraM3Mf+cUKVsmK6cfwRLd2JSKelbXFBrffQSlfzxyW60Xpbofp81HgApVFfJbWF9nKEi3VMRMKcfb+0P0tDeqaP7A2P5kP7k69V3yMthUGInhJNLRQ/xyrKo/yzXActMtCVpDx4HGCRG6EAVYscfyTGKsS8ALsksQKqoFT0gXyhx46slH2BTXiZwlUCaKn2Wqohw4hPCS1kKovK9EqyQEWOpVrH/jwbCnAHyW8yBUIT0Vc5xrJa3Wmu6tGp83l2KWyFzWxAODuHyMpBwSUta477VE+hioEIGJPR0xZW7I/JtSXjIi21alBv7eDE6+GnPRFMhvuyDPDUEjn0zCwLi2/DfLoc8enqeJcHqC5yFi/KsLA0jMlcMFSnIoqJLRRcojrHgZaHoCzmJxeORNCqh1atF2NoCRscWkJAThTH3HL8VEYqC2PDJUN1EJnjNMAImwAdOLB55CMgiiV+M4ic1/epnxx/bBaT1aD59AsG1PSbDVp+62HSaBWCYPQInT41k7MVlcZ81oXO8HDnA2g0V8OMAZXaKvVwwCKVlEZPrUQiRvyURiQyeqrfl4ugzCtfD5vK0wR/DMIEVibaUWB0JIEUVhy2xYtOLDO17lg7htQSRrBU/qjgI6Y7mSxOU/7Wc6q6kNyMDfxrFqV+vkVUC/fzNpIyuTivsEfsUFzfu4zhiCIcFwv6aiISqavWNOlGC922YcwSh8tva0Cp6rukqtfh3ynIBzAdFiCS4FTA4dLBM5uaNDgd46ydrx3s7z35/uOb03+cHNGk7O8RhGptOocCk0vMGhfroX+aWTa/q6KGcuxSu37I9Xrab2gUWMj+Ho3Z/pz+oPmAfu4hU0OvzZjVqALxDfEBSQLeouoeeRiewZnVwUs+enr+l2AozqEtGMogDdzxOozz2O/TsAAoUpJZFKZ1vkbJDIbADtb2sZ+ty8i7n88nbnwFR5327hSOXqhva+8SyF6n3X66OwnCdT658+/FgmuhvyR6y4ZeT+hidkn9q3SO1arLxcIhUgIg0R2q/bDRS6AA2HrhzS6uDIpvpiCN4Iu/i6VHwHp614Hn+WE1fl+uVS86O0+tV0+tTvfproYr84T1K6F3bna2tj3/qiW6YLWftoQpwdruwjPbCdB55qm9yyiiYtNK4PznWd/5L4evXvnYoSi+nM8V4u4lFJilvkB0Z/vL7a5Akp4n7h1PW29rC1XC+Ft85xcxPa93oYNpNO29eCob76rG46tLt9nd2mx1O51WZ2en5Wy+lDiuY/dmSW+bJgyR67mjFEdc0FAPraC7RXyR5cJAbqn2OjXtdavai2djfz4XHQKM9QmQY8ZUB/OdptGk1/Un+qQuFted+VzTCjub21ACJ09NttPt7makW0ky68hfem54f3vtx3kaBVyZ56wzyozCJmAgWtmsRR6nZhPwUmAY557lvAJ0NzrOtlVQdedV8R3susSKFekadOglfK7oy2KRKcGZz+DShDXvD3EsLGRfPbH0acFpejzxe3/PC76ol0An+GoD3pkfcHSyL9edffJcHUh+Bi+M4tqYZrWmJaZUgsI/AcwUigrc4Yn7QrlXcobivr6haJuSza6v/KOf7XjiNbfT13aqEtWbinrg1KQlyVRpg8bjGCZMxQNYMWVqXS7UEklL5C89Pw9LE6I61kqZTcvTmK6UyjSfzpQERa9FLqEU9CUCqyc3CT4LsbTfyFLSDhpaVHU6mVYEVcvfwG/EAQjlan3YEwfDJvzmSBcHiyKz9MpEfwfSzKEHZXfFKFiKtG6hO250C+93tli+qgm9Vk6kbeE+WhXg3FIxzpmNn/DLOYPXBwgbMc81kcJGuaqQ4YCUlmoUjjEU3KhIIcT+ACMG+/RB/awEicFJE3KmhWdYFDFnNsTK6gv9om/VYDDsFyhjPHDTNJbAsjcKaK6cBJ29q8EU3e78QXKfiMxChKT+sjoHU34aVoou59HJwuP14VcB8jXVjRDv34LSAO8ar6wHoPL90dt3h6cPR6Yu/l/CzMqM4dA87r+qzoTIKyuoXlm5qHftDAXnnlWQsWtWtMFBOqsioWlu7niL+TYshMN4WeOSe2NcvPRTt9wYjsxffMcp8PI6rvenhP0fMqroAIpugiiYcPB/VZC/ivlAPDIzCm65T/Q1aJEqAwuVZLjIEf6TskW4cheOQ0JeOM6KNtAMOBvCpukX5oBi+TnQkkdebP2PSxmwPFtAIVHAG4qqh4OQ78G2TOFl6KF+/yQX6c/l2Jm4YZjWzHLs+YtFDMWCkcY9Sz5QkXeARu/W5dQ+WeoBDFY5fn/4w9Hgzcf3J5+OPn/++GnQ2a4MWkFd3uNDVoDlPzg05b9Pjn4Y/J8fD98dn/4D/S23z8O/H70+yb16f/jzgPvx/fH7ow+fjz9+wC/oSaKCW1xvMA1Q7GiWxxeTe/bJ8TuptzxGXtfiPx+nSTF+OFfAjEA+JiCF0GMi70+zEHd4JvDztRPCympC27bMvgRnQeBGKC9ax2EWrtiiiGDrJAC6TnxkRCT6NBhEoyXrgbQqohYx9i7FlPLJECTWVI/D44Fhlg7czWsqaaYnu5IaxjQlhsuCudym2YUM9lnHvJQBaqkrKCRzoJZFFHYmD+VH1XA45mfhdtxEqe0SVcZZ/K3DJf7m+1OO0JMLgBqzqLQFJ7jQx8UHB3KhzLJuKQG8H47h/MdxYcSwio3zoJSNmvJaxiIiv3uz4fxzSpn04K/PD9OQ/976l1Mj8ZoZmE75kuwySqVthgbIQXLQNeckr9BGg198r8jkgF+j0Nbk75jiLxm4sEJx6TVkq6RVLpQMB6MY1eM0y9Z+IZq7vg+GyhaGUM4wstvRAETVMJni6YObK6vk4CLO74pyhgfC3RzEVoYgjq3SXjKbTkuTe+frq4lDzoPzdPKB/iDXqUiTt7THI4pg4z6gTgUHr4RlleWdojoqdUqzWVKtVQbLFkvI+eQn7gSWZ3jlvDv88OaXj5/zAyhP2xoZLR8mlMhphMqTZTHeE3SHUQP66QeM8Wu8q0u92jikkDSuDgR4CYSY1Ca9zDREkqYc4AuytWzMW1azu73dsuR/6nL8uuPptStXOaKB7CX0x7AZ12WpzFABOSLB0yfVZy6TMko2GqOTmz41UZeNU6ySDOajTiESTBkmVdSWuCDaMFW0LJ7uvlwN/5qBMJbe9/VtGTcl2M9gjOks31KSNUieeeuJiswqoydcab0HYcVrM9e82mDKTz+VzdMKf1j7VCUbFV0yaaHx9Try+juFsCNGj5zIGCCSGMVolSw8rbiKMlKvMHMHvqlKmCl5U1ajZWkzUpPUNLNclvM3kbDoOrodVEb5SlXViSigIny7W+a2/n0AAgQmmbISEL7Q20fUoMjd9Bom6DaKbygZAG7NUh4Cek4i3KW1/Rmj/khBtde39JwmUmsl3HJgMxhyMlAKSBfhtxSqK2OIZTRcgHKYKCijgnPhxiVxxqJaIbaY34sKIBE7Seqp420utHjTWzy1mvPFxnxhKzWstHFThLHoRssyx94uwqeo4+ZKEcdlWIXGNSslYHPCHaonzYRvFYLd73N5VkbgeK4lafMxl2JVqYH/N96LpVicpHw5EsBscEMsGVwhRbNknnD+IprvmwCkp5L3wBM9FsGzlzAwwhF0mQbaSPMpFpvQfKvUnkvU34LaKjTgjImknIJ6u0SqfsQ9Yqs4qK7spKqFGTNMlF4zrUvNrVE1t4lR0kEv8vloOcbg5HFw4wO7zVQrq+uysoSpD1LjExUORMo/w3pQVVZRWzKbNJsdI30yD05gHF8pH7I6ja12+rLtSpMN8IITTk2Gmj9gyqRDkR0Argx4TaeU4UeIWZynEPWCymSmd7pl9MuuMGNg4fsBu2s/xqKxeurW/M1gNYYMYKgSbjbeNeXhTKkGZyBlUAlkpYmpNgwUQNeIv6ghEFpzlZOtVP9QrnuoTZYvIC5JSJ9jqaZfcGlKa42nPu9n0h2IDvgse7QkWb5m18LH6sJLzg8l3L+6C6Y0aBJybiU03ohZgLVVNdmIvEql/Hva0CRgaS9Tlin+uaSSNLllP5ZUMAxosqLxcnmLRQDGy2X9fLwd7kHmN31gfycjnAT5Laa4ldB6qEHOROxbzXJiz/kJ3VTuZXoxmbA5Z2kyl1m7hZYzrimclBv2EqlmxXTUK9ikKu1RRVFECNaYcXplc5S8HylnjsqsT/9mE1VFzIGyRhV7VjNznfqZyxmyKrNgF81ZD8h+XZ35Gum76uRQRILZO+1dWN48eqxnwP6krNrHvHXp5jhNsULmN2OfLq2toG+IHRHrmZtjST3eimlketZTpzuy3r/G8O+mvtFvWM1Ou7tF+ofulm3XWfHIKc+AlBvuemByZAUc+kcHls17BRypYBGzvW9oWUQjpwSA0ofEvjcbQrnLe9mM1XzqdEZPn9oONagDyzXZssyPuY5yYrXaFOSnZMhRY+cFfMnvpQ+z71sUUOvHu7r8ztkwb1AvdksGNF8SCi7qictZAycWGYpiYUN9/eO7vw3eHn/4fvDp6OTd4ZujVS6y/2cShZXW02JWcT1dONkq0TXaoQQisbRZvnYT/6+npyef/H/NgGH/1Q29MUpf+O4zlRR1Z/F4HFw6FHkhK9OPwb8ebqM9Pfr5dAD/Z8vDZ4yNbaib2PCB/qqL2BwR/eOIG1GccHhHf4ekIoQT/F3KRwMYIPHAyQy+XDUW5+FfP34+Raw63RdOG/7tAAonHz/hu5cvdrbhx+EPR+Su/sSLhsTfyZER2A37oetO4vQS/TfxodwpPPv0jW7hAhR7oL+ejW8sSgX8X9LHUDqnYyH2LYWnZ+WO2gv4RM7gtbkdCu7lnZ2cU+2oi/9KJ9hOp4OArzu6/+8LcpJmQFbbAghYZip919Elu211tvg1kFToj3UP9dtrkJhyvsod9LNWOG1lDXTQx7qNgCiP4txjzXCPEpVrqSo6L/J1rG1GgBRvZySEoQrxopX4Y3+YzjUPZw3MSx0P8pbOu15/9/Llyxz2uTHkDpojKBrVHOS3XooBIplEdWw09u92QWi4Ctf5Kq8hJT7dvXKnvVeYe6O8yx05TAyO1Y2ij13sh3QA73Krl7M0jcJ5Vc83ARzNieh+O9fjFzmq6b7YeeF6os/cfz0sIPOhfqU3D8wK1ovnxvdGBMP29jaW+Y5D0ecEjny0/R7wXfK7rvLCNij5Bf5bMoHD4bBkAo1Z1+bpVdscdUHueiYV/oDu6WLSoQcVGGJV6ShOj4rXkIs1cZ+OzgvcyXQ34wfwDYtM999cR1GCeeZ4HwPR9vTnU5Z7iJ9TRuZc7mUHvbqxuu4eTsuTGZFl7dEiQ7UTfKHtZ23/bT7r8t4GlRI1mLA5S5CosReR8YizDPbRErP/LqK9i3dUOL7sbXAZcjJHAAIa00WW4ELSB3BW4TvPJTDLQzgcB8MbeIVIEZZwGFnb/+SPgHCueSzwKLC3wXVEE3rnRQINgT0NkvKRp9mRD6uOWOjRiIW5QaLVKMcIy+hBQPDLnaURShV0L9b5WkTZj2jKrwkpeHeKFhHKSk5tFBsXZwMaAbYx4FGvEg9V/OGoCPikKeFaBjoqqgEZEQ6n1urQTbQmqQTsXZjC5A1abhI/xNCRL76J9nK4t4BcBeC/4ydOX4npuR8KOfav/LtyyD8mKM1egQQUW/6dFAnNBgRBVxPvEJhV+h7vOxD0+wZf8A0IfpKj3aXQxKwejsdiLTAlAJXrkFamawCALNjsEtYRQ0OpQtb2PzMPcGnNtUSmblRYIHXIbPnu1DK65pQsM/ZJw0e05KbWX+j2Wau/b4HgNkOCwyOniD59fX/sNQPP3oXiIziLEc8BmdWdwEDOCVdhquYffEFx7y/N8/MGcapzOPZzllT1HfYN8R1WWeG7GF0uIhdQoRTS+EBRMhcmuseSRD++J8sS3VLAJZdjOi4pSGQoG0aK1MpQkQUOA+4ubnIfDi01IBpz5GEQMGjqEAjO0RsptZ43dE5N7BO4Nbzepbop7NSylzRBcd+9dYPUGqFLDALeIA6PgHeNgp4oGJMQ38x9TfrGrOxaiROEoR//9fT9O0RKIYCnzeYTz+F9ZOyHV+m1LVGyLL6WFNVkH2l7QaAfosIWmXA6ZfjYYuC2wmeBx8Z6gAa1l8GwLIkgcOYjFwZm1N8vQBq1RrbWrvjL48A7UcnsvOVbLSx4fI4ObfhrV69aPbFvySVKVNSG7zm8ohHakMPTTGzHEr3E1Bt4jYBIjZuRwmKIy7jp2/Ml7b4hR0o2NLp8Z3fCHfB3F+U0m1CGLHoWk8tkMu3L5c04IC1MqTNLsRCXCCT63FFnBIsIZ+Px7sKAGnqrQhUMD3dokJNw+yfQJicZAQdDzIsNLmnk71GMsQYPXIc4wDyErTk7HvUQYTgqI8mi1OnHSW9OE0RNrZ/CrgI/sZie4IK0EueNBQUo9/7788cPDofoB6P75tRerLjQcVRjJ7qxvn6F5eGjstRGpUZ0y2pt0p6KD1+/QoNCZSHUpjpHESPoPZAQ2feaKc+ZwGbtXvmF2SihRnOH1ulR9pXoFbk8lswwhS579rLZFYDFhSFifRKg58RX5LVexyN22xZ5u+BpGMWY661FW6u200syKemKLh7MFbFDZ0ZBPEE835ANCC8WgTmhLYBvc732ZV26xfbAOtV9qUXB8Vjo0lRAAbFFHuLdmnHTtlJt5OYr8DUxVP1+v33AvJ6kCzKY4HLECAdOnY+XHQrPVkYXbRzUW0Kzp3g3skqhhH6SDb8m8yak9KuZqs+knXSTnniFxbhpScHcfW1rFqQsZi33Ac5ISi4Sobh8dBRKrIaRqFtkR23SvRAsgJkSSUuTOlqYRW5AEoW0BAgTi6pem9i+lAEitdDhdRT440z1nonIeMuTBI/tKRw4pDL2ZTyxKpWpmjWJSUuIroNuyCv+bu3mQY/dv9Tn51YD3orPjVzmO3XNW1ahZbXJtm+MoELz+IcPHz8dvTn8fKQc3vgWOr4ArfruOt2HMn9xXct6+BV2xaDc6hbWk+Aqa4V/6UO5vDUdPibiUhm9eAiEfUa7uVkOAgssLemTYrj3yaLCkyz1J5VegJqjiZ6hX5ajRCeyKbJwo0egYDLSH1BatbLccpxXLmcoyxL498qvBShtdNSYY7sL1ehgHi7m0OrCyDJWzL6o5e83L0McZc5nLZlruaXz5D5NgRGoU+E9ibE4pqehCFGhO8VQ1553gqOgEtl4I75kC/GokH/tFhc2+w7pl/bJqwplXhi8sFFbJVAvdymVuJRw1TRvSvMlYqXYie3H07frL/lO0oaBzYwcPPgeQr7pD9kMbJzqwkITHW2Q9Wx0ApDpVGz6WM+w17lkdxEnMigukeIth6VXEXI8d/FqxWyiInRIb9xWzNJIuPDKLVokXZBzYxevKJMdiVQwoTQDCwfPzIdP3l1Q4zpZ5TW58pXkeS+1urh7zfCtFoFZXlsL2HLOclVi8V9GzRVeKSZZI5WWkHaWHpJlwpWptJiN4XlfQqn05MnRtcSJogpE3RofGjENSym0QGC54AumHXlvhX6NesacKlagIENzBaqbczjkQFt9S1ZeKc2KtdQoc2SVFMvoslMm319tdnHJPfE5hHmVnYeklbOEwbZZbsfFpZFdJzuOrgbiWNOEc+6oZT0buPGVef03RXFkdVACH9BBjWuw61KSuuks6Xfbbb0uCp4wgFja8WaTaSJcJUEqmsX+wE2GQdDncJDqVC7YjEOtgoA1hdMA4EqtlZbhY2rTOKKi5Td/Pt1VRtqaBvPA3pH6A102YFr4rkLv3nAALqnrwrJYRwhxRDbrMFpHW7hfaDKrZVzGS99uicaYD1Oj+pR40eCHo1OaD9v04aG67AePNvi8452YHzR2V49/xRzgVFcVqpoESmCGZ5Ca0f/WGVg2nHVDasR35caOtFD5ASxPBgkbCJ6rvABa1v0gWhwKMohuymLapLpZu/VVvzkOgOLmhve96jBtfccKEhL6DAHTRACTEyO3Lrl+riluh5XuE7Z9wffEwlBz6RKEs5kiljAXishGzzLbbYjh4x4uyvNgqiAyZJ3wrrdCe6T9AbhID1DFXrSsbYMySxw7MyBUu7nV3sqvJ9R61S8oFZO6QcIODtuG2HUK0anlDdalbyoSFqteRQwZARTEzUk7Cwuk0W7kl4XYgIkd043LDCemhUCSkVCP58+XOThZTh1FeRhFRRskHR75TkW8fJGuhMuvPr4tNXcQMumlWjpjTYNAgPLlp3n6N0+Q9SeBvJaXTwKZVVzd5dqoR2WV9bSaj6u6EBjXaWZ/cGM/ixYpYJNdPW9odPTZCD2eDUqnNtY+mZqKhl0skWlQyr6SHqYYB6OLYH1LL86LhJAp2aTkd1aZmHcJq+NYK4s5X/m8W7nJCFbC67gnG2hwC/CCHxZFlccShrUKs9oCZsX3/b4/OXxzOnh3/OFo8Bkejz/8MHh7/HPN9b9VfoBFv7+liVb+33UMRE+9liV885qaw14LPfXwnj8YpMGbz+gyiN7AG8948bzD9LSfOUuj9Ta4s55tCHc3YdvVk1FaHWdz23rCuLphKnXh6KrjUKLb1etMRVnNg8lqO1v+JFdWlRApNEsLLVhX+xBvRJGy9nf2Q6xzQ6TxPnFhEmN3eq0Puh///v6Ihr/W5mhrtCNdqLrtbqe7VeKwKNzmJm4QzrPUrTvdtuYNB2XIkcWEPxopKN3Mt025IG7RK+jKtetFt722hW6E5Ev4XbvdZj/I7lyjhPbCuYb9e645fWnuYHR3lpEjlbzaSPWwkref6ROJHnkvM6QFnWlebb7vK/h8n/Ycofc6NZ5owguwwsnvVT7f6rb7qt1Wjo0v8N/i1WemD+HLgvNchWOgnFdGqQcD5F6OfW8uLvPp8eh9x4dFfRYYZpmPYG70a8bBuYoiT85jZ/PF5ubmAqQg9epys7vT8Rfs8ife7ezs6M58ZtZXpE5e0d0lKwoKkEefcsNBkkI3INPBr9qpz6KQXg7agH1rMk3vyQuGWktI7oBtkwxdnOb7EjaUm0S45QBDSawUhwj2BlXNEhlx0fTPnOzSh7ML64YoebFj/QORicxIhNS914MudH9D5SCYaO6A3DV6OYMFv5N5AglPJ3HPo+HjNAru8D5lcnDCvaCAteHqpNpmykEPN2BC62PMRXK+No1QK2j4/E3392ie90V8EoqArByi8HJ3mA7E3cMgD4phiEl4t9zpFPaBe+va/YIR/omFFzXLoYSRTjmQC3MQASnGAd53itlwRfoQ/Axjxq3LsdsgUtI8o5b497CFFfhYv8plSjjaZE46yptguU9PrZFfmvjr7fqaP0iQpFbOX6jMvQc6k7eaS6cezZtHd1HVPDuEjwXCyFyKZAsTd9psjlqB3d//H8MXTnqysiOg8LdDtoikKHZbLiMI+y/zAC+olS6vf5mzBubHT8cY2ApiL5zzRhSdZmM5KC5t1sqJizwv0NNi33QqZdD7ADIZKhh7l7GkU/mBEkktMvphnz0m7P+x+VwmXJVorDPHiZIBrvHaUb4T0lytaBHxSOy50Gh+5oscEluFrW2c/dfe/vkaQLnYuGoN+/tN9D/5L9F1cnUW/lR78t04la/25asr9YpA0Tu8mYHfrtF7evnd5it8tzgbXtj2bok7hOIk2soZZusGJOP4nv2gMC/feYNDCWj6cUAuetnc8ZBKb7aapSfYENRoXdaVA6YnoZKPhj1Plvg08U5RIP1LR+6l/TSe+buY9QKI/AMRMbvWFSADW8UTB/Fkzp2nMg5iAsEQGZV0RlqBe6C34jd6IYGcd3tLN4ivw4mEF5eXuSXBUyg69HzI7pjSMWkVjvX1KzCdZYzr49SP9UjOjGnlhhSFCeWqVTK2mnOJ5i+isS/pW8JHVelcQmWRfUkdgvfPWZL6qrT8bZQ/yssDG5k0wIKAEB0y3yOgqjAHhb/IdU/9KndhyXhKbkxAmCqltFKnLKJbEcY61+h3hMaF3WVeMrls9dKSfj2buCHdr9sMpfKGCAWN1gAru7UNtbQzOCKxRpBy1P2N/vue/oup0kw9IoPZoxhFS1ZG9QcULTcOjxpzqtRzOqOFNccKCy1fPQPc6BNElUoJJ2YAku/NbGq4lujZrkgYJJlC5XeZoYMOkQHINjopYD8nESwOOG0kIrPlMZVPrD0U2tV2iAIPbEEUuIEf9ulKGSFOYiRWgrFtw/GMFRWk87yOZgkm67OiETe/8ZsfR3xcs7KzOFfHtPpIhVgtUTClX+F4DAhyEs4QxHeMIA09OFRbrz9BwyzhUu0xq0rwveVSXtspyrV8P1tJ7k6hz6B7ZvQXM/Z+yTJlmBrclP0rqlxrVnfbMVOpteF/tpmriTIeyeRVYmVmhnccwEGmLNQcmBo0f7h2L5sH/bNf9y+e0Q+aUHxKnvX5T/OMljhtyvbZr9kPrkAzjw+FTx2bwO43nWcHNpMFQ8TrVtE3yvqKfz4byvggGRAtkAjdJIHMzLoVXfrcEzQoN/aerK8D+PV1usKV0tmG5F8zdq+SvoBeWZnxEzXpa0lpur5iFspbonKl+IYuZAT0JbeYh5ReVCMWB974V1F83xxel2uY4YMTJHyhGKctcFPj/sA3Dfma2c8vFOr6Cxkbf5nyxyajBPz5DtkqbNPtS/qz04Y/I380qtBPM7mRjbZAhGjE0qeKl5Q+XeQUoMMNo5AuJpOUaTBFc6qproOahGmzW0BOUnYxlYy8p7dRwFeHKJeNWJj6uhCeCbm+tCzNq5CdJENFOmGz0TzoMTEDoxPkL5ZQ8mzjYJ8f7Hm3xdef0wVbLQFIEeexba5b6F2ojzDIx5MB7lUDIoCHjC/VotTPfWMgOvpFHSCl5D53c5+7uW7/ulq/n4s1hSBarGHvd0o6Xux8bg6zbjxnfIxplAu5SUqVDJ19G3iOje2bAygnoAShjBcZLhfoHJYzlbesDmU0QBSeZJkr2H4BHFr0x9ZvSBZH/MEwSWp8Pv+gXUNPMIwJc6vVTZRJN+/SWwmLLytjPXzlzWXoTClV9s/pkm2pFm5o3jsOpyYHlkxKsmyb4PkiiikOlOLjuUpjd3LpudakJ1B8bk0UG6ghAZUWIocSbf5IWyvjo2qoDSZDKUOFxoN0gjhIElXRm6zzdZgatm6BhQSUiQX11Cx8E7TrvJNkgJdB/X9EqvILD0EssmniaCMhmiRKmUuXDJM0Qmo5S1vAsZMUOAEFJfUe7ea46s3lZ0F22Q05mqkkhxfGLvuIxJC/V1JIkQwsKSRaWtqefoVHj8R6dY8HJYmT7oijAObSaJN13iWpRPXZERd25q7PWuH2LMnHy7OHcttL78eSx3DMlJUX2MudQcpTcj3maixyNcyS2CGRVeaw0x1uiYL+nfkj8X6LvqW7WlS6qcJ3ww3jTk8kk2WUse0lzqowkMBt5awY5+iaxO9yMkF8qUmaqAk5w6VY0EUw/XLBYTVM0GmIwFSmv8uPG+fSWWGINORyG8Xvg1pNDsf/pG78I1M3KgAoZwwu0TolF7V88Z+cj39uzscle8GfcmGYMIIW0hhabvqtV4atjMODUioWMPij7yMz7yHTc8MtR1RP6YhzrEsx1f5pq7oty0SO6k6yHMCPn1e7pl7125S2Jds3z8QPj1sgnzpcPyIGASXzFqkG4JkW0nJ/fyNIFUULrP6gKAQs+ZAYBMLscXEGGPD27w4z4CC73yHKIEOWpqzbbrco5GDFgIBvdMaXLvVnc7L3NXoiUXcD7TrwSzPyFHKU1vjRo6Bq2wv2zxcpyYXXfpWnft6bXu6TRddh4TnMrvpNPNdUuRgPQvQDGUuxUHkcDy7HbngzHYh1lr0vOqSg5y419IAoAur9RZ17fjbVWvTPPBcGUBoJ9DvEBlDj24XGC+639qpxAgRwq70FIzg/XyM46DGw9gGPnJQYZo3idB8YQ/CEafmusWLD0Q20SibNVh0W//bAAjSyU2QfO/k+MqxAHBsRGDdN67VlnTXQztS+KLWOyDCAQiAC3+DwpK9K1Kwjud5W89CXughSf7ArBdBlYadeJcyhOsThgSENKPQBGVDGHoEmu6H44trTUNJIEc8V4+YLl72pOHmDpxiX56ijYial1A9I4abV8mTUJZq18jE5ovKmZJq7l4dkUtEp6A3alSXJeD7mtLOCMr2SfoxtaXqbpZrA5ZujwbSiG+BYfCtZPiIBwxoFBvAuQ6YhsMFYBn6Cd8JTAt41TiudN2EDrnPgXHIX7FJ+/tCwCcH9SoeEgEO/SmIqypGoDXsti3rFsIxPR+8//nQ0eP3u8MPfZFjGKgEZyfUsDcarB2CwP8EDYyP+dnR0Mjh+O8Bbd48+nObt+cJaH0yuviZfrr5+CTw/+urOvCD6Gl3+E3jD14Au4/w6gZX1NUWHma9DF5hbYkvrRj5hycnhp8MfPh2e/HXw6SjfXPPgZC91r/abB72zw/Vf3PXfBhfkKXDrrF8869kHB1NbuBec7KHaItkna4i9jy/IAYf9AuBnHwDZpm+AQoMNc99/PD189y67gjZhiWegaJpjOrMMNbnBktYcvVS5wTtvyzF8BLTAUVHO9A7I2YyFc4Y6wjWEKZ6DoYzXZJOn18YZiqpLcwXKwg3T2Yd0nYadRnMMKckdA6sFF1DSV3FZqj3y8WJNtG7jp1LaOFfboAWIvI0/P1G6ubmBA1rciCUy32rtz9i0Tsl6KoIMr5YauZzNSMnUeYuQwLLOKCQ7FkcRsO9BTcoV/a46JD+owJstTTOAd2fj1JT75W14w5vZlIKISQDBPY3fNepvtMuJqeL6udJN07FWupXud7iCTr/JLYsF5Jz+BonqNyXJM1/78Ua3UYlpzLxybTUb2RLzmNVUeiAoPAnoNiPbNGAtu89OGZ7EIY/urcsZuwRRLTVFrWpqMi5xq7MvYfcy9X1YplurMEoplakC0coMRVr1Oh0qK+bselNWbe4YY0Fo9qyVldsyD+ZqBrC61DRVqJSGHj/e5pWtqsKOUnuZmXQKXu0yM16iy+8yM1f6835xU3lA4pTf40ajP05xTvwALUNX0IF7Br9cd547LwqOzgy/bLJZMgW5bXrfVUxQFM/J4VzSvNqn4ohWzqbL7xaSN8CoKrryadltQ/U3DhVvBXqSu8bnNQofukuzJNtGy6Q1sxo60W/8rLnSy6v7tHt/+O7GJXcQVVzLg64mOAzFIxndJTP2R2n11UTmsQzwd4Ow5iaj1zTZiJKYdjzo8N3vfNxZKeR86ZFmGiXBHc6NenMHkrGfxr7viMiVU3jGdXZ0+uCzD+N79POpuCum8i7Iq2CU3QmJD5cT/puKD/B3pO6Gwb/uF/iykEIcibKc/AkPJT1TGnevnJhzETbQr7Njn613Lkh6WLBDknvFfoDwoJ1V+ApMusFWJ3JiuJwi61pxdQH+gMG3L+SL7+QLAyM16plASVAxbRkilI2binKI/RGjEk1HYo3jO4kUPuO5Bv4Umi4gV4ELaqm5t+oVKX+yn+qCX4GDLZCwK2MZhPbMiGgQIQF8F5PPRJZsABxYRCBtJhwUy+sYlxsXxMVHbgvGLeB/rH9bFihQaQVYcRfPn0+z83d7/dVg/eI5HL3hXTDhEzW7IB5sHMgjbN4F2XR8LWthGpBZVXNohIP73ob2Onn2eOhl+NM8Ze19C/KwyjXEhevyhni7Kt5kk6rSJef9ZvK+yQe9LEQefqxT5+yDryh/rpOzJr/6KmLr+cfETW5EUca0d/br7nxx8WwWk2tp8+xXm/2ubfFht6Irdqleg4A+B3ySePgV1mXqx1/vxkF406N1mI8AWeM4L44AUT+e4x8HgAAbPrj6Cjz4K/Dfr8h7vwLf/Yq89oC0UchkMdnu2cF3FzqEZ/YBhYrU464rQwomW+YXwoGfL9Uz7gn/XW+NDyPRxH8ujQ+XnrZrL0Ff1c+19vLzP9m/lbZ1qX2YK1dcaSDmLgR5EUDEeGdHc7EHktm6GkgV/8E78XTjLFaWICmTnAS/kv2cFE99ENEc3Ds5j39TnVfVdl11xhaXrSMUB37EdQdsTdSii9hR3lKqJDxv49u6s/bE9wJXemkxDDIk0vt1VhcQVTTseidSTe7JoOALWb/2JJyhYcRp0YxvCKs+AltyVNaoiW4CqRTUKizmp84JGmRX89jRG/OCZOjGXrmOBvjPAIS1Eodq+du9TAhLnYc+RJ9lOFgr/lrhYi3QWarYEqe6gUzm3P5GndeDnKx/f8dp6WKJALOZqyEos//1epeHqazqNVUPFW3lJZ5LFVVlbtmlBnXDj6iWZ9a0WM4bl/LJJVozSRtw6qdExavwyXzd4XUwplQAtBcypFXqFnkuQXo4063gmwztAYyznplr4B7FzQsTinfvpuJcm23DgqPiyFA/6Oz+EKxXYP+Yh5pbX3n1lv3DUy01YTQ+K/ZfOPsvm3jME/eQicfyA8HC9PkiN57HzxSBncbRNAcWX/lxev8NoFFPM8TESqSryfDHLAdZq31Z6A+foCmcC5EcwkRY/HBSzjo9pWdZSD0LKdxFAYPK5jAcKxEtAMiaW6FnwNhi/yrAcyENEgekU5y8ArOke4JtA6Q0EgyS7aAy03tfGaXvJuOB5w/HLudPqcqX/ECRp95heYWAE2Nn/k/kyR8VefKfAJI/P4Dkz7aGCX0IdKQYFbEkjoSd0sxYEsqQsSy+JCv0bwkBeUiAih73kbfF5ZVBlSa3P8rIlrcwFc1eJfU/GnfBBTUGq2PS0rNaRTPXGUeaCtiUQ9R66nRH1vvXDeupVXDy10+p1obVpIxMzyiNkgq50LrFAOmfOqh6r4tQ1xb/F/vXctk="
MODULE_SOURCES = json.loads(zlib.decompress(base64.b64decode(MODULES_B64)).decode("utf-8"))
MOD = {}
for filename, source in MODULE_SOURCES.items():
    ns = {"__name__": filename.replace(".py", "").replace(" ", "_"), "__file__": filename}
    exec(compile(source, filename, "exec"), ns)
    ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    MOD[filename] = ns

def set_download_dir(path):
    """Set Android's Download directory and discover files throughout shared storage."""
    global DOWNLOAD_DIR, STORAGE_ROOT
    if not path:
        raise ValueError("Direktori Download dari Android kosong.")
    DOWNLOAD_DIR = os.path.abspath(path)
    STORAGE_ROOT = os.path.dirname(DOWNLOAD_DIR.rstrip(os.sep)) or DOWNLOAD_DIR
    for module_ns in MOD.values():
        module_ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    return DOWNLOAD_DIR

def unique_output(path):
    if not os.path.exists(path): return path
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{stem}_{n}{ext}"): n += 1
    return f"{stem}_{n}{ext}"

def safe_file(name, exts):
    """Resolve a selected relative path safely inside Android shared internal storage."""
    if not name or not isinstance(name, str) or not name.lower().endswith(exts):
        raise ValueError("Pilihan file tidak valid.")
    relative = name.replace("\\", "/").lstrip("/")
    if any(part in ("", ".", "..") for part in relative.split("/")):
        raise ValueError("Lokasi file tidak valid.")
    root = os.path.realpath(STORAGE_ROOT)
    path = os.path.realpath(os.path.join(root, *relative.split("/")))
    if os.path.commonpath((root, path)) != root:
        raise ValueError("File harus berada di penyimpanan bersama Android.")
    if not os.path.isfile(path):
        raise FileNotFoundError("File tidak ditemukan atau tidak dapat diakses.")
    return path

def relative_storage_path(path):
    return os.path.relpath(path, STORAGE_ROOT).replace(os.sep, "/")

def run_captured(fn, *args):
    out = io.StringIO()
    old_input = builtins.input
    builtins.input = lambda *_a, **_k: "y"
    try:
        with contextlib.redirect_stdout(out):
            result = fn(*args)
    finally:
        builtins.input = old_input
    return result, out.getvalue()

def fix_no_preview(src):
    ns = MOD["FIX_NO_PREVIEW.py"]
    stem = os.path.splitext(src)[0]
    output = stem + "_FORMATTED.epub"
    if os.path.exists(output):
        os.remove(output)
    changed_files, total = {}, 0
    with zipfile.ZipFile(src, "r") as zin:
        for info in zin.infolist():
            if info.filename.lower().endswith((".xhtml", ".html", ".htm")):
                updated, changed = ns["process_xhtml"](zin.read(info.filename))
                if changed:
                    changed_files[info.filename] = updated
                    total += changed
        if total == 0:
            return {"message": "Tidak ada paragraf yang perlu diperbaiki.", "changed": 0}
        with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(output, "w") as zout:
            zout.comment = zin.comment
            for info in zin.infolist():
                zout.writestr(info, changed_files.get(info.filename, zin.read(info.filename)))
    return {"output": os.path.basename(output), "changed": total}

def epub_metadata_title(epub_path):
    """Read the first non-empty dc:title from an EPUB package document."""
    with zipfile.ZipFile(epub_path, "r") as book:
        try:
            container = ET.fromstring(book.read("META-INF/container.xml"))
        except KeyError:
            raise ValueError("EPUB tidak memiliki META-INF/container.xml.")
        rootfile = container.find(".//{urn:oasis:names:tc:opendocument:xmlns:container}rootfile")
        if rootfile is None or not rootfile.get("full-path"):
            raise ValueError("Lokasi metadata OPF tidak ditemukan.")
        opf_path = rootfile.get("full-path")
        try:
            package = ET.fromstring(book.read(opf_path))
        except KeyError:
            raise ValueError("File metadata OPF tidak ditemukan di dalam EPUB.")
        titles = package.findall(".//{http://purl.org/dc/elements/1.1/}title")
        for node in titles:
            title = " ".join("".join(node.itertext()).split())
            if title:
                return title
    raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")

def safe_epub_filename(title):
    # Remove path separators, control characters, and characters rejected by common filesystems.
    title = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", title)
    title = re.sub(r'\s+', " ", title).strip().rstrip(". ")
    if not title:
        raise ValueError("Judul metadata tidak menghasilkan nama file yang valid.")
    # Keep filenames manageable on Android and common desktop filesystems.
    return title[:180].rstrip(". ") + ".epub"

def validate_epub(path):
    with zipfile.ZipFile(path, "r") as book:
        names = book.namelist()
        if not names or names[0] != "mimetype" or "mimetype" not in names:
            raise ValueError("Struktur EPUB tidak valid: entri mimetype harus menjadi entri pertama.")
        if book.getinfo("mimetype").compress_type != zipfile.ZIP_STORED:
            raise ValueError("Struktur EPUB tidak valid: mimetype harus tanpa kompresi.")
        bad = book.testzip()
        if bad:
            raise ValueError("EPUB rusak setelah diproses: " + bad)

def commit_in_place(src, staged_output):
    """Safely overwrite the source using a same-directory temporary file.

    The processed file may live in the app cache (a different filesystem),
    so it must be copied into the destination directory before atomic replace.
    No persistent backup is created.
    """
    if not staged_output or not os.path.isfile(staged_output):
        raise RuntimeError("Proses tidak menghasilkan file. File asli tidak diubah.")
    if src.lower().endswith(".epub"):
        validate_epub(staged_output)

    destination_dir = os.path.dirname(os.path.abspath(src)) or "."
    fd, destination_temp = tempfile.mkstemp(
        prefix=".epub_toolkit_", suffix=".tmp", dir=destination_dir
    )
    os.close(fd)
    try:
        shutil.copy2(staged_output, destination_temp)
        if os.path.getsize(staged_output) != os.path.getsize(destination_temp):
            raise IOError("File hasil tidak berhasil disalin sepenuhnya.")
        if src.lower().endswith(".epub"):
            validate_epub(destination_temp)
        os.replace(destination_temp, src)
    finally:
        if os.path.exists(destination_temp):
            os.remove(destination_temp)
    return os.path.basename(src)


def reader_open_epub(relative_name, chapter_index=0, search_query=""):
    """Read one EPUB spine item for the built-in gallery-style reader."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            raise ValueError("Package OPF tidak ditemukan.")
        opf_data = book.read(rootfile)
        opf = ET.fromstring(opf_data)
        base = os.path.dirname(rootfile).replace("\\", "/")
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        spine = next((e for e in opf.iter() if e.tag.endswith("spine")), None)
        if spine is None:
            raise ValueError("Daftar bab EPUB tidak ditemukan.")
        chapters = []
        # ZIP paths in EPUBs may be percent-encoded; keep a normalized lookup so
        # relative image/resource references work across common EPUB exporters.
        zip_names = set(book.namelist())
        zip_names_folded = {unquote(n).replace("\\\\", "/").casefold(): n for n in zip_names}
        def resolve_zip_path(path):
            path = unquote(path or "").replace("\\\\", "/").lstrip("/")
            normalized = posixpath.normpath(path)
            if normalized in zip_names:
                return normalized
            return zip_names_folded.get(normalized.casefold())
        for ref in spine:
            if not ref.tag.endswith("itemref"):
                continue
            item = manifest.get(ref.attrib.get("idref"))
            if not item:
                continue
            href = item.get("href", "")
            media_type = (item.get("media-type") or "").split(";", 1)[0].strip().lower()
            # EPUB exporters often label spine documents as text/html. The
            # spine establishes reading order, so accept both common types.
            if media_type not in ("application/xhtml+xml", "text/html", "application/xml", "text/xml") and not href.lower().endswith((".xhtml", ".html", ".htm")):
                continue
            full = resolve_zip_path(posixpath.join(base, href))
            if not full:
                continue
            try:
                raw = book.read(full).decode("utf-8-sig", "replace")
            except KeyError:
                continue
            try:
                doc = ET.fromstring(raw)
                title = ""
                for el in doc.iter():
                    if el.tag.lower().endswith(("h1", "h2", "title")) and "".join(el.itertext()).strip():
                        title = " ".join("".join(el.itertext()).split())
                        break
                if not title:
                    title = os.path.splitext(os.path.basename(href))[0].replace("_", " ")
                body = next((el for el in doc.iter() if el.tag.lower().endswith("body")), doc)
                # Serialize XHTML using local tag names. ElementTree otherwise emits
                # ns0:p/ns1:div prefixes that are not HTML tags in the WebView.
                def to_reader_html(node):
                    tag = node.tag.split("}", 1)[-1] if isinstance(node.tag, str) else ""
                    if not tag:
                        return html.escape(node.text or "")
                    attrs = []
                    for key, value in node.attrib.items():
                        key = key.split("}", 1)[-1]
                        low_key = key.lower()
                        if low_key.startswith("on"):
                            continue
                        # Convert book-local images to data URIs: the reader
                        # HTML is rendered outside the EPUB ZIP filesystem.
                        if tag.lower() in ("img", "image", "source") and low_key == "src":
                            src_value = str(value).strip()
                            parts = urlsplit(src_value)
                            if src_value and not parts.scheme and not src_value.startswith("//"):
                                resource_path = resolve_zip_path(posixpath.join(posixpath.dirname(full), parts.path))
                                if resource_path:
                                    payload = book.read(resource_path)
                                    guessed = mimetypes.guess_type(resource_path)[0]
                                    ext = os.path.splitext(resource_path.lower())[1]
                                    mime = "image/webp" if ext == ".webp" else (guessed or "application/octet-stream")
                                    value = "data:" + mime + ";base64," + base64.b64encode(payload).decode("ascii")
                        # Avoid srcset overriding a resolved local src with a
                        # remote or unresolved candidate.
                        if low_key == "srcset" and tag.lower() in ("img", "source"):
                            continue
                        attrs.append(f' {key}="{html.escape(str(value), quote=True)}"')
                    void = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
                    opening = "<" + tag + "".join(attrs) + ">"
                    if tag.lower() in void:
                        return opening
                    inner = html.escape(node.text or "")
                    for child in list(node):
                        inner += to_reader_html(child)
                        inner += html.escape(child.tail or "")
                    return opening + inner + "</" + tag + ">"
                content = html.escape(body.text or "") + "".join(to_reader_html(child) + html.escape(child.tail or "") for child in list(body))
                if not content.strip():
                    content = "<p>" + html.escape(" ".join(" ".join(body.itertext()).split())) + "</p>"
            except Exception:
                title = os.path.splitext(os.path.basename(href))[0]
                content = "<p>" + html.escape(re.sub(r"<[^>]+>", " ", raw)) + "</p>"
            chapters.append({"title": title[:180], "content": content})
        if not chapters:
            raise ValueError("Tidak ada bab XHTML yang dapat dibaca.")
        try:
            title = next((" ".join("".join(e.itertext()).split()) for e in opf.iter()
                          if e.tag.endswith("title") and "".join(e.itertext()).strip()), os.path.basename(src))
        except Exception:
            title = os.path.basename(src)
        index = max(0, min(int(chapter_index or 0), len(chapters)-1))
        result = {"title": title, "chapters": [{"title": c["title"]} for c in chapters],
                  "index": index, "content": chapters[index]["content"]}
        if search_query:
            needle = search_query.casefold()
            found = []
            for chapter_no, chapter in enumerate(chapters):
                plain = html.unescape(re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", chapter["content"]))
                plain = re.sub(r"(?s)<[^>]*>", " ", plain)
                plain = re.sub(r"\s+", " ", plain).strip()
                folded = plain.casefold()
                pos = 0
                occurrence = 0
                while True:
                    pos = folded.find(needle, pos)
                    if pos < 0:
                        break
                    # V28.8: compact excerpts, with five words before and after the match.
                    before = plain[:pos]
                    after = plain[pos+len(search_query):]
                    before_words = list(re.finditer(r"\S+", before))
                    after_words = list(re.finditer(r"\S+", after))
                    start = before_words[-5].start() if len(before_words) >= 5 else 0
                    end = (pos+len(search_query)+after_words[4].end()) if len(after_words) >= 5 else len(plain)
                    snippet = ("…" if start else "") + plain[start:end] + ("…" if end < len(plain) else "")
                    found.append({"chapter": chapter_no, "chapter_title": chapter["title"], "occurrence": occurrence, "snippet": snippet})
                    occurrence += 1
                    pos += len(needle)
            result["matches"] = found
        return result

def reader_cover_data(relative_name):
    """Return the embedded EPUB cover as a data URI for the library thumbnail."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            return {"cover": None}
        opf = ET.fromstring(book.read(rootfile))
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        cover_id = None
        for meta in opf.iter():
            if meta.tag.endswith("meta") and meta.attrib.get("name", "").lower() == "cover":
                cover_id = meta.attrib.get("content")
                break
        cover_item = manifest.get(cover_id) if cover_id else None
        if not cover_item:
            cover_item = next((item for item in manifest.values()
                               if "cover-image" in item.get("properties", "").split()), None)
        if not cover_item:
            # EPUB 2 guide references are a useful fallback for older files.
            for ref in opf.iter():
                if ref.tag.endswith("reference") and ref.attrib.get("type", "").lower() == "cover":
                    href = ref.attrib.get("href", "").split("#", 1)[0]
                    candidate = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
                    if candidate in book.namelist():
                        raw = book.read(candidate)
                        mime = mimetypes.guess_type(candidate)[0] or "image/jpeg"
                        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}
        if not cover_item:
            return {"cover": None}
        href = cover_item.get("href", "").split("#", 1)[0]
        image_path = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
        if image_path not in book.namelist():
            return {"cover": None}
        raw = book.read(image_path)
        if len(raw) > 4 * 1024 * 1024:
            return {"cover": None}
        mime = cover_item.get("media-type") or mimetypes.guess_type(image_path)[0] or "image/jpeg"
        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}

def api_action(path, d):
    name = d.get("file", "")
    if path == "/reader-cover":
        return reader_cover_data(name)
    if path == "/delete-book":
        src = safe_file(name, (".epub",))
        deleted_name = os.path.basename(src)
        os.remove(src)
        return {"deleted": True, "file": relative_storage_path(src), "name": deleted_name}
    if path == "/reader-open":
        return reader_open_epub(name, d.get("chapter", 0))
    if path == "/reader-search":
        query = str(d.get("query", "")).strip()[:120]
        if not query:
            return {"matches": []}
        result = reader_open_epub(name, 0, query)
        return {"matches": result.get("matches", [])}
    if path == "/rename-by-title":
        src = safe_file(name, (".epub",))
        title = epub_metadata_title(src)
        target_name = safe_epub_filename(title)
        target = os.path.join(os.path.dirname(src), target_name)
        if os.path.abspath(src) == os.path.abspath(target):
            return {"output": relative_storage_path(src), "title": title, "message": "Nama file sudah sesuai dengan judul metadata."}
        base, ext = os.path.splitext(target)
        n = 2
        while os.path.exists(target):
            target = f"{base}_{n}{ext}"
            n += 1
        os.rename(src, target)
        return {"output": relative_storage_path(target), "title": title, "previous_name": name}

    if path in ("/bulk-count", "/bulk-replace"):
        ns = MOD["BULK_FIND_REPLACE.py"]
        src = safe_file(name, (".epub", ".txt"))
        pat = ns["make_pattern"](d.get("find", ""), bool(d.get("case_sensitive")), bool(d.get("whole_word")), bool(d.get("regex")))
        if path == "/bulk-count":
            count, _ = ns["process_file"](src, pat, None)
            return {"count": count}
        if os.path.splitext(src)[1].lower() == ".epub":
            validate_epub(src)
        import tempfile, shutil
        with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
            staged = os.path.join(work, os.path.basename(src))
            shutil.copy2(src, staged)
            count, generated = ns["process_file"](staged, pat, d.get("replace", ""))
            if count == 0:
                return {"count": 0, "output": os.path.basename(src), "message": "Tidak ada teks yang cocok; file tidak diubah."}
            output = commit_in_place(src, generated)
        return {"count": count, "output": output, "message": "File asli berhasil diperbarui."}

    src = safe_file(name, (".epub",))
    if path == "/cover-meta":
        ns = MOD["COVER MAKER.py"]
        with zipfile.ZipFile(src, "r") as z:
            opf = ns["find_opf"](z)
            title, author, _ = ns["read_metadata"](z.read(opf))
        return {"title": title, "author": author}

    import tempfile, shutil
    with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
        staged = os.path.join(work, os.path.basename(src))
        shutil.copy2(src, staged)
        stem = os.path.splitext(staged)[0]
        details = {}
        generated = None

        if path == "/remove-cover":
            _, log = run_captured(MOD["REMOVE_EPUB_COVER.py"]["remove_epub_cover"], staged)
            generated = stem + "_no_cover.epub"
            details["details"] = log[-500:]
        elif path == "/no-preview":
            result = fix_no_preview(staged)
            if result.get("changed", 0) == 0:
                return result
            generated = os.path.join(work, result["output"])
            details["changed"] = result["changed"]
        elif path == "/make-cover":
            ns = MOD["COVER MAKER.py"]
            with zipfile.ZipFile(staged, "r") as z:
                opf = ns["find_opf"](z)
                metadata_title, author, root = ns["read_metadata"](z.read(opf))
            # A manually entered title remains supported in the single-file tool;
            # batch Cover Maker defaults to the EPUB's own dc:title metadata.
            title = (d.get("title") or metadata_title or "").strip()
            if not title:
                raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")
            ns["add_cover"](staged, opf, root, title, author)
            generated = stem + "_with_cover.epub"
            details.update({"title": title, "author": author})
        elif path == "/compress":
            ns = MOD["IMAGE_COMPRESSOR_15.py"]
            Image, ImageOps = ns["load_pillow"]()
            _, log = run_captured(ns["compress_epub"], staged, Image, ImageOps)
            generated = stem + "_compressed.epub"
            details["details"] = log[-700:]
        elif path == "/compact-spacing":
            ns = MOD["COMPACT_LINE_SPACING_FIXER.py"]
            generated = os.path.join(work, "processed.epub")
            adjusted, cleaned = ns["process_epub"](staged, generated)
            details.update({"adjusted": adjusted, "cleaned": cleaned})
        elif path == "/blank-spacing":
            ns = MOD["REMOVE_BLANK_SPACING.py"]
            _, log = run_captured(ns["process_epub"], staged)
            generated = stem + "_clean_default_spacing.epub"
            details["details"] = log[-500:]
        elif path == "/remove-images":
            ns = MOD["IMAGE_REMOVER.py"]
            _, log = run_captured(ns["remove_images"], staged)
            generated = stem + "_no_images.epub"
            details["details"] = log[-500:]
        else:
            raise ValueError("Endpoint tidak dikenal.")

        output = commit_in_place(src, generated)
        details.update({"output": output, "message": "File asli berhasil diperbarui."})
        return details

PAGE = r"""<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#08285f"><title>EPUB All-in-One Toolkit</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#eef2f8;color:#172033;font-family:Arial,sans-serif;padding:14px}main{max-width:760px;margin:auto}
.hero{background:linear-gradient(135deg,#08285f,#145da0);color:white;border-radius:18px;padding:20px;margin-bottom:14px}.hero h1{font-size:22px;margin:0 0 6px}.hero p{margin:0;color:#dce7ff;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0}.tab{border:0;border-radius:11px;padding:13px 9px;background:#dce4f1;color:#1b3155;font-weight:bold;font-size:13px;text-align:left;min-height:54px}.tab.active{background:#08285f;color:white}
.panel{background:white;border-radius:14px;padding:16px;margin:12px 0;box-shadow:0 2px 10px #13294b0d}.panel h2{margin:0 0 8px;font-size:19px}.hint{color:#596579;font-size:13px;line-height:1.5}
label{display:block;font-size:14px;font-weight:bold;margin:12px 0 6px}input[type=text],select{width:100%;padding:12px;border:1px solid #b8c3d3;border-radius:9px;font-size:16px;background:white;color:#172033}
.check{display:flex;align-items:center;gap:8px;font-weight:normal;margin:10px 0}.check input{width:19px;height:19px}.batch-file{display:flex;align-items:flex-start;gap:9px;padding:8px 4px;border-bottom:1px solid #edf1f6;font-size:13px;font-weight:normal;margin:0}.batch-file:last-child{border-bottom:0}.batch-file input{width:18px;height:18px;flex:0 0 auto;margin:1px 0 0}.batch-file span{overflow-wrap:anywhere}button.action{width:100%;border:0;border-radius:10px;background:#1265bd;color:white;font-weight:bold;padding:13px;margin-top:10px;font-size:15px}button.alt{background:#53657e}
.hide{display:none}.small{font-size:12px;color:#657187;overflow-wrap:anywhere}
footer{text-align:center;color:#718096;font-size:12px;padding:14px}
.status{
  white-space:pre-wrap;
  overflow-wrap:anywhere;
  background:#f5f7fb;
  border:1px solid #e2e8f0;
  border-radius:12px;
  padding:14px;
  margin-top:12px;
  min-height:42px;
  font-size:14px;
  line-height:1.6;
  color:#334155;
}@media(max-width:420px){.grid{grid-template-columns:1fr 1fr}.tab{font-size:12px;padding:10px 7px}}

/* Gallery-style top-level navigation and EPUB reader */
body{padding-bottom:88px}
#gallery-nav{position:fixed;z-index:1000;left:0;right:0;bottom:0;height:72px;background:#050505;border-top:1px solid #252525;display:flex;justify-content:space-around;align-items:center}
.gallery-btn{border:0;background:transparent;color:#777;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;min-width:110px;height:100%;font-weight:500}
.gallery-btn.active{color:#f2f2f2;font-weight:bold}
.gallery-btn svg{width:27px;height:27px;fill:currentColor}
.gallery-btn .gallery-emoji{font-size:25px;line-height:27px}
/* V25: recolor tab icons only; keep tab labels and active styling unchanged */
.gallery-btn .gallery-emoji{filter:grayscale(1);opacity:.82}
#reader-view{display:none;position:fixed;inset:0 0 72px;background:#050505;color:#eee;overflow:auto;padding:18px 18px 30px}
#reader-view .reader-head{font-size:30px;font-weight:300;margin:8px 0 22px}
#reader-view .reader-tools{background:#1d1d1d;border-radius:14px;padding:14px;margin-bottom:16px}
#reader-view select,#reader-view input{width:100%;padding:10px;border-radius:8px;border:1px solid #555;background:#292929;color:#eee;font-size:15px}
#reader-view label{color:#ddd;font-size:13px;margin:10px 0 5px}
#reader-view .reader-actions{display:flex;gap:8px}
#reader-view button{border:0;border-radius:8px;padding:10px 12px;background:#3478df;color:white;font-weight:bold}
#reader-view button.secondary{background:#444}
#reader-view .reader-page{border-radius:12px;padding:20px 18px;min-height:48vh;background:#fff;color:#242424;font-family:Georgia,serif;font-size:19px;line-height:1.65}
#reader-view .reader-page p{margin:0 0 1em}
#reader-view .reader-page img{max-width:100%;height:auto}
#reader-view .reader-empty{color:#aaa;text-align:center;padding:55px 15px;line-height:1.6}
#reader-view .reader-settings{display:grid;grid-template-columns:1fr 1fr;gap:8px}
#reader-view .theme-row{display:flex;gap:7px;margin-top:10px}
#reader-view .theme-row button{flex:1}
@media(max-width:420px){#reader-view{padding:14px 12px 24px}.reader-page{font-size:18px}}

/* Horizontal page-by-page EPUB reading */
#reader-view .reader-page{height:62vh;min-height:360px;overflow-x:auto;overflow-y:hidden;column-width:100%;column-gap:30px;column-fill:auto;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch;touch-action:pan-y;overscroll-behavior-x:contain}
#reader-view .reader-page::-webkit-scrollbar{display:none}
#reader-view .reader-page>*{break-inside:auto}
#reader-view .reader-page p{break-inside:auto;orphans:2;widows:2}
#reader-view .reader-page img,#reader-view .reader-page figure{break-inside:avoid-column}
#reader-view .reader-page img{max-height:45vh;object-fit:contain}
#reader-view .page-nav{display:flex;align-items:center;gap:8px;margin:0 0 10px}
#reader-view .page-nav button{background:#444}
#reader-view .page-nav span{color:#aaa;font-size:12px;margin-left:auto}

/* Immersive reading: tap the page to toggle all controls */
#reader-view{inset:0;padding:12px 14px 18px;transition:padding .18s ease}
#reader-controls{opacity:1;max-height:1000px;overflow:hidden;transition:opacity .18s ease,max-height .22s ease,transform .18s ease}
#reader-view.controls-hidden{padding:0}
#reader-view.controls-hidden #reader-controls{opacity:0;max-height:0;transform:translateY(-12px);pointer-events:none;margin:0}
body.reader-reading #gallery-nav{display:none}
body.reader-reading{padding-bottom:0}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 8px);min-height:calc(100vh - 8px);border-radius:0;padding:28px 22px}
#reader-view #reader-content{cursor:pointer}
@media(max-width:420px){#reader-view{padding:10px 10px 14px}#reader-view.controls-hidden #reader-content{padding:28px 20px}}

/* Read Book: dedicated library and immersive reader */
#reader-view{background:#071d23;color:#f3f7f8;padding:0;inset:0;overflow-y:auto}
#library-view{min-height:100%;padding:0 14px 24px}
#library-refresh-indicator{height:0;overflow:hidden;display:flex;align-items:center;justify-content:center;color:#b9e7ec;font-size:12px;transition:height .12s ease;background:#064b5b;margin:0 -14px}
#library-refresh-indicator.visible{height:42px}
#library-top{position:sticky;top:0;z-index:5;background:#075b70;margin:0 -14px 14px;padding:17px 16px 14px;box-shadow:0 3px 12px #0003}
#library-top .lib-title{font-size:24px;font-weight:700;margin:0 0 10px}
#library-search{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #43808c;border-radius:10px;background:#064b5b;color:white;font-size:15px;outline:none}
#library-search::placeholder{color:#b5d1d6}
#library-sort-row{display:flex;align-items:center;gap:9px;margin-top:9px}
#library-sort-label{font-size:12px;color:#b5d1d6;white-space:nowrap}
#library-sort{flex:1;min-width:0;box-sizing:border-box;padding:9px 10px;border:1px solid #43808c;border-radius:9px;background:#064b5b;color:white;font-size:14px}
#library-stats{font-size:12px;color:#a9c2c7;margin:10px 2px}
.book-card{display:flex;gap:11px;align-items:center;background:#1a343a;border:1px solid #28474e;border-radius:11px;padding:9px;margin:0 0 9px;min-height:94px;box-shadow:0 2px 7px #0002;cursor:pointer}
.book-cover{width:58px;min-width:58px;height:78px;min-height:78px;border-radius:3px;background:linear-gradient(145deg,#275e6b,#102b34);display:flex;align-items:center;justify-content:center;color:#d7e6e9;font-size:27px;box-shadow:0 2px 5px #0005}
.book-cover span{font-size:27px}.book-cover img{width:100%;height:100%;object-fit:cover;border-radius:3px;display:block}
.book-info{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px;align-self:stretch;padding:1px 0}
.book-name{font-size:15px;line-height:1.25;font-weight:600;overflow-wrap:anywhere;color:#f5f8f9;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.book-meta{font-size:11px;color:#a9bdc1;overflow-wrap:anywhere}
.book-progress{height:3px;border-radius:9px;background:#496168;overflow:hidden;margin-top:auto}
.book-progress>i{display:block;height:100%;background:#21b6a6}
.book-open-hint{font-size:11px;color:#70d5ca;margin-top:1px}
#library-selection-toolbar{display:none;align-items:center;gap:7px;flex-wrap:wrap;background:#123c45;border:1px solid #2b6670;border-radius:10px;padding:9px;margin:0 0 10px}
#library-selection-toolbar.visible{display:flex}
#library-selection-count{font-size:12px;color:#c5e0e3;flex:1;min-width:95px}
#library-selection-toolbar button{border:1px solid #4b7c83;background:#204e57;color:#f5fbfc;border-radius:8px;padding:8px 10px;font-size:12px}
#library-selection-toolbar button.delete{background:#8b3030;border-color:#b34b4b}
.book-card.selected{border:2px solid #21b6a6;background:#21454b;padding:8px}
.book-select-mark{width:23px;height:23px;min-width:23px;border-radius:50%;border:2px solid #91aeb2;display:none;align-items:center;justify-content:center;color:#062a30;font-size:14px;font-weight:800}
.selection-mode .book-select-mark{display:flex}
.book-card.selected .book-select-mark{background:#46d4c4;border-color:#46d4c4}
@media(max-width:420px){.book-cover{width:54px;min-width:54px;height:74px;min-height:74px}.book-card{min-height:88px;padding:8px;gap:9px}.book-name{font-size:14px}}
#reader-screen{display:none;min-height:100%;background:#101719;padding:0 14px 22px}
#reader-screen-head{position:sticky;top:0;z-index:6;background:#101719;padding:12px 0 10px;display:flex;align-items:center;gap:14px;border-bottom:1px solid #29383b}
#reader-screen-head button{background:transparent;color:#f2f5f5;padding:8px;font-size:22px}
#reader-book-title{font-size:15px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
#reader-view #reader-controls{padding-top:10px}
/* V28.3: dedicated full-screen Find in Book UI, modeled after the supplied reference video. */
#reader-search-screen{display:none;position:fixed;inset:0;background:#071d23;color:#f2f5f5;z-index:40;overflow:hidden}
#reader-search-screen.active{display:flex;flex-direction:column}
#reader-search-head{height:58px;min-height:58px;background:#00677d;display:flex;align-items:center;padding:0 10px;box-sizing:border-box;box-shadow:0 2px 4px #0006}
#reader-search-head button{border:0;background:transparent;color:#fff;width:50px;height:50px;font-size:39px;font-weight:300;line-height:1;padding:0;display:flex;align-items:center;justify-content:center}
#reader-search-head button.search-back{font-size:39px;margin-left:-4px}
#reader-search-head input{flex:1;min-width:0;height:54px;border:0;outline:0;background:transparent;color:#f5f7f7;font-size:30px;font-weight:300;padding:0 5px}
#reader-search-head input::placeholder{color:#d7e0e2;opacity:1}
#reader-search-head button.search-clear{font-size:38px}
#reader-search-body{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:10px 0 24px}
#reader-search-history{display:none;border-bottom:1px solid #102f36;padding:0;color:#b7c3c5}
#reader-search-history.visible{display:flex;flex-direction:column}
.reader-search-history-item{display:flex;align-items:center;gap:18px;padding:9px 22px;min-height:48px;box-sizing:border-box;touch-action:pan-y}
.reader-search-history-item .history-icon{font-size:28px;color:#8c989a;line-height:1;flex:0 0 auto}
.reader-search-history-item .history-query{font-size:20px;color:#29b7d0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.reader-search-history-item:active{background:#102d33}
#reader-search-results{padding:8px 9px 0}
.search-result-card.search-result-selected{border:2px solid #d9b94b!important;background:#24434a!important;box-shadow:0 0 0 1px #d9b94b33!important}
.search-result-card[aria-current="true"] .search-result-location{color:#d9b94b;font-weight:600}
.search-result-card{display:flex!important;align-items:stretch!important;width:calc(100% - 18px)!important;padding:0!important;text-align:left!important;font-family:Arial,sans-serif!important;font-weight:400!important;font-size:inherit!important;line-height:normal!important;color:#f0f3f3!important;background:#1c3439!important;border:1px solid #263f44!important;border-radius:7px!important;margin:0 9px 4px!important;min-height:48px!important;box-sizing:border-box!important;overflow:hidden!important;box-shadow:0 1px 1px #0004!important;appearance:none!important;-webkit-appearance:none!important;outline:none!important}
.search-result-text{flex:1;min-width:0;padding:5px 6px 6px 11px}
.search-result-chapter-title{font-size:11px;line-height:1.15;color:#8fc6d1;margin:0 0 3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.search-result-snippet{color:#f0f3f3;font-size:15px;line-height:1.22;word-break:break-word}
.search-result-snippet mark{background:transparent;color:#e6c94e;font-weight:400;padding:0}
.search-result-location{width:58px;flex:0 0 58px;display:flex;align-items:center;justify-content:center;color:#f2f5f5;font-size:14px;font-weight:500}
#reader-search-empty{display:none;padding:0;text-align:center;color:#8f9b9d;font-size:16px}
#reader-search-empty:not(:empty){display:block;padding:24px 25px}
#reader-search-loading{display:none;padding:55px 25px;text-align:center;color:#1290b2;font-size:48px}
#reader-search-loading.active{display:block}
#reader-search-tools{display:flex;gap:6px;align-items:center;margin:0 0 9px}
#reader-search-tools input{min-width:0;flex:1;background:#263437;border:1px solid #536367;color:#f3f7f8;border-radius:8px;padding:9px 10px;font-size:14px}
#reader-search-tools button{padding:8px 10px;white-space:nowrap}
#reader-search-status{font-size:12px;color:#b9c7ca;margin:0 0 8px;min-height:16px}
#reader-content mark.reader-search-hit{background:#ffdf65;color:#241d08;border-radius:2px;padding:0}
#reader-view .reader-tools{background:#1b292c;border:1px solid #33464a}
#reader-view .reader-head{display:none}
#reader-view .reader-page{height:calc(100vh - 260px);min-height:360px;border-radius:5px;padding:28px 23px;background:#f7f2e8;color:#28251f;font-family:Georgia,serif;font-size:19px;line-height:1.7;box-shadow:0 4px 18px #0005}
#reader-view .page-nav span{color:#b9c7ca}
#reader-view .reader-actions{align-items:center}
#reader-view .reader-actions button,#reader-view .page-nav button{padding:9px 13px}
#reader-view .reader-settings{margin-top:8px}
#reader-view .reader-tools label{display:block}
#reader-view input[type=range]{padding:0;background:transparent;border:0}
#reader-view .theme-row button{padding:9px 6px}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 12px);min-height:calc(100vh - 12px);margin:0}
@media(max-width:420px){.book-cover{width:78px;min-width:78px}.book-name{font-size:16px}#reader-view .reader-page{height:calc(100vh - 270px);padding:23px 19px}}


/* Reader rendering fixes v2: proper XHTML block tags and predictable page columns */
#reader-view #reader-content.reader-page {
  display:block; box-sizing:border-box; width:100%; max-width:100%;
  overflow-x:auto; overflow-y:hidden; white-space:normal;
  column-fill:auto; column-gap:28px; column-rule:0;
  column-width:auto; -webkit-column-width:auto;
  word-break:normal; overflow-wrap:break-word; text-align:left;
  touch-action:pan-y; overscroll-behavior-x:contain;
}
#reader-view #reader-content.reader-page p {
  display:block; margin:0 0 1em; padding:0; text-indent:0 !important;
  line-height:inherit; white-space:normal; break-inside:auto;
}
#reader-view #reader-content.reader-page article,
#reader-view #reader-content.reader-page main,
#reader-view #reader-content.reader-page blockquote,
#reader-view #reader-content.reader-page ul,
#reader-view #reader-content.reader-page ol,
#reader-view #reader-content.reader-page li { display:block; }
#reader-view #reader-content.reader-page p + p { margin-top:0; }

#reader-view #reader-content.reader-page h1,
#reader-view #reader-content.reader-page h2,
#reader-view #reader-content.reader-page h3,
#reader-view #reader-content.reader-page h4 { display:block; white-space:normal; break-after:avoid; margin:1.1em 0 .65em; line-height:1.25; }
#reader-view #reader-content.reader-page div,
#reader-view #reader-content.reader-page section { display:block; max-width:100%; }
#reader-view #reader-content.reader-page img,
#reader-view #reader-content.reader-page svg,
#reader-view #reader-content.reader-page table { max-width:100%; }
#reader-view #reader-content.reader-page table { border-collapse:collapse; }
#reader-view #reader-content.reader-page a { overflow-wrap:anywhere; }


/* Reader presentation v5: edge-to-edge text with floating controls; suppress Android WebView blue tap flash */
#reader-view, #reader-view *, #reader-view button, #reader-view input, #reader-view select {
  -webkit-tap-highlight-color: transparent;
}
#reader-screen {
  position:fixed; inset:0; z-index:20; display:none; overflow:hidden;
  min-height:100dvh; height:100dvh; padding:0; background:#101719;
}
#reader-screen-head {
  position:fixed; top:0; left:0; right:0; z-index:30;
  padding:calc(8px + env(safe-area-inset-top)) 12px 8px;
  margin:0; background:linear-gradient(180deg,rgba(8,19,23,.96),rgba(8,19,23,.78));
  border:0; min-height:54px; box-sizing:border-box;
  transition:opacity .14s ease, transform .14s ease;
}
#reader-content.reader-page {
  position:fixed; z-index:21; inset:0; width:100vw; height:100dvh !important;
  min-height:100dvh !important; max-height:none; box-sizing:border-box;
  margin:0 !important; border-radius:0 !important; box-shadow:none !important;
  padding:calc(76px + env(safe-area-inset-top)) 24px calc(96px + env(safe-area-inset-bottom)) !important;
  background:#f7f2e8; color:#28251f;
  -webkit-tap-highlight-color:transparent; outline:none;
}
#reader-view #reader-controls {
  position:fixed; left:0; right:0; bottom:0; z-index:32;
  box-sizing:border-box; max-height:62dvh; overflow-y:auto;
  padding:10px 14px calc(12px + env(safe-area-inset-bottom));
  background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));
  border-top:1px solid rgba(255,255,255,.12); border-radius:16px 16px 0 0;
  backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
  transition:opacity .14s ease, transform .14s ease, max-height .14s ease;
}
#reader-view #reader-controls {position:fixed;inset:auto 10px auto 10px;top:calc(62px + env(safe-area-inset-top));z-index:35;max-height:none;overflow:visible;padding:0;background:transparent;border:0;border-radius:0;backdrop-filter:none;-webkit-backdrop-filter:none;pointer-events:none}
#reader-view .reader-popup-menu{display:none;pointer-events:auto;position:absolute;top:0;right:0;width:min(92vw,440px);max-height:72dvh;overflow-y:auto;box-sizing:border-box;background:#253438;border:1px solid #43565a;border-radius:15px;padding:15px;box-shadow:0 12px 32px #0008}
#reader-view .reader-popup-menu.active{display:block}
#reader-view .reader-popup-title{font-size:17px;font-weight:700;color:#e5f0f1;margin:0 0 12px}
#reader-view .reader-popup-menu .reader-settings{margin:0;gap:10px}
#reader-view .reader-popup-menu .theme-row{margin-top:12px}
#reader-view .reader-popup-menu .reader-actions{margin:12px 0 6px;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .reader-actions button{flex:1;min-width:120px}
#reader-view .reader-popup-menu .page-nav{margin:6px 0 0;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .page-nav button{flex:1;min-width:90px}
#reader-view #reader-screen-head button{width:42px;font-size:24px}
#reader-view.controls-hidden #reader-controls{opacity:0;pointer-events:none}
#reader-view.controls-hidden #reader-settings-menu,#reader-view.controls-hidden #reader-navigation-menu{display:none!important}
#reader-view #reader-controls .reader-tools { margin:0 0 8px; padding:10px; }
#reader-view #reader-controls .reader-actions { margin:6px 0; }
#reader-view #reader-controls .page-nav { margin:5px 0 0; }
#reader-view #reader-bottom-navigation{position:fixed;left:0;right:0;bottom:0;z-index:34;box-sizing:border-box;padding:10px 14px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));border-top:1px solid rgba(255,255,255,.12);border-radius:16px 16px 0 0;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);transition:opacity .14s ease,transform .14s ease}
#reader-view #reader-bottom-navigation .reader-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 8px}
#reader-view #reader-bottom-navigation .reader-actions button{flex:1;min-width:120px}
#reader-view #reader-bottom-navigation .page-nav{display:flex;align-items:center;gap:8px;margin:0;flex-wrap:wrap}
#reader-view #reader-bottom-navigation .page-nav button{flex:1;min-width:90px}
#reader-view #reader-bottom-navigation #reader-page-count{margin-left:auto;color:#aab8ba}
#reader-view.controls-hidden #reader-bottom-navigation{opacity:0;transform:translateY(12px);pointer-events:none}

#reader-view.controls-hidden #reader-controls {
  opacity:0; max-height:0; padding-top:0; padding-bottom:0;
  transform:translateY(12px); pointer-events:none; border:0;
}
#reader-view.controls-hidden #reader-screen-head {
  opacity:0; transform:translateY(-10px); pointer-events:none;
}
/* Keep the reading viewport identical in both states. Controls float above it. */
#reader-view.controls-hidden #reader-content.reader-page {
  padding-top:calc(76px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(96px + env(safe-area-inset-bottom)) !important;
}
#reader-content, #reader-content * { -webkit-tap-highlight-color:transparent; }
@media(max-width:420px) {
  #reader-content.reader-page { padding-left:20px !important; padding-right:20px !important; }
  #reader-view #reader-controls { max-height:68dvh; }
}
/* V17 reader spacing: stronger, explicit override of the original reader viewport padding. */
#reader-screen #reader-content.reader-page {
  padding-top:calc(48px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(48px + env(safe-area-inset-bottom)) !important;
  padding-left:32px !important;
  padding-right:32px !important;
}
#reader-view.controls-hidden #reader-screen #reader-content.reader-page {
  padding-top:calc(48px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(48px + env(safe-area-inset-bottom)) !important;
}
/* Prevent EPUB-supplied first-paragraph spacing or indentation from reintroducing a blank offset. */
#reader-screen #reader-content.reader-page p,
#reader-screen #reader-content.reader-page p * {
  text-indent:0 !important;
}
#reader-screen #reader-content.reader-page > :first-child,
#reader-screen #reader-content.reader-page > :first-child > :first-child {
  margin-top:0 !important;
}
/* V19: horizontal page isolation is calculated from the full reader viewport in setReaderStyle(). */
#reader-screen #reader-content.reader-page {
  column-fill:auto !important;
  -webkit-column-fill:auto !important;
  overflow-x:auto !important;
  overflow-y:hidden !important;
}
</style></head><body><main>
<header class="hero"><h1>RED DUST - EPUB Toolkit</h1><p>Semua fitur · Batch processing · Android offline standalone</p></header>
<nav class="grid">
<button class="tab active" onclick="showTab('remove-cover',this)">1. Remove Cover</button><button class="tab" onclick="showTab('no-preview',this)">2. Add Paragraph</button>
<button class="tab" onclick="showTab('cover-maker',this)">3. Cover Maker</button><button class="tab" onclick="showTab('compress',this)">4. Image Compressor</button>
<button class="tab" onclick="showTab('bulk',this)">5. Bulk Find & Replace</button><button class="tab" onclick="showTab('compact',this)">6. Compact Line Spacing</button>
<button class="tab" onclick="showTab('blank',this)">7. Remove Blank Spacing</button><button class="tab" onclick="showTab('images',this)">8. Remove All Images</button><button class="tab" onclick="showTab('rename-title',this)">9. Rename from Metadata</button>
</nav>
<section id="remove-cover" class="panel"><h2>Remove EPUB Cover</h2><p class="hint">Menghapus gambar cover, halaman cover yang dikenali, dan metadata thumbnail.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-cover','remove-cover')">Remove Cover</button><div class="status" id="remove-cover-status">Pilih EPUB untuk diproses.</div></section>
<section id="no-preview" class="panel hide"><h2>Add Paragraph</h2><p class="hint">Merapikan paragraf XHTML pada file asli. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/no-preview','no-preview')">Fix Preview</button><div class="status" id="no-preview-status">Pilih EPUB untuk diproses.</div></section>
<section id="cover-maker" class="panel hide"><h2>EPUB Cover Maker</h2><p class="hint">Membuat cover SVG dan halaman cover dari metadata judul dan penulis EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action alt" onclick="meta()">Baca Metadata</button><label>Judul cover</label><input id="title" type="text" placeholder="Judul cover"><div id="author" class="small"></div><button class="action" onclick="run('/make-cover','cover-maker',{title:val('title')})">Buat Cover</button><div class="status" id="cover-maker-status">Pilih EPUB lalu baca metadata.</div></section>
<section id="compress" class="panel hide"><h2>Image Compressor</h2><p class="hint">Mengompres gambar JPEG, PNG, dan WebP di dalam EPUB. GIF dan SVG dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compress','compress')">Compress Images</button><div class="status" id="compress-status">Pilih EPUB untuk diproses. Memerlukan Pillow.</div></section>
<section id="bulk" class="panel hide"><h2>Bulk Find &amp; Replace</h2><p class="hint">Cari dan ganti teks pada EPUB atau TXT secara langsung. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB/TXT</label><select id="bulkfile"></select><label>Teks yang dicari</label><input id="find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="regex" type="checkbox"> Regular expression</label><button class="action alt" onclick="bulk('/bulk-count')">Hitung Kecocokan</button><button class="action" onclick="bulk('/bulk-replace')">Ganti Semua</button><div class="status" id="bulk-status">Pilih file dan masukkan teks pencarian.</div></section>
<section id="compact" class="panel hide"><h2>Compact Line Spacing Fixer</h2><p class="hint">Membersihkan baris kosong/BR berulang, lalu mengatur line-height dan margin paragraf sesuai script asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compact-spacing','compact')">Perbaiki Line Spacing</button><div class="status" id="compact-status">Pilih EPUB untuk diproses.</div></section>
<section id="blank" class="panel hide"><h2>Remove Blank Spacing</h2><p class="hint">Menghapus paragraf kosong saja. CSS dan jarak paragraf asli tetap dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/blank-spacing','blank')">Remove Blank Paragraphs</button><div class="status" id="blank-status">Pilih EPUB untuk diproses.</div></section>
<section id="images" class="panel hide"><h2>Remove All Images</h2><p class="hint">Menghapus file gambar dan referensi gambar dari EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-images','images')">Remove Images</button><div class="status" id="images-status">Pilih EPUB untuk diproses.</div></section>
<section id="rename-title" class="panel hide"><h2>Rename EPUB from Metadata</h2><p class="hint">Mengganti nama file EPUB berdasarkan judul (dc:title) di metadata EPUB. Isi EPUB tidak diubah. Jika nama sudah dipakai, aplikasi menambahkan akhiran angka agar file lain tidak tertimpa.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="renameByTitle()">Rename using Metadata Title</button><div class="status" id="rename-title-status">Pilih EPUB untuk membaca judul dan mengganti nama file.</div></section>
<section id="folder-picker-panel" class="panel" style="margin:0 0 14px;padding:16px;border:2px solid #1265bd"><h2 style="font-size:17px;margin:0 0 8px">Pilih folder EPUB</h2><label for="folderFilter" style="margin-top:0">Tampilkan file dari folder</label><select id="folderFilter" onchange="renderFileChoices()" aria-label="Pilih folder untuk menyaring file"><option value="">Memuat folder…</option></select><p id="folderFilterHelp" class="hint" style="margin-bottom:0">Pilih Download untuk menampilkan EPUB dari folder Download saja. Pilih Semua folder untuk mencari di seluruh penyimpanan.</p></section>
<section id="batch-panel" class="panel" style="border:2px solid #15803d">
<h2>Batch Processing</h2><p class="hint">Jalankan salah satu fitur toolkit pada banyak file sekaligus. Pilih file manual atau gunakan tombol pilih semua pada folder aktif. File diproses satu per satu; file yang gagal tidak menghentikan file lainnya.</p>
<label for="batchOperation">Fitur yang dijalankan</label>
<select id="batchOperation" onchange="updateBatchOptions()">
<option value="/remove-cover">1. Remove Cover (EPUB)</option><option value="/no-preview">2. Add Paragraph (EPUB)</option><option value="/make-cover">3. Cover Maker (EPUB)</option><option value="/compress">4. Image Compressor (EPUB)</option><option value="/bulk-count">5a. Bulk Find &amp; Replace — Count (EPUB/TXT)</option><option value="/bulk-replace">5b. Bulk Find &amp; Replace — Replace (EPUB/TXT)</option><option value="/compact-spacing">6. Compact Line Spacing (EPUB)</option><option value="/blank-spacing">7. Remove Blank Spacing (EPUB)</option><option value="/remove-images">8. Remove All Images (EPUB)</option><option value="/rename-by-title">9. Rename from Metadata (EPUB)</option><option value="/batch-unzip">10. Batch Unzip (ZIP)</option><option value="/cover-meta">Read Cover Metadata (EPUB)</option>
</select>
<div id="batch-options"></div>
<div class="row" style="display:flex;gap:8px;margin-top:12px"><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(true)">Pilih semua di folder aktif</button><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(false)">Kosongkan pilihan</button></div>
<div id="batch-selection-count" class="small" style="margin:10px 0">0 file dipilih</div><div id="batch-file-list" style="max-height:200px;overflow:auto;border:1px solid #d8e0eb;border-radius:9px;padding:8px"><span class="small">Memuat daftar file…</span></div>
<button class="action" onclick="runBatch()">Jalankan Batch</button><div class="status" id="batch-status">Pilih fitur dan satu atau beberapa file.</div>
</section>
<footer>RED DUST - EPUB Toolkit · Berjalan sepenuhnya offline melalui Android WebView bridge. Pilih folder atau file satu per satu untuk batch. Perubahan disimpan langsung ke file asli; tidak ada backup yang dibuat.</footer></main>

<div id="reader-view">
  <section id="library-view">
    <div id="library-refresh-indicator" aria-live="polite">Tarik ke bawah untuk scan ulang</div>
    <div id="library-top">
      <div class="lib-title">My Library</div>
      <input id="library-search" type="search" placeholder="Search your EPUB books…" oninput="renderLibrary()">
      <div id="library-sort-row"><label id="library-sort-label" for="library-sort">Sort by</label><select id="library-sort" onchange="setLibrarySort(this.value)"><option value="name">Name (A–Z)</option><option value="added">Date added</option><option value="recent">Recently opened</option></select></div>
    </div>
    <div id="library-stats">Your EPUB collection</div>
    <div id="library-selection-toolbar"><span id="library-selection-count">0 selected</span><button onclick="selectAllVisibleBooks()">Select all</button><button onclick="cancelBookSelection()">Cancel</button><button class="delete" onclick="deleteSelectedBooks()">Delete</button></div>
    <div id="library-books"></div>
  </section>
  <section id="reader-search-screen" aria-label="Find in Book">
    <div id="reader-search-head">
      <button class="search-back" onclick="closeReaderSearch()" aria-label="Back">‹</button>
      <input id="reader-dedicated-search-input" type="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="Text search" oninput="showReaderSearchHistory()" onkeydown="if(event.key==='Enter'){event.preventDefault();searchDedicatedBook();}">
      <button class="search-clear" onclick="clearDedicatedSearch()" aria-label="Clear search">×</button>
    </div>
    <div id="reader-search-body">
      <div id="reader-search-history"></div>
      <div id="reader-search-loading">◔</div>
      <div id="reader-search-empty"></div>
      <div id="reader-search-results"></div>
    </div>
  </section>
  <section id="reader-screen">
    <div id="reader-screen-head">
      <button onclick="closeReaderBook()" aria-label="Back to library">‹</button>
      <div id="reader-book-title">Reading</div>
      <button onclick="openReaderSearch()" aria-label="Find in book">⌕</button><button onclick="toggleReaderMenu('settings')" aria-label="Display settings">⚙</button><button onclick="toggleReaderMenu('navigation')" aria-label="Table of contents">☷</button>
    </div>
    <div id="reader-controls">
      <div id="reader-search-status" aria-live="polite"></div>
      <div id="reader-settings-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Display settings</div>
        <div class="reader-settings">
          <div><label for="reader-font">Font size: <span id="font-value">19</span> px</label><input id="reader-font" type="range" min="14" max="32" value="19" oninput="setReaderStyle()"></div>
          <div><label for="reader-line">Line spacing: <span id="line-value">1.65</span></label><input id="reader-line" type="range" min="1.2" max="2.4" step="0.05" value="1.65" oninput="setReaderStyle()"></div>
          <div><label for="reader-para">Paragraph spacing: <span id="para-value">1.0</span> em</label><input id="reader-para" type="range" min="0" max="2.5" step="0.1" value="1" oninput="setReaderStyle()"></div>
        </div>
        <div class="theme-row"><button onclick="readerTheme('light')">Light</button><button onclick="readerTheme('sepia')">Sepia</button><button onclick="readerTheme('night')">Night</button></div>
      </div>
      <div id="reader-navigation-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Table of contents</div>
        <label for="reader-chapter">Choose chapter</label><select id="reader-chapter" onchange="loadReaderChapter()"><option value="0">Chapter</option></select>
      </div>
    </div>
    <div id="reader-bottom-navigation">
      <div class="reader-actions"><button class="secondary" onclick="readerPrev()">Previous chapter</button><button class="secondary" onclick="readerNext()">Next chapter</button><span id="reader-progress" style="color:#aaa;font-size:12px;align-self:center;margin-left:auto"></span></div>
      <div class="page-nav"><button class="secondary" onclick="readerPagePrev()">‹ Page</button><button class="secondary" onclick="readerPageNext()">Page ›</button><span id="reader-page-count">Page 1</span></div>
    </div>
    <article id="reader-content" class="reader-page"><div class="reader-empty">Choose a book from your library to start reading.</div></article>
  </section>
</div>
<nav id="gallery-nav">
 <button id="gallery-albums" class="gallery-btn active" onclick="switchGallery('albums')"><span class="gallery-emoji" aria-hidden="true">📖</span>Read Book</button>
 <button id="gallery-photos" class="gallery-btn" onclick="switchGallery('photos')"><span class="gallery-emoji" aria-hidden="true">🛠️</span>Tools</button>
</nav>

<script>
const $=id=>document.getElementById(id), val=id=>$(id).value;let files=[];const readerCoverCache={};let selectedBookPaths=new Set(),bookLongPressTimer=null,suppressBookClick=false;

function switchGallery(which){
  const albums=which==='albums';
  document.body.classList.toggle('reader-active',albums);
  $('reader-view').classList.remove('controls-hidden');
  document.querySelector('main').style.display=albums?'none':'block';
  $('reader-view').style.display=albums?'block':'none';
  $('library-view').style.display='block';$('reader-screen').style.display='none';
  $('gallery-photos').classList.toggle('active',!albums);
  $('gallery-albums').classList.toggle('active',albums);
  if(albums)populateReaderFiles();
}
let readerBook=null, readerFileLoaded='', readerSearchMatches=[], readerSearchIndex=-1, readerSearchQuery='';
let readerSearchPanelScrollTop=0;
let readerSearchHistory=[];let readerSearchHistoryPressTimer=null;
let libraryPullStartY=0,libraryPullStartX=0,libraryPullArmed=false,libraryPullDistance=0,libraryRefreshBusy=false;
const libraryScrollArea=$('reader-view');
if(libraryScrollArea){
 libraryScrollArea.addEventListener('touchstart',e=>{
  if($('library-view').style.display==='none'||$('reader-screen').style.display==='block'||libraryRefreshBusy||e.touches.length!==1)return;
  const t=e.touches[0];libraryPullStartY=t.clientY;libraryPullStartX=t.clientX;libraryPullArmed=libraryScrollArea.scrollTop<=2;libraryPullDistance=0;
 },{passive:true});
 libraryScrollArea.addEventListener('touchmove',e=>{
  if(!libraryPullArmed||e.touches.length!==1)return;
  const t=e.touches[0],dy=t.clientY-libraryPullStartY,dx=t.clientX-libraryPullStartX;
  if(Math.abs(dx)>Math.abs(dy)*.8){libraryPullArmed=false;return;}
  if(dy>0&&libraryScrollArea.scrollTop<=2){libraryPullDistance=Math.min(100,dy);const ind=$('library-refresh-indicator');if(ind){ind.classList.toggle('visible',dy>12);ind.textContent=dy>=76?'Lepaskan untuk scan ulang':'Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchend',()=>{
  const shouldRefresh=libraryPullArmed&&libraryPullDistance>=76;libraryPullArmed=false;libraryPullDistance=0;
  if(shouldRefresh)refreshLibraryScan();else{const ind=$('library-refresh-indicator');if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchcancel',()=>{libraryPullArmed=false;libraryPullDistance=0;const ind=$('library-refresh-indicator');if(ind)ind.classList.remove('visible');},{passive:true});
}
async function refreshLibraryScan(){
 if(libraryRefreshBusy)return;libraryRefreshBusy=true;const ind=$('library-refresh-indicator');
 if(ind){ind.classList.add('visible');ind.textContent='Memindai ulang EPUB…';}
 try{
  Object.keys(readerCoverCache).forEach(k=>delete readerCoverCache[k]);
  await new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,30)));
  await loadFiles();
  if(ind)ind.textContent='Scan selesai · My Library diperbarui';
 }catch(e){if(ind)ind.textContent='Gagal scan ulang: '+e.message;}
 setTimeout(()=>{if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}libraryRefreshBusy=false;},900);
}
function savedReaderState(){try{return JSON.parse(localStorage.getItem('redDustReaderProgress')||'{}')}catch(e){return {}}}
function saveReaderState(){if(!readerFileLoaded||!readerBook)return;const all=savedReaderState();all[readerFileLoaded]={chapter:readerBook.index||0,title:readerBook.title||''};localStorage.setItem('redDustReaderProgress',JSON.stringify(all));}
function populateReaderFiles(){renderLibrary();}
function libraryTimestamps(){
 try{return JSON.parse(localStorage.getItem('redDustLibraryTimestamps')||'{"added":{},"recent":{}}');}
 catch(e){return {added:{},recent:{}};}
}
function setLibrarySort(mode){
 try{localStorage.setItem('redDustLibrarySort',mode);}catch(e){}
 renderLibrary();
}
function isBookSelectionMode(){return selectedBookPaths.size>0;}
function updateBookSelectionUI(){
 const toolbar=$('library-selection-toolbar'),count=$('library-selection-count');
 if(toolbar)toolbar.classList.toggle('visible',isBookSelectionMode());
 if(count)count.textContent=selectedBookPaths.size+' book'+(selectedBookPaths.size===1?'':'s')+' selected';
 $('library-view').classList.toggle('selection-mode',isBookSelectionMode());
}
function toggleBookSelection(path){if(selectedBookPaths.has(path))selectedBookPaths.delete(path);else selectedBookPaths.add(path);updateBookSelectionUI();renderLibrary();}
function beginBookSelection(path){if(!selectedBookPaths.has(path))selectedBookPaths.add(path);suppressBookClick=true;updateBookSelectionUI();renderLibrary();setTimeout(()=>{suppressBookClick=false;},450);}
function cancelBookSelection(){selectedBookPaths.clear();updateBookSelectionUI();renderLibrary();}
function selectAllVisibleBooks(){const q=($('library-search')?.value||'').toLowerCase().trim();files.filter(f=>/\.epub$/i.test(f.name)&&(!q||(f.name+' '+f.path).toLowerCase().includes(q))).forEach(f=>selectedBookPaths.add(f.path));updateBookSelectionUI();renderLibrary();}
async function deleteSelectedBooks(){
 const targets=[...selectedBookPaths];if(!targets.length)return;
 if(!confirm('Delete '+targets.length+' selected book'+(targets.length===1?'':'s')+' from your device? This cannot be undone.'))return;
 let deleted=0,failed=[];const progress=savedReaderState(),stamps=libraryTimestamps();
 for(const file of targets){try{await api('/delete-book',{file});deleted++;delete progress[file];delete stamps.added[file];delete stamps.recent[file];selectedBookPaths.delete(file);}catch(e){failed.push(file.split('/').pop()+': '+e.message);}}
 try{localStorage.setItem('redDustReaderProgress',JSON.stringify(progress));localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 updateBookSelectionUI();await loadFiles();
 if(failed.length)alert(deleted+' book(s) deleted. Could not delete '+failed.length+':\n'+failed.join('\n'));
 else alert(deleted+' book(s) deleted.');
}
function renderLibrary(){
 const box=$('library-books');if(!box)return;box.innerHTML='';
 const q=($('library-search')?.value||'').toLowerCase().trim();
 const books=files.filter(f=>/\.epub$/i.test(f.name)&&(!q||(f.name+' '+f.path).toLowerCase().includes(q)));
 const stamps=libraryTimestamps(),now=Date.now();
 books.forEach(f=>{if(!stamps.added[f.path])stamps.added[f.path]=(Number(f.added)>0?Number(f.added)*1000:now);});
 try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 const sortControl=$('library-sort');let sort=localStorage.getItem('redDustLibrarySort')||'name';
 if(!['name','added','recent'].includes(sort))sort='name';
 if(sortControl)sortControl.value=sort;
 books.sort((a,b)=>{
  if(sort==='added')return (stamps.added[b.path]||0)-(stamps.added[a.path]||0)||a.name.localeCompare(b.name);
  if(sort==='recent')return (stamps.recent[b.path]||0)-(stamps.recent[a.path]||0)||a.name.localeCompare(b.name);
  return a.name.localeCompare(b.name,undefined,{sensitivity:'base'});
 });
 $('library-stats').textContent=books.length+' EPUB book'+(books.length===1?'':'s')+' · Tap to read · Hold to select';
 updateBookSelectionUI();
 if(!books.length){box.innerHTML='<div class="reader-empty">No EPUB books found. Add EPUB files to your device storage and refresh the app.</div>';return;}
 const progress=savedReaderState();
 books.forEach(f=>{const state=progress[f.path],card=document.createElement('div');card.className='book-card'+(selectedBookPaths.has(f.path)?' selected':'');
 card.onclick=()=>{if(suppressBookClick){suppressBookClick=false;return;}if(isBookSelectionMode())toggleBookSelection(f.path);else openReaderBook(f.path,state?.chapter||0);};
 let pressStart=null,pressMoved=false;
 card.addEventListener('touchstart',()=>{pressMoved=false;clearTimeout(bookLongPressTimer);bookLongPressTimer=setTimeout(()=>beginBookSelection(f.path),560);},{passive:true});
 card.addEventListener('touchmove',()=>{pressMoved=true;clearTimeout(bookLongPressTimer);},{passive:true});
 card.addEventListener('touchend',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('touchcancel',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('contextmenu',e=>{e.preventDefault();beginBookSelection(f.path);});
 const selectMark=document.createElement('div');selectMark.className='book-select-mark';selectMark.textContent=selectedBookPaths.has(f.path)?'✓':'';
 const cover=document.createElement('div');cover.className='book-cover';cover.innerHTML='<span>▤</span>';
 if(Object.prototype.hasOwnProperty.call(readerCoverCache,f.path)){
  if(readerCoverCache[f.path]){const img=document.createElement('img');img.alt='Book cover';img.src=readerCoverCache[f.path];cover.replaceChildren(img);}
 }else{
  readerCoverCache[f.path]=null;
  api('/reader-cover',{file:f.path}).then(result=>{
   if(result.cover){readerCoverCache[f.path]=result.cover;
    if(card.isConnected){const img=document.createElement('img');img.alt='Book cover';img.src=result.cover;cover.replaceChildren(img);}
   }
  }).catch(()=>{});
 }
 const info=document.createElement('div');info.className='book-info';
 const name=document.createElement('div');name.className='book-name';name.textContent=f.name.replace(/\.epub$/i,'');
 const meta=document.createElement('div');meta.className='book-meta';meta.textContent='EPUB · '+(f.size||'');
 const hint=document.createElement('div');hint.className='book-open-hint';hint.textContent=state?'Continue reading · Chapter '+(state.chapter+1):'Tap to start reading';
 const bar=document.createElement('div');bar.className='book-progress';const fill=document.createElement('i');fill.style.width=state?'12%':'0%';bar.appendChild(fill);
 info.append(name,meta,hint,bar);card.append(selectMark,cover,info);box.appendChild(card);
 });
}
async function openReaderBook(file,chapter){
 file=file||'';if(!file)return;
 readerSearchMatches=[];readerSearchIndex=-1;readerSearchQuery='';$('reader-dedicated-search-input').value='';$('reader-search-status').textContent='';
 $('library-view').style.display='none';$('reader-search-screen').classList.remove('active');$('reader-screen').style.display='block';
 $('reader-view').classList.remove('controls-hidden');
 document.body.classList.add('reader-reading');
 $('reader-content').innerHTML='<div class="reader-empty">Opening book…</div>';
 $('reader-book-title').textContent=file.split('/').pop().replace(/\.epub$/i,'');
 try{readerBook=await api('/reader-open',{file,chapter:chapter||0});readerFileLoaded=file;const stamps=libraryTimestamps();stamps.recent[file]=Date.now();try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}renderReaderChapter();}catch(e){$('reader-content').textContent='Could not open EPUB: '+e.message;}
}
function closeReaderBook(){saveReaderState();document.body.classList.remove('reader-reading');$('reader-screen').style.display='none';$('library-view').style.display='block';$('reader-view').classList.remove('controls-hidden');renderLibrary();}
function handleAndroidBack(){if($('reader-search-screen').classList.contains('active')){closeReaderSearch();return true;}if($('reader-screen').style.display==='block'){closeReaderBook();return true;}if($('reader-view').style.display==='block'){return false;}if(document.querySelector('main').style.display!=='none'){switchGallery('albums');return true;}return false;}
async function loadReaderChapter(position='start'){
 if(!readerFileLoaded)return;
 try{
  readerChapterLanding=position;
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:parseInt(val('reader-chapter')||0)});
  renderReaderChapter();
 }catch(e){$('reader-content').textContent='Could not load chapter: '+e.message;}
}
let readerChapterLanding='start';
async function navigateReaderChapter(index,position){
 if(!readerBook||index<0||index>=readerBook.chapters.length)return;
 $('reader-chapter').value=String(index);
 await loadReaderChapter(position);
}
function renderReaderChapter(){
 /* Preserve the reader chrome state when moving between chapters. */
 const landing=readerChapterLanding;readerChapterLanding='start';
 const s=$('reader-chapter');s.innerHTML='';
 readerBook.chapters.forEach((c,i)=>s.add(new Option((i+1)+'. '+c.title,i)));
 s.value=String(readerBook.index);
 $('reader-content').innerHTML=readerBook.content;
 $('reader-book-title').textContent=readerBook.title||'Reading';
 if(readerSearchQuery)highlightReaderSearch();
 $('reader-content').scrollLeft=0;
 saveReaderState();
 $('reader-progress').textContent=(readerBook.index+1)+' / '+readerBook.chapters.length;
 setReaderStyle();
 initReaderSwipe();
 /* Wait for WebView to lay out the new chapter columns before landing. */
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const el=$('reader-content');
  el.scrollLeft=landing==='end'?el.scrollWidth:0;
  updateReaderPageCount();
 }));
}
let readerTouchX=0,readerTouchY=0,readerTouchStart=0;
function readerPageWidth(){const el=$('reader-content');return Math.max(120,el.clientWidth);}
function updateReaderPageCount(){const el=$('reader-content');if(!el)return;const page=Math.max(1,Math.round(el.scrollLeft/readerPageWidth())+1);$('reader-page-count').textContent='Page '+page;}
function readerPageNext(){const el=$('reader-content');const atEnd=el.scrollLeft+el.clientWidth>=el.scrollWidth-36;if(atEnd){if(readerBook&&readerBook.index<readerBook.chapters.length-1){navigateReaderChapter(readerBook.index+1,'start');return;}return;}el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,el.scrollLeft+readerPageWidth());updateReaderPageCount();}
function readerPagePrev(){const el=$('reader-content');if(el.scrollLeft<=4){if(readerBook&&readerBook.index>0){navigateReaderChapter(readerBook.index-1,'end');return;}return;}el.scrollLeft=Math.max(0,el.scrollLeft-readerPageWidth());updateReaderPageCount();}
function toggleReaderControls(){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.toggle('controls-hidden');closeReaderMenus();}
function closeReaderMenus(){['reader-settings-menu','reader-navigation-menu'].forEach(id=>$(id).classList.remove('active'));}
function toggleReaderMenu(which){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.remove('controls-hidden');const target=which==='settings'?'reader-settings-menu':'reader-navigation-menu';const wasOpen=$(target).classList.contains('active');closeReaderMenus();if(!wasOpen)$(target).classList.add('active');}
function initReaderSwipe(){
 const el=$('reader-content');
 if(!el)return;
 if(el.dataset.swipeReady)return;
 el.dataset.swipeReady='1';
 el.addEventListener('touchstart',e=>{if(e.touches.length===1){readerTouchX=e.touches[0].clientX;readerTouchY=e.touches[0].clientY;readerTouchStart=Date.now();}},{passive:true});
 el.addEventListener('touchend',e=>{
  if(!e.changedTouches.length)return;
  const t=e.changedTouches[0],dx=t.clientX-readerTouchX,dy=t.clientY-readerTouchY;
  /* Keep the existing swipe navigation unchanged. */
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){if(dx<0)readerPageNext();else readerPagePrev();return;}
  if(Date.now()-readerTouchStart>600||Math.abs(dx)>18||Math.abs(dy)>18)return;
  if(e.target.closest('a,button,input,select,textarea'))return;
  const rect=el.getBoundingClientRect(),relativeX=(t.clientX-rect.left)/Math.max(1,rect.width);
  /* Center toggles the overlay; screen edges turn pages in either direction. */
  if(relativeX>=0.35&&relativeX<=0.65){toggleReaderControls();return;}
  if(relativeX>0.65){readerPageNext();return;}
  readerPagePrev();
 },{passive:true});
 el.addEventListener('scroll',updateReaderPageCount,{passive:true});
}

function loadReaderSearchHistory(){try{const saved=JSON.parse(localStorage.getItem('redDustReaderSearchHistory')||'[]');readerSearchHistory=Array.isArray(saved)?saved.filter(x=>typeof x==='string'&&x.trim()).slice(0,20):[];}catch(e){readerSearchHistory=[];}}
function saveReaderSearchHistory(){try{localStorage.setItem('redDustReaderSearchHistory',JSON.stringify(readerSearchHistory));}catch(e){}}
function showReaderSearchHistory(){
 const input=$('reader-dedicated-search-input'),box=$('reader-search-history');if(!input||!box)return;
 if(!input.value.trim()){box.classList.remove('visible');box.innerHTML='';return;}
 loadReaderSearchHistory();box.innerHTML='';if(!readerSearchHistory.length){box.classList.remove('visible');return;}
 readerSearchHistory.forEach((q,i)=>{const row=document.createElement('div');row.className='reader-search-history-item';row.innerHTML='<span class="history-icon">↶</span><span class="history-query"></span>';row.querySelector('.history-query').textContent=q;let wasLongPressed=false;row.onclick=()=>{if(wasLongPressed){wasLongPressed=false;return;}input.value=q;searchDedicatedBook();};
  let pressTimer=null;const cancel=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
  row.addEventListener('touchstart',()=>{wasLongPressed=false;pressTimer=setTimeout(()=>{wasLongPressed=true;readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();pressTimer=null;},550);},{passive:true});row.addEventListener('touchend',cancel,{passive:true});row.addEventListener('touchmove',cancel,{passive:true});row.addEventListener('contextmenu',e=>{e.preventDefault();readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();});box.appendChild(row);
 });box.classList.add('visible');
}
function openReaderSearch(){
 const screen=$('reader-search-screen');if(!screen)return;
 const body=$('reader-search-body'),input=$('reader-dedicated-search-input');screen.classList.add('active');
 // Preserve query/results/selection/scroll on return; otherwise open a clean search view.
 if(readerSearchMatches.length&&readerSearchQuery){input.value=readerSearchQuery;$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='';}
 else if(!readerSearchQuery){input.value='';$('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';$('reader-search-loading').classList.remove('active');}
 if(readerSearchMatches.length&&readerSearchQuery){$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';}else{showReaderSearchHistory();}
 requestAnimationFrame(()=>{if(readerSearchMatches.length&&readerSearchQuery){body.scrollTop=readerSearchPanelScrollTop;}else{input.focus();try{input.setSelectionRange(input.value.length,input.value.length);}catch(e){}}});
}
function closeReaderSearch(){
 const screen=$('reader-search-screen'),body=$('reader-search-body');
 if(body)readerSearchPanelScrollTop=body.scrollTop;
 if(screen)screen.classList.remove('active');
 try{if(document.activeElement)document.activeElement.blur();}catch(e){}
}
function clearDedicatedSearch(){
 const input=$('reader-dedicated-search-input');
 input.value='';input.focus();
 $('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';
 $('reader-search-loading').classList.remove('active');
}
function escapeHtmlText(text){return String(text||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderDedicatedSearchResults(matches,query){
 const box=$('reader-search-results');box.innerHTML='';
 if(!matches.length){$('reader-search-empty').textContent='No results found';return;}
 const needle=query.toLocaleLowerCase();
 matches.forEach((m,i)=>{
  const card=document.createElement('div');card.className='search-result-card'+(i===readerSearchIndex?' search-result-selected':'');card.setAttribute('role','button');card.setAttribute('tabindex','0');if(i===readerSearchIndex)card.setAttribute('aria-current','true');
  const textWrap=document.createElement('div');textWrap.className='search-result-text';
  const chapterTitle=document.createElement('div');chapterTitle.className='search-result-chapter-title';
  const chapter=Number(m.chapter)||0;chapterTitle.textContent='Chapter '+(chapter+1)+(m.chapter_title?' · '+m.chapter_title:'');
  const snippet=document.createElement('div');snippet.className='search-result-snippet';
  const raw=String(m.snippet||'');const lower=raw.toLocaleLowerCase();let from=0,html='';
  while(true){const at=lower.indexOf(needle,from);if(at<0){html+=escapeHtmlText(raw.slice(from));break;}html+=escapeHtmlText(raw.slice(from,at))+'<mark>'+escapeHtmlText(raw.slice(at,at+query.length))+'</mark>';from=at+query.length;}
  snippet.innerHTML=html;textWrap.append(chapterTitle,snippet);
  const loc=document.createElement('div');loc.className='search-result-location';loc.textContent='Ch. '+(chapter+1);
  card.append(textWrap,loc);card.onclick=async()=>{readerSearchIndex=i;readerSearchPanelScrollTop=card.offsetTop;renderDedicatedSearchResults(readerSearchMatches,readerSearchQuery);closeReaderSearch();await goToReaderSearchMatch();};card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}};
  box.appendChild(card);
 });
}
async function searchDedicatedBook(){
 const input=$('reader-dedicated-search-input');const query=(input?.value||'').trim();
 if(!readerFileLoaded||!query)return;
 readerSearchQuery=query;readerSearchMatches=[];readerSearchIndex=-1;readerSearchPanelScrollTop=0;$('reader-search-body').scrollTop=0;
 try{localStorage.setItem('redDustLastReaderSearch',query);}catch(e){}
 loadReaderSearchHistory();readerSearchHistory=[query,...readerSearchHistory.filter(x=>x.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,20);saveReaderSearchHistory();$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';
 $('reader-search-empty').textContent='';$('reader-search-results').innerHTML='';$('reader-search-loading').classList.add('active');
 try{
  const result=await api('/reader-search',{file:readerFileLoaded,query});
  readerSearchMatches=Array.isArray(result?.matches)?result.matches:[];
  $('reader-search-loading').classList.remove('active');
  renderDedicatedSearchResults(readerSearchMatches,query);
 }catch(e){$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='Search failed: '+(e?.message||String(e));}
}
async function searchInsideBook(){
 openReaderSearch();
}
function clearReaderSearchMarks(){document.querySelectorAll('#reader-content mark.reader-search-hit').forEach(mark=>mark.replaceWith(document.createTextNode(mark.textContent)));}
function highlightReaderSearch(){
 const root=$('reader-content');clearReaderSearchMarks();if(!readerSearchQuery)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(node){return node.nodeValue.toLocaleLowerCase().includes(readerSearchQuery.toLocaleLowerCase())?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 const needle=readerSearchQuery.toLocaleLowerCase();
 nodes.forEach(node=>{const text=node.nodeValue,lower=text.toLocaleLowerCase(),frag=document.createDocumentFragment();let from=0,at;
  while((at=lower.indexOf(needle,from))!==-1){if(at>from)frag.appendChild(document.createTextNode(text.slice(from,at)));const mark=document.createElement('mark');mark.className='reader-search-hit';mark.textContent=text.slice(at,at+readerSearchQuery.length);frag.appendChild(mark);from=at+readerSearchQuery.length;}
  if(from<text.length)frag.appendChild(document.createTextNode(text.slice(from)));node.parentNode.replaceChild(frag,node);
 });
}
async function goToReaderSearchMatch(){
 const match=readerSearchMatches[readerSearchIndex];if(!match)return;
 const targetChapter=Number(match.chapter)||0;
 if(readerBook.index!==targetChapter){
  $('reader-chapter').value=String(targetChapter);
  readerChapterLanding='start';
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:targetChapter});
  renderReaderChapter();
 }else{
  // Same chapter: preserve the current pagination/column geometry. Only refresh marks.
  highlightReaderSearch();
 }
 const page=$('reader-content');
 // Allow WebView's column layout to settle before measuring the highlighted text.
 requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const marks=page.querySelectorAll('mark.reader-search-hit');
  const occurrence=Math.max(0,Number(match.occurrence)||0),target=marks[occurrence];
  if(target){
   const rect=target.getBoundingClientRect(),base=page.getBoundingClientRect();
   /* Search navigation must land on a whole reader column/page. WebView's
      mandatory snap can otherwise restore at an intermediate offset and show
      slivers of two columns (the broken layout seen after selecting a result). */
   const stride=Math.max(1,page.clientWidth);
   const targetX=Math.max(0,page.scrollLeft+rect.left-base.left);
   const destination=Math.floor(targetX/stride)*stride;
   page.style.scrollSnapType='none';
   page.style.scrollBehavior='auto';
   page.scrollLeft=destination;
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
    page.scrollLeft=destination;
    page.style.scrollSnapType='x mandatory';
    updateReaderPageCount();
   }));
  }
  $('reader-search-status').textContent='Match '+(readerSearchIndex+1)+' of '+readerSearchMatches.length+' · '+(readerBook.chapters[targetChapter]?.title||'Chapter '+(targetChapter+1));
 })));
}

function readerSearchNext(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex+1)%readerSearchMatches.length;goToReaderSearchMatch();}
function readerSearchPrev(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex-1+readerSearchMatches.length)%readerSearchMatches.length;goToReaderSearchMatch();}

function readerPrev(){if(readerBook&&readerBook.index>0){$('reader-chapter').value=readerBook.index-1;loadReaderChapter();}}
function readerNext(){if(readerBook&&readerBook.index<readerBook.chapters.length-1){$('reader-chapter').value=readerBook.index+1;loadReaderChapter();}}
function setReaderStyle(){
 const page=$('reader-content'),font=val('reader-font'),line=val('reader-line'),para=val('reader-para');
 const cs=getComputedStyle(page);
 const padLeft=parseFloat(cs.paddingLeft)||0, padRight=parseFloat(cs.paddingRight)||0;
 const contentWidth=Math.max(120,page.clientWidth-padLeft-padRight);
 /* A CSS multi-column column occupies the text box, not the full outer viewport.
    Make the inter-column gap equal both side paddings combined so the next
    column begins exactly one full screen later. This prevents previous/next
    page text from entering the visible current-page viewport in Android WebView. */
 const pageGap=Math.max(0,padLeft+padRight);
 page.style.columnWidth=contentWidth+'px';page.style.webkitColumnWidth=contentWidth+'px';
 page.style.columnGap=pageGap+'px';page.style.webkitColumnGap=pageGap+'px';
 page.style.columnFill='auto';page.style.webkitColumnFill='auto';
 $('font-value').textContent=font;$('line-value').textContent=line;$('para-value').textContent=para;
 page.style.fontSize=font+'px';page.style.lineHeight=line;
 page.querySelectorAll('p').forEach(p=>p.style.marginBottom=para+'em');
}
function readerTheme(theme){
 const p=$('reader-content');
 const styles={light:['#fff','#242424'],sepia:['#f2e4c9','#5b4632'],night:['#171717','#ddd']};
 p.style.background=styles[theme][0];p.style.color=styles[theme][1];
}

function showTab(id,b){document.querySelectorAll('main>section:not(#folder-picker-panel):not(#batch-panel)').forEach(x=>x.classList.add('hide'));$('folder-picker-panel').classList.remove('hide');$(id).classList.remove('hide');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active')}
async function api(path,data){let d=JSON.parse(AndroidBridge.post(path,JSON.stringify(data)));if(d.error)throw Error(d.error||'Operasi gagal');return d}
function fileFor(id){return $(id).querySelector('select.epub')?.value || ''}
function renderFileChoices(){
  const filter=$('folderFilter')?.value||'';
  const visible=files.filter(f=>!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter);
  const help=$('folderFilterHelp');
  if(help) help.textContent=(filter ? 'Folder aktif: '+filter : 'Menampilkan semua folder')+' · '+visible.length+' file ditemukan. Pilih folder lain kapan saja.';
  document.querySelectorAll('select.epub').forEach(s=>{
    const old=s.value;s.innerHTML='<option value="">Pilih EPUB</option>';
    visible.filter(f=>/\.epub$/i.test(f.name)).forEach(f=>s.add(new Option(f.path+' ('+f.size+')',f.path)));
    if(old&&Array.from(s.options).some(o=>o.value===old))s.value=old;
  });
  const b=$('bulkfile'),old=b.value;b.innerHTML='<option value="">Pilih EPUB/TXT</option>';
  visible.filter(f=>/\.(epub|txt)$/i.test(f.name)).forEach(f=>b.add(new Option(f.path+' ('+f.size+')',f.path)));
  if(old&&Array.from(b.options).some(o=>o.value===old))b.value=old;
  renderBatchFiles();
}
function updateBatchOptions(){
  const op=val('batchOperation'), box=$('batch-options');box.innerHTML='';
  if(op==='/bulk-count'||op==='/bulk-replace'){
    box.innerHTML='<label>Teks yang dicari</label><input id="batch-find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="batch-replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="batch-case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="batch-whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="batch-regex" type="checkbox"> Regular expression</label>';
  }else if(op==='/make-cover'){
    box.innerHTML='<p class="hint">Judul cover dan nama penulis akan diambil otomatis dari metadata setiap EPUB (dc:title dan creator). Tidak perlu mengisi judul secara manual.</p>';
  }else if(op==='/batch-unzip'){
    const dirs=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    box.innerHTML='<label>Password ZIP (default)</label><input id="unzip-password" type="password" autocomplete="off" value="taiwanandnorthkorea" placeholder="Password yang sama untuk semua ZIP"><label>Folder tujuan (semua hasil digabung ke sini)</label><select id="unzip-destination"></select><p class="hint">Password default sudah diisi otomatis. Ubah jika ZIP menggunakan password lain, atau hapus jika ZIP tidak dikunci. Daftar ZIP dicari di semua folder penyimpanan, tidak mengikuti filter folder EPUB di atas. Mendukung AES dan ZipCrypto. Jika nama file bentrok, file berikutnya otomatis diberi akhiran _2, _3, dan seterusnya. Nama asli tetap dipakai jika tidak bentrok. File ZIP asli tidak diubah.</p>';
    const dest=box.querySelector('#unzip-destination');dirs.forEach(d=>dest.add(new Option(d,d)));if(dirs.includes('Download'))dest.value='Download';
  }else if(op==='/cover-meta'){
    box.innerHTML='<p class="hint">Hanya membaca metadata judul dan penulis; file tidak diubah.</p>';
  }else{
    box.innerHTML='<p class="hint">Tidak memerlukan pengaturan tambahan. Setiap EPUB yang dipilih akan diproses dengan fitur ini.</p>';
  }
  renderBatchFiles();
}
function selectedBatchFiles(){return Array.from(document.querySelectorAll('.batch-file input:checked')).map(x=>x.value)}
function updateBatchCount(){$('batch-selection-count').textContent=selectedBatchFiles().length+' file dipilih';}
function renderBatchFiles(){
  const filter=val('folderFilter'), op=val('batchOperation'), isText=op==='/bulk-count'||op==='/bulk-replace', isZip=op==='/batch-unzip';
  // ZIP extraction searches every discovered folder, regardless of the active EPUB folder filter.
  // This prevents archives in Documents, Telegram, or another folder from being hidden by e.g. Download/Novel.
  const visible=files.filter(f=>(isZip||!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter)&& (isZip?/\.zip$/i.test(f.name):(isText?/\.(epub|txt)$/i.test(f.name):/\.epub$/i.test(f.name))));
  const list=$('batch-file-list');list.innerHTML='';
  if(!visible.length){list.textContent='Tidak ada file yang cocok pada folder aktif.';updateBatchCount();return;}
  visible.forEach(f=>{const label=document.createElement('label');label.className='batch-file';const cb=document.createElement('input');cb.type='checkbox';cb.value=f.path;cb.addEventListener('change',updateBatchCount);const span=document.createElement('span');span.textContent=f.path+' ('+f.size+')';label.append(cb,span);list.appendChild(label);});updateBatchCount();
}
function selectVisibleBatch(checked){document.querySelectorAll('#batch-file-list input[type=checkbox]').forEach(x=>x.checked=checked);updateBatchCount();}
async function runBatch(){
  const operation=val('batchOperation'), chosen=selectedBatchFiles();
  if(!chosen.length)return $('batch-status').textContent='Pilih minimal satu file.';
  if(operation==='/batch-unzip'){
    const destination=val('unzip-destination');if(!destination)return $('batch-status').textContent='Pilih folder tujuan.';
    if(!confirm('Ekstrak '+chosen.length+' ZIP ke folder '+destination+'? File ZIP asli tetap disimpan.'))return;
    $('batch-status').textContent='Mengekstrak '+chosen.length+' arsip…';
    try{const result=JSON.parse(AndroidBridge.unzipBatch(JSON.stringify({files:chosen,destination,password:val('unzip-password')})));if(result.error)throw Error(result.error);
      const box=$('batch-status');box.textContent='';const summary=document.createElement('div');summary.style.cssText='padding:12px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e3a8a;margin-top:10px';summary.textContent='Batch Unzip selesai: '+result.succeeded+' berhasil · '+result.failed+' gagal · '+result.total+' ZIP';box.appendChild(summary);
      result.results.forEach(r=>addResultCard(box,r.file,r.ok,r.result||{},r.error||''));await loadFiles();
    }catch(e){$('batch-status').textContent='Error: '+e.message;}return;
  }
  const options={};
  if(operation==='/bulk-count'||operation==='/bulk-replace'){
    options.find=val('batch-find');options.replace=val('batch-replace');options.case_sensitive=$('batch-case').checked;options.whole_word=$('batch-whole').checked;options.regex=$('batch-regex').checked;
    if(!options.find)return $('batch-status').textContent='Isi teks yang dicari terlebih dahulu.';
  }
  const readOnly=operation==='/bulk-count'||operation==='/cover-meta';
  const prompt=readOnly?'Jalankan fitur pada '+chosen.length+' file terpilih?':'Proses '+chosen.length+' file terpilih? File yang berhasil diproses akan langsung menimpa file asli tanpa backup.';
  if(!confirm(prompt))return;
  $('batch-status').textContent='Memproses '+chosen.length+' file…';
  try{
    const d=await api('/batch',{operation,files:chosen,options});
    const box=$('batch-status');box.textContent='';
    box.style.cssText='padding:0;margin-top:12px;border:0;background:transparent;min-height:0;overflow:visible;';
    const resultsList=document.createElement('div');
    resultsList.style.cssText='max-height:200px;overflow-y:auto;overflow-x:hidden;border:1px solid #d8e0eb;border-radius:12px;padding:10px;background:#fff;';
    const summary=document.createElement('div');
    summary.style.cssText='background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px;margin:8px 0 12px;color:#1e3a8a;';
    const heading=document.createElement('div');heading.textContent='Batch selesai diproses';
    heading.style.cssText='font-size:17px;font-weight:700;margin-bottom:6px;';
    const count=document.createElement('div');
    count.textContent='✓ '+d.succeeded+' berhasil   ·   ✕ '+d.failed+' gagal   ·   Total '+d.total+' file';
    count.style.cssText='font-size:14px;';
    summary.append(heading,count);resultsList.appendChild(summary);
    d.results.forEach(item=>addResultCard(resultsList,item.file,item.ok,item.result||{},item.error||''));
    box.appendChild(resultsList);
    await loadFiles();
  }catch(e){$('batch-status').textContent='Error: '+e.message;}
}
async function loadFiles(){try{
  let d=JSON.parse(AndroidBridge.getFiles());if(d.error)throw Error(d.error);files=d.files;
  const available=new Set(files.filter(f=>/\.epub$/i.test(f.name)).map(f=>f.path));selectedBookPaths=new Set([...selectedBookPaths].filter(path=>available.has(path)));updateBookSelectionUI();
  const folder=$('folderFilter'),previous=folder.value;
  const folders=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  folder.innerHTML='<option value="">Semua folder</option>';
  folders.forEach(f=>folder.add(new Option(f,f)));
  if(folders.includes(previous)) folder.value=previous;
  else if(folders.includes('Download')) folder.value='Download';
  else folder.value='';
  renderFileChoices();if($('reader-file')||document.body.classList.contains('reader-active'))populateReaderFiles();
}catch(e){document.querySelectorAll('.status').forEach(x=>x.textContent='Gagal memuat file: '+e.message)}}
function currentFile(panel){return $(panel).querySelector('select').value}
function addResultCard(parent, fileName, ok, result={}, errorText=''){
  const card=document.createElement('div');
  card.style.cssText='background:#fff;border:1px solid '+(ok?'#bbf7d0':'#fecaca')+';border-radius:12px;padding:12px;margin:9px 0;color:#172033;';
  const head=document.createElement('div');
  head.style.cssText='display:flex;gap:8px;align-items:flex-start;font-weight:700;';
  const mark=document.createElement('span');mark.textContent=ok?'✓':'✕';
  mark.style.cssText='font-size:18px;color:'+(ok?'#15803d':'#dc2626')+';';
  const name=document.createElement('div');name.textContent=fileName||'File';
  name.style.cssText='overflow-wrap:anywhere;flex:1;';
  head.append(mark,name);card.appendChild(head);
  if(ok){
    const out=document.createElement('div');out.textContent='Hasil: '+(result.output||fileName||'Selesai');
    out.style.cssText='font-size:13px;color:#334155;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(out);
    const labels={message:'Status',title:'Judul',changed:'Paragraf diperbarui',count:'Jumlah perubahan',removed:'Item dihapus',images:'Gambar',matches:'Kecocokan',author:'Penulis'};
    const notes=[];
    for(const [key,value] of Object.entries(result)){
      if(key==='output'||value===null||value===undefined||value==='')continue;
      if(!Object.prototype.hasOwnProperty.call(labels,key))continue;
      const val=typeof value==='object'?JSON.stringify(value):String(value);
      if(/cache|chaquopy|tmp|backup/i.test(val))continue;
      notes.push(labels[key]+': '+val);
    }
    if(notes.length){const note=document.createElement('div');note.textContent=notes.join(' · ');
      note.style.cssText='font-size:12px;color:#64748b;margin:6px 0 0 26px;line-height:1.5;overflow-wrap:anywhere;';card.appendChild(note);}
  }else{
    const err=document.createElement('div');err.textContent='Gagal: '+(errorText||'Terjadi kesalahan');
    err.style.cssText='font-size:13px;color:#b91c1c;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(err);
  }
  parent.appendChild(card);
}
function showSuccess(panel,d){
  const box=$(panel+'-status');box.textContent='';
  const summary=document.createElement('div');
  summary.style.cssText='background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px;color:#166534;';
  const title=document.createElement('div');title.textContent='✓ Selesai diproses';
  title.style.cssText='font-size:17px;font-weight:700;margin-bottom:5px;';
  const output=document.createElement('div');output.textContent=d.output?'File hasil: '+d.output:'Proses berhasil diselesaikan.';
  output.style.cssText='font-size:14px;overflow-wrap:anywhere;';
  summary.append(title,output);box.appendChild(summary);
  addResultCard(box,d.output||'File EPUB',true,d);
}
async function run(path,panel,extra={}){let f=currentFile(panel);if(!f){$(panel+'-status').textContent='Pilih EPUB terlebih dahulu.';return}if(!confirm('Jalankan proses ini? File asli akan diperbarui langsung dan tidak ada backup yang dibuat.'))return;$(panel+'-status').textContent='Memproses…';try{let d=await api(path,{file:f,...extra});showSuccess(panel,d);await loadFiles()}catch(e){$(panel+'-status').textContent='Error: '+e.message}}
async function meta(){let f=currentFile('cover-maker');if(!f)return $('cover-maker-status').textContent='Pilih EPUB.';try{let d=await api('/cover-meta',{file:f});$('title').value=d.title;$('author').textContent='Penulis: '+d.author;$('cover-maker-status').textContent='Metadata berhasil dibaca.'}catch(e){$('cover-maker-status').textContent='Error: '+e.message}}
async function bulk(path){let p={file:val('bulkfile'),find:val('find'),replace:val('replace'),case_sensitive:$('case').checked,whole_word:$('whole').checked,regex:$('regex').checked};if(!p.file||!p.find)return $('bulk-status').textContent='Pilih file dan isi teks pencarian.';if(path==='/bulk-replace'&&!confirm('Ganti teks pada file asli? Perubahan akan langsung menimpa file tersebut.'))return;$('bulk-status').textContent='Memproses…';try{let d=await api(path,p);$('bulk-status').textContent=path==='/bulk-count'?'Jumlah kecocokan: '+d.count:(d.count?'Selesai. Penggantian: '+d.count+'\nFile diperbarui: '+d.output:'Tidak ada teks yang cocok.');await loadFiles()}catch(e){$('bulk-status').textContent='Error: '+e.message}}
async function renameByTitle(){
  const file=currentFile('rename-title');
  if(!file)return $('rename-title-status').textContent='Pilih EPUB terlebih dahulu.';
  if(!confirm('Nama file akan diganti sesuai judul metadata. Isi EPUB tidak diubah. Lanjutkan?'))return;
  $('rename-title-status').textContent='Membaca metadata dan mengganti nama…';
  try{const d=await api('/rename-by-title',{file});$('rename-title-status').textContent='Berhasil!\nJudul metadata: '+d.title+'\nNama file baru: '+d.output+(d.message?'\n'+d.message:'');await loadFiles();}
  catch(e){$('rename-title-status').textContent='Error: '+e.message;}
}
switchGallery('albums');updateBatchOptions();loadFiles();
</script></body></html>"""

def batch_action(d):
    """Run one existing toolkit operation over multiple selected files."""
    operation = d.get("operation", "")
    files = d.get("files", [])
    options = d.get("options", {}) or {}
    allowed = {
        "/remove-cover", "/no-preview", "/make-cover", "/compress",
        "/bulk-count", "/bulk-replace", "/compact-spacing",
        "/blank-spacing", "/remove-images", "/rename-by-title", "/cover-meta"
    }
    if operation not in allowed:
        raise ValueError("Operasi batch tidak dikenal.")
    if not isinstance(files, list) or not files:
        raise ValueError("Pilih minimal satu file.")
    if len(files) > 500:
        raise ValueError("Maksimal 500 file dalam satu batch.")
    results = []
    for selected in files:
        item = {**options, "file": selected}
        try:
            result = api_action(operation, item) or {}
            results.append({"file": selected, "ok": True, "result": result})
        except Exception as exc:
            results.append({"file": selected, "ok": False,
                            "error": type(exc).__name__ + ": " + str(exc)})
    succeeded = sum(1 for item in results if item["ok"])
    return {"total": len(results), "succeeded": succeeded,
            "failed": len(results) - succeeded, "results": results}

def get_files_payload():
    """Return EPUB/TXT inventory directly to the Android WebView bridge."""
    try:
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        arr = []
        for current, dirs, names in os.walk(STORAGE_ROOT, topdown=True, followlinks=False):
            if os.path.basename(current) == "Android":
                dirs[:] = [d for d in dirs if d not in ("data", "obb")]
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for n in names:
                if n.lower().endswith((".epub", ".txt", ".zip")):
                    path = os.path.join(current, n)
                    try:
                        if os.path.isfile(path):
                            stat = os.stat(path)
                            # Prefer true creation time when the filesystem exposes it;
                            # otherwise use inode-change time as the closest available added-date proxy.
                            added_at = getattr(stat, "st_birthtime", stat.st_ctime)
                            arr.append({"name": n, "path": relative_storage_path(path),
                                        "size": f"{stat.st_size/1048576:.2f} MB",
                                        "added": float(added_at)})
                    except (OSError, PermissionError):
                        continue
        arr.sort(key=lambda f: f["path"].lower())
        return {"files": arr}
    except Exception as e:
        return {"error": type(e).__name__ + ": " + str(e)}

def bridge_get_files():
    return json.dumps(get_files_payload(), ensure_ascii=False)

def bridge_post(path, data_json):
    try:
        data = json.loads(data_json or "{}")
        result = batch_action(data) if path == "/batch" else (api_action(path, data) or {})
        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": type(e).__name__ + ": " + str(e)}, ensure_ascii=False)

def main():
    print("EPUB Toolkit Android menggunakan komunikasi WebView lokal tanpa server jaringan.")

if __name__ == "__main__":
    main()
