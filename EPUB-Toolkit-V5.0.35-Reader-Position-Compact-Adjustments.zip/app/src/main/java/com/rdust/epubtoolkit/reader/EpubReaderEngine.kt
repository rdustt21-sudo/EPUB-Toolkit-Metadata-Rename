package com.rdust.epubtoolkit.reader

import android.content.ContentResolver
import android.net.Uri
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.File
import java.net.URLDecoder
import java.util.zip.ZipFile
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader

data class ReaderChapter(val title: String, val href: String, val plainText: String = "", val html: String = "", val imagePaths: List<String> = emptyList())
data class ReaderBook(val title: String, val author: String, val chapters: List<ReaderChapter>, val archivePath: String)
data class EpubSearchResult(val chapterIndex: Int, val snippet: String, val occurrenceInChapter: Int)

object EpubReaderEngine {
    /** Copy the selected EPUB once to app cache, then retain only spine metadata in memory. */
    fun open(resolver: ContentResolver, uri: Uri, displayName: String): ReaderBook {
        val archive = File.createTempFile("rd-reader-", ".epub")
        try {
            resolver.openInputStream(uri)?.use { input -> archive.outputStream().use { output -> input.copyTo(output) } }
                ?: error("Cannot open this EPUB file")
            ZipFile(archive).use { zip ->
                val containerEntry = zip.getEntry("META-INF/container.xml") ?: error("Invalid EPUB: container.xml missing")
                val container = secureParse(zip.getInputStream(containerEntry).bufferedReader(Charsets.UTF_8).use { it.readText() })
                val rootfile = container.getElementsByTagNameNS("*", "rootfile").item(0) as? org.w3c.dom.Element
                    ?: error("EPUB package document not found")
                val opfPath = rootfile.getAttribute("full-path")
                require(opfPath.isNotBlank()) { "Invalid EPUB: OPF path is empty" }
                val opfEntry = zip.getEntry(opfPath) ?: error("EPUB OPF file missing")
                val opf = secureParse(zip.getInputStream(opfEntry).bufferedReader(Charsets.UTF_8).use { it.readText() })
                val title = firstText(opf, "title").ifBlank { displayName.removeSuffix(".epub") }
                val author = firstText(opf, "creator")
                val base = opfPath.substringBeforeLast('/', "")
                val manifest = mutableMapOf<String, Pair<String, String>>()
                val items = opf.getElementsByTagNameNS("*", "item")
                for (i in 0 until items.length) {
                    val item = items.item(i) as org.w3c.dom.Element
                    manifest[item.getAttribute("id")] = item.getAttribute("href") to item.getAttribute("media-type")
                }
                val spine = opf.getElementsByTagNameNS("*", "spine").item(0) ?: error("EPUB spine missing")
                val chapters = mutableListOf<ReaderChapter>()
                val refs = (0 until spine.childNodes.length).mapNotNull { spine.childNodes.item(it) as? org.w3c.dom.Element }.filter { it.localName == "itemref" }
                for (ref in refs) {
                    val pair = manifest[ref.getAttribute("idref")] ?: continue
                    val href = pair.first.substringBefore('#')
                    if (!(pair.second.contains("xhtml") || pair.second.contains("html") || href.endsWith(".xhtml", true) || href.endsWith(".html", true) || href.endsWith(".htm", true))) continue
                    val fullPath = normalizePath(if (base.isBlank()) href else "$base/$href")
                    val entry = zip.getEntry(fullPath) ?: zip.entries().asSequence().firstOrNull { it.name.equals(fullPath, true) } ?: continue
                    // Read just enough to identify the chapter. Discard its document immediately;
                    // full HTML/text conversion happens only when this chapter is requested.
                    val parsed = Jsoup.parse(zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() })
                    parsed.select("script,style,nav").remove()
                    val chapterTitle = parsed.selectFirst("h1,h2,title")?.text()?.trim()?.takeIf { it.isNotBlank() }
                        ?: href.substringAfterLast('/').substringBeforeLast('.').replace('_', ' ')
                    if (parsed.body().text().isNotBlank() || parsed.body().select("img[src], img[data-src], img[data-original]").isNotEmpty()) chapters += ReaderChapter(chapterTitle, fullPath)
                }
                if (chapters.isEmpty()) error("No readable XHTML chapters found in this EPUB")
                return ReaderBook(title, author, chapters, archive.absolutePath)
            }
        } catch (e: Exception) {
            archive.delete()
            throw e
        }
    }

    fun close(book: ReaderBook?) {
        if (book != null) {
            runCatching { File(book.archivePath).delete() }
            runCatching { File(book.archivePath + ".images").deleteRecursively() }
        }
    }

    /** Render only the selected chapter. The returned HTML/text is not retained for other chapters. */
    fun loadChapter(book: ReaderBook, index: Int): ReaderChapter {
        val metadata = book.chapters[index]
        ZipFile(book.archivePath).use { zip ->
            val entry = zip.getEntry(metadata.href) ?: error("Chapter file missing: ${metadata.href}")
            val raw = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            val parsed: Document = Jsoup.parse(raw)
            parsed.select("script,style,nav").remove()
            val body = parsed.body()
            val html = body.html()
            val text = chapterPlainText(body)
            val imagePaths = extractChapterImages(zip, metadata.href, body, book.archivePath)
            return metadata.copy(plainText = text, html = html, imagePaths = imagePaths)
        }
    }

    /** Extract chapter image assets to a temporary cache directory so Compose can decode them. */
    private fun extractChapterImages(zip: ZipFile, chapterPath: String, body: org.jsoup.nodes.Element, archivePath: String): List<String> {
        val cacheDir = File(archivePath + ".images").apply { mkdirs() }
        val result = mutableListOf<String>()
        val base = chapterPath.substringBeforeLast('/', "")
        for (img in body.select("img[src], img[data-src], img[data-original]")) {
            val rawSrc = img.attr("src").ifBlank { img.attr("data-src") }.ifBlank { img.attr("data-original") }
                .substringBefore('#').substringBefore('?').trim()
            if (rawSrc.isBlank() || rawSrc.startsWith("data:", true)) continue
            val decoded = runCatching { URLDecoder.decode(rawSrc, "UTF-8") }.getOrDefault(rawSrc)
            val normalized = normalizePath(if (decoded.startsWith('/')) decoded.trimStart('/') else "$base/$decoded")
            val entry = zip.getEntry(normalized) ?: zip.entries().asSequence().firstOrNull { it.name.equals(normalized, true) } ?: continue
            val extension = entry.name.substringAfterLast('.', "img").lowercase().take(8)
            val outFile = File(cacheDir, "${normalized.hashCode().toUInt().toString(16)}.$extension")
            if (!outFile.exists() || outFile.length() == 0L) runCatching {
                zip.getInputStream(entry).use { input -> outFile.outputStream().use { output -> input.copyTo(output) } }
            }.onFailure { outFile.delete() }
            if (outFile.exists() && outFile.length() > 0) result += outFile.absolutePath
        }
        return result.distinct()
    }

    /** Search the EPUB archive directly and return each occurrence, without rendering chapter HTML or images. */
    fun search(book: ReaderBook, query: String): List<EpubSearchResult> {
        val q = query.trim().take(200)
        if (q.isEmpty()) return emptyList()
        val results = ArrayList<EpubSearchResult>()
        ZipFile(book.archivePath).use { zip ->
            for ((index, chapter) in book.chapters.withIndex()) {
                if (results.size >= 1000) break
                val entry = zip.getEntry(chapter.href) ?: continue
                val parsed = Jsoup.parse(zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() })
                parsed.select("script,style,nav").remove()
                val text = chapterPlainText(parsed.body())
                var cursor = 0
                var occurrence = 0
                while (cursor <= text.length - q.length && results.size < 1000) {
                    val pos = text.indexOf(q, startIndex = cursor, ignoreCase = true)
                    if (pos < 0) break
                    occurrence++
                    val matchEnd = pos + q.length
                    val start = contextStart(text, pos, 5)
                    val end = contextEnd(text, matchEnd, 5)
                    val snippet = buildString {
                        if (start > 0) append("… ")
                        append(text.substring(start, end).replace(Regex("\\s+"), " ").trim())
                        if (end < text.length) append(" …")
                    }
                    results += EpubSearchResult(index, snippet, occurrence)
                    // Advance by the query length to avoid duplicate overlapping hits.
                    cursor = pos + q.length
                }
            }
        }
        return results
    }

    private fun chapterPlainText(body: org.jsoup.nodes.Element): String =
        body.select("h1,h2,h3,h4,p,li,blockquote,pre").eachText()
            .filter { it.isNotBlank() }.joinToString("\n\n").ifBlank { body.text() }.trim()

    private fun contextStart(text: String, matchStart: Int, wordsBefore: Int): Int {
        var i = matchStart.coerceIn(0, text.length); var found = 0
        while (i > 0 && found < wordsBefore) {
            while (i > 0 && text[i - 1].isWhitespace()) i--
            if (i == 0) break
            while (i > 0 && !text[i - 1].isWhitespace()) i--
            found++
        }
        return i
    }

    private fun contextEnd(text: String, matchEnd: Int, wordsAfter: Int): Int {
        var i = matchEnd.coerceIn(0, text.length); var found = 0
        while (i < text.length && found < wordsAfter) {
            while (i < text.length && text[i].isWhitespace()) i++
            if (i >= text.length) break
            while (i < text.length && !text[i].isWhitespace()) i++
            found++
        }
        return i
    }

    private fun secureParse(xml: String): org.w3c.dom.Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { isXIncludeAware = false }; runCatching { isExpandEntityReferences = false }
            setFeatureIfSupported(XMLConstants.FEATURE_SECURE_PROCESSING, true)
            setFeatureIfSupported("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeatureIfSupported("http://xml.org/sax/features/external-general-entities", false)
            setFeatureIfSupported("http://xml.org/sax/features/external-parameter-entities", false)
            setAttributeIfSupported("http://javax.xml.XMLConstants/property/accessExternalDTD", "")
            setAttributeIfSupported("http://javax.xml.XMLConstants/property/accessExternalSchema", "")
        }
        val builder = factory.newDocumentBuilder().apply { setEntityResolver { _, _ -> InputSource(StringReader("")) } }
        return builder.parse(InputSource(StringReader(xml)))
    }
    private fun DocumentBuilderFactory.setFeatureIfSupported(name: String, value: Boolean) { runCatching { setFeature(name, value) } }
    private fun DocumentBuilderFactory.setAttributeIfSupported(name: String, value: String) { runCatching { setAttribute(name, value) } }
    private fun firstText(doc: org.w3c.dom.Document, tag: String): String {
        val nodes = doc.getElementsByTagNameNS("*", tag)
        for (i in 0 until nodes.length) nodes.item(i).textContent?.trim()?.let { if (it.isNotBlank()) return it }
        return ""
    }
    private fun normalizePath(path: String): String {
        val stack = mutableListOf<String>()
        path.replace('\\', '/').split('/').forEach { part ->
            when (part) { "", "." -> Unit; ".." -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); else -> stack += URLDecoder.decode(part, "UTF-8") }
        }
        return stack.joinToString("/")
    }
}
