package com.example.epubtoolkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ToolkitApp() }
    }
}


private val Background = Color(0xFF0D121E)
private val SurfaceDark = Color(0xFF171F2D)
private val SurfaceRaised = Color(0xFF202B3B)
private val TextPrimary = Color(0xFFE8EDF5)
private val TextMuted = Color(0xFF9AA9BC)
private val Accent = Color(0xFF8EBBFF)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolkitApp() {
    var screen by rememberSaveable { mutableStateOf("Library") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Background, surface = SurfaceDark, primary = Accent,
        onBackground = TextPrimary, onSurface = TextPrimary
    )) {
        Scaffold(
            containerColor = Background,
            topBar = {
                TopAppBar(
                    title = { Text(screen, fontWeight = FontWeight.SemiBold) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                    navigationIcon = {
                        Icon(Icons.Default.Book, contentDescription = null,
                            modifier = Modifier.padding(start = 16.dp), tint = Accent)
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    listOf("Library", "Single", "Batch").forEach { label ->
                        val icon = when (label) {
                            "Library" -> Icons.Default.Folder
                            "Single" -> Icons.Default.Tune
                            else -> Icons.Default.Build
                        }
                        NavigationBarItem(
                            selected = screen == label,
                            onClick = { screen = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = SurfaceRaised,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "Library" -> LibraryHome()
                    "Single" -> FeatureList(singleFeatures, "Single Feature")
                    "Batch" -> FeatureList(batchFeatures, "Batch Feature")
                }
            }
        }
    }
}


@Composable
private fun LibraryHome() {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("My Library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Native V5 foundation", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = { /* file picker will be wired in Library milestone */ }) {
                Icon(Icons.Default.Folder, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Choose folder")
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Book, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
                Spacer(Modifier.height(8.dp))
                Text("Library engine is not connected yet", fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("This is the native V5 shell. File scanning and EPUB actions will be ported next.",
                    color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}


private val singleFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace", "Unzip File"
)
private val batchFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Batch Unzip (ZIP)",
    "Bulk Find & Replace — Count Matches", "Bulk Find & Replace — Execute"
)


@Composable
private fun FeatureList(features: List<String>, heading: String) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(heading, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Feature catalog · Processing will be added as native modules", color = TextMuted,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        }
        items(features) { feature ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(feature, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text("›", color = TextMuted, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}
