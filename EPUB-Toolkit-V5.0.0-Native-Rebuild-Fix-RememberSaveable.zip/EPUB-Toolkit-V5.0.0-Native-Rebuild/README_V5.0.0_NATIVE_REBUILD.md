# EPUB Toolkit V5 V5.0.0 — Native Rebuild Foundation


## This milestone
This is the first native Android foundation built with Kotlin and Jetpack Compose. It does not embed WebView, JavaScript, or Python.\n
Included:
- Native Compose app shell and dark theme
- Bottom navigation for Library, Single Feature, and Batch Feature
- Feature catalog reflecting the V4 tool ordering
- Native project structure for future EPUB, file, and ZIP modules
- Existing launcher icon assets reused

Not yet implemented:
- Library folder selection, scan, sorting, covers, and history
- EPUB reader
- Single-feature processing implementations
- Batch processing engine
- ZIP extraction/password workflow
- EPUB metadata/content parsing and image compression

This shell is intentionally explicit about unfinished functionality; it is not a replacement for V4 yet.

## Stack
- Kotlin / Android Gradle Plugin 8.6.1
- Kotlin 2.0.21
- Jetpack Compose BOM 2024.12.01
- Compose Material 3
- Navigation Compose dependency reserved for later native navigation
- minSdk 24, targetSdk 35, compileSdk 35
- appId retained: com.rdustt21.epubtoolkit.v5
- versionName 5.0.0 / versionCode 500

## Build
Open this folder in Android Studio and sync Gradle. Gradle wrapper is not included in this archive.
