package com.example.epubtoolkit.core.epub

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/** First native EPUB operation, migrated from V4's metadata-title rename behavior. */
object NativeEpubProcessor {
    data class RenameResult(val title: String, val newName: String, val message: String = "")


    fun renameByMetadataTitle(context: Context, uri: Uri): Result<RenameResult> = runCatching {
        val source = DocumentFile.fromSingleUri(context, uri) ?: error("Cannot access selected file")
        val currentName = source.name ?: error("File name is unavailable")
        require(currentName.endsWith(".epub", ignoreCase = true)) { "Please select an EPUB file." }
        val title = readMetadataTitle(context, uri).trim().ifBlank { currentName.removeSuffixEpub() }
        val safeStem = sanitizeFilename(title).ifBlank { currentName.removeSuffixEpub() }
        val targetName = uniqueSiblingName(source, safeStem + ".epub")
        if (targetName.equals(currentName, ignoreCase = true)) {
            return@runCatching RenameResult(title, currentName, "Filename already matches the metadata title.")
        }
        val renamed = source.renameTo(targetName)
        check(renamed) { "Android could not rename this file. Try a folder with write access." }
        RenameResult(title, targetName)
    }


    private fun readMetadataTitle(context: Context, uri: Uri): String {
        val resolver = context.contentResolver
        val containerBytes = resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "META-INF/container.xml") return@use zip.readBytes()
                    zip.closeEntry(); entry = zip.nextEntry
                }
                null
            }
        } ?: return ""
        var opfPath = ""
        try {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(containerBytes), null)
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name.equals("rootfile", true)) {
                    opfPath = parser.getAttributeValue(null, "full-path") ?: ""
                    if (opfPath.isNotBlank()) break
                }
            }
        } catch (_: Exception) { return "" }
        if (opfPath.isBlank()) return ""
        val opfBytes = resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == opfPath) return@use zip.readBytes()
                    zip.closeEntry(); entry = zip.nextEntry
                }
                null
            }
        } ?: return ""
        try {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(opfBytes), null)
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name.equals("title", true)) {
                    return parser.nextText().trim()
                }
            }
        } catch (_: Exception) { }
        return ""
    }


    private fun uniqueSiblingName(source: DocumentFile, desired: String): String {
        val parent = source.parentFile ?: error("File's parent folder is unavailable")
        if (desired.equals(source.name, ignoreCase = true)) return desired
        var candidate = desired
        var counter = 2
        while (parent.findFile(candidate) != null) {
            val stem = desired.removeSuffixEpub()
            candidate = "${stem}_$counter.epub"
            counter++
        }
        return candidate
    }

    private fun sanitizeFilename(input: String): String = input
        .replace(Regex("[\\/:*?\"<>|\\x00-\\x1f]"), "")
        .replace(Regex("\\s+"), " ")
        .trim().trimEnd('.', ' ').take(180).trimEnd('.', ' ')

    private fun String.removeSuffixEpub(): String = if (endsWith(".epub", true)) dropLast(5) else this
}
