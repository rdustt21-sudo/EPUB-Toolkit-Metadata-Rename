EPUB Toolkit V4.2.15 — Startup Animation

Base: V4.2.14 Pull Refresh Fix
App version: 2.0.6 (version code 15)\n
Changes:
- Set native Android launch/window theme to a dark background to prevent the white launch flash.
- Set WebView background to the same dark color while HTML initializes.
- Added a short native startup overlay with a book emoji, Toolkit title, subtitle, and progress animation.
- Startup overlay fades away as soon as the WebView finishes loading; no artificial delay is added.
- Existing Toolkit code/features were not intentionally modified.

Build/device testing was not performed in this environment.
