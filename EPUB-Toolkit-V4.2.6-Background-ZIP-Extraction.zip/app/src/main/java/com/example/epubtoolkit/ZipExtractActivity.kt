package com.example.epubtoolkit

import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.Toast
import net.lingala.zip4j.ZipFile
import java.io.File
import java.io.FileOutputStream

/** Handles ZIP files sent from file managers without displaying the toolkit UI. */
class ZipExtractActivity : Activity() {
    private val zipPassword = "taiwanandnorthkorea"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent?.data
        if (uri == null || !Intent.ACTION_VIEW.equals(intent?.action)) {
            finish()
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("Izinkan akses file untuk mengekstrak ZIP")
            finish()
            return
        }
        Thread {
            val message = try {
                extract(uri)
            } catch (e: Exception) {
                "Ekstraksi ZIP gagal: ${e.message ?: e.javaClass.simpleName}"
            }
            runOnUiThread {
                toast(message)
                finish()
            }
        }.start()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()


    private fun displayName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = cursor.getString(idx)
                }
            }
        }
        if (name.isNullOrBlank()) name = uri.lastPathSegment
        return name ?: "archive.zip"
    }

    private fun parentFolder(uri: Uri): File? {
        if (uri.scheme == "file") return File(uri.path ?: return null).parentFile
        if (uri.scheme == ContentResolver.SCHEME_CONTENT && uri.authority == "com.android.externalstorage.documents") {
            return try {
                val id = DocumentsContract.getDocumentId(uri)
                if (id.startsWith("primary:")) {
                    val relative = id.substringAfter("primary:")
                    val root = Environment.getExternalStorageDirectory().canonicalFile
                    val file = File(root, relative).canonicalFile
                    if (file.path.startsWith(root.path + File.separator) && file.isFile) file.parentFile else null
                } else null
            } catch (_: Exception) { null }
        }
        return null
    }


    private fun extract(uri: Uri): String {
        val fileName = displayName(uri)
        if (!fileName.endsWith(".zip", true)) throw IllegalArgumentException("File bukan ZIP")
        val target = (parentFolder(uri) ?: Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)).canonicalFile
        if (!target.exists() && !target.mkdirs()) throw IllegalStateException("Folder tujuan tidak dapat dibuat")
        if (!target.isDirectory) throw IllegalStateException("Tujuan bukan folder")

        val temp = File(cacheDir, "zip-open-${System.currentTimeMillis()}.zip")
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("File ZIP tidak dapat dibaca")
            val zip = ZipFile(temp, zipPassword.toCharArray())
            var count = 0
            for (header in zip.fileHeaders) {
                val normalized = header.fileName.replace("\\", "/")
                if (normalized.startsWith("/") || normalized.split("/").any { it == ".." || it == "." }) {
                    throw IllegalArgumentException("ZIP berisi jalur tidak valid: $normalized")
                }
                val parts = normalized.split("/").filter { it.isNotEmpty() }
                if (parts.isEmpty()) continue
                var folder = target
                val parentParts = if (header.isDirectory) parts else parts.dropLast(1)
                for (part in parentParts) folder = File(folder, part)
                val safeParent = folder.canonicalFile
                if (!safeParent.path.startsWith(target.path + File.separator) && safeParent != target) {
                    throw IllegalArgumentException("Lokasi ekstraksi tidak valid")
                }
                if (!safeParent.exists() && !safeParent.mkdirs()) throw IllegalStateException("Folder gagal dibuat")
                if (header.isDirectory) continue
                val original = parts.last()
                val dot = original.lastIndexOf('.')
                val base = if (dot > 0) original.substring(0, dot) else original
                val ext = if (dot > 0) original.substring(dot) else ""
                var outputName = original
                var suffix = 2
                while (File(safeParent, outputName).exists()) {
                    outputName = "${base}_${suffix}${ext}"
                    suffix++
                }
                zip.extractFile(header, safeParent.absolutePath, outputName)
                count++
            }
            return "ZIP selesai: $count file diekstrak ke ${target.name}"
        } finally {
            temp.delete()
        }
    }
}
