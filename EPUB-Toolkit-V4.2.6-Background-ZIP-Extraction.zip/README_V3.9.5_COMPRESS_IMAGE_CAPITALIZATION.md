# RED-DUST EPUB Toolkit V3.9.5 — Compress Image Capitalization

Updated the feature label from `Compress image` to `Compress Image` in both Single Feature and Batch Processing menus, and in the Single Feature panel title.

No operation routes or image compression logic were changed.
