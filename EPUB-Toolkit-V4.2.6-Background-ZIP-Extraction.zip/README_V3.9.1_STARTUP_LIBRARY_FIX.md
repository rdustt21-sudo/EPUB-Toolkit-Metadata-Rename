# RED-DUST EPUB Toolkit V3.9.1 – Startup My Library Fix

## Change
- My Library is visible from the initial HTML/CSS paint.
- Toolkit main area is initially hidden, preventing the Toolkit screen from flashing before the startup navigation JavaScript runs.
- Existing `switchGallery('albums')` startup behavior remains as a consistency check after JavaScript initializes.

## Preserved
- Toolkit remains accessible from the Tools tab.
- No reader, search, pagination, cover-cache, or processing logic changed.

## Validation
- ZIP integrity, Python syntax, and embedded JavaScript syntax checked.
- No Android Gradle build or device test performed.
