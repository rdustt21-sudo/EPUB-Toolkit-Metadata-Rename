EPUB Toolkit V4.2.5 — Open With ZIP Auto Extract

Base: stable V4.2.4 recovery version.

Added: Android ACTION_VIEW ZIP intent filters so the app can appear in compatible file-manager Open with menus. When opened with a ZIP, it copies the incoming content URI to a temporary file, extracts automatically without a destination picker, avoids overwriting existing files by suffixing names, and reports the extraction result in the app status.

Destination: attempts to use the source ZIP parent folder when the Android external-storage document URI exposes a reliable primary-storage path; otherwise uses Downloads. Password handling uses the toolkit's existing default ZIP password.

Existing toolkit UI and batch-unzip logic were not changed.
