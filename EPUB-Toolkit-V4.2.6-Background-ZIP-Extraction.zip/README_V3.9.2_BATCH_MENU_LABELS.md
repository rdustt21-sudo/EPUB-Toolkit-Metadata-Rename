# RED-DUST EPUB Toolkit V3.9.2 — Batch Menu Labels

## Change
Updated the Batch Processing operation dropdown labels for clearer, consistent capitalization and removed the redundant `(EPUB)` suffix from EPUB-only operation names.

- Capitalized and standardized the operation names.
- Changed `5A` to `Bulk Find & Replace — Count Matches`.
- Changed `5B` to `Bulk Find & Replace — Execute`.
- Removed `(EPUB)` from the other EPUB operation labels, including Read Cover Metadata.
- Kept `(EPUB/TXT)` on the two Find & Replace operations to indicate supported file types.
- Kept `(ZIP)` on Batch Unzip because it identifies the file type.

No batch processing logic, route values, file selection, or other features were changed.
