# RED-DUST EPUB Toolkit V3.5 — Stage 3.1 Lazy Chapter Rendering

## Change
- Reader opening still scans the EPUB spine to collect chapter titles and navigation hrefs.
- Reader HTML conversion and local-image Base64 embedding now happen only for the selected chapter.
- Non-selected chapters are not serialized into reader HTML during chapter navigation.
- Invalid/stale chapter indices are clamped and the clamped chapter is rendered.

## Preserved
- Chapter metadata/order used by the chapter selector and internal links.
- Existing selected-chapter rendering, image data URI conversion, and internal-link handling.
- Search function and search snippet optimization are unchanged.
- UI is unchanged.

## Verification
- Python syntax compilation passed.
- Synthetic EPUB test passed: chapter list preserved, selected chapter rendered, selected chapter image embedded, other chapters not present in returned content, and out-of-range chapter index clamped to the final chapter.
- ZIP integrity check passed.
- No Android/Gradle build or device test performed.
