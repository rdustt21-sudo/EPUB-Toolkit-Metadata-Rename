# RED-DUST EPUB Toolkit V3.9.1 — Default My Library Startup

## Change
- Explicitly define the startup gallery destination as `albums` (Read Book / My Library).
- `switchGallery()` defaults to the My Library destination.
- Startup calls the destination constant; Toolkit remains accessible from Tools.

## Preserved
- Toolkit features and controls
- EPUB reader, search, pagination, style controls, and reader state
- Stage 3.1–3.5 optimizations from V3.9

## Validation
- ZIP integrity checked after packaging
- Python syntax parsed
- Embedded JavaScript syntax checked with Node
- No Android Gradle build or device test performed
