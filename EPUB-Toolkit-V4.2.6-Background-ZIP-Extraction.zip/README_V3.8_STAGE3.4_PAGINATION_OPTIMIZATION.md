# RED-DUST EPUB Toolkit V3.8 - Stage 3.4

- Replaced per-paragraph margin updates on settings changes with a CSS custom property.
- Added a signature guard to avoid reapplying reader styles and column geometry when effective settings are unchanged.
- Captures and restores approximate current page index after a style change and refreshes page counter/saved progress.
- Search, EPUB loading, chapter rendering, cover cache, and UI controls intentionally left unchanged.

Verification: Python syntax, ZIP integrity, and JavaScript syntax checked. Android build and device test not performed.
