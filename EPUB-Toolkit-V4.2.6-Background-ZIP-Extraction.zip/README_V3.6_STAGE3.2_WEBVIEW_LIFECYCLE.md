# RED-DUST EPUB Toolkit V3.6 — Stage 3.2 WebView Lifecycle

Based on V3.5 Stage 3.1 Lazy Chapter Rendering.

## Changes
- WebView resumes with the Activity and resumes timers on foreground.
- WebView pauses with the Activity and pauses timers while backgrounded.
- Activity destruction stops WebView loading, removes the Android JavaScript bridge,
  clears WebView history, detaches its child views, and destroys the WebView.
- Normal pause/resume intentionally preserves the reader DOM and JavaScript state.

## Preserved
- V3.4 search optimization
- V3.5 lazy chapter rendering
- Reader UI and settings
- EPUB chapter navigation and internal links

## Verification
- ZIP integrity checked.
- Python source syntax checked.
- Kotlin lifecycle patch reviewed; Android Gradle build/device testing not performed here.
