# EPUB Toolkit V4.1.8 — JavaScript Cleanup Stage 2

Changes are intentionally small and behavior-preserving:
- Removed the unused `readerSearchHistoryPressTimer` declaration.
- Removed the unused `pressStart` declaration in the library card touch handler.

No functions, event handlers, UI, reader behavior, search/sort behavior, or Android integration were changed.

Validation performed:
- Python syntax compilation of `epub_app.py`.
- JavaScript static checks: no duplicate named functions; declarations removed were confirmed to have no references.
- ZIP integrity check.

This is a conservative cleanup stage; it does not claim broad JavaScript optimization or runtime testing on Android.
