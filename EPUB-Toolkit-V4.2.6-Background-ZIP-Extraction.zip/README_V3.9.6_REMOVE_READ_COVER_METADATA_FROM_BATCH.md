# RED-DUST EPUB Toolkit V3.9.6 — Remove Read Cover Metadata from Batch Menu

- Removed the `Read Cover Metadata` option from the Batch Processing dropdown only.
- Kept the underlying `/cover-meta` endpoint and feature code intact.
- No other menu labels, order, routes, or functionality intentionally changed.

Validation: ZIP integrity and Python syntax checked. No Android build/device test performed.
