# EPUB Toolkit V4.2.6 — Background ZIP Extraction

Based on V4.2.5 Open-With ZIP auto-extraction.

## Change
- ZIP file manager Open With handling moved from MainActivity to a separate translucent ZipExtractActivity.
- ZIP extraction runs without loading the Toolkit WebView/UI.
- Shows a brief Toast with extraction result, then closes the handler.
- Keeps the existing password, destination-folder resolution, Downloads fallback, safe path checks, and conflict-renaming behavior.
- MainActivity remains the regular launcher and does not handle external ZIP intents.

## Notes
- Requires the app's existing All Files Access permission. If not granted, this handler reports that permission is needed and closes without launching the toolkit or settings.
- Android build/device test not performed in this environment.
