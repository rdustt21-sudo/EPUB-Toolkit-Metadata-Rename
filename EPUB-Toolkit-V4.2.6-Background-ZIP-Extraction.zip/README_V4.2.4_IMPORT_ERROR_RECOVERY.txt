EPUB Toolkit V4.2.4 — Import Error Recovery

Recovery baseline: V4.2.2. The V4.2.3 cleanup package is not used.
The BaseHTTPRequestHandler NameError resulted from removal of the http.server
import in embedded modules. This package restores the V4.2.2 source, where both
modules retain:
  from http.server import BaseHTTPRequestHandler, HTTPServer

No additional cleanup or functional/UI changes were applied.
Affected modules: BULK_FIND_REPLACE.py and COMPACT_LINE_SPACING_FIXER.py.