# RED-DUST EPUB Toolkit V3.7 — Stage 3.3: Bounded Cover Cache

## Change
- Bounds the library cover cache to at most 10 entries.
- Bounds retained cover data to about 4 MiB of string data.
- Covers larger than about 1.5 MiB are displayed for the current card but are not retained in the JS cache.
- Cache hits are refreshed in insertion order so recently used entries are less likely to be evicted.
- Library rescan continues to clear the cover cache.

## Scope
This is a conservative cache-retention change only. It does not change EPUB extraction, reader HTML, search, chapter rendering, WebView lifecycle, or UI.

## Verification
- Python syntax compile: passed.
- Embedded JavaScript syntax (`node --check`): passed.
- ZIP integrity test: passed.
- Android Gradle build and on-device testing: not performed; user testing required.
