
const $=id=>document.getElementById(id), val=id=>$(id).value;let files=[];const readerCoverCache={};
// Stage 3.3: bound retained cover data to prevent library browsing from growing
// the JavaScript cache indefinitely. Large covers are displayed but not retained.
const READER_COVER_CACHE_MAX_ENTRIES=10, READER_COVER_CACHE_MAX_CHARS=4*1024*1024, READER_COVER_CACHE_MAX_ITEM_CHARS=1536*1024;
function readerCoverCacheChars(){return Object.values(readerCoverCache).reduce((sum,value)=>sum+(typeof value==='string'?value.length:0),0);}
function readerCoverCacheSet(key,value){delete readerCoverCache[key];if(typeof value==='string'&&value.length>READER_COVER_CACHE_MAX_ITEM_CHARS)return;readerCoverCache[key]=value;while(Object.keys(readerCoverCache).length>READER_COVER_CACHE_MAX_ENTRIES||readerCoverCacheChars()>READER_COVER_CACHE_MAX_CHARS){const first=Object.keys(readerCoverCache)[0];if(first===undefined)break;delete readerCoverCache[first];}}
function readerCoverCacheTouch(key){if(!Object.prototype.hasOwnProperty.call(readerCoverCache,key))return;const value=readerCoverCache[key];delete readerCoverCache[key];readerCoverCache[key]=value;}
let selectedBookPaths=new Set(),bookLongPressTimer=null,suppressBookClick=false;

function switchGallery(which){
  const albums=which==='albums';
  document.body.classList.toggle('reader-active',albums);
  $('reader-view').classList.remove('controls-hidden');
  document.querySelector('main').style.display=albums?'none':'block';
  $('reader-view').style.display=albums?'block':'none';
  $('library-view').style.display='block';$('reader-screen').style.display='none';
  $('gallery-photos').classList.toggle('active',!albums);
  $('gallery-albums').classList.toggle('active',albums);
  if(albums)populateReaderFiles();
}
let readerBook=null, readerFileLoaded='', readerSearchMatches=[], readerSearchIndex=-1, readerSearchQuery='';
let readerSearchPanelScrollTop=0;
let readerSearchHistory=[];let readerSearchHistoryPressTimer=null;
let libraryPullStartY=0,libraryPullStartX=0,libraryPullArmed=false,libraryPullDistance=0,libraryRefreshBusy=false;
const libraryScrollArea=$('reader-view');
if(libraryScrollArea){
 libraryScrollArea.addEventListener('touchstart',e=>{
  if($('library-view').style.display==='none'||$('reader-screen').style.display==='block'||libraryRefreshBusy||e.touches.length!==1)return;
  const t=e.touches[0];libraryPullStartY=t.clientY;libraryPullStartX=t.clientX;libraryPullArmed=libraryScrollArea.scrollTop<=2;libraryPullDistance=0;
 },{passive:true});
 libraryScrollArea.addEventListener('touchmove',e=>{
  if(!libraryPullArmed||e.touches.length!==1)return;
  const t=e.touches[0],dy=t.clientY-libraryPullStartY,dx=t.clientX-libraryPullStartX;
  if(Math.abs(dx)>Math.abs(dy)*.8){libraryPullArmed=false;return;}
  if(dy>0&&libraryScrollArea.scrollTop<=2){libraryPullDistance=Math.min(100,dy);const ind=$('library-refresh-indicator');if(ind){ind.classList.toggle('visible',dy>12);ind.textContent=dy>=76?'Lepaskan untuk scan ulang':'Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchend',()=>{
  const shouldRefresh=libraryPullArmed&&libraryPullDistance>=76;libraryPullArmed=false;libraryPullDistance=0;
  if(shouldRefresh)refreshLibraryScan();else{const ind=$('library-refresh-indicator');if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchcancel',()=>{libraryPullArmed=false;libraryPullDistance=0;const ind=$('library-refresh-indicator');if(ind)ind.classList.remove('visible');},{passive:true});
}
async function refreshLibraryScan(){
 if(libraryRefreshBusy)return;libraryRefreshBusy=true;const ind=$('library-refresh-indicator');
 if(ind){ind.classList.add('visible');ind.textContent='Memindai ulang EPUB…';}
 try{
  Object.keys(readerCoverCache).forEach(k=>delete readerCoverCache[k]);
  await new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,30)));
  await loadFiles();
  if(ind)ind.textContent='Scan selesai · My Library diperbarui';
 }catch(e){if(ind)ind.textContent='Gagal scan ulang: '+e.message;}
 setTimeout(()=>{if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}libraryRefreshBusy=false;},900);
}
function savedReaderState(){try{return JSON.parse(localStorage.getItem('redDustReaderProgress')||'{}')}catch(e){return {}}}
let readerPendingFragment='';
function readerLinkPath(raw,current){try{const u=new URL(String(raw||''),'https://rd-epub.invalid/'+String(current||'').replace(/^\//,''));let p=decodeURIComponent(u.pathname).replace(/^\//,'');const parts=[];p.split('/').forEach(seg=>{if(!seg||seg==='.')return;if(seg==='..')parts.pop();else parts.push(seg);});return parts.join('/');}catch(e){return '';}}
function readerLandOnFragment(fragment){if(!fragment)return;const el=$('reader-content');let target=null;try{target=el.querySelector('[id="'+CSS.escape(fragment)+'"]')||el.querySelector('[name="'+CSS.escape(fragment)+'"]');}catch(e){}if(target){const rect=target.getBoundingClientRect();const base=el.getBoundingClientRect();el.scrollLeft=Math.max(0,el.scrollLeft+rect.left-base.left);updateReaderPageCount();saveReaderState();}}
function readerFragmentFromHref(raw){const i=String(raw||'').indexOf('#');if(i<0)return '';try{return decodeURIComponent(String(raw).slice(i+1));}catch(e){return String(raw).slice(i+1);}}
function handleReaderInternalLink(event){const anchor=event.target&&event.target.closest?event.target.closest('a[data-rd-href]'):null;if(!anchor)return;event.preventDefault();const raw=(anchor.getAttribute('data-rd-href')||'').trim();if(!raw)return;const current=readerBook&&readerBook.chapters[readerBook.index]?readerBook.chapters[readerBook.index].href:'';const targetPath=readerLinkPath(raw.split('#')[0]||current,current);const fragment=readerFragmentFromHref(raw);const currentPath=readerLinkPath(current,current);if(!targetPath||targetPath===currentPath){readerLandOnFragment(fragment);return;}const chapters=readerBook&&readerBook.chapters||[];let idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href)===targetPath);if(idx<0){const base=targetPath.split('/').pop().toLowerCase();if(base)idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href).split('/').pop().toLowerCase()===base);}if(idx>=0){readerPendingFragment=fragment;navigateReaderChapter(idx,'start');}else{console.warn('EPUB internal link target was not found in reading chapters:',raw,targetPath);}}
function readerCurrentPage(){const el=$('reader-content');return el&&el.clientWidth>0?Math.max(0,Math.round(el.scrollLeft/Math.max(1,el.clientWidth))):0;}
function saveReaderState(){if(!readerFileLoaded||!readerBook)return;const all=savedReaderState();all[readerFileLoaded]={chapter:readerBook.index||0,page:readerCurrentPage(),title:readerBook.title||''};try{localStorage.setItem('redDustReaderProgress',JSON.stringify(all));}catch(e){}}
function populateReaderFiles(){renderLibrary();}
function libraryTimestamps(){
 try{return JSON.parse(localStorage.getItem('redDustLibraryTimestamps')||'{"added":{},"recent":{}}');}
 catch(e){return {added:{},recent:{}};}
}
function setLibrarySort(mode){
 try{localStorage.setItem('redDustLibrarySort',mode);}catch(e){}
 renderLibrary();
}
function isBookSelectionMode(){return selectedBookPaths.size>0;}
function updateBookSelectionUI(){
 const toolbar=$('library-selection-toolbar'),count=$('library-selection-count');
 if(toolbar)toolbar.classList.toggle('visible',isBookSelectionMode());
 if(count)count.textContent=selectedBookPaths.size+' book'+(selectedBookPaths.size===1?'':'s')+' selected';
 $('library-view').classList.toggle('selection-mode',isBookSelectionMode());
}
function toggleBookSelection(path){if(selectedBookPaths.has(path))selectedBookPaths.delete(path);else selectedBookPaths.add(path);updateBookSelectionUI();renderLibrary();}
function beginBookSelection(path){if(!selectedBookPaths.has(path))selectedBookPaths.add(path);suppressBookClick=true;updateBookSelectionUI();renderLibrary();setTimeout(()=>{suppressBookClick=false;},450);}
function cancelBookSelection(){selectedBookPaths.clear();updateBookSelectionUI();renderLibrary();}
function selectAllVisibleBooks(){const q=($('library-search')?.value||'').toLowerCase().trim();files.filter(f=>/\.epub$/i.test(f.name)&&(!q||(f.name+' '+f.path).toLowerCase().includes(q))).forEach(f=>selectedBookPaths.add(f.path));updateBookSelectionUI();renderLibrary();}
async function deleteSelectedBooks(){
 const targets=[...selectedBookPaths];if(!targets.length)return;
 if(!confirm('Delete '+targets.length+' selected book'+(targets.length===1?'':'s')+' from your device? This cannot be undone.'))return;
 let deleted=0,failed=[];const progress=savedReaderState(),stamps=libraryTimestamps();
 for(const file of targets){try{await api('/delete-book',{file});deleted++;delete progress[file];delete stamps.added[file];delete stamps.recent[file];selectedBookPaths.delete(file);}catch(e){failed.push(file.split('/').pop()+': '+e.message);}}
 try{localStorage.setItem('redDustReaderProgress',JSON.stringify(progress));localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 updateBookSelectionUI();await loadFiles();
 if(failed.length)alert(deleted+' book(s) deleted. Could not delete '+failed.length+':\n'+failed.join('\n'));
 else alert(deleted+' book(s) deleted.');
}
function renderLibrary(){
 const box=$('library-books');if(!box)return;box.innerHTML='';
 const q=($('library-search')?.value||'').toLowerCase().trim();
 const books=files.filter(f=>/\.epub$/i.test(f.name)&&(!q||(f.name+' '+f.path).toLowerCase().includes(q)));
 const stamps=libraryTimestamps(),now=Date.now();
 books.forEach(f=>{if(!stamps.added[f.path])stamps.added[f.path]=(Number(f.added)>0?Number(f.added)*1000:now);});
 try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 const sortControl=$('library-sort');let sort=localStorage.getItem('redDustLibrarySort')||'name';
 if(!['name','added','recent'].includes(sort))sort='name';
 if(sortControl)sortControl.value=sort;
 books.sort((a,b)=>{
  if(sort==='added')return (stamps.added[b.path]||0)-(stamps.added[a.path]||0)||a.name.localeCompare(b.name);
  if(sort==='recent')return (stamps.recent[b.path]||0)-(stamps.recent[a.path]||0)||a.name.localeCompare(b.name);
  return a.name.localeCompare(b.name,undefined,{sensitivity:'base'});
 });
 $('library-stats').textContent=books.length+' EPUB book'+(books.length===1?'':'s')+' · Tap to read · Hold to select';
 updateBookSelectionUI();
 if(!books.length){box.innerHTML='<div class="reader-empty">No EPUB books found. Add EPUB files to your device storage and refresh the app.</div>';return;}
 const progress=savedReaderState();
 books.forEach(f=>{const state=progress[f.path],card=document.createElement('div');card.className='book-card'+(selectedBookPaths.has(f.path)?' selected':'');
 card.onclick=()=>{if(suppressBookClick){suppressBookClick=false;return;}if(isBookSelectionMode())toggleBookSelection(f.path);else openReaderBook(f.path,state?.chapter||0);};
 let pressStart=null,pressMoved=false;
 card.addEventListener('touchstart',()=>{pressMoved=false;clearTimeout(bookLongPressTimer);bookLongPressTimer=setTimeout(()=>beginBookSelection(f.path),560);},{passive:true});
 card.addEventListener('touchmove',()=>{pressMoved=true;clearTimeout(bookLongPressTimer);},{passive:true});
 card.addEventListener('touchend',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('touchcancel',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('contextmenu',e=>{e.preventDefault();beginBookSelection(f.path);});
 const selectMark=document.createElement('div');selectMark.className='book-select-mark';selectMark.textContent=selectedBookPaths.has(f.path)?'✓':'';
 const cover=document.createElement('div');cover.className='book-cover';cover.innerHTML='<span>▤</span>';
 if(Object.prototype.hasOwnProperty.call(readerCoverCache,f.path)){
  readerCoverCacheTouch(f.path);
  if(readerCoverCache[f.path]){const img=document.createElement('img');img.alt='Book cover';img.src=readerCoverCache[f.path];cover.replaceChildren(img);}
 }else{
  readerCoverCacheSet(f.path,null);
  api('/reader-cover',{file:f.path}).then(result=>{
   if(result.cover){readerCoverCacheSet(f.path,result.cover);
    if(card.isConnected){const img=document.createElement('img');img.alt='Book cover';img.src=result.cover;cover.replaceChildren(img);}
   }
  }).catch(()=>{});
 }
 const info=document.createElement('div');info.className='book-info';
 const name=document.createElement('div');name.className='book-name';name.textContent=f.name.replace(/\.epub$/i,'');
 const meta=document.createElement('div');meta.className='book-meta';meta.textContent='EPUB · '+(f.size||'');
 const hint=document.createElement('div');hint.className='book-open-hint';hint.textContent=state?'Continue reading · Chapter '+(state.chapter+1):'Tap to start reading';
 const bar=document.createElement('div');bar.className='book-progress';const fill=document.createElement('i');fill.style.width=state?'12%':'0%';bar.appendChild(fill);
 info.append(name,meta,hint,bar);card.append(selectMark,cover,info);box.appendChild(card);
 });
}
async function openReaderBook(file,chapter,page=0){
 file=file||'';if(!file)return;readerRestorePage=Math.max(0,Number(page)||0);try{localStorage.setItem('redDustLastOpenedBook',file);}catch(e){}
 readerSearchMatches=[];readerSearchIndex=-1;readerSearchQuery='';$('reader-dedicated-search-input').value='';$('reader-search-status').textContent='';
 $('library-view').style.display='none';$('reader-search-screen').classList.remove('active');$('reader-screen').style.display='block';
 $('reader-view').classList.remove('controls-hidden');
 document.body.classList.add('reader-reading');
 $('reader-content').innerHTML='<div class="reader-empty">Opening book…</div>';
 $('reader-book-title').textContent=file.split('/').pop().replace(/\.epub$/i,'');
 try{readerBook=await api('/reader-open',{file,chapter:chapter||0});readerFileLoaded=file;const stamps=libraryTimestamps();stamps.recent[file]=Date.now();try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}renderReaderChapter();}catch(e){$('reader-content').textContent='Could not open EPUB: '+e.message;}
}
function closeReaderBook(){saveReaderState();document.body.classList.remove('reader-reading');$('reader-screen').style.display='none';$('library-view').style.display='block';$('reader-view').classList.remove('controls-hidden');renderLibrary();}
function restoreReaderAfterWebViewError(){try{const file=localStorage.getItem('redDustLastOpenedBook');if(!file)return;const state=savedReaderState();openReaderBook(file,state[file]?.chapter||0,state[file]?.page||0);}catch(e){console.warn('Reader restore failed',e);}}
function handleAndroidBack(){if(isBookSelectionMode()&&$('library-view').style.display!=='none'){cancelBookSelection();return true;}if($('reader-search-screen').classList.contains('active')){closeReaderSearch();return true;}if($('reader-view').style.display==='block'&&document.querySelector('#reader-view .reader-popup-menu.active')){closeReaderMenus();return true;}if($('reader-screen').style.display==='block'){closeReaderBook();return true;}if($('reader-view').style.display==='block'){return false;}if(document.querySelector('main').style.display!=='none'){switchGallery('albums');return true;}return false;}
async function loadReaderChapter(position='start'){
 if(!readerFileLoaded)return;
 try{
  readerChapterLanding=position;
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:parseInt(val('reader-chapter')||0)});
  renderReaderChapter();
 }catch(e){$('reader-content').textContent='Could not load chapter: '+e.message;}
}
let readerChapterLanding='start';
let readerRestorePage=0;
async function navigateReaderChapter(index,position){
 if(!readerBook||index<0||index>=readerBook.chapters.length)return;
 $('reader-chapter').value=String(index);
 await loadReaderChapter(position);
}
function renderReaderChapter(){
 /* Preserve the reader chrome state when moving between chapters. */
 const landing=readerChapterLanding;readerChapterLanding='start';
 const s=$('reader-chapter');s.innerHTML='';
 readerBook.chapters.forEach((c,i)=>s.add(new Option((i+1)+'. '+c.title,i)));
 s.value=String(readerBook.index);
 $('reader-content').innerHTML=readerBook.content;
 const readerContent=$('reader-content');if(!readerContent.dataset.rdLinkHandler){readerContent.addEventListener('click',handleReaderInternalLink);readerContent.dataset.rdLinkHandler='1';}
 $('reader-book-title').textContent=readerBook.title||'Reading';
 if(readerSearchQuery)highlightReaderSearch();
 $('reader-content').scrollLeft=0;
 saveReaderState();
 $('reader-progress').textContent=(readerBook.index+1)+' / '+readerBook.chapters.length;
 setReaderStyle();
 initReaderSwipe();
 /* Wait for WebView to lay out the new chapter columns before landing. */
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const el=$('reader-content');
  if(landing==='end'){el.scrollLeft=el.scrollWidth;}else{el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,Math.max(0,readerRestorePage)*readerPageWidth());readerRestorePage=0;}
  if(readerPendingFragment){const fragment=readerPendingFragment;readerPendingFragment='';readerLandOnFragment(fragment);}
  updateReaderPageCount();saveReaderState();
 }));
}
let readerTouchX=0,readerTouchY=0,readerTouchStart=0;
function readerPageWidth(){const el=$('reader-content');return Math.max(120,el.clientWidth);}
function updateReaderPageCount(){const el=$('reader-content');if(!el)return;const page=Math.max(1,Math.round(el.scrollLeft/readerPageWidth())+1);$('reader-page-count').textContent='Page '+page;}
function readerPageNext(){const el=$('reader-content');const atEnd=el.scrollLeft+el.clientWidth>=el.scrollWidth-36;if(atEnd){if(readerBook&&readerBook.index<readerBook.chapters.length-1){navigateReaderChapter(readerBook.index+1,'start');return;}return;}el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,el.scrollLeft+readerPageWidth());updateReaderPageCount();}
function readerPagePrev(){const el=$('reader-content');if(el.scrollLeft<=4){if(readerBook&&readerBook.index>0){navigateReaderChapter(readerBook.index-1,'end');return;}return;}el.scrollLeft=Math.max(0,el.scrollLeft-readerPageWidth());updateReaderPageCount();}
function toggleReaderControls(){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.toggle('controls-hidden');closeReaderMenus();}
function closeReaderMenus(){['reader-settings-menu','reader-navigation-menu','reader-navigation-controls-menu'].forEach(id=>$(id).classList.remove('active'));}
function toggleReaderMenu(which){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.remove('controls-hidden');const map={settings:'reader-settings-menu',navigation:'reader-navigation-menu','navigation-controls':'reader-navigation-controls-menu'};const target=map[which]||'reader-navigation-menu';const wasOpen=$(target).classList.contains('active');closeReaderMenus();if(!wasOpen)$(target).classList.add('active');}
function initReaderSwipe(){
 const el=$('reader-content');
 if(!el)return;
 if(el.dataset.swipeReady)return;
 el.dataset.swipeReady='1';
 el.addEventListener('touchstart',e=>{if(e.touches.length===1){readerTouchX=e.touches[0].clientX;readerTouchY=e.touches[0].clientY;readerTouchStart=Date.now();}},{passive:true});
 el.addEventListener('touchend',e=>{
  if(!e.changedTouches.length)return;
  const t=e.changedTouches[0],dx=t.clientX-readerTouchX,dy=t.clientY-readerTouchY;
  /* Keep the existing swipe navigation unchanged. */
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){if(dx<0)readerPageNext();else readerPagePrev();return;}
  if(Date.now()-readerTouchStart>600||Math.abs(dx)>18||Math.abs(dy)>18)return;
  if(e.target.closest('a,button,input,select,textarea'))return;
  const rect=el.getBoundingClientRect(),relativeX=(t.clientX-rect.left)/Math.max(1,rect.width);
  /* Center toggles the overlay; screen edges turn pages in either direction. */
  if(relativeX>=0.35&&relativeX<=0.65){toggleReaderControls();return;}
  if(relativeX>0.65){readerPageNext();return;}
  readerPagePrev();
 },{passive:true});
 el.addEventListener('scroll',()=>{updateReaderPageCount();saveReaderState();},{passive:true});
}

function loadReaderSearchHistory(){try{const saved=JSON.parse(localStorage.getItem('redDustReaderSearchHistory')||'[]');readerSearchHistory=Array.isArray(saved)?saved.filter(x=>typeof x==='string'&&x.trim()).slice(0,20):[];}catch(e){readerSearchHistory=[];}}
function saveReaderSearchHistory(){try{localStorage.setItem('redDustReaderSearchHistory',JSON.stringify(readerSearchHistory));}catch(e){}}
function showReaderSearchHistory(){
 const input=$('reader-dedicated-search-input'),box=$('reader-search-history');if(!input||!box)return;
 if(!input.value.trim()){box.classList.remove('visible');box.innerHTML='';return;}
 loadReaderSearchHistory();box.innerHTML='';if(!readerSearchHistory.length){box.classList.remove('visible');return;}
 readerSearchHistory.forEach((q,i)=>{const row=document.createElement('div');row.className='reader-search-history-item';row.innerHTML='<span class="history-icon">↶</span><span class="history-query"></span>';row.querySelector('.history-query').textContent=q;let wasLongPressed=false;row.onclick=()=>{if(wasLongPressed){wasLongPressed=false;return;}input.value=q;searchDedicatedBook();};
  let pressTimer=null;const cancel=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
  row.addEventListener('touchstart',()=>{wasLongPressed=false;pressTimer=setTimeout(()=>{wasLongPressed=true;readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();pressTimer=null;},550);},{passive:true});row.addEventListener('touchend',cancel,{passive:true});row.addEventListener('touchmove',cancel,{passive:true});row.addEventListener('contextmenu',e=>{e.preventDefault();readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();});box.appendChild(row);
 });box.classList.add('visible');
}
function openReaderSearch(){
 const screen=$('reader-search-screen');if(!screen)return;
 const body=$('reader-search-body'),input=$('reader-dedicated-search-input');screen.classList.add('active');
 // Preserve query/results/selection/scroll on return; otherwise open a clean search view.
 if(readerSearchMatches.length&&readerSearchQuery){input.value=readerSearchQuery;$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='';}
 else if(!readerSearchQuery){input.value='';$('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';$('reader-search-loading').classList.remove('active');}
 if(readerSearchMatches.length&&readerSearchQuery){$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';}else{showReaderSearchHistory();}
 requestAnimationFrame(()=>{if(readerSearchMatches.length&&readerSearchQuery){body.scrollTop=readerSearchPanelScrollTop;}else{input.focus();try{input.setSelectionRange(input.value.length,input.value.length);}catch(e){}}});
}
function closeReaderSearch(){
 const screen=$('reader-search-screen'),body=$('reader-search-body');
 if(body)readerSearchPanelScrollTop=body.scrollTop;
 if(screen)screen.classList.remove('active');
 try{if(document.activeElement)document.activeElement.blur();}catch(e){}
}
function clearDedicatedSearch(){
 const input=$('reader-dedicated-search-input');
 input.value='';input.focus();
 $('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';
 $('reader-search-loading').classList.remove('active');
}
function escapeHtmlText(text){return String(text||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderDedicatedSearchResults(matches,query){
 const box=$('reader-search-results');box.innerHTML='';
 if(!matches.length){$('reader-search-empty').textContent='No results found';return;}
 const needle=query.toLocaleLowerCase();
 matches.forEach((m,i)=>{
  const card=document.createElement('div');card.className='search-result-card'+(i===readerSearchIndex?' search-result-selected':'');card.setAttribute('role','button');card.setAttribute('tabindex','0');if(i===readerSearchIndex)card.setAttribute('aria-current','true');
  const textWrap=document.createElement('div');textWrap.className='search-result-text';
  const chapterTitle=document.createElement('div');chapterTitle.className='search-result-chapter-title';
  const chapter=Number(m.chapter)||0;chapterTitle.textContent='Chapter '+(chapter+1)+(m.chapter_title?' · '+m.chapter_title:'');
  const snippet=document.createElement('div');snippet.className='search-result-snippet';
  const raw=String(m.snippet||'');const lower=raw.toLocaleLowerCase();let from=0,html='';
  while(true){const at=lower.indexOf(needle,from);if(at<0){html+=escapeHtmlText(raw.slice(from));break;}html+=escapeHtmlText(raw.slice(from,at))+'<mark>'+escapeHtmlText(raw.slice(at,at+query.length))+'</mark>';from=at+query.length;}
  snippet.innerHTML=html;textWrap.append(chapterTitle,snippet);
  const loc=document.createElement('div');loc.className='search-result-location';loc.textContent='Ch. '+(chapter+1);
  card.append(textWrap,loc);card.onclick=async()=>{readerSearchIndex=i;readerSearchPanelScrollTop=card.offsetTop;renderDedicatedSearchResults(readerSearchMatches,readerSearchQuery);closeReaderSearch();await goToReaderSearchMatch();};card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}};
  box.appendChild(card);
 });
}
async function searchDedicatedBook(){
 const input=$('reader-dedicated-search-input');const query=(input?.value||'').trim();
 if(!readerFileLoaded||!query)return;
 readerSearchQuery=query;readerSearchMatches=[];readerSearchIndex=-1;readerSearchPanelScrollTop=0;$('reader-search-body').scrollTop=0;
 try{localStorage.setItem('redDustLastReaderSearch',query);}catch(e){}
 loadReaderSearchHistory();readerSearchHistory=[query,...readerSearchHistory.filter(x=>x.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,20);saveReaderSearchHistory();$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';
 $('reader-search-empty').textContent='';$('reader-search-results').innerHTML='';$('reader-search-loading').classList.add('active');
 try{
  const result=await api('/reader-search',{file:readerFileLoaded,query});
  readerSearchMatches=Array.isArray(result?.matches)?result.matches:[];
  $('reader-search-loading').classList.remove('active');
  renderDedicatedSearchResults(readerSearchMatches,query);
 }catch(e){$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='Search failed: '+(e?.message||String(e));}
}
async function searchInsideBook(){
 openReaderSearch();
}
function clearReaderSearchMarks(){document.querySelectorAll('#reader-content mark.reader-search-hit').forEach(mark=>mark.replaceWith(document.createTextNode(mark.textContent)));}
function highlightReaderSearch(){
 const root=$('reader-content');clearReaderSearchMarks();if(!readerSearchQuery)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(node){return node.nodeValue.toLocaleLowerCase().includes(readerSearchQuery.toLocaleLowerCase())?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 const needle=readerSearchQuery.toLocaleLowerCase();
 nodes.forEach(node=>{const text=node.nodeValue,lower=text.toLocaleLowerCase(),frag=document.createDocumentFragment();let from=0,at;
  while((at=lower.indexOf(needle,from))!==-1){if(at>from)frag.appendChild(document.createTextNode(text.slice(from,at)));const mark=document.createElement('mark');mark.className='reader-search-hit';mark.textContent=text.slice(at,at+readerSearchQuery.length);frag.appendChild(mark);from=at+readerSearchQuery.length;}
  if(from<text.length)frag.appendChild(document.createTextNode(text.slice(from)));node.parentNode.replaceChild(frag,node);
 });
}
async function goToReaderSearchMatch(){
 const match=readerSearchMatches[readerSearchIndex];if(!match)return;
 const targetChapter=Number(match.chapter)||0;
 if(readerBook.index!==targetChapter){
  $('reader-chapter').value=String(targetChapter);
  readerChapterLanding='start';
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:targetChapter});
  renderReaderChapter();
 }else{
  // Same chapter: preserve the current pagination/column geometry. Only refresh marks.
  highlightReaderSearch();
 }
 const page=$('reader-content');
 // Allow WebView's column layout to settle before measuring the highlighted text.
 requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const marks=page.querySelectorAll('mark.reader-search-hit');
  const occurrence=Math.max(0,Number(match.occurrence)||0),target=marks[occurrence];
  if(target){
   const rect=target.getBoundingClientRect(),base=page.getBoundingClientRect();
   /* Search navigation must land on a whole reader column/page. WebView's
      mandatory snap can otherwise restore at an intermediate offset and show
      slivers of two columns (the broken layout seen after selecting a result). */
   const stride=Math.max(1,page.clientWidth);
   const targetX=Math.max(0,page.scrollLeft+rect.left-base.left);
   const destination=Math.floor(targetX/stride)*stride;
   page.style.scrollSnapType='none';
   page.style.scrollBehavior='auto';
   page.scrollLeft=destination;
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
    page.scrollLeft=destination;
    page.style.scrollSnapType='x mandatory';
    updateReaderPageCount();
   }));
  }
  $('reader-search-status').textContent='Match '+(readerSearchIndex+1)+' of '+readerSearchMatches.length+' · '+(readerBook.chapters[targetChapter]?.title||'Chapter '+(targetChapter+1));
 })));
}

function readerSearchNext(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex+1)%readerSearchMatches.length;goToReaderSearchMatch();}
function readerSearchPrev(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex-1+readerSearchMatches.length)%readerSearchMatches.length;goToReaderSearchMatch();}

function readerPrev(){if(readerBook&&readerBook.index>0){$('reader-chapter').value=readerBook.index-1;loadReaderChapter();}}
function readerNext(){if(readerBook&&readerBook.index<readerBook.chapters.length-1){$('reader-chapter').value=readerBook.index+1;loadReaderChapter();}}
function setReaderStyle(){
 const page=$('reader-content'),font=val('reader-font'),line=val('reader-line'),para=val('reader-para'),letter=val('reader-letter'),weight=val('reader-weight'),family=val('reader-family');
 const cs=getComputedStyle(page);
 const padLeft=parseFloat(cs.paddingLeft)||0, padRight=parseFloat(cs.paddingRight)||0;
 const contentWidth=Math.max(120,page.clientWidth-padLeft-padRight);
 /* A CSS multi-column column occupies the text box, not the full outer viewport.
    Make the inter-column gap equal both side paddings combined so the next
    column begins exactly one full screen later. This prevents previous/next
    page text from entering the visible current-page viewport in Android WebView. */
 const pageGap=Math.max(0,padLeft+padRight);
 page.style.columnWidth=contentWidth+'px';page.style.webkitColumnWidth=contentWidth+'px';
 page.style.columnGap=pageGap+'px';page.style.webkitColumnGap=pageGap+'px';
 page.style.columnFill='auto';page.style.webkitColumnFill='auto';
 $('font-value').textContent=font;$('line-value').textContent=line;$('para-value').textContent=para;$('letter-value').textContent=letter;$('weight-value').textContent=weight;
 page.style.fontSize=font+'px';page.style.lineHeight=line;page.style.letterSpacing=letter+'px';page.style.fontWeight=weight;page.style.fontFamily=family;
 page.querySelectorAll('p').forEach(p=>p.style.marginBottom=para+'em');
}
function readerTheme(theme){
 const p=$('reader-content');
 const styles={light:['#fff','#242424'],sepia:['#f2e4c9','#5b4632'],night:['#171717','#ddd']};
 p.style.background=styles[theme][0];p.style.color=styles[theme][1];
}

function showTab(id,b){document.querySelectorAll('main>section:not(#folder-picker-panel):not(#batch-panel)').forEach(x=>x.classList.add('hide'));$('folder-picker-panel').classList.remove('hide');$(id).classList.remove('hide');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active')}
async function api(path,data){let d=JSON.parse(AndroidBridge.post(path,JSON.stringify(data)));if(d.error)throw Error(d.error||'Operasi gagal');return d}
function fileFor(id){return $(id).querySelector('select.epub')?.value || ''}
function renderFileChoices(){
  const filter=$('folderFilter')?.value||'';
  const visible=files.filter(f=>!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter);
  const help=$('folderFilterHelp');
  if(help) help.textContent=(filter ? 'Folder aktif: '+filter : 'Menampilkan semua folder')+' · '+visible.length+' file ditemukan. Pilih folder lain kapan saja.';
  document.querySelectorAll('select.epub').forEach(s=>{
    const old=s.value;s.innerHTML='<option value="">Pilih EPUB</option>';
    visible.filter(f=>/\.epub$/i.test(f.name)).forEach(f=>s.add(new Option(f.path+' ('+f.size+')',f.path)));
    if(old&&Array.from(s.options).some(o=>o.value===old))s.value=old;
  });
  const b=$('bulkfile'),old=b.value;b.innerHTML='<option value="">Pilih EPUB/TXT</option>';
  visible.filter(f=>/\.(epub|txt)$/i.test(f.name)).forEach(f=>b.add(new Option(f.path+' ('+f.size+')',f.path)));
  if(old&&Array.from(b.options).some(o=>o.value===old))b.value=old;
  renderBatchFiles();
}
function updateBatchOptions(){
  const op=val('batchOperation'), box=$('batch-options');box.innerHTML='';
  if(op==='/bulk-count'||op==='/bulk-replace'){
    box.innerHTML='<label>Teks yang dicari</label><input id="batch-find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="batch-replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="batch-case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="batch-whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="batch-regex" type="checkbox"> Regular expression</label>';
  }else if(op==='/make-cover'){
    box.innerHTML='<p class="hint">Judul cover dan nama penulis akan diambil otomatis dari metadata setiap EPUB (dc:title dan creator). Tidak perlu mengisi judul secara manual.</p>';
  }else if(op==='/batch-unzip'){
    const dirs=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    box.innerHTML='<label>Password ZIP (default)</label><input id="unzip-password" type="password" autocomplete="off" value="taiwanandnorthkorea" placeholder="Password yang sama untuk semua ZIP"><label>Folder tujuan (semua hasil digabung ke sini)</label><select id="unzip-destination"></select><p class="hint">Password default sudah diisi otomatis. Ubah jika ZIP menggunakan password lain, atau hapus jika ZIP tidak dikunci. Daftar ZIP dicari di semua folder penyimpanan, tidak mengikuti filter folder EPUB di atas. Mendukung AES dan ZipCrypto. Jika nama file bentrok, file berikutnya otomatis diberi akhiran _2, _3, dan seterusnya. Nama asli tetap dipakai jika tidak bentrok. File ZIP asli tidak diubah.</p>';
    const dest=box.querySelector('#unzip-destination');dirs.forEach(d=>dest.add(new Option(d,d)));if(dirs.includes('Download'))dest.value='Download';
  }else if(op==='/cover-meta'){
    box.innerHTML='<p class="hint">Hanya membaca metadata judul dan penulis; file tidak diubah.</p>';
  }else{
    box.innerHTML='<p class="hint">Tidak memerlukan pengaturan tambahan. Setiap EPUB yang dipilih akan diproses dengan fitur ini.</p>';
  }
  renderBatchFiles();
}
function selectedBatchFiles(){return Array.from(document.querySelectorAll('.batch-file input:checked')).map(x=>x.value)}
function updateBatchCount(){$('batch-selection-count').textContent=selectedBatchFiles().length+' file dipilih';}
function renderBatchFiles(){
  const filter=val('folderFilter'), op=val('batchOperation'), isText=op==='/bulk-count'||op==='/bulk-replace', isZip=op==='/batch-unzip';
  // ZIP extraction searches every discovered folder, regardless of the active EPUB folder filter.
  // This prevents archives in Documents, Telegram, or another folder from being hidden by e.g. Download/Novel.
  const visible=files.filter(f=>(isZip||!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter)&& (isZip?/\.zip$/i.test(f.name):(isText?/\.(epub|txt)$/i.test(f.name):/\.epub$/i.test(f.name))));
  const list=$('batch-file-list');list.innerHTML='';
  if(!visible.length){list.textContent='Tidak ada file yang cocok pada folder aktif.';updateBatchCount();return;}
  visible.forEach(f=>{const label=document.createElement('label');label.className='batch-file';const cb=document.createElement('input');cb.type='checkbox';cb.value=f.path;cb.addEventListener('change',updateBatchCount);const span=document.createElement('span');span.textContent=f.path+' ('+f.size+')';label.append(cb,span);list.appendChild(label);});updateBatchCount();
}
function selectVisibleBatch(checked){document.querySelectorAll('#batch-file-list input[type=checkbox]').forEach(x=>x.checked=checked);updateBatchCount();}
async function runBatch(){
  const operation=val('batchOperation'), chosen=selectedBatchFiles();
  if(!chosen.length)return $('batch-status').textContent='Pilih minimal satu file.';
  if(operation==='/batch-unzip'){
    const destination=val('unzip-destination');if(!destination)return $('batch-status').textContent='Pilih folder tujuan.';
    if(!confirm('Ekstrak '+chosen.length+' ZIP ke folder '+destination+'? File ZIP asli tetap disimpan.'))return;
    $('batch-status').textContent='Mengekstrak '+chosen.length+' arsip…';
    try{const result=JSON.parse(AndroidBridge.unzipBatch(JSON.stringify({files:chosen,destination,password:val('unzip-password')})));if(result.error)throw Error(result.error);
      const box=$('batch-status');box.textContent='';const summary=document.createElement('div');summary.style.cssText='padding:12px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e3a8a;margin-top:10px';summary.textContent='Batch Unzip selesai: '+result.succeeded+' berhasil · '+result.failed+' gagal · '+result.total+' ZIP';box.appendChild(summary);
      result.results.forEach(r=>addResultCard(box,r.file,r.ok,r.result||{},r.error||''));await loadFiles();
    }catch(e){$('batch-status').textContent='Error: '+e.message;}return;
  }
  const options={};
  if(operation==='/bulk-count'||operation==='/bulk-replace'){
    options.find=val('batch-find');options.replace=val('batch-replace');options.case_sensitive=$('batch-case').checked;options.whole_word=$('batch-whole').checked;options.regex=$('batch-regex').checked;
    if(!options.find)return $('batch-status').textContent='Isi teks yang dicari terlebih dahulu.';
  }
  const readOnly=operation==='/bulk-count'||operation==='/cover-meta';
  const prompt=readOnly?'Jalankan fitur pada '+chosen.length+' file terpilih?':'Proses '+chosen.length+' file terpilih? File yang berhasil diproses akan langsung menimpa file asli tanpa backup.';
  if(!confirm(prompt))return;
  $('batch-status').textContent='Memproses '+chosen.length+' file…';
  try{
    const d=await api('/batch',{operation,files:chosen,options});
    const box=$('batch-status');box.textContent='';
    box.style.cssText='padding:0;margin-top:12px;border:0;background:transparent;min-height:0;overflow:visible;';
    const resultsList=document.createElement('div');
    resultsList.style.cssText='max-height:200px;overflow-y:auto;overflow-x:hidden;border:1px solid #d8e0eb;border-radius:12px;padding:10px;background:#fff;';
    const summary=document.createElement('div');
    summary.style.cssText='background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px;margin:8px 0 12px;color:#1e3a8a;';
    const heading=document.createElement('div');heading.textContent='Batch selesai diproses';
    heading.style.cssText='font-size:17px;font-weight:700;margin-bottom:6px;';
    const count=document.createElement('div');
    count.textContent='✓ '+d.succeeded+' berhasil   ·   ✕ '+d.failed+' gagal   ·   Total '+d.total+' file';
    count.style.cssText='font-size:14px;';
    summary.append(heading,count);resultsList.appendChild(summary);
    d.results.forEach(item=>addResultCard(resultsList,item.file,item.ok,item.result||{},item.error||''));
    box.appendChild(resultsList);
    await loadFiles();
  }catch(e){$('batch-status').textContent='Error: '+e.message;}
}
async function loadFiles(){try{
  let d=JSON.parse(AndroidBridge.getFiles());if(d.error)throw Error(d.error);files=d.files;
  const available=new Set(files.filter(f=>/\.epub$/i.test(f.name)).map(f=>f.path));selectedBookPaths=new Set([...selectedBookPaths].filter(path=>available.has(path)));updateBookSelectionUI();
  const folder=$('folderFilter'),previous=folder.value;
  const folders=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  folder.innerHTML='<option value="">Semua folder</option>';
  folders.forEach(f=>folder.add(new Option(f,f)));
  if(folders.includes(previous)) folder.value=previous;
  else if(folders.includes('Download')) folder.value='Download';
  else folder.value='';
  renderFileChoices();if($('reader-file')||document.body.classList.contains('reader-active'))populateReaderFiles();
}catch(e){document.querySelectorAll('.status').forEach(x=>x.textContent='Gagal memuat file: '+e.message)}}
function currentFile(panel){return $(panel).querySelector('select').value}
function addResultCard(parent, fileName, ok, result={}, errorText=''){
  const card=document.createElement('div');
  card.style.cssText='background:#fff;border:1px solid '+(ok?'#bbf7d0':'#fecaca')+';border-radius:12px;padding:12px;margin:9px 0;color:#172033;';
  const head=document.createElement('div');
  head.style.cssText='display:flex;gap:8px;align-items:flex-start;font-weight:700;';
  const mark=document.createElement('span');mark.textContent=ok?'✓':'✕';
  mark.style.cssText='font-size:18px;color:'+(ok?'#15803d':'#dc2626')+';';
  const name=document.createElement('div');name.textContent=fileName||'File';
  name.style.cssText='overflow-wrap:anywhere;flex:1;';
  head.append(mark,name);card.appendChild(head);
  if(ok){
    const out=document.createElement('div');out.textContent='Hasil: '+(result.output||fileName||'Selesai');
    out.style.cssText='font-size:13px;color:#334155;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(out);
    const labels={message:'Status',title:'Judul',changed:'Paragraf diperbarui',count:'Jumlah perubahan',removed:'Item dihapus',images:'Gambar',matches:'Kecocokan',author:'Penulis'};
    const notes=[];
    for(const [key,value] of Object.entries(result)){
      if(key==='output'||value===null||value===undefined||value==='')continue;
      if(!Object.prototype.hasOwnProperty.call(labels,key))continue;
      const val=typeof value==='object'?JSON.stringify(value):String(value);
      if(/cache|chaquopy|tmp|backup/i.test(val))continue;
      notes.push(labels[key]+': '+val);
    }
    if(notes.length){const note=document.createElement('div');note.textContent=notes.join(' · ');
      note.style.cssText='font-size:12px;color:#64748b;margin:6px 0 0 26px;line-height:1.5;overflow-wrap:anywhere;';card.appendChild(note);}
  }else{
    const err=document.createElement('div');err.textContent='Gagal: '+(errorText||'Terjadi kesalahan');
    err.style.cssText='font-size:13px;color:#b91c1c;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(err);
  }
  parent.appendChild(card);
}
function showSuccess(panel,d){
  const box=$(panel+'-status');box.textContent='';
  const summary=document.createElement('div');
  summary.style.cssText='background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px;color:#166534;';
  const title=document.createElement('div');title.textContent='✓ Selesai diproses';
  title.style.cssText='font-size:17px;font-weight:700;margin-bottom:5px;';
  const output=document.createElement('div');output.textContent=d.output?'File hasil: '+d.output:'Proses berhasil diselesaikan.';
  output.style.cssText='font-size:14px;overflow-wrap:anywhere;';
  summary.append(title,output);box.appendChild(summary);
  addResultCard(box,d.output||'File EPUB',true,d);
}
async function run(path,panel,extra={}){let f=currentFile(panel);if(!f){$(panel+'-status').textContent='Pilih EPUB terlebih dahulu.';return}if(!confirm('Jalankan proses ini? File asli akan diperbarui langsung dan tidak ada backup yang dibuat.'))return;$(panel+'-status').textContent='Memproses…';try{let d=await api(path,{file:f,...extra});showSuccess(panel,d);await loadFiles()}catch(e){$(panel+'-status').textContent='Error: '+e.message}}
async function meta(){let f=currentFile('cover-maker');if(!f)return $('cover-maker-status').textContent='Pilih EPUB.';try{let d=await api('/cover-meta',{file:f});$('title').value=d.title;$('author').textContent='Penulis: '+d.author;$('cover-maker-status').textContent='Metadata berhasil dibaca.'}catch(e){$('cover-maker-status').textContent='Error: '+e.message}}
async function bulk(path){let p={file:val('bulkfile'),find:val('find'),replace:val('replace'),case_sensitive:$('case').checked,whole_word:$('whole').checked,regex:$('regex').checked};if(!p.file||!p.find)return $('bulk-status').textContent='Pilih file dan isi teks pencarian.';if(path==='/bulk-replace'&&!confirm('Ganti teks pada file asli? Perubahan akan langsung menimpa file tersebut.'))return;$('bulk-status').textContent='Memproses…';try{let d=await api(path,p);$('bulk-status').textContent=path==='/bulk-count'?'Jumlah kecocokan: '+d.count:(d.count?'Selesai. Penggantian: '+d.count+'\nFile diperbarui: '+d.output:'Tidak ada teks yang cocok.');await loadFiles()}catch(e){$('bulk-status').textContent='Error: '+e.message}}
async function renameByTitle(){
  const file=currentFile('rename-title');
  if(!file)return $('rename-title-status').textContent='Pilih EPUB terlebih dahulu.';
  if(!confirm('Nama file akan diganti sesuai judul metadata. Isi EPUB tidak diubah. Lanjutkan?'))return;
  $('rename-title-status').textContent='Membaca metadata dan mengganti nama…';
  try{const d=await api('/rename-by-title',{file});$('rename-title-status').textContent='Berhasil!\nJudul metadata: '+d.title+'\nNama file baru: '+d.output+(d.message?'\n'+d.message:'');await loadFiles();}
  catch(e){$('rename-title-status').textContent='Error: '+e.message;}
}
switchGallery('albums');updateBatchOptions();loadFiles();
