# EPUB Toolkit V4.1.9 — Stage 3 Library Search Optimization

## Scope
- Added a small cache for normalized Library search text (book name + path).
- Reuses cached text during Library rendering and Select All Visible Books filtering.
- Cache is cleared when the file list is reloaded and recalculates when a file name changes.

## Behavior intentionally unchanged
- Search matches (same name/path text and lowercase matching).
- Sorting, book selection, book cards, cover dimensions, progress, and reader behavior.
- No UI or layout changes.

## Validation
- Python syntax compilation passed.
- JavaScript syntax checks passed for packaged check scripts.
- ZIP integrity check passed after packaging.
