# RED-DUST EPUB Toolkit V3.9.3 — Batch Menu Reorder

## Change
Reordered Batch Processing options into a more workflow-oriented sequence.

1. Add Paragraph
2. Compact Line Spacing
3. Remove Blank Spacing
4. Remove All Images
5A. Bulk Find & Replace — Count Matches (EPUB/TXT)
5B. Bulk Find & Replace — Execute (EPUB/TXT)
6. Remove Cover
7. Cover Maker
8. Image Compressor
9. Rename From Metadata
10. Batch Unzip (ZIP)
11. Read Cover Metadata

Only the visible dropdown order and numbering changed. The operation values/routes, batch processing logic, file selection, and other features were preserved.
