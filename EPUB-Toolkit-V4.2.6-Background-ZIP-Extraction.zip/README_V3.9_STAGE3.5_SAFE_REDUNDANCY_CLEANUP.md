# RED-DUST EPUB Toolkit V3.9 — Stage 3.5 Safe Redundancy Cleanup

## Scope
- Combined two reader viewport CSS rules that repeated the same top/bottom padding declarations.
- Kept both selectors in the combined selector list so the normal reader and controls-hidden reader retain their selector specificity and behavior.
- Consolidated identical declarations into one rule.

## Explicitly unchanged
- Reader UI and settings
- Search behavior and search optimization
- Lazy chapter rendering
- WebView lifecycle handling
- Bounded cover cache
- Stage 3.4 pagination/style optimization
- Python/backend processing

## Validation
- ZIP integrity test
- Python syntax parse
- Embedded JavaScript syntax check (if Node is available)
- No Android Gradle build or device testing performed
