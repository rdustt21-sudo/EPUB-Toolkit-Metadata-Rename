package com.example.epubtoolkit

import android.content.Intent
import android.Manifest
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.util.Xml
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.example.epubtoolkit.core.epub.NativeEpubProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ToolkitApp() }
    }
}


private val Background = Color(0xFF0D121E)
private val SurfaceDark = Color(0xFF171F2D)
private val SurfaceRaised = Color(0xFF202B3B)
private val TextPrimary = Color(0xFFE8EDF5)
private val TextMuted = Color(0xFF9AA9BC)
private val Accent = Color(0xFF8EBBFF)


private data class EpubBook(
    val uri: Uri,
    val fileName: String,
    val title: String,
    val author: String,
    val lastModified: Long = 0L,
    val size: Long = 0L
)
private enum class LibrarySort { TITLE, FILE_NAME }


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolkitApp() {
    var screen by rememberSaveable { mutableStateOf("Library") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Background, surface = SurfaceDark, primary = Accent,
        onBackground = TextPrimary, onSurface = TextPrimary
    )) {
        Scaffold(
            containerColor = Background,
            topBar = {
                TopAppBar(
                    title = { Text(screen, fontWeight = FontWeight.SemiBold) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                    navigationIcon = { Icon(Icons.Default.Book, contentDescription = null, modifier = Modifier.padding(start = 16.dp), tint = Accent) }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    listOf("Library", "Single", "Batch").forEach { label ->
                        val icon = when (label) { "Library" -> Icons.Default.Folder; "Single" -> Icons.Default.Tune; else -> Icons.Default.Build }
                        NavigationBarItem(
                            selected = screen == label, onClick = { screen = label },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent,
                                indicatorColor = SurfaceRaised, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "Library" -> LibraryHome()
                    "Single" -> FeatureList(singleFeatures, "Single Feature")
                    "Batch" -> FeatureList(batchFeatures, "Batch Feature")
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("native_library", 0) }
    var books by remember { mutableStateOf(loadCachedBooks(prefs)) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Library uses direct device storage access.") }
    var sort by rememberSaveable { mutableStateOf("name") }
    var query by rememberSaveable { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var selectedBook by remember { mutableStateOf<EpubBook?>(null) }
    var permissionGranted by remember { mutableStateOf(Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()) }
    val scope = rememberCoroutineScope()

    fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${context.packageName}"))
                context.startActivity(intent)
            } catch (_: Exception) {
                context.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        }
    }

    fun scan() {
        permissionGranted = storagePermissionAvailable(context)
        if (!permissionGranted) {
            permissionGranted = false
            status = "All files access permission is required for direct storage scanning."
            return
        }
        if (scanning) return
        scanning = true
        status = "Scanning device storage…"
        scope.launch {
            try {
                val found = withContext(Dispatchers.IO) { scanDirectStorage(context, loadCachedBooks(prefs)) }
                books = found
                saveCachedBooks(prefs, found)
                val timestamps = runCatching { JSONObject(prefs.getString("library_timestamps", "{}")) }.getOrElse { JSONObject() }
                val added = timestamps.optJSONObject("added") ?: JSONObject()
                found.forEach { book ->
                    val key = book.uri.path ?: book.fileName
                    if (!added.has(key)) added.put(key, book.lastModified)
                }
                timestamps.put("added", added)
                if (!timestamps.has("recent")) timestamps.put("recent", JSONObject())
                prefs.edit().putString("library_timestamps", timestamps.toString()).apply()
                selected = emptySet()
                status = if (found.isEmpty()) "No EPUB books found in shared storage." else "${found.size} EPUB book${if (found.size == 1) "" else "s"} found."
            } catch (e: Exception) {
                status = "Scan failed: ${e.message ?: "Storage access error"}"
            } finally { scanning = false }
        }
    }


    LaunchedEffect(Unit) {
        permissionGranted = storagePermissionAvailable(context)
        if (permissionGranted) scan()
    }

    LaunchedEffect(sort) {
        val stamps = prefs.getString("library_timestamps", null)?.let { runCatching { JSONObject(it) }.getOrNull() } ?: JSONObject()
        val added = stamps.optJSONObject("added") ?: JSONObject()
        val recent = stamps.optJSONObject("recent") ?: JSONObject()
        books = when (sort) {
            "added" -> books.sortedByDescending { added.optLong(it.uri.path ?: it.fileName, it.lastModified) }
            "recent" -> books.sortedByDescending { recent.optLong(it.uri.path ?: it.fileName, 0L) }
            else -> books.sortedBy { it.title.lowercase() }
        }
    }

    val visible = books.filter { query.isBlank() || it.title.contains(query, true) || it.fileName.contains(query, true) || it.author.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("My Library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${visible.size} EPUB books", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { scan() }, enabled = !scanning) { Icon(Icons.Default.Refresh, contentDescription = "Refresh scan", tint = Accent) }
            IconButton(onClick = { sort = when(sort) { "name" -> "added"; "added" -> "recent"; else -> "name" } }) { Icon(Icons.Default.Sort, contentDescription = "Sort", tint = Accent) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Search your EPUB books…") }, leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = SurfaceRaised, focusedBorderColor = Accent))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)) {
            Text("Sort: ${when(sort) { "added" -> "Date added"; "recent" -> "Recently opened"; else -> "Name (A–Z)" }}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            if (scanning) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        if (!permissionGranted) {
            Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Direct storage access required", fontWeight = FontWeight.SemiBold)
                    Text("Grant All files access so V5 can scan, list, and manage EPUB files directly without the SAF folder picker.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { requestStorageAccess() }) { Text("Grant storage access") }
                }
            }
        }
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size} selected", modifier = Modifier.weight(1f), color = TextMuted)
                TextButton(onClick = { selected = visible.map { it.uri.path ?: it.fileName }.toSet() }) { Text("Select all") }
                TextButton(onClick = { selected = emptySet() }) { Text("Cancel") }
                IconButton(onClick = {
                    val targets = books.filter { (it.uri.path ?: it.fileName) in selected }
                    val deleted = targets.count { runCatching { File(it.uri.path ?: "").delete() }.getOrDefault(false) }
                    status = "$deleted file(s) deleted"
                    scan()
                }) { Icon(Icons.Default.Delete, contentDescription = "Delete selected", tint = Color(0xFFFF7777)) }
            }
        }
        if (status.isNotBlank()) Text(status, color = TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 6.dp))
        if (permissionGranted && visible.isEmpty() && !scanning) {
            Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
                Text(if (query.isNotBlank()) "No matching books" else "No EPUB books found. Add EPUB files to your device storage, then refresh.", color = TextMuted)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(visible, key = { it.uri.path ?: it.fileName }) { book ->
                    val key = book.uri.path ?: book.fileName
                    Card(colors = CardDefaults.cardColors(containerColor = if (key in selected) SurfaceRaised else SurfaceDark),
                        shape = RoundedCornerShape(9.dp), modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = {
                                if (selected.isNotEmpty()) selected = if (key in selected) selected - key else selected + key
                                else {
                                    val stamps = runCatching { JSONObject(prefs.getString("library_timestamps", "{}")) }.getOrElse { JSONObject() }
                                    val recent = stamps.optJSONObject("recent") ?: JSONObject()
                                    recent.put(key, System.currentTimeMillis()); stamps.put("recent", recent)
                                    prefs.edit().putString("library_timestamps", stamps.toString()).apply()
                                    selectedBook = book
                                    if (sort == "recent") books = books.sortedByDescending { recent.optLong(it.uri.path ?: it.fileName, 0L) }
                                }
                            },
                            onLongClick = { selected = selected + key })) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp, 62.dp).background(SurfaceRaised, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Book, contentDescription = null, tint = Accent, modifier = Modifier.size(26.dp))
                                if (key in selected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).size(16.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(book.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                if (book.author.isNotBlank()) Text(book.author, color = TextMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                Text(book.fileName, color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                Text("EPUB · ${formatFileSize(book.size)}", color = Accent, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
    selectedBook?.let { book ->
        AlertDialog(onDismissRequest = { selectedBook = null }, title = { Text(book.title) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(5.dp)) { Text("Author: ${book.author.ifBlank { "Unknown" }}"); Text(book.fileName); Text("Location: ${book.uri.path ?: ""}"); Text(formatFileSize(book.size)) } },
            confirmButton = { TextButton(onClick = { selectedBook = null }) { Text("Close") } })
    }
}


private fun storagePermissionAvailable(context: android.content.Context): Boolean = when {
    Build.VERSION.SDK_INT >= 30 -> Environment.isExternalStorageManager()
    Build.VERSION.SDK_INT >= 23 -> context.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
    else -> true
}


private fun formatFileSize(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> "%.0f KB".format(bytes / 1024.0)
    else -> "$bytes B"
}


private fun scanDirectStorage(context: android.content.Context, cachedBooks: List<EpubBook>): List<EpubBook> {
    val root = File("/storage/emulated/0")
    require(root.exists() && root.canRead()) { "Shared storage is not accessible. Check All files access permission." }
    val cachedByPath = cachedBooks.associateBy { it.uri.path ?: "" }
    val found = mutableListOf<EpubBook>()
    val visitedDirs = mutableSetOf<String>()
    fun visit(dir: File) {
        val canonical = runCatching { dir.canonicalPath }.getOrDefault(dir.absolutePath)
        if (!visitedDirs.add(canonical)) return
        val children = dir.listFiles() ?: return
        for (file in children) {
            if (file.isDirectory) {
                val hidden = file.name.startsWith(".") || file.name.equals(".thumbnails", true)
                val blockedAndroidDir = dir.absolutePath == root.absolutePath + "/Android" &&
                    (file.name.equals("data", true) || file.name.equals("obb", true))
                if (!hidden && !blockedAndroidDir) visit(file)
            } else if (file.isFile && file.extension.equals("epub", true)) {
                val path = file.absolutePath
                val modified = file.lastModified()
                val size = file.length()
                val cached = cachedByPath[path]
                val book = if (cached != null && cached.lastModified == modified && cached.size == size && cached.title.isNotBlank()) cached else {
                    val uri = Uri.fromFile(file)
                    val meta = readEpubMetadata(context.contentResolver, uri)
                    EpubBook(uri, file.name, meta.first.ifBlank { file.nameWithoutExtension }, meta.second, modified, size)
                }
                found += book
            }
        }
    }
    visit(root)
    return found.sortedBy { it.title.lowercase() }
}


private fun loadCachedBooks(prefs: android.content.SharedPreferences): List<EpubBook> {
    return try {
        val array = JSONArray(prefs.getString("cached_books", "[]"))
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val uri = obj.optString("uri").takeIf { it.isNotBlank() }?.let(Uri::parse) ?: continue
                add(EpubBook(uri, obj.optString("fileName"), obj.optString("title"), obj.optString("author"), obj.optLong("lastModified"), obj.optLong("size")))
            }
        }
    } catch (_: Exception) { emptyList() }
}


private fun saveCachedBooks(prefs: android.content.SharedPreferences, books: List<EpubBook>) {
    val array = JSONArray()
    books.forEach { book ->
        array.put(JSONObject().put("uri", book.uri.toString()).put("fileName", book.fileName)
            .put("title", book.title).put("author", book.author)
            .put("lastModified", book.lastModified).put("size", book.size))
    }
    prefs.edit().putString("cached_books", array.toString()).apply()
}


@Composable
private fun BookRow(book: EpubBook) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 54.dp, height = 72.dp).background(SurfaceRaised, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Book, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(book.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                if (book.author.isNotBlank()) Text(book.author, color = TextMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Text(book.fileName, color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }
    }
}


private suspend fun scanEpubTree(
    context: android.content.Context,
    treeUri: Uri,
    cachedBooks: List<EpubBook>,
    onBookFound: suspend (EpubBook) -> Unit
): List<EpubBook> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    val cachedByUri = cachedBooks.associateBy { it.uri.toString() }
    val found = mutableListOf<EpubBook>()

    suspend fun visit(folder: DocumentFile) {
        for (file in folder.listFiles()) {
            if (file.isDirectory) {
                visit(file)
            } else if (file.isFile && file.name?.endsWith(".epub", ignoreCase = true) == true) {
                val name = file.name ?: "Unknown.epub"
                val modified = file.lastModified()
                val fileSize = file.length()
                val cached = cachedByUri[file.uri.toString()]
                val book = if (cached != null && cached.fileName == name && cached.lastModified == modified && cached.size == fileSize && cached.title.isNotBlank() && (modified > 0L || fileSize > 0L)) {
                    cached
                } else {
                    val meta = readEpubMetadata(context.contentResolver, file.uri)
                    EpubBook(file.uri, name, meta.first.ifBlank { name.removeSuffixIgnoreCase(".epub") }, meta.second, modified, fileSize)
                }
                found.add(book)
                onBookFound(book)
            }
        }
    }

    visit(root)
    return found
}


private fun String.removeSuffixIgnoreCase(suffix: String): String =
    if (endsWith(suffix, ignoreCase = true)) dropLast(suffix.length) else this


private fun readEpubMetadata(resolver: android.content.ContentResolver, uri: Uri): Pair<String, String> {
    fun readEntry(entryName: String): ByteArray? {
        return try {
            resolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name == entryName) return zip.readBytes()
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
            null
        } catch (_: Exception) { null }
    }
    val containerBytes = readEntry("META-INF/container.xml") ?: return "" to ""
    var opfPath: String? = null
    try {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(containerBytes), null)
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG && parser.name == "rootfile") {
                opfPath = parser.getAttributeValue(null, "full-path")
                if (!opfPath.isNullOrBlank()) break
            }
        }
    } catch (_: Exception) { return "" to "" }
    val opfBytes = opfPath?.let { readEntry(it) } ?: return "" to ""
    var title = ""
    var author = ""
    try {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(opfBytes), null)
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "title" -> if (title.isBlank()) title = parser.nextText().trim()
                    "creator" -> if (author.isBlank()) author = parser.nextText().trim()
                }
            }
        }
    } catch (_: Exception) { }
    return title to author
}


private val singleFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace", "Unzip File"
)
private val batchFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Batch Unzip (ZIP)",
    "Bulk Find & Replace — Count Matches", "Bulk Find & Replace — Execute"
)

@Composable
private fun FeatureList(features: List<String>, heading: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedTool by remember { mutableStateOf<String?>(null) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutput by remember { mutableStateOf<NativeEpubProcessor.PreparedOutput?>(null) }
    val scope = rememberCoroutineScope()

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/epub+zip")) { targetUri ->
        val prepared = pendingOutput
        if (targetUri != null && prepared != null) {
            scope.launch {
                val message = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(targetUri, "wt")?.use { out -> prepared.file.inputStream().use { it.copyTo(out) } }
                            ?: error("Unable to open destination for writing")
                        prepared.file.delete()
                        "Finished\nSaved: ${prepared.suggestedName}\n${prepared.detail}"
                    } catch (e: Exception) {
                        "Failed to save: ${e.message ?: "Unknown error"}"
                    }
                }
                resultMessage = message
                pendingOutput = null
            }
        } else {
            prepared?.file?.delete()
            pendingOutput = null
        }
    }


    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val feature = selectedTool ?: return@rememberLauncherForActivityResult
            resultMessage = "Processing…"
            scope.launch {
                val preparedResult: Result<NativeEpubProcessor.PreparedOutput> = withContext(Dispatchers.IO) {
                    val name = queryDisplayName(context, uri) ?: "book.epub"
                    if (feature == "Rename File") NativeEpubProcessor.prepareRename(context, uri, name)
                    else if (feature in listOf("Remove All Images", "Remove Blank Spacing", "Compact Line Spacing", "Add Paragraph"))
                        NativeEpubProcessor.prepareOperation(context, uri, name, feature)
                    else Result.failure(IllegalArgumentException("$feature is not migrated yet."))
                }
                preparedResult.fold(
                    { prepared ->
                        pendingOutput = prepared
                        resultMessage = "Choose where to save the processed EPUB.\n${prepared.suggestedName}"
                        savePicker.launch(prepared.suggestedName)
                    },
                    { error -> resultMessage = "Failed: ${error.message ?: "Unknown error"}" }
                )
            }
        }
    }


    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(heading, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Native tools · Migrating V4 functionality", color = TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        }
        items(features) { feature ->
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable {
                selectedTool = feature
                resultMessage = null
                filePicker.launch(arrayOf("application/epub+zip", "application/zip", "application/octet-stream"))
            }) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(feature, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text("›", color = TextMuted, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
    if (selectedTool != null && resultMessage != null && !resultMessage!!.startsWith("Choose where to save")) {
        AlertDialog(
            onDismissRequest = { selectedTool = null; resultMessage = null },
            title = { Text(selectedTool ?: "Tool") },
            text = { Text(resultMessage ?: "") },
            confirmButton = { TextButton(onClick = { selectedTool = null; resultMessage = null }) { Text("OK") } }
        )
    }
}


private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }
}
