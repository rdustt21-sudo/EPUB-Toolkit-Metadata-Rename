# EPUB Toolkit V4.2.12 — Reader Search History Pinning & Toolkit Pull Refresh

Based on V4.2.11 (App Version 2.0.2).

Changes:
- Reader search history is placed below the search header and outside the scrolling results container, so it stays visible while search results scroll.
- History remains available while search results are shown.
- Added pull-down-to-scan gesture to Single Feature and Batch Feature screens. No refresh button is added.
- Refresh uses the existing file scan/load flow (`loadFiles`) and updates the file choices.
- App version updated to 2.0.3 (version code 12).

No feature processing logic intentionally changed.
