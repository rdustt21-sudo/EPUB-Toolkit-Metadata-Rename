package com.example.epubtoolkit.core.epub

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.util.zip.CRC32
import java.util.regex.Pattern
import net.lingala.zip4j.ZipFile as PasswordZipFile

object DirectStorageEngine {
    data class BookInfo(val file: File, val title: String, val author: String, val coverPath: String?, val chapterPaths: List<String>)
    data class Result(val success: Boolean, val message: String, val output: String = "", val changed: Int = 0)
    val singleFeatures = listOf("Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph", "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace", "Unzip File")
    val batchFeatures = listOf("Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph", "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Batch Unzip (ZIP)", "Bulk Find & Replace — Count Matches", "Bulk Find & Replace — Execute")
    private data class Entry(val name: String, val bytes: ByteArray, val time: Long)
    private val metadataCache = java.util.concurrent.ConcurrentHashMap<String, BookInfo>()

    fun scan(root: File): List<File> {
        if (!root.exists() || !root.canRead()) return emptyList()
        val found = mutableListOf<File>()
        root.walkTopDown().onEnter { dir -> !dir.name.startsWith(".") && dir.name != "Android" }.forEach { f ->
            if (f.isFile && f.extension.lowercase() in setOf("epub", "zip", "txt")) found += f
        }
        return found
    }

    fun info(file: File): BookInfo {
        val cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
        metadataCache[cacheKey]?.let { return it }
        ZipFile(file).use { zip ->
            fun read(name: String): String = zip.getEntry(name)?.let { zip.getInputStream(it).use { stream -> stream.readBytes().decodeToString() } }.orEmpty()
            val container = read("META-INF/container.xml")
            val opf = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(container)?.groupValues?.get(1)
                ?: zip.entries().asSequence().map { it.name }.firstOrNull { it.endsWith(".opf", true) }.orEmpty()
            val opfText = read(opf)
            val title = tagText(opfText, "title").ifBlank { file.nameWithoutExtension }
            val author = tagText(opfText, "creator")
            val items = Regex("<item\\b([^>]*?)/?>", RegexOption.IGNORE_CASE).findAll(opfText).map { it.groupValues[1] }.toList()
            val coverId = Regex("<meta\\b[^>]*name=['\"]cover['\"]\\s+content=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(opfText)?.groupValues?.get(1)
            val coverItem = items.firstOrNull { (coverId != null && it.contains("id=['\"]$coverId['\"]")) || it.contains("cover-image", true) }
            val coverPath = coverItem?.let { Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }?.let { resolveEntry(opf, it) }
            val manifest = items.associate { item ->
                val id = Regex("id=['\"]([^'\"]+)['\"]").find(item)?.groupValues?.get(1).orEmpty()
                id to (Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(item)?.groupValues?.get(1).orEmpty())
            }
            val spineIds = Regex("<itemref\\b[^>]*idref=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).findAll(opfText).map { it.groupValues[1] }.toList()
            val chapters = spineIds.mapNotNull { manifest[it] }.map { resolveEntry(opf, it) }.filter { zip.getEntry(it) != null }
            val result = BookInfo(file, title, author, coverPath, chapters)
            metadataCache[cacheKey] = result
            return result
        }
    }


    fun coverBytes(file: File): ByteArray? {
        val path = runCatching { info(file).coverPath }.getOrNull() ?: return null
        return runCatching { ZipFile(file).use { zip -> zip.getEntry(path)?.let { zip.getInputStream(it).use { stream -> stream.readBytes() } } } }.getOrNull()
    }

    fun rename(file: File): Result {
        val title = info(file).title.trim().ifBlank { file.nameWithoutExtension }
        val safe = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().trim('.').ifBlank { file.nameWithoutExtension }
        var target = File(file.parentFile, "$safe.epub")
        var n = 2
        while (target.exists() && target.canonicalFile != file.canonicalFile) { target = File(file.parentFile, "${safe}_$n.epub"); n++ }
        if (target.canonicalFile == file.canonicalFile) return Result(true, "Filename already matches the EPUB title.", file.name)
        return if (file.renameTo(target)) Result(true, "Renamed successfully.", target.name) else Result(false, "Could not rename file.")
    }


    fun process(file: File, operation: String, options: Map<String, String> = emptyMap()): Result {
        return try {
            require(file.exists() && file.isFile) { "File not found." }
            when (operation) {
                "Rename File" -> rename(file)
                "Bulk Find & Replace — Count Matches" -> bulk(file, options, countOnly = true)
                "Bulk Find & Replace" , "Bulk Find & Replace — Execute" -> bulk(file, options, countOnly = false)
                "Unzip File", "Batch Unzip (ZIP)" -> unzip(file, options)
                else -> transformEpub(file, operation, options)
            }
        } catch (e: Throwable) { Result(false, e.message ?: e.javaClass.simpleName) }
    }


    private fun transformEpub(file: File, operation: String, options: Map<String, String>): Result {
        require(file.extension.equals("epub", true)) { "Select an EPUB file." }
        val entries = readEntries(file)
        require(entries.any { it.name == "mimetype" }) { "Not a valid EPUB: mimetype is missing." }
        var changed = 0
        val transformed = when (operation) {
            "Remove All Images" -> removeImages(entries).also { changed = entries.size - it.size }
            "Remove Cover" -> removeCover(entries).also { changed = entries.size - it.size }
            "Add Cover" -> addCover(entries, options["title"].orEmpty()).also { changed = 1 }
            "Remove Blank Spacing" -> entries.map { e -> if (isMarkup(e.name)) Entry(e.name, removeBlankParagraphs(e.bytes.decodeToString()).encodeToByteArray(), e.time).also { if (!it.bytes.contentEquals(e.bytes)) changed++ } else e }
            "Compact Line Spacing" -> compact(entries).also { changed = 1 }
            "Add Paragraph" -> entries.map { e -> if (isMarkup(e.name)) Entry(e.name, splitParagraphs(e.bytes.decodeToString()).encodeToByteArray(), e.time).also { if (!it.bytes.contentEquals(e.bytes)) changed++ } else e }
            "Compress Image" -> compressImages(entries).also { out -> changed = entries.zip(out).count { (a,b) -> !a.bytes.contentEquals(b.bytes) } }
            else -> error("Unknown operation: $operation")
        }
        val staged = File(file.parentFile, ".${file.name}.v5tmp")
        val backup = File(file.parentFile, ".${file.name}.v5bak")
        if (staged.exists()) staged.delete()
        if (backup.exists()) backup.delete()
        try {
            writeZip(staged, transformed)
            validateZip(staged)
            check(file.renameTo(backup)) { "Unable to stage original file." }
            if (!staged.renameTo(file)) { backup.renameTo(file); error("Unable to replace original EPUB.") }
            backup.delete()
        } finally {
            if (staged.exists()) staged.delete()
            if (backup.exists() && !file.exists()) backup.renameTo(file)
        }
        return Result(true, "$operation completed. Original file updated.", file.name, changed)
    }

    private fun readEntries(file: File): List<Entry> = ZipFile(file).use { z ->
        z.entries().asSequence().filterNot { it.isDirectory }.map { e -> Entry(e.name, z.getInputStream(e).use { it.readBytes() }, e.time) }.toList()
    }

    private fun writeZip(file: File, entries: List<Entry>) {
        ZipOutputStream(FileOutputStream(file)).use { z ->
            entries.sortedBy { if (it.name == "mimetype") 0 else 1 }.forEach { e ->
                val entry = ZipEntry(e.name).apply { if (e.time > 0) time = e.time }
                if (e.name == "mimetype") { entry.method = ZipEntry.STORED; entry.size = e.bytes.size.toLong(); entry.crc = CRC32().apply { update(e.bytes) }.value }
                z.putNextEntry(entry); z.write(e.bytes); z.closeEntry()
            }
        }
    }
    private fun validateZip(file: File) { ZipFile(file).use { z -> require(z.getEntry("mimetype") != null && z.getEntry("META-INF/container.xml") != null) { "EPUB validation failed." } } }
    private fun isMarkup(name: String) = name.endsWith(".xhtml", true) || name.endsWith(".html", true) || name.endsWith(".htm", true)
    private fun tagText(text: String, tag: String) = Regex("<(?:\\w+:)?$tag\\b[^>]*>(.*?)</(?:\\w+:)?$tag\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(text)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), "")?.trim().orEmpty()
    private fun resolveEntry(opf: String, href: String): String {
        val joined = (File(opf).parent.orEmpty() + "/" + href.replace("\\\\", "/"))
        val stack = mutableListOf<String>()
        joined.split("/").forEach { part -> when (part) { "", "." -> Unit; ".." -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); else Unit; else -> stack.add(part) } }
        return stack.joinToString("/")
    }

    private fun removeImages(entries: List<Entry>): List<Entry> {
        val ext = setOf("jpg","jpeg","png","gif","webp","bmp","tif","tiff","svg","avif")
        val imagePaths = entries.filter { it.name.substringAfterLast('.', "").lowercase() in ext }.map { it.name }.toSet()
        return entries.filterNot { it.name in imagePaths }.map { e ->
            val text = e.bytes.decodeToString(); val updated = when {
                isMarkup(e.name) -> text.replace(Regex("<img\\b[^>]*?/?>", RegexOption.IGNORE_CASE), "").replace(Regex("<picture\\b[^>]*>.*?</picture\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "").replace(Regex("<image\\b[^>]*/?>", RegexOption.IGNORE_CASE), "")
                e.name.endsWith(".css", true) -> text.replace(Regex("(?:background(?:-image)?|list-style-image|border-image|mask-image)\\s*:[^;{}]*url\\([^)]*\\)[^;{}]*;", RegexOption.IGNORE_CASE), "")
                e.name.endsWith(".opf", true) -> text.replace(Regex("<item\\b[^>]*?/?>", RegexOption.IGNORE_CASE)) { if (it.value.contains("image/", true)) "" else it.value }.replace(Regex("<meta\\b[^>]*cover[^>]*?/?>", RegexOption.IGNORE_CASE), "")
                else -> text
            }
            if (updated == text) e else Entry(e.name, updated.encodeToByteArray(), e.time)
        }
    }

    private fun removeCover(entries: List<Entry>): List<Entry> {
        val container = entries.firstOrNull { it.name == "META-INF/container.xml" }?.bytes?.decodeToString().orEmpty()
        val opf = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]").find(container)?.groupValues?.get(1) ?: entries.firstOrNull { it.name.endsWith(".opf", true) }?.name.orEmpty()
        val opfText = entries.firstOrNull { it.name == opf }?.bytes?.decodeToString().orEmpty()
        val coverId = Regex("<meta\\b[^>]*name=['\"]cover['\"]\\s+content=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(opfText)?.groupValues?.get(1)
        val itemTags = Regex("<item\\b[^>]*?/?>", RegexOption.IGNORE_CASE).findAll(opfText).map { it.value }.toList()
        val coverItemTags = itemTags.filter { (coverId != null && it.contains("id=['\"]$coverId['\"]")) || it.contains("cover-image", true) || (it.contains("cover", true) && it.contains("image/", true)) }
        val coverIds = coverItemTags.mapNotNull { Regex("id=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }.toSet()
        val removePaths = coverItemTags.mapNotNull { Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.let { resolveEntry(opf, it) } }.toMutableSet()
        val coverPageTags = itemTags.filter { tag -> Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1)?.let { resolveEntry(opf, it) }?.let { path -> path.contains("cover", true) && entries.firstOrNull { it.name == path }?.bytes?.decodeToString()?.contains("cover", true) == true } == true }
        val coverPageIds = coverPageTags.mapNotNull { Regex("id=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
        val coverPages = coverPageTags.mapNotNull { Regex("href=['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.let { resolveEntry(opf, it) } }
        removePaths.addAll(coverPages)
        val allRemovedIds = coverIds + coverPageIds
        return entries.filterNot { it.name in removePaths }.map { e ->
            if (e.name != opf) e else {
                var updated = e.bytes.decodeToString()
                updated = updated.replace(Regex("<meta\\b[^>]*name=['\"]cover['\"][^>]*?/?>", RegexOption.IGNORE_CASE), "")
                updated = Regex("<item\\b[^>]*?/?>", RegexOption.IGNORE_CASE).replace(updated) { m -> if (m.value in coverItemTags || m.value in coverPageTags) "" else m.value }
                allRemovedIds.forEach { id -> updated = updated.replace(Regex("<itemref\\b[^>]*idref=['\"]$id['\"][^>]*?/?>", RegexOption.IGNORE_CASE), "") }
                Entry(e.name, updated.encodeToByteArray(), e.time)
            }
        }
    }


    private fun addCover(entries: List<Entry>, titleOverride: String): List<Entry> {
        val container = entries.firstOrNull { it.name == "META-INF/container.xml" }?.bytes?.decodeToString().orEmpty()
        val opf = Regex("full-path\\s*=\\s*['\"]([^'\"]+)['\"]").find(container)?.groupValues?.get(1) ?: entries.firstOrNull { it.name.endsWith(".opf", true) }?.name ?: error("OPF missing")
        val rawOpfText = entries.first { it.name == opf }.bytes.decodeToString()
        val opfText = rawOpfText.replace(Regex("<item\\b[^>]*(?:v5-cover-image|v5-cover-page)[^>]*?/?>", RegexOption.IGNORE_CASE), "").replace(Regex("<itemref\\b[^>]*idref=[\"\']v5-cover-page[\"\'][^>]*?/?>", RegexOption.IGNORE_CASE), "")
        val title = titleOverride.trim().ifBlank { tagText(opfText, "title") }.ifBlank { "Untitled" }
        val author = tagText(opfText, "creator")
        val stem = File(opf).parent?.takeIf { it.isNotEmpty() }?.let { "$it/" }.orEmpty()
        val coverSvgPath = stem + "v5-cover.svg"
        val coverPagePath = stem + "v5-cover.xhtml"
        val safeTitle = title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val safeAuthor = author.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1800" viewBox="0 0 1200 1800"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#163d62"/><stop offset="1" stop-color="#0d1423"/></linearGradient></defs><rect width="1200" height="1800" fill="url(#g)"/><rect x="90" y="90" width="1020" height="1620" fill="none" stroke="#a9c7ec" stroke-width="4"/><text x="600" y="820" text-anchor="middle" font-family="serif" font-size="82" fill="#ffffff">$safeTitle</text><text x="600" y="980" text-anchor="middle" font-family="sans-serif" font-size="42" fill="#c7d8ed">$safeAuthor</text></svg>"""
        val xhtml = """<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Cover</title></head><body><div style="text-align:center"><img src="v5-cover.svg" alt="Cover" style="max-width:100%;height:auto"/></div></body></html>"""
        val itemSvg = "<item id=\"v5-cover-image\" href=\"v5-cover.svg\" media-type=\"image/svg+xml\" properties=\"cover-image\"/>"
        val itemPage = "<item id=\"v5-cover-page\" href=\"v5-cover.xhtml\" media-type=\"application/xhtml+xml\"/>"
        val itemPattern = Regex("<item\\b[^>]*?/?>", RegexOption.IGNORE_CASE)
        val opfNew = itemPattern.replace(opfText) { if (it.value.contains("cover-image", true)) "" else it.value }.replace(Regex("<manifest\\b[^>]*>")) { it.value + itemSvg + itemPage }
        val spinePattern = Regex("<spine\\b[^>]*>")
        val spineNew = spinePattern.replace(opfNew) { it.value + "<itemref idref=\"v5-cover-page\" linear=\"yes\"/>" }
        return entries.filterNot { it.name == coverSvgPath || it.name == coverPagePath || it.name == opf } + listOf(Entry(coverSvgPath, svg.encodeToByteArray(), System.currentTimeMillis()), Entry(coverPagePath, xhtml.encodeToByteArray(), System.currentTimeMillis()), Entry(opf, spineNew.encodeToByteArray(), entries.first { it.name == opf }.time))
    }

    private fun removeBlankParagraphs(text: String): String = Regex("<p\\b([^>]*)>(.*?)</p\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).replace(text) { m ->
        val body = m.groupValues[2]
        if (Regex("<(img|svg|video|audio|object|iframe|math|table|canvas)\\b", RegexOption.IGNORE_CASE).containsMatchIn(body)) m.value
        else if (body.replace(Regex("<[^>]*>"), "").replace(Regex("[\\u200B\\uFEFF]"), "").trim().isEmpty()) "" else m.value
    }
    private fun compact(entries: List<Entry>) = entries.map { e ->
        if (isMarkup(e.name)) {
            var t = e.bytes.decodeToString().replace(Regex("(?:\\s*<br\\b[^>]*?/?>\\s*){2,}", RegexOption.IGNORE_CASE), "<br/>")
            if (!t.contains("EPUB Paragraph Spacing Fix")) { val css = "<style>/* EPUB Paragraph Spacing Fix */body{line-height:1.35!important}p{margin:.4em 0!important}</style>"; t = t.replace(Regex("</head\\s*>", RegexOption.IGNORE_CASE), "$css</head>") }
            Entry(e.name, t.encodeToByteArray(), e.time)
        } else if (e.name.endsWith(".css", true) && !e.bytes.decodeToString().contains("EPUB Paragraph Spacing Fix")) Entry(e.name, (e.bytes.decodeToString()+"\n/* EPUB Paragraph Spacing Fix */\nbody{line-height:1.35!important}p{margin:.4em 0!important}\n").encodeToByteArray(),e.time) else e
    }
    private fun splitParagraphs(text: String): String {
        fun splitText(input: String): List<String> {
            var normalized = input.replace("\r\n", "\n").replace("\r", "\n")
            normalized = normalized.replace(Regex("\\u3000+"), "\n\n")
            val blocks = normalized.trim().split(Regex("\\n\\s*\\n"))
            val result = mutableListOf<String>()
            blocks.forEach { block0 ->
                var block = block0.trim()
                if (block.isNotEmpty()) {
                    block = block.replace(Regex("(?<!^)(?<!\n)(:\\s*)(?=[\"“])"), "$1\n\n")
                    block = block.replace(Regex("([\"”])\\s+(?=[A-Z][a-z])"), "$1\n\n")
                    block = block.replace(Regex("([.!?…])\\s+(?=[\"“])"), "$1\n\n")
                    block.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.forEach(result::add)
                }
            }
            return result
        }
        return Regex("(<p\\b[^>]*>)(.*?)(</p\\s*>)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).replace(text) { m ->
            val content = m.groupValues[2]
            if (content.contains('<') || content.contains('>') || content.length < 30) m.value else {
                val parts = splitText(content)
                if (parts.size <= 1) m.value else parts.joinToString("\n") { m.groupValues[1] + it + m.groupValues[3] }
            }
        }
    }


    private fun compressImages(entries: List<Entry>): List<Entry> {
        val supported = setOf("jpg", "jpeg", "png", "webp")
        return entries.mapNotNull { e ->
            val ext = e.name.substringAfterLast('.', "").lowercase()
            if (ext !in supported) return@mapNotNull e
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(e.bytes, 0, e.bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@mapNotNull e
            var sample = 1
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
            val decoded = BitmapFactory.decodeByteArray(e.bytes, 0, e.bytes.size, opts) ?: return@mapNotNull e
            val bmp = if (maxOf(decoded.width, decoded.height) > 1600) Bitmap.createScaledBitmap(decoded, (decoded.width * 1600f / maxOf(decoded.width, decoded.height)).toInt().coerceAtLeast(1), (decoded.height * 1600f / maxOf(decoded.width, decoded.height)).toInt().coerceAtLeast(1), true).also { decoded.recycle() } else decoded
            val format = when (ext) { "jpg", "jpeg" -> Bitmap.CompressFormat.JPEG; "webp" -> if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP; else -> Bitmap.CompressFormat.PNG }
            val out = ByteArrayOutputStream()
            bmp.compress(format, if (ext == "png") 100 else 15, out); bmp.recycle()
            val bytes = out.toByteArray()
            if (bytes.isNotEmpty() && bytes.size < e.bytes.size) Entry(e.name, bytes, e.time) else e
        }
    }

    private fun replaceFileSafely(source: File, staged: File) {
        val backup = File(source.parentFile, ".${source.name}.bulk.bak")
        if (backup.exists()) backup.delete()
        check(source.renameTo(backup)) { "Unable to stage source file." }
        if (!staged.renameTo(source)) { backup.renameTo(source); error("Unable to replace source file.") }
        backup.delete()
        if (staged.exists()) staged.delete()
        if (backup.exists() && !source.exists()) backup.renameTo(source)
    }

    private fun replacementString(raw: String, regexMode: Boolean): String {
        if (!regexMode) return java.util.regex.Matcher.quoteReplacement(raw)
        var converted = raw.replace(Regex("\\\\([1-9])")) { "$" + it.groupValues[1] }
        converted = converted.replace(Regex("\\\\g<([1-9]+)>")) { "$" + it.groupValues[1] }
        return converted
    }

    private fun bulk(file: File, options: Map<String,String>, countOnly: Boolean): Result {
        val find=options["find"].orEmpty(); require(find.isNotEmpty()){ "Enter search text." }
        val flags=if(options["case_sensitive"]=="true")0 else Pattern.CASE_INSENSITIVE
        val pattern=if(options["regex"]=="true") Pattern.compile(if(options["whole_word"]=="true") "\\b(?:$find)\\b" else find, flags) else Pattern.compile(if(options["whole_word"]=="true") "\\b${Pattern.quote(find)}\\b" else Pattern.quote(find), flags)
        if(file.extension.equals("txt",true)){
            val original=file.readText(); val matcher=pattern.matcher(original); var count=0; while(matcher.find())count++
            if (!countOnly && count > 0) {
                val temp = File(file.parentFile, ".${file.name}.bulk.tmp")
                temp.writeText(pattern.matcher(original).replaceAll(replacementString(options["replace"].orEmpty(), options["regex"] == "true")))
                replaceFileSafely(file, temp)
            }
            return Result(true, if(countOnly) "$count match(es)." else "$count replacement(s).", file.name, count)
        }
        require(file.extension.equals("epub",true)){ "Choose EPUB or TXT." }
        val entries=readEntries(file); var count=0
        val modified=entries.map { e -> if(e.name.substringAfterLast('.', "").lowercase() in setOf("html","htm","xhtml","xml","opf","ncx","css","txt","json","js","svg")){ val text=e.bytes.decodeToString(); val m=pattern.matcher(text); while(m.find())count++; if(!countOnly)Entry(e.name,pattern.matcher(text).replaceAll(replacementString(options["replace"].orEmpty(), options["regex"] == "true")).encodeToByteArray(),e.time) else e } else e }
        if (!countOnly && count > 0) {
            val staged = File(file.parentFile, ".${file.name}.bulk.tmp")
            if (staged.exists()) staged.delete()
            writeZip(staged, modified); validateZip(staged); replaceFileSafely(file, staged)
        }
        return Result(true, if(countOnly) "$count match(es)." else "$count replacement(s).", file.name, count)
    }
    private fun unzip(file: File, options: Map<String,String>): Result {
        val destination=File(options["destination"].orEmpty().ifBlank { file.parentFile?.path ?: Environment.getExternalStorageDirectory().path }).apply { mkdirs() }
        val password=options["password"].orEmpty()
        var extracted=0
        val zf=PasswordZipFile(file).apply { if(password.isNotEmpty()) setPassword(password.toCharArray()) }
        zf.fileHeaders.forEach { h ->
            val raw=h.fileName.replace('\\','/'); val safe=raw.split('/').filter { it.isNotBlank() && it!="." && it!=".." }.joinToString("/")
            if(safe.isNotBlank()){
                val target=File(destination,safe); if(h.isDirectory){target.mkdirs()} else {
                    target.parentFile?.mkdirs(); var unique=target; var n=2; while(unique.exists()){ unique=File(target.parentFile,"${target.nameWithoutExtension}_$n.${target.extension}");n++ }
                    zf.extractFile(h,unique.parentFile.absolutePath,unique.name); extracted++
                }
            }
        }
        return Result(true,"Extracted $extracted file(s). Original ZIP retained.",destination.absolutePath,extracted)
    }
}
