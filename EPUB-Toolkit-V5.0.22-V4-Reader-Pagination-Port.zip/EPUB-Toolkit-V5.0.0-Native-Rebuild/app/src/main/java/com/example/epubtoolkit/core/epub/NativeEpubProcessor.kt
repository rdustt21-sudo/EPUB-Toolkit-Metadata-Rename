package com.example.epubtoolkit.core.epub

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Native EPUB operations. Source files are never overwritten; prepared results are saved through the SAF destination picker. */
object NativeEpubProcessor {
    data class RenameResult(val title: String, val newName: String, val message: String = "")
    data class OperationResult(val outputName: String, val detail: String)
    data class PreparedOutput(val file: File, val suggestedName: String, val detail: String)
    private data class EntryData(val name: String, val bytes: ByteArray, val time: Long)

    fun renameByMetadataTitle(context: Context, source: DocumentFile): Result<RenameResult> = runCatching {
        val currentName = source.name ?: error("File name is unavailable")
        require(currentName.endsWith(".epub", ignoreCase = true)) { "Please select an EPUB file." }
        val title = readMetadataTitle(context, source.uri).trim().ifBlank { currentName.removeSuffixEpub() }
        val safeStem = sanitizeFilename(title).ifBlank { currentName.removeSuffixEpub() }
        val targetName = uniqueSiblingName(source, safeStem + ".epub")
        if (targetName.equals(currentName, ignoreCase = true)) return@runCatching RenameResult(title, currentName, "Filename already matches the metadata title.")
        check(source.renameTo(targetName)) { "Android could not rename this file. Try a folder with write access." }
        RenameResult(title, targetName)
    }


    private fun readMetadataTitle(context: Context, uri: Uri): String {
        val resolver = context.contentResolver
        val containerBytes = resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "META-INF/container.xml") return@use zip.readBytes()
                    zip.closeEntry(); entry = zip.nextEntry
                }
                null
            }
        } ?: return ""
        var opfPath = ""
        try {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(containerBytes), null)
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name.equals("rootfile", true)) {
                    opfPath = parser.getAttributeValue(null, "full-path") ?: ""
                    if (opfPath.isNotBlank()) break
                }
            }
        } catch (_: Exception) { return "" }
        if (opfPath.isBlank()) return ""
        val opfBytes = resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == opfPath) return@use zip.readBytes()
                    zip.closeEntry(); entry = zip.nextEntry
                }
                null
            }
        } ?: return ""
        try {
            val parser = Xml.newPullParser()
            parser.setInput(ByteArrayInputStream(opfBytes), null)
            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                if (parser.eventType == XmlPullParser.START_TAG && parser.name.equals("title", true)) {
                    return parser.nextText().trim()
                }
            }
        } catch (_: Exception) { }
        return ""
    }




    /** Process an arbitrary picker URI and stage the result in app cache. No source-folder access is required. */
    fun prepareOperation(context: Context, sourceUri: Uri, sourceName: String, operation: String): Result<PreparedOutput> = runCatching {
        require(sourceName.endsWith(".epub", true)) { "Please select an EPUB file." }
        val suffix = when (operation) {
            "Remove All Images" -> "_no_images"
            "Remove Blank Spacing" -> "_clean_default_spacing"
            "Compact Line Spacing" -> "_compact_lines"
            "Add Paragraph" -> "_formatted"
            else -> error("This operation is not migrated yet.")
        }
        val entries = readEntries(context, sourceUri)
        require(entries.any { it.name == "mimetype" }) { "Not a valid EPUB: mimetype is missing." }
        val temp = File(context.cacheDir, "prepared_${System.nanoTime()}.epub")
        writeZip(temp, transformEntries(entries, operation))
        validateZip(temp)
        PreparedOutput(temp, sourceName.removeSuffixEpub() + suffix + ".epub", when(operation) {
            "Remove All Images" -> "Image files and image markup removed."
            "Remove Blank Spacing" -> "Empty paragraphs removed; original spacing styles preserved."
            "Compact Line Spacing" -> "Empty lines cleaned and compact spacing rules added."
            else -> "Long text paragraphs split into shorter paragraphs where recognized."
        })
    }

    /** Rename-by-title now creates a copy for the user to save, rather than requiring sibling access. */
    fun prepareRename(context: Context, sourceUri: Uri, sourceName: String): Result<PreparedOutput> = runCatching {
        require(sourceName.endsWith(".epub", true)) { "Please select an EPUB file." }
        val title = readMetadataTitle(context, sourceUri).trim().ifBlank { sourceName.removeSuffixEpub() }
        val safeStem = sanitizeFilename(title).ifBlank { sourceName.removeSuffixEpub() }
        val entries = readEntries(context, sourceUri)
        require(entries.any { it.name == "mimetype" }) { "Not a valid EPUB: mimetype is missing." }
        val temp = File(context.cacheDir, "prepared_rename_${System.nanoTime()}.epub")
        writeZip(temp, entries)
        validateZip(temp)
        PreparedOutput(temp, safeStem + ".epub", "Title: $title")
    }

    /** Migrated operations from V4: image removal, blank spacing, compact spacing, paragraph splitting. */
    fun runOperation(context: Context, source: DocumentFile, operation: String): Result<OperationResult> = runCatching {
        val sourceName = source.name ?: error("File name unavailable")
        require(sourceName.endsWith(".epub", true)) { "Please select an EPUB file." }
        val suffix = when (operation) {
            "Remove All Images" -> "_no_images"
            "Remove Blank Spacing" -> "_clean_default_spacing"
            "Compact Line Spacing" -> "_compact_lines"
            "Add Paragraph" -> "_formatted"
            else -> error("This operation is not migrated yet.")
        }
        val outputName = uniqueSiblingName(source, sourceName.removeSuffixEpub() + suffix + ".epub")
        val temp = File(context.cacheDir, "native_epub_${System.nanoTime()}.tmp")
        val entries = readEntries(context, source.uri)
        require(entries.any { it.name == "mimetype" }) { "Not a valid EPUB: mimetype is missing." }
        val processed = transformEntries(entries, operation)
        writeZip(temp, processed)
        validateZip(temp)
        val parent = source.parentFile ?: error("Source folder is unavailable")
        val output = parent.createFile("application/epub+zip", outputName) ?: error("Cannot create output EPUB in this folder.")
        try {
            context.contentResolver.openOutputStream(output.uri, "wt")?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                ?: error("Cannot write output file")
        } catch (e: Exception) { output.delete(); throw e }
        temp.delete()
        OperationResult(output.name ?: outputName, when(operation) {
            "Remove All Images" -> "Image files and image markup removed."
            "Remove Blank Spacing" -> "Empty paragraphs removed; original spacing styles preserved."
            "Compact Line Spacing" -> "Empty lines cleaned and compact spacing rules added."
            else -> "Long text paragraphs split into shorter paragraphs where recognized."
        })
    }

    private fun readEntries(context: Context, uri: Uri): List<EntryData> {
        val result = mutableListOf<EntryData>()
        context.contentResolver.openInputStream(uri)?.use { input -> ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) result += EntryData(entry.name, zip.readBytes(), entry.time)
                zip.closeEntry(); entry = zip.nextEntry
            }
        } } ?: error("Cannot open selected EPUB")
        return result
    }

    private fun transformEntries(entries: List<EntryData>, operation: String): List<EntryData> {
        val imageExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "tif", "tiff", "svg", "avif")
        val images = entries.filter { it.name.substringAfterLast('.', "").lowercase() in imageExtensions }.map { it.name }.toSet()
        return entries.mapNotNull { e ->
            if (operation == "Remove All Images" && e.name in images) return@mapNotNull null
            var bytes = e.bytes
            val lower = e.name.lowercase()
            if (lower.endsWith(".xhtml") || lower.endsWith(".html") || lower.endsWith(".htm")) {
                val text = bytes.toString(Charsets.UTF_8)
                bytes = when (operation) {
                    "Remove All Images" -> cleanImageMarkup(text).toByteArray(Charsets.UTF_8)
                    "Remove Blank Spacing" -> removeBlankParagraphs(text).toByteArray(Charsets.UTF_8)
                    "Compact Line Spacing" -> compactMarkup(text).toByteArray(Charsets.UTF_8)
                    "Add Paragraph" -> splitParagraphs(text).toByteArray(Charsets.UTF_8)
                    else -> bytes
                }
            } else if (operation == "Remove All Images" && lower.endsWith(".css")) {
                bytes = cleanImageCss(bytes.toString(Charsets.UTF_8)).toByteArray(Charsets.UTF_8)
            } else if (operation == "Remove All Images" && lower.endsWith(".opf")) {
                bytes = cleanOpf(bytes)
            } else if (operation == "Compact Line Spacing" && lower.endsWith(".css")) {
                bytes = addCssRules(bytes.toString(Charsets.UTF_8)).toByteArray(Charsets.UTF_8)
            }
            EntryData(e.name, bytes, e.time)
        }
    }

    private fun cleanImageMarkup(text: String): String = text
        .replace(Regex("<img\\b[^>]*?/?>", RegexOption.IGNORE_CASE), "")
        .replace(Regex("<picture\\b[^>]*>.*?</picture\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), "")
        .replace(Regex("<image\\b[^>]*/?>", RegexOption.IGNORE_CASE), "")
        .replace(Regex("<svg\\b[^>]*>\\s*</svg\\s*>", RegexOption.IGNORE_CASE), "")

    private fun cleanImageCss(text: String): String = text.replace(
        Regex("(?:background(?:-image)?|list-style-image|border-image|mask-image)\\s*:[^;{}]*url\\([^)]*\\)[^;{}]*;", RegexOption.IGNORE_CASE), "")


    private fun cleanOpf(bytes: ByteArray): ByteArray {
        val text = bytes.toString(Charsets.UTF_8)
        val cleaned = Regex("<item\\b[^>]*?/?>", RegexOption.IGNORE_CASE).replace(text) { match ->
            if (match.value.contains("image/", ignoreCase = true)) "" else match.value
        }.replace(Regex("<meta\\b[^>]*cover[^>]*?/?>", RegexOption.IGNORE_CASE), "")
        return cleaned.toByteArray(Charsets.UTF_8)
    }

    private fun removeBlankParagraphs(text: String): String {
        val pattern = Regex("<p\\b([^>]*)>(.*?)</p\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        return pattern.replace(text) { m ->
            val body = m.groupValues[2]
            if (Regex("<(img|svg|video|audio|object|iframe|math|table|canvas)\\b", RegexOption.IGNORE_CASE).containsMatchIn(body)) m.value
            else if (body.replace(Regex("<[^>]*>"), "").replace(Regex("[\\u200B\\uFEFF]"), "").trim().isEmpty()) "" else m.value
        }
    }
    private fun compactMarkup(text: String): String {
        var cleaned = text.replace(Regex("<font\\b(?=[^>]*class=[^>]*line)[^>]*>\\s*</font\\s*>", RegexOption.IGNORE_CASE), "")
        cleaned = cleaned.replace(Regex("(?:\\s*<br\\b[^>]*?/?>\\s*){2,}", RegexOption.IGNORE_CASE), "<br/>")
        cleaned = cleaned.replace(Regex("(<body\\b[^>]*>)(?:\\s*<br\\b[^>]*?/?>\\s*)+", RegexOption.IGNORE_CASE), "${'\$'}1")
        val css = """
/* EPUB Paragraph Spacing Fix */
body { line-height: 1.35 !important; }
font.line { line-height: 1.35 !important; }
p { margin-top: 0.4em !important; margin-bottom: 0.4em !important; }
"""
        if (!cleaned.contains("EPUB Paragraph Spacing Fix")) {
            if (cleaned.contains("</head>", true)) cleaned = cleaned.replaceFirst(Regex("</head\\s*>", RegexOption.IGNORE_CASE), "<style>$css</style></head>")
            else cleaned += css
        }
        return cleaned
    }
    private fun splitParagraphs(text: String): String {
        val pattern = Regex("(<p\\b[^>]*>)(.*?)(</p\\s*>)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        return pattern.replace(text) { m ->
            val opening = m.groupValues[1]; val body = m.groupValues[2]; val closing = m.groupValues[3]
            if (body.length < 30 || body.contains('<') || body.contains('>')) m.value else {
                val pieces = body.replace(Regex("(?<=[.!?…])\\s+(?=[\\\"“])"), "\n\n")
                    .replace(Regex("(?<=[\\\"”])\\s+(?=[A-Z][a-z])"), "\n\n")
                    .split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }
                if (pieces.size <= 1) m.value else pieces.joinToString("\n") { opening + it + closing }
            }
        }
    }
    private fun addCssRules(text: String): String = if (text.contains("EPUB Paragraph Spacing Fix")) text else text.trimEnd() + "\n" + """
body { line-height: 1.35 !important; }
p { margin-top: 0.4em !important; margin-bottom: 0.4em !important; }
""" + "\n"


    private fun writeZip(file: File, entries: List<EntryData>) {
        ZipOutputStream(FileOutputStream(file)).use { zip ->
            entries.sortedBy { if (it.name == "mimetype") 0 else 1 }.forEach { data ->
                val entry = ZipEntry(data.name).apply { if (data.time > 0) time = data.time }
                if (data.name == "mimetype") entry.method = ZipEntry.STORED
                if (entry.method == ZipEntry.STORED) { entry.size = data.bytes.size.toLong(); entry.crc = java.util.zip.CRC32().apply { update(data.bytes) }.value }
                zip.putNextEntry(entry); zip.write(data.bytes); zip.closeEntry()
            }
        }
    }
    private fun validateZip(file: File) {
        ZipInputStream(file.inputStream()).use { zip ->
            val first = zip.nextEntry ?: error("Empty output ZIP")
            require(first.name == "mimetype") { "EPUB structure invalid: mimetype must be first." }
            require(zip.readBytes().toString(Charsets.UTF_8).trim() == "application/epub+zip") { "EPUB mimetype invalid." }
        }
    }
    private fun uniqueSiblingName(source: DocumentFile, desired: String): String {
        val parent = source.parentFile ?: error("File's parent folder is unavailable")
        if (desired.equals(source.name, ignoreCase = true)) return desired
        var candidate = desired; var counter = 2
        while (parent.findFile(candidate) != null) { candidate = desired.removeSuffixEpub() + "_$counter.epub"; counter++ }
        return candidate
    }
    private fun sanitizeFilename(input: String): String = input.replace(Regex("[\\\\/:*?<>|\\x00-\\x1f]"), "")
        .replace(Regex("\\s+"), " ").trim().trimEnd('.', ' ').take(180).trimEnd('.', ' ')
    private fun String.removeSuffixEpub(): String = if (endsWith(".epub", true)) dropLast(5) else this
}
