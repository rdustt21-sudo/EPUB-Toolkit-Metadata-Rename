# V5.0.22 – V4 Reader Pagination Port

- Restores V4-style horizontal, column-based EPUB page navigation in V5 WebView reader.
- Page progress uses horizontal scroll position and page-width stride.
- Reader pagination recalculates after viewport resize and chapter injection.
- Keeps V5 native library, direct storage, search, settings and reader UI.
- Version code 522 / name 5.0.22.

This source package has not been built in this environment. Reader behavior still requires installation and on-device verification.
