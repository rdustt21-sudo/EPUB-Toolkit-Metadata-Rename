# V5.0.7 SAF output fix

- Single-feature processing no longer requires the selected EPUB to be inside the saved Library tree.
- Input is opened from the selected SAF URI directly.
- Processed EPUBs are staged in app cache and saved using Android's Create Document picker, allowing the user to choose any destination.
- Rename File is implemented as a metadata-title-named copy saved through the destination picker; it does not overwrite the original.
- Version is 5.0.7 (versionCode 507).

This source package has ZIP integrity and source-level checks only. It was not compiled on an Android/Gradle runner in this environment.

Currently implemented native single-file operations in this package: Rename File, Remove All Images, Remove Blank Spacing, Compact Line Spacing, and Add Paragraph. Other listed tools remain placeholders/not migrated.
