# EPUB Toolkit V5.0.5 — Native EPUB Engine Foundation

This is a native Kotlin/Jetpack Compose milestone based on the V5.0.3 Library source and the V5.0.4 Rename feature source. It preserves the existing application ID and stable-signing setup.

## Native single-file operations currently implemented
- Rename File using the EPUB metadata title
- Remove All Images (image files, image markup, and image manifest entries)
- Remove Blank Spacing (empty paragraphs; paragraph CSS is left alone)
- Compact Line Spacing (empty break cleanup and compact paragraph CSS)
- Add Paragraph (splits long text paragraphs using V4-style punctuation heuristics)

Operations save a new EPUB alongside the original. The original is not intentionally overwritten.


## Still awaiting migration from V4
- Remove Cover and Add Cover
- Compress Image (requires a native image-compression implementation)
- Bulk Find & Replace with its options/count mode
- Unzip File / Batch Unzip
- Full Batch UI and processing queue

## Build validation
The ZIP was integrity-checked. Android Gradle compilation was not run in this environment; please use the repository GitHub Actions build before installing. This is an engine foundation checkpoint, not feature-parity completion.
