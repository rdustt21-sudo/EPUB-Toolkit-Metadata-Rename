# EPUB Toolkit V5.0.8 — Direct Storage / Library Phase 1


## Scope
This phase replaces the V5 Library folder-picker/SAF scan with direct shared-storage access and rebuilds the native Library screen foundation. Single Feature and Batch Feature remain unchanged in this phase.

## Direct storage
- Android 11+ requests the All files access permission through the system settings page.
- Android 6–10 requests shared-storage runtime permissions.
- Scanning is rooted at `/storage/emulated/0`.
- Scans EPUB files recursively, skips hidden folders and `Android/data` / `Android/obb`.
- EPUB metadata is read using file URIs; cache is retained for unchanged files.

## Library UI foundation
- Native search by title, filename, and author.
- Sort cycle: Name (A–Z), Date added (filesystem modified time proxy for first-seen entries), Recently opened.
- Pull-independent refresh button.
- Long-press multi-selection, select-all-visible, cancel selection, and delete selected files.
- File details dialog on tap (native reader is not included in this phase).

## Version
- versionCode 508
- versionName 5.0.8
- applicationId unchanged: `com.rdustt21.epubtoolkit.v5`

## Verification limitation
This source archive was checked for ZIP integrity and key manifest/source changes. Android Gradle build was not run in this environment because Gradle wrapper/system Gradle and Android SDK are not available here.
