# EPUB Toolkit V5.0.6 — SAF Parent Access Fix

This checkpoint fixes output/rename failures caused by Android's single-document URI (`DocumentFile.fromSingleUri`) not exposing a parent folder.

## Changes
- Features resolve the selected EPUB back to a `DocumentFile` inside the persisted Library folder tree.
- Operations now receive the tree-backed document, which provides a usable parent folder for sibling output files.
- Rename and transform operations create or rename within the selected Library folder.
- If a selected file is outside the Library folder, the app displays a clear explanation instead of the misleading parent-folder error.
- Version code 506, version name 5.0.6. Application ID unchanged.

## Important
Select the folder in Library first and keep the EPUB inside that folder (or a subfolder). The Single Feature file picker still asks you to choose the EPUB, but the processor resolves its URI using the saved folder tree.

ZIP integrity checked. Android Gradle compilation is not available in this environment; compile in GitHub Actions before installing.
