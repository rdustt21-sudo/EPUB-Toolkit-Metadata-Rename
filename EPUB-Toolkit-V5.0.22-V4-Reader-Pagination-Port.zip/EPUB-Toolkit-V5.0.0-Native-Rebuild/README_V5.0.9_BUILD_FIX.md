# EPUB Toolkit V5.0.9 Build Fix

- Added the missing Zip4j dependency (`net.lingala.zip4j:zip4j:2.11.5`) used by `DirectStorageEngine` for password-protected ZIP extraction.
- Bumped Android versionCode to 509 and versionName to 5.0.9 so this correction can be installed as an update over 5.0.8.
- This source correction has not been compiled in this environment.
