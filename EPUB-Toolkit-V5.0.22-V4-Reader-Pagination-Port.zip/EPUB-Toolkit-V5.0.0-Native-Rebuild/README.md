# EPUB Toolkit V5.0.8 — Direct Storage Native Rebuild

V5.0.8 rebuild work based on V5.0.7, using V4.2.21 as the behavior reference.

## Direction
- Native Android/Compose Library and feature UI.
- Direct filesystem access only; SAF is not used for Library or Feature workflows.
- Android target API 29 with `requestLegacyExternalStorage="true"` for legacy shared-storage access. Storage permissions are requested at runtime.
- Library scans shared internal storage for EPUB, ZIP and TXT files. The Library view displays EPUB files; feature workflows filter EPUB/ZIP/TXT as appropriate.
- Single and Batch operations update EPUBs/TXT in place; Rename File renames the file; Unzip preserves the original ZIP and extracts to a path with collision-safe names.
- Batch processing is sequential and capped at 500 selections. Per-file errors are collected rather than stopping the batch.

## Single Features
1. Rename File
2. Remove Cover
3. Add Cover
4. Remove All Images
5. Add Paragraph
6. Remove Blank Spacing
7. Compact Line Spacing
8. Compress Image
9. Bulk Find & Replace (Count Matches first, then Replace)
10. Unzip File

## Batch Features
- Same EPUB operations as Single, with Batch Unzip.
- Bulk Find & Replace — Count Matches
- Bulk Find & Replace — Execute

## Library work included in this rebuild draft
- EPUB inventory and metadata (title/author), raster cover thumbnail, filename search, folder filter, Name/Date Added/Recently Opened sort, selection/delete, and refresh.
- EPUB chapter extraction and reading view with chapter selection, horizontal-page-style navigation, full-book text search, font family/size/weight, line/paragraph spacing, letter spacing and theme controls.

## Build
Requires Android SDK and Gradle 8.7-compatible setup; build with `gradle assembleDebug` from the project root.


## Important status
This is a source rebuild draft. It has not been compiled with the Android Gradle toolchain or tested on a device in this environment. Direct storage access and reader/EPUB behavior need Android build and device validation before it should be considered stable.
