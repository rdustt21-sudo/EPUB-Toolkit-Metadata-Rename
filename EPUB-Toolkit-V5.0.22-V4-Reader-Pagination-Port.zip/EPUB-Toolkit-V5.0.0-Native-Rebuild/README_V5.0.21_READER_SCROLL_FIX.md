# V5.0.21 Reader Layout Fix

- Version: 5.0.21 (versionCode 521)
- Keeps package ID and signing setup unchanged.
- Replaces WebView CSS horizontal multi-column reader with vertical text flow.
- Updates page navigation and saved progress to vertical viewport positions.
- Keeps chapter, settings, search, TOC, and theme functions.

This source change is intended to resolve the blank reader body observed in the supplied video. Android build/runtime still needs verification in GitHub Actions and on device.
