# V5.0.19 Stable Debug Signing

- VersionName: 5.0.19
- VersionCode: 519
- Application ID remains: com.rdustt21.epubtoolkit.v5
- Debug APK explicitly uses the persistent `$HOME/.android/debug.keystore` installed by the workflow.
- Signing credentials remain the Android debug keystore defaults (`android` / `androiddebugkey`).

This is an installation compatibility test build. It must be signed with the exact same keystore as V5.0.18 to update in place. A source-only check cannot prove the installed APK's certificate matches; compare APK signing fingerprints if Android still rejects the update.
