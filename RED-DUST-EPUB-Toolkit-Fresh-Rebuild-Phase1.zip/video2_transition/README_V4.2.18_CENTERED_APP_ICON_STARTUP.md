# V4.2.18 – Centered App Icon Startup

- Replaced the blank dark startup surface with the existing app launcher icon, centered on the same dark background.
- Kept normal startup icon-only (no text or spinner).
- The icon overlay is removed immediately once the Library WebView finishes loading; no fade or added delay.
- ZIP extraction, permission prompts, and startup error messages still use the existing overlay status elements.
- App version: versionCode 18, versionName 2.0.9.

Device testing and Gradle compilation were not performed in this environment.
