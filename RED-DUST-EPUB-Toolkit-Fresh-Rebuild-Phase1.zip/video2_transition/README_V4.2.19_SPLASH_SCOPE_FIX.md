# V4.2.19 – Centered Icon Startup Scope Fix

- Fixed Kotlin compilation error: `splash` was declared locally in `onCreate`, but referenced by `launchPendingZipOrToolkit` and `startToolkit`.
- Promoted the splash/icon overlay to an Activity property so these methods can access it.
- No startup design or toolkit behavior changes beyond the compile fix.
- App version: 2.0.10 (versionCode 19).
