# V4.2.17 — Direct Library Startup (Video 2 Style)

- Removed the standalone book/title startup splash from normal app startup.
- The app now immediately shows its dark background surface while Python/WebView initialize.
- The Library loads into that surface as soon as the HTML is ready, with no splash-to-library animation or extra fade.
- Kept a visible overlay for external ZIP extraction and startup errors, so those states remain understandable.
- Updated app version to 2.0.8 (version code 17).

This package is source-updated and ZIP-validated. Gradle compilation was not run because the package does not include a Gradle wrapper.
