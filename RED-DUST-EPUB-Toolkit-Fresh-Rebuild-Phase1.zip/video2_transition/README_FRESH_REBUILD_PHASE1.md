# RED DUST EPUB Toolkit – Fresh Rebuild Foundation (V4 codebase)

This project starts from the user's V4.2.21 source archive. No V5 source files or
V5 reader implementation are used.

## Phase 1: Storage permission and startup gate

- Preserves V4's Android 11+ `MANAGE_EXTERNAL_STORAGE` settings flow.
- Checks the permission again when the Activity resumes from Android Settings.
- Starts the toolkit only after storage access is confirmed.
- Adds legacy READ/WRITE storage permission handling for Android 10 and earlier.
- Keeps pending ZIP-open intents waiting until permission is granted.
- Increments app version to 2.0.13 (versionCode 22).

## Important validation note

This is the first foundation pass, not the completed full-app rebuild. The source
archive does not include a Gradle wrapper, and a Gradle/device build was not run
in this environment. The permission flow must be compiled and tested on-device,
particularly on Android 10 and Android 11+.

Next rebuild stages: isolate the native Android shell and storage layer, then
rebuild the toolkit UI/features and replace the EPUB reader independently of V5.
