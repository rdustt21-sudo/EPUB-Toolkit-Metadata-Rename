# EPUB Toolkit V4.2.16 — Python initialization guard

- App version: 2.0.7 (versionCode 16)
- Startup animation remains from V4.2.15 fast-start baseline.
- Python startup is serialized with JavaScript bridge access using the existing lock.
- If Python reports that it is already started, the existing runtime is reused rather than displaying a startup failure.
- No unrelated Toolkit features were changed.
