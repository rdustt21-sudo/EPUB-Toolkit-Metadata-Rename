package com.example.epubtoolkit

import android.app.Activity
import android.content.Intent
import android.content.ContentResolver
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.view.Gravity
import android.widget.FrameLayout
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import org.json.JSONArray
import net.lingala.zip4j.ZipFile
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var splash: LinearLayout
    private var restoreReaderAfterWebViewBack = false
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val pythonLock = Any()
    private var pendingZipUri: Uri? = null
    private var pendingZipHandled = false
    private var startupTriggered = false
    private var externalZipStatus: String? = null
    private val externalZipPassword = "taiwanandnorthkorea"

    inner class ToolkitBridge {
        @JavascriptInterface
        fun getFiles(): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_get_files").toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Gagal membaca daftar file").toString()
            }
        }

        @JavascriptInterface
        fun post(path: String, data: String): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_post", path, data).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Operasi gagal").toString()
            }
        }

        @JavascriptInterface
        fun unzipBatch(data: String): String = synchronized(pythonLock) {
            try {
                val input = JSONObject(data)
                val selected = input.getJSONArray("files")
                val destinationRel = input.getString("destination").replace("\\", "/")
                val password = input.optString("password", "").ifEmpty { "taiwanandnorthkorea" }
                val storageRoot = File(Environment.getExternalStorageDirectory(), "") .canonicalFile
                val destination = File(storageRoot, destinationRel).canonicalFile
                if (!destination.path.startsWith(storageRoot.path + File.separator)) throw IllegalArgumentException("Folder tujuan tidak valid.")
                if (!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder tujuan.")
                if (!destination.isDirectory) throw IllegalArgumentException("Tujuan bukan folder.")
                if (selected.length() == 0 || selected.length() > 500) throw IllegalArgumentException("Pilih 1 sampai 500 file ZIP.")
                val results = JSONArray(); var succeeded = 0
                for (i in 0 until selected.length()) {
                    val rel = selected.getString(i).replace("\\", "/")
                    try {
                        if (rel.startsWith("/") || rel.split("/").any { it == ".." || it.isEmpty() }) throw IllegalArgumentException("Lokasi ZIP tidak valid.")
                        val archive = File(storageRoot, rel).canonicalFile
                        if (!archive.path.startsWith(storageRoot.path + File.separator) || !archive.isFile || !archive.extension.equals("zip", true)) throw IllegalArgumentException("File ZIP tidak ditemukan.")
                        val zip = if (password.isNotEmpty()) ZipFile(archive, password.toCharArray()) else ZipFile(archive)
                        var extractedCount = 0
                        // Extract entries one by one so files from later archives never overwrite earlier ones.
                        for (header in zip.fileHeaders) {
                            val entryName = header.fileName.replace("\\", "/")
                            if (entryName.startsWith("/") || entryName.split("/").any { it == ".." || it == "." }) {
                                throw IllegalArgumentException("ZIP berisi lokasi file yang tidak valid: $entryName")
                            }
                            val parts = entryName.split("/").filter { it.isNotEmpty() }
                            if (parts.isEmpty()) continue
                            val parentParts = if (header.isDirectory) parts else parts.dropLast(1)
                            var parent = destination
                            for (part in parentParts) parent = File(parent, part)
                            val safeParent = parent.canonicalFile
                            if (!safeParent.path.startsWith(destination.canonicalPath + File.separator) && safeParent != destination.canonicalFile) {
                                throw IllegalArgumentException("Lokasi ekstraksi tidak valid: $entryName")
                            }
                            if (!safeParent.exists() && !safeParent.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder: ${safeParent.name}")
                            if (header.isDirectory) continue

                            val originalName = parts.last()
                            val dot = originalName.lastIndexOf('.')
                            val base = if (dot > 0) originalName.substring(0, dot) else originalName
                            val extension = if (dot > 0) originalName.substring(dot) else ""
                            var outputName = originalName
                            var suffix = 2
                            while (File(safeParent, outputName).exists()) {
                                outputName = "${base}_${suffix}${extension}"
                                suffix++
                            }
                            zip.extractFile(header, safeParent.absolutePath, outputName)
                            extractedCount++
                        }
                        results.put(JSONObject().put("file", rel).put("ok", true).put("result", JSONObject().put("message", "Berhasil mengekstrak $extractedCount file ke ${destinationRel}")))
                        succeeded++
                    } catch (e: Exception) {
                        results.put(JSONObject().put("file", rel).put("ok", false).put("error", (e.message ?: e.javaClass.simpleName)))
                    }
                }
                JSONObject().put("total", selected.length()).put("succeeded", succeeded).put("failed", selected.length() - succeeded).put("results", results).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Ekstraksi gagal").toString()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(13, 18, 30))
        window.statusBarColor = Color.rgb(13, 18, 30)
        window.navigationBarColor = Color.rgb(13, 18, 30)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(13, 18, 30))
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Preparing…"
            setTextColor(Color.rgb(145, 151, 165))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 0)
            visibility = View.GONE
        }
        progress = ProgressBar(this).apply {
            isIndeterminate = true
            alpha = 0.75f
            visibility = View.GONE
        }
        splash.addView(status, LinearLayout.LayoutParams(-2, -2))
        val progressParams = LinearLayout.LayoutParams(36, 36).apply { topMargin = 18 }
        splash.addView(progress, progressParams)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(13, 18, 30))
            alpha = 1f
            visibility = View.VISIBLE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (restoreReaderAfterWebViewBack) {
                        restoreReaderAfterWebViewBack = false
                        view.evaluateJavascript("restoreReaderAfterWebViewError()", null)
                    }
                    view.visibility = View.VISIBLE
                    view.alpha = 1f
                    if (splash.visibility == View.VISIBLE) {
                        splash.clearAnimation()
                        splash.visibility = View.GONE
                    }
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ToolkitBridge(), "AndroidBridge")
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        // Direct Library startup: keep the dark surface blank during initialization.
        // The overlay is reserved for permission, ZIP-processing, and error messages.
        setContentView(root)
        if (intent?.action == Intent.ACTION_VIEW) {
            pendingZipUri = intent.data
        }

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            splash.visibility = View.VISIBLE
            splash.alpha = 1f
            status.text = "Izinkan akses semua file agar EPUB di folder Download dapat diproses."
            status.visibility = View.VISIBLE
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startToolkit()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
        }
        if (::web.isInitialized && Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
            && web.url == null) launchPendingZipOrToolkit()
    }

    override fun onPause() {
        if (::web.isInitialized) {
            // Suspend WebView work while the Activity is backgrounded without
            // clearing the reader DOM, scroll position, or JavaScript state.
            web.onPause()
            web.pauseTimers()
        }
        super.onPause()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            // Release the bridge and WebView resources when this Activity is
            // actually being destroyed; ordinary pause/resume keeps reader state.
            web.stopLoading()
            web.removeJavascriptInterface("AndroidBridge")
            web.clearHistory()
            web.removeAllViews()
            web.destroy()
        }
        super.onDestroy()
    }

    private fun launchPendingZipOrToolkit() {
        if (startupTriggered) return
        startupTriggered = true
        val uri = pendingZipUri
        if (uri != null && !pendingZipHandled) {
            pendingZipHandled = true
            pendingZipUri = null
            splash.visibility = View.VISIBLE
            splash.alpha = 1f
            status.text = "Mengekstrak ZIP secara otomatis…"
            status.visibility = View.VISIBLE
            progress.visibility = View.VISIBLE
            thread {
                val result = try {
                    extractExternalZip(uri)
                } catch (e: Exception) {
                    "Ekstraksi ZIP gagal: ${e.message ?: e.javaClass.simpleName}"
                }
                externalZipStatus = result
                runOnUiThread {
                    status.text = result
                    progress.visibility = View.GONE
                    startToolkit()
                }
            }
        } else {
            startToolkit()
        }
    }


    private fun getDisplayName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)
                }
            }
        }
        if (name.isNullOrBlank()) name = uri.lastPathSegment
        return name ?: "archive.zip"
    }

    private fun resolveZipParent(uri: Uri, displayName: String): File? {
        if (uri.scheme == "file") {
            val source = File(uri.path ?: return null)
            return source.parentFile
        }
        if (uri.scheme == ContentResolver.SCHEME_CONTENT && uri.authority == "com.android.externalstorage.documents") {
            return try {
                val docId = DocumentsContract.getDocumentId(uri)
                if (docId.startsWith("primary:")) {
                    val relative = docId.substringAfter("primary:")
                    val source = File(Environment.getExternalStorageDirectory(), relative).canonicalFile
                    val root = Environment.getExternalStorageDirectory().canonicalFile
                    if (source.path.startsWith(root.path + File.separator) && source.isFile) source.parentFile else null
                } else null
            } catch (_: Exception) { null }
        }
        return null
    }

    private fun extractExternalZip(uri: Uri): String {
        val displayName = getDisplayName(uri)
        if (!displayName.endsWith(".zip", true)) throw IllegalArgumentException("File yang dibuka bukan ZIP.")
        val target = resolveZipParent(uri, displayName)
            ?: Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val destination = target.canonicalFile
        if (!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder tujuan.")
        if (!destination.isDirectory) throw IllegalStateException("Folder tujuan tidak valid.")

        val tempZip = File(cacheDir, "incoming-${System.currentTimeMillis()}.zip")
        try {
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw IllegalStateException("Tidak dapat membuka file ZIP.")
                FileOutputStream(tempZip).use { output -> input.copyTo(output) }
            }
            val zip = ZipFile(tempZip, externalZipPassword.toCharArray())
            var extracted = 0
            for (header in zip.fileHeaders) {
                val entry = header.fileName.replace("\\", "/")
                if (entry.startsWith("/") || entry.split("/").any { it == ".." || it == "." }) {
                    throw IllegalArgumentException("ZIP berisi jalur file yang tidak valid: $entry")
                }
                val parts = entry.split("/").filter { it.isNotEmpty() }
                if (parts.isEmpty()) continue
                var parent = destination
                val parentParts = if (header.isDirectory) parts else parts.dropLast(1)
                for (part in parentParts) parent = File(parent, part)
                val safeParent = parent.canonicalFile
                if (!safeParent.path.startsWith(destination.path + File.separator) && safeParent != destination) {
                    throw IllegalArgumentException("Lokasi ekstraksi tidak valid: $entry")
                }
                if (!safeParent.exists() && !safeParent.mkdirs()) throw IllegalStateException("Gagal membuat folder ${safeParent.name}")
                if (header.isDirectory) continue
                val original = parts.last()
                val dot = original.lastIndexOf('.')
                val baseName = if (dot > 0) original.substring(0, dot) else original
                val ext = if (dot > 0) original.substring(dot) else ""
                var name = original
                var suffix = 2
                while (File(safeParent, name).exists()) {
                    name = "${baseName}_${suffix}${ext}"
                    suffix++
                }
                zip.extractFile(header, safeParent.absolutePath, name)
                extracted++
            }
            return "ZIP berhasil diekstrak: $extracted file · ${destination.name}"
        } finally {
            tempZip.delete()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun startToolkit() {
        // Normal launch keeps the dark blank surface visible while Python starts.
        thread {
            try {
                val html = synchronized(pythonLock) {
                    // Serialize Python initialization with JavaScript bridge calls.
                    // If another component has already started Python, reuse that runtime.
                    if (!Python.isStarted()) {
                        try {
                            Python.start(AndroidPlatform(this))
                        } catch (startError: IllegalStateException) {
                            if (!(startError.message ?: "").contains("already started", ignoreCase = true)) {
                                throw startError
                            }
                        }
                    }
                    val module = Python.getInstance().getModule("epub_app")
                    val downloadDir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    ).absolutePath
                    module.callAttr("set_download_dir", downloadDir)
                    module.get("PAGE").toString()
                }
                runOnUiThread {
                    status.text = (externalZipStatus?.let { "$it · " } ?: "") + "EPUB Toolkit siap · Offline"
                    progress.visibility = View.GONE
                    web.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    splash.visibility = View.VISIBLE
                    splash.alpha = 1f
                    progress.visibility = View.GONE
                    status.visibility = View.VISIBLE
                    status.text = "Gagal menjalankan aplikasi: ${e.message}"
                }
            }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized) {
            // First let the reader UI consume Back (selection, popups, search, reader exit).
            // If the WebView is showing a failed local EPUB page, its JavaScript is no
            // longer available; fall back to native WebView history before exiting.
            web.evaluateJavascript("handleAndroidBack()") { result ->
                if (result != "true") {
                    if (web.canGoBack()) {
                        // Native WebView history may return to the toolkit shell after a
                        // broken EPUB resource. Reopen the last book/chapter afterward.
                        restoreReaderAfterWebViewBack = true
                        web.goBack()
                    } else {
                        super.onBackPressed()
                    }
                }
            }
        } else {
            super.onBackPressed()
        }
    }
}
