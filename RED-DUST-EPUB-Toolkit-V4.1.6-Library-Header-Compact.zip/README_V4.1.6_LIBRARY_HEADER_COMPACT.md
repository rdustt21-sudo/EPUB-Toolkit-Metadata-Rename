RED-DUST EPUB Toolkit V4.1.6 – Library Header Compact

- Further compacted My Library header vertical spacing (title, search, sort).
- Reduced gap before the book count/status line.
- Book list/card layout and sizing intentionally unchanged: covers, card dimensions, text, metadata, and progress bars retain existing CSS.
- Search, sorting, reader, and toolkit functionality unchanged.
