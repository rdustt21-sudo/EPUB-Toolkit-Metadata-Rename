# V5.0.22 XHTML Reader Rendering Fix

- Version code: 522 / version name 5.0.22
- Replaced regex-based chapter body extraction and cleanup with namespace-aware XML parsing and recursive XHTML serialization.
- Local image sources are converted to embedded data URIs when found in the EPUB archive.
- Internal relative links are carried as `data-rd-href` for the reader navigation handler.
- Scripts, event attributes, and XML namespace declarations are not copied into reader markup.
- If XML parsing fails, fallback extracts readable plain text instead of returning an empty chapter.

Build status: source ZIP checked; Android Gradle build not run in this environment (Gradle executable/wrapper not available).
