# V5.0.24 EPUB Reader Rendering Recovery

This revision targets the native EPUB reader only.

## Changes
- XHTML documents with standard EPUB 2 DOCTYPE declarations are now accepted.
- External general entities, parameter entities, and external DTD loading remain disabled.
- Malformed XHTML fallback retains readable HTML structure and text instead of reducing every chapter to an unreliable plain-text regex result.
- Saved page positions are clamped after the chapter's content has completed layout, preventing stale page numbers from a previous reader engine from being restored as invalid positions.
- Existing reader controls, settings, navigation, search, themes, and progress preferences are retained.

## Test target
The supplied sample EPUB is EPUB 2 and its chapter documents contain XHTML 1.1 DOCTYPE declarations. This was the key parser compatibility case addressed here.

## Build note
Source changes are packaged; Android compilation/device verification has not been performed in this environment.
