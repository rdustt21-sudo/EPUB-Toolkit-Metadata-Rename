#!/usr/bin/env python3
# EPUB Toolkit V11 - Offline Android Edition
# Batch processing is performed locally through the Android WebView bridge.
import os, re, json, zipfile, tempfile, io, contextlib, builtins, shutil, html
import base64, zlib, mimetypes, posixpath, bisect
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

DOWNLOAD_DIR = "/storage/emulated/0/Download"  # Android Download directory, retained for module compatibility.
STORAGE_ROOT = "/storage/emulated/0"  # Shared internal storage root for EPUB discovery.
MODULES_B64 = "eNrtfWt32za26F9h3MmhmMi0JD+SyJaznNTp+Ewevonb6dR2dWiJsjmWSJWkYruK1pofcu7X88Pml9z9AECAL8lOO13nrmlnaooENjaAjY2N/cJ87ePhuw8/HPYPj79/1X8NTx/d6d1a11oLJtMoTq0oOQvFY3I1S4Ox+vlrMB0FY1/9nkZJcDv10iv1JvUnZpHbydj109j33cOxP/HD9ASeLS+xDk/Owm8//PX92w8H3/a/Pfpo9Sx7I0mj2Lv0N/zJbOyl/nCjtfFtdBOOI29on4Vn4dAfWeNo4I37oTfxG6l36XTPQgv+if10FocWvHHjZDoO0oa9sJtW2zldb59bwciCn1ZABSx/nPj4ICGGST8alQM7bXfPXRNei8BhQ0nqxWlyE6RXDXtuOwzXVogOroLxsDH1Yuh100KEJfxRFENhRGccJKkoIj/iP4HRTX/sInJWr0dQtHIasv7YwP19FPoSkavYH/VxmhrRlB+a9E62iM8w/PhH9vUb2Vf54qV8YbSiCMANo3hCTWSv/h4FofZzGMTUG4mDI5BwJJqxP4k++31/OrvoD+ApbiTRLB74XFrgeuElftPyb1NAOEpcgkwowiujPBePZul0ltIbqICVraeW3Q8jbsHFxmwJeXA9m8qiGiis4fJXURSmR7bt38IMJg2tHX0ep3EQwuB9oK+WN459b3hncZ2u7eQL6lCyb16Y3Pgx4BSE8LVhf/SnY2/gW0H60mrcbYRO17IdIMY4mDYcdxxB4YZj0JKA8AiW2J2dIx+B4msvHPjjsT90dbSyqeZ3SOuSC7g/BdM38Fcf9aZlx7AQYHn/GoRaQzjxCY6qnzbgi4u/ifQdrbFBFKZeEPoxUT3yg3eHJwfrR+/fbKhPLvAT2+hbrlYYpbiuqMH8QvECmP4fvPHMP4zjKG7YJ1cBMCJgg9YVoBxGVnmDxpBk7cVRhFR4eOKO4miC4x9eUu9wlhsmXno/sR4OINTlVSo/ZGzBbMQF6oYpzXWnkkfYsoH8VOcalxxD/+cCcL82xldVgKFCdC1AEgdZvncvYU7t0Ww8XkcKsJ2lo/46mo2HBGMUhEMrvfJ5DqawxID5W40Px28ci2DrAy/5BmBe2baBuapwT5rwLUBAYSP7PgmSBCYY1hrwA8XDTPSGXuoBeooGSoqVEo2sqzMEbr4f4rLhDYpIASc5K/ULfBx7k4uhxzuDBfsQoKdVfkob31P6jIOifaLtCt9n8CZeGIz8BDHk3QvbhEUt3+sjnEyBQPMF6aVe6nIWDAul6GVutlTTgs5WmiiDbsQaloAM4pEv+7CUJjikp7e03G7VJixLOLmFdZutK6xrn2tYD/tpRBAB4PyWqTEYwhKwNOi5pgG6VnKhUQZvf8FQMkqn8A1pseQrbWVAaJcVtREVwrKATWEviKZYv4EfGUl85cdp4CfA1wGObastRogGue1i4g8Dz4RBr9bTu6lfgFFgaTZ1Zj2YQG9IYCOcyhiZGi7XGw611nBYi3C98K7RsNOr2eQi9IIxg6aRmapWHOcr2pn4qSfWv7l0xPs8ucviQUL8qYTkc1KirFGG5FjsmMUNoXyg5f7B1XqMZdl2ITdvnFCASB3H30smUicovaqgprsVqwOKCkOiCxvmcWhJaLhLguBsOxWIl0xfoWp1yzliIUQQ6RwNQY9qmpeT5jIe0H5JgyAK6XMxDsLrqrmIgSC08YSfqw9lDnOo+1DEARjz9XrixWOFpF4qXzZRJrfFI0gmx/gjH05GA5+nXZIAgKRyNAKlXEVypor+ifOOgoG/7epxw881IyW5L0kmlUet6vorc+cS1DJuxH2gcSrDIV+QBjjDfElLhdZok1tep7g5LefVJYuXtj2qmWFcUYvITNKsOe7ITIBWTXxKqHbluZikD9zmNBosTCDVKxbHIRB8ODtR43GWVg1RWC2nn5AE3LC9KayMgZcGUbhxe5VOxk/xQAXbFJ6fN/CFICLVIFXjwzJVwML8U/5Kg3Ts44BmBbJXDLJbubhWpqmH0lGBhiqXqFMmi7mzKbBBv2E2nxOuxGvF7HKF81IWvWepMRMhqSOiSlF8QcrN6okjmHqhU1DJEOJmF4QzvwSNGrZVCr2IWQam4oiF/6TxXcXUUvX6k7RqoWqKqcAwiI3FIdVNWe3yyiMazCERukKm/MS9ROJCKEtkroLsRasrmFziomGZdxlfTeIBngixLZoX+M1sI3s1v0rTaXdj4+bmxr3ZdKP4cqP94sWLjVuULBZ1u52GH8BdgcMXVtcKGkExW01swimbU/924E9T65D+AKeqJJ0kyauq8thUTH5OKiwuu5U3ggILY9FKHeWQl66wRFfiUoXF+HseKUrVS5Kyl54ZhHxNWqacxF25Fcg6xgA+VETVJ9A839eq0WiIzQN/bgqLc1wmGkgdhEANq5uTxdqT+pnCWroMTXWWz5WoZnYDCUb1REm+wZCljlWGnFrXO1QQrzLdUg4EMPbYv4QuCG1oAiX9hm03tSr5LRWgB7dNaxYHxCQb9nCATFKwtuksHhNjGw42fDYsJRttt71hO03gqLBmtMLIB4PhdEQVOq3Wsw38TgWHA8BpklRApm8A0lmpPxrKWmdC/6YPzfH2lkZic2PlAJxtoiH87NmzdLT+HLAAaaw/9AdjLyYZrXcSz3wNGOnfpY3NfQ9ND098NLR58R3p4ocwGKnfe+ON0UySzEaAUc9mM0fTAq7bk4YLuT/qNhPS3KeT/IEWG5SSAnx1TZ1hcW8vtRIoIDDUN8JGEM3Scmq2JwGsbpSk66QKKhyOIqFyBYrGX42scgWvwXbdmxhoGGajgXWamc5Wq90EljSBWU2SPr7oqS4dHfc/nXz4ePhtSQO0cBEpQByB4jObOurVK1jOlVL3cnWIwrJWZC6T+/LQsrVPu8+D4Qnll6R3DVmliCeNsxppsousPkM5BflKhCaMUYMrf3Bd0rELb0jqOvjqYlO/ogWtlCChZJVGplQxDaPAyumRBzgh100sIBsY7NS/hH7dCZzImgDAyyX+nJFRs1CWERMb691BNL3rmEY5vaJZT9Qhnq4NXLkhchSE3nh8V9xAc3gqQGVYQlmxh2TFuJSwRJ6dhW+CMEiuNFuk+PRejGrXLkNRGlvj4BIRVZabWTi48sLLIrhXNCwIrDhAYgZyklxDe0erpcTY+z5K/S5s6VBuEF2Gwa/eBeBBR0JLY+2JBZKUD+xiFg53MyPYxLtTduIr7zMaNLmuQh4XUbHVj4TUkMtuKE3feuyTIwVsNbDxwOqGzgKLaWT9coAAtTfcK2etaa29Ofqx//5D//jj4Q9Hh38VPiJn9C+hegw9uYy96ZX1JriFziHnO74bxhGchDetDesgpGeXqyiPkBj4Bx7zLBztcXBhiffH5EfCrgCkv+uTTR//I0c5Zbs//gEiIis40ksMJIM7OP5xjA/qrVE/9t1kdoEFzs5mm61W66kox3CoReETAGLVdSKqsCMEVgrxP8kTehQVpP3dkf4RyWyckqHpPPP5IHDIcBmuNov8pcd/JayC7oq+5tZUkSlLWLKbjZd7j3528L+EsNPoMvrwqnd6tvbPf/z3ucMDcHbWVt3DjhEkpwYyVf+/5w4BfIrwDtZ/Oj/11n99OEj30ct//uN/dJj3wpGEx8AfiI2tZtq4Zl45Q1V7/Lc4EVLSxa+lxziadtebTv0QzpVYzDE8ZkQJSejTOBqgfEGas4Z+FjPFqkgytR7tgy4wEjjuN4TcKDkDn5u/DwP8+C0VoT2pq2u2CA1qqmm1JEP0UpBlQ54HFHpwI7Ube1Mcq4vTn/fPn+w7DffJS6extzHlYdzHCYHiR9YX/PNJgBK8FkC1zoTXCDv38KqceOnA2BfCKKSzi6yoW9T9EITjpjwYwsM4Qhs8wCYw7mUczaZJbqHYe7Z0ocDTJCpU9/NvkOGJn461Z222yn2qtFYaLcM4H9Pa1tiUhGb6cPmo7oCy0EjPat+vETmQT6FmYf6Iq7E+pSHGiez+wEefqmFi1WScsmoL0RDgWaeJcyQmntaemKKmIjaTchuilkunloz2mhJT5cgFgjh7cZH+Qk42bwNv0OWDJSMyZsMxxB+k4zvEUWwYdmJJpz/owngIWwvsu7DmBtd+7KjthChLluvR9tGo9yA0t3ZZ1w0SVEcZ8vkI5ByUCQRc9yqCk5IDe5ot4Nv4LCEkpkeSrFwGOIe0LJoVyO3upocWou0NkGGQwJAbJdzbJWynFMTBeBzdaHu0hBWJycjmwPrkp7CtXCZNbClEbmR5lx6I7uXuYZon00UU0ZaZwKbuDxsNzcqeDTkQHQ0NMVMcKESgwaaHqcvnVkPZxEdYILZr/64nXF6mXYsPo7KkOcGESJl8ZhEw0edMCgMMK4aQa56tvQMJyboDyZopGF5GNBHTK+h9Cdlib+JZKEbubM0prONs2DLpV1sdMGYSpnIX5APm0L9tUg+xjB/OJn6MZgrqM3pqFvo9si1rTvUWrjXHcjR0C21VILsiADTk7eLQAXLfE2fBTgPfvhMrGUePxGisjE6juaOd6Kz8LHwJr1A+RwVHV2d6UTDwla/jiMYDOCuMpQWdvEBe0F6fZ5guHORXVguJeEA+jLo3pOkpKGADNbXs7hIqNuoAgQ6BJaaCQNvIzXFA+Csx9wyjcsjcd73SutU+L4zw8dhHH1WfukzediMabNQgAMPmIUhoEWa8VhyFmOhy/PYTniGAyyiJ1BtHsKzReI9w+ZgoyVkRm8FkRQ9WYbB4bCCPcuvdwV9q/MpR2qn2GV/uZv6/wascRLtL1B01BrOYXcDTKPXGcP7yLvxxz341C8ao/KPBB6A3wTC96m22lACIpUnUuW2Imm25I+MJEj/B9o+fRQuwJ4mCLScrfOGhYcz+xraeENFSO/BMQPD0Z6/jJ/F+vaRM/nwezxfW6Xxxbs272257tHhsu8CUQI5pUNfwOB03BZJPrHYLsQFxuIcK39F4llzpak1cZAL9/R7jX2A8itrRYRS1S41flfO64Vo8KnoW4yRV+BGX6RbLTZEjoRusAOTkzh/Snriq866yHC513xVa2MzWV+r8aujk6y2zujM/rTDZCp1dQ+6OAkBbq/KygTkV0Q8uKdTPje2XgOgjW1CUmV6/CMNht2DcT5SgoWHHm4eMFvCGfWkCMk5OpVOoaQ/JOQEKeLP0KqK1YWc7a/3U4Tpf1eb7GXuKHiJcBlUPwimkbHMiyD3hOcGWGgag1E70JU9Hsi9UVpciNZADGCrggKVAeQzyUNXIaGDFrFKDtbP6CoUSxitzm7ZI48MaLmm2y01wg+o0ZeM4Vt+H1yEwauuAXuFxE2ZFMYOb2Jv2b6J4mDQIT+CswSRQyiL6Ivtg+qqOYeUmTfqDE3R63sR5yYgAqyIREIhu4UiHrx1rn5srWdhBWKYboEalZgB/OOVlNII0qwIFYVVq/jToBqi4QwzOWSQkqsWDWKPVzNCUg5K3sxfVRiA9DQM84eGQECKwNZB+mgCVUi0VQ2KiA7UEUDU2y0ZA9B6bqz0QiXKqvUyANUe+qj1BcPQZ6ezUthVbmXjXPscG9ZPPlyZNmpLVR4bioVI3ws3uMxRE6QSWRLrOG6L16YfvhPpWl6i45Z5OwaKh9nNTHKeSOJ7P8v1CPoR/T7s75zBHpzBVrA/gtzvdc0dpHsO0nwS/4pi12zs50CC7brLs8qJT/LTNn57taKyzT3FvCKz1oiUEhoZWDQRbB/b9rNknVsvd0ZlvH1liXjkaiAVpnGcYpM6Bs/pyZu09Yq63vbO19nbrbM26g6f5Ah4GYy9J4AdVOlvbny/2NrDsvhJY9A49pZ4EOdTbbqeDoWopipzJwJsyUmpBMWn0S6aUvzQtEOlOu51zo7gaAAP5rTLkuUYp9u0Xz1uINqC5s1WGY/XA6mhLQpFqLUAKaB+F7BARKHoTdVqt1gYUASxZagXkd1o49Fd+cHmVwu/O9g7+/hz4N68i7F0LzmhYyBJf0K7qx5/9g2TqD9KPKCxCqdt3wfBv8H/YJfwU+ow63z1Ylwk/Ibpe/F3sDQPyFBlClQtE47aNTeDwyYfbDmKFb8QDQ4CzwBQOVSMQF0VBfLM+iMZRDC++aT9rb3eAVjbKirtbzwsVNoeb7e3tigrtQnFvZ3u001HFN8weVffyEg53K/SztWo/R8+HI2+4MtrDFy8unr2oRxt/eOMc2iAWrYqS/+Li+fNn8nUEgmGQ4mpwN7dWxrMKRitD3USTX0r9N+E8jNJEo2xalYqu6Zco/n0YpLhAZkDIn9AF5EP4feLL7g6CeICGPyR+rDS4Ew+IKFAAqnjGNBWjEfzS+tvWsBVNyd7fjX16dP07/yKObubIqtZH3iQY33UPYuhYM/HCZB0wCka79BH5WHezNb3dHfsIax29VTCSrb0J7xCJ7jej7eFzb7ggyMQSDbjf+bDoA6+pAb2h8eheAFVqrTweZhBHo+f+Rb5Jd3t6CyfmxxmHxRaZF63alS0NbSDii2G+EWoD4SYTbzxeFWxnqzhCz1VLvjfYfOEteE54GvY2Mr6EOuxlrFBM9yweN765uHTUFN+3LpJnVlunsnbnRUsS2jbBQVLb6eQh4KK8D4StZxqEEFVkuL7i6Non8gUO6O2oV+uyK5smUW8+v0eLmy8e0mLHbLGTcWU6BePafgeb0Ha7Zb2GFqz2ZqdlPYctqf1sS2xO7c3NlvVW7VPWW/77k7Zc5Q5R0bmsKRBGrG1o5s/tre2W3gGeBFg6TrEPGasrkQt4gKRgIFgA8JsDC92R/ibFA307l6cGTW5ySj6fmohvwZAg5tsvVkZ8hxA/LwOuyzwVjZd0ttPZ1ntLixn6asleqrWD1bafyyF6rgslW88N5t3Z2iIGLFnyV5L0dhmBwbDhyG0CkYnnH+iZyK4DSwnoAWhef/GD6Op90dk20XmWoYPCWTYZRZshWwPzljx5BpqFwS8zdA4RbooYZyJlcNjr0HA1zzRQ5BBboTphrYFecqH7RzSlTh9OnJzYoePoxgEuhTCxWcOKTR/gpDxfrM8XSiBmIAxU98HkVjJLqmGMl932hkORd0I4QSnHax4GPhWWnggpgLsiACEXBF7qs1aXOwG93xLh4pg5E94ztwLFFkgfzpxDvkAe47L9kE4Hw3U+swIV2Y4Mpcf+cYaTsmK6cfwBLd2K0KOlbXFBrffQSkdzkCW60Xpbofp80HgApVFfJbWFznKEi3VMRMKcfb+0P0tjbKYP7A2P5n37k69V3yMtp0CInhINLTY+xyrKw+6z5ANNMtCV5CB4GGCRrKAAVQvlfiDGKua7ALsk0wGqoFQ4gHyhB3OslA6BTXiZwlUCaKr2mqohw4hPGSZkbonKfEeyQEXSo1pP+zwbCnAHyW8yBUIT4VA5xrJa3Wmu6uGJ+2l2IWyFjWxAOF2GSJNB0R5Na477VFehipEBGCTR1RZW7I/JtSXjIk21alBv7eLE6/GgXRHdhfuyjLjUMit0zbQHi6/DfLoc8enqeJdHjC5yFi9KebA0rshcMFSnIqyILRRcojrpgJYYoCwIJxcfRNCqh1atF2NoCRscWkJAThQHwXJAU0YqC2PDJUN1EJnj1MeQlwAdOLB55CMgiiV+I4jcV3epnxx9aBSzx6D59DNGuPQaNi2/9TCxm4WoFD1kpkfN5GxFpUGYdbEsPNz5iBbN1TBjQKW2Sj0+r0glpeFMK5GIEdCkEYkMZ+r15CIoc5PX45jyNMEfgzCBlYl2FBgdSSCFFYdt8aITy0ytO9aOIbWEESyV3ysaiOlOZm/TlL/1nKouRjZjA7/MotTPt4hq4V7eRlImF+cV9ogdiut7FzEcUYTjYkFfTUQiddWaJt1oodMyjFnicPl1DShVfYdU9Tr8WwX5JUyHBYgkOBVwuHTxzKYmDU7HOGtnay/39x59++H1yd+OD2lS9vcIQrU2nWNzySVmjYt10T/NLJvfVVFDOfaoXT/kel3tNzQKLGR/j8Zsf05/0HxAP/eQqaHXZsxqVIH4hviAJAFvUXWPPAzP4Mzq4CUfPYf+52AgzqFNGMogDbzxOozz2O/RsAAoUpJZFDd1tkbZBQbADtb2sZ/Ni2h4N59PvPgSjjqt3SkcvVDf1tolkN12q/V4dxKE63xy59+LBddCf0n0lg2HXaGL2SX1r9I5VqsuFwuXSAmARLeo9sNGL4ACYOuFN7u4MijgmKImgs/+LpYeAevpXgXDoR9W4/f5SvWivfPYevHYance72q4Mk9YvxR650Z7a3voXzZFF6zW46YwJVjbHXhmOwE6zzx2dhlFVGxaCZz/htY3/vPBixc+diiKL+Zzhbh3AQVmqS8Q3dn+fLMrkKTniXfL09bd2kKVMP4W3/lFTM/rHehgGk27zx7Lxjuq8fjywmt0tjabnXa72d7ZabqbzyWO69i9WdLdpglD5LreKMURFzTURSvobhFfZLkwkFuqvXZNe52q9uLZ2J/PRYcAY30C5Jgx1cF8p2k06Xb8iT6pi8VVez7XtMLu5jaUwMlTk+12OrsZ6VaSzDryl64X3t1c+XGeRgFX5jnrjDKjsAkYiFY2a5HHqdkEvBQYxrlruS8A3Y22u20VVN15VXwbuy6xYkW6Bh16CZ8r+rJYZEpw5jO4NGHN+wMcCwvZV1csfVpwmh5P/N7fGwaf1UugE3y1Ae/MDzg62Zer9j55rvYlP4MXRnFtTLNa0xJTKkHhnwBmCkUF7vDEfaFkKDlDcU/fULRNyWHXV/7Ry3Y88Zrb6Wk7VYnqTUU9cK7QkuymtEHjcQwzmOIBrJjDtC45aYmkJRKKnp2FpRlKXWulVKPleUVXyi2azy9KguKwSS6hFOglIp0n1wk+C7G0Z2c5Yvu2FuacTqYVUc7yN/AbcQBCuVof9sTFsAm/MdLFwaLILL0y0d+BNHPoQdlZMSyVQp+b6I4b3cD7nS2Wr2pioZUTaUu4j1ZFHDdV0HFm4yf8cs7g9RG7RhByTeiuUa4qhjcgpaUahSOMzTYqUkyvD6sG5A36oH5WgsTgpAk508IzLIqYUw1iZfWFftG3ajAYhwuUMe57aRpLYNkbBTRXToLO3tVgim53fj+5S0SqH0JSf1mdFCk/DSuFe/PoZPHq+vCriPWa6kbM9a9BacR1jVfWPVD59vDN24OT+yNTF5AvYWZlxnBoHvdeVKcm5JUVVK+sXBi6doaCc88qyDg1K9rgIO1VkdA0N7e8xXwdFsJhvKxxyb0xUF36qVteDEfmz77rFnh5Hdf7Q+LwDxhVdABFN0EUTDgavyrqXsV8IB6ZGQW33Ef6GrRIlYGFSlJO5Aj/UdkiXLkLRyEhLxxnRRtoBpwNYNP0C3NAwfUcaMkjL7b+h8XwLw/fL0Tuv6YwdzgI+UPYlim8DD3U7x7lQu+5HDsT24ZpzSzHnr9YxFAsGHnVs2wAFYkAaPRuPM61k+UCwGCVo3cH3x32X394d/zx8NOnDx/77e3KoBXU5T08ZAVY/r1DU/7z+PC7/v/5/uDt0cnf0N9y+yz86+Gr49yrdwc/9rkf3x69O3z/6ejDe/yCniQquMUb9qcBih2N8vhics8+Pnor9ZZHyOua/OfDNCnGD+cKmBHIRwSkEHpM5P1xFuIOzwR+tnZMWFkNaNuR6ZDgLAjcCOVF6yjMwhWbFBFsHQdA14mPjIhEH5tB2E1ZD6RVEbWIsXcp5nhPBiCxpnocHg8Ms3TgbsOGkma6siupYUxTYrgsmEs2mt2Q4Jy2zVsSoJa6E0IyB2pZRGFn8lB+VA2HY34WbscNlNouUGWcxd+6XOIvvj/lCD25AKgxi0pbcIILfVx8cCAXyizrhjKy++EYzn8cF0YMq9g4D0rZqCmvZSwiEq43bPfvU0ptB399fpiG/PfGv5gamdDMwHRKYOSUUSptMzRALpKDrjkneYU2GvziD4tMDvg1Cm0N/o4595K+BysUl54tWyWtcqFk2B/FqB6nWbb2C9Hc9X0wVLYwhHKGkd2O+iCqhskUTx/cXFklFxdxfleUM9wX7uYgtjIEcWyV9pLZdFqabTtfX00cch6cp+P39Ae5TkXeuqU9HlEEG/cBdSo4eCUsqywRFNVRuUwajZJqzTJYjlhC7kc/8SawPMNL9+3B+9c/ffiUH0B52tbIaPkwoUROI1SevYrxnqA7jBrQj99hjJ/9ti4Xqn1AIWlcHQjwAggxqc1CmWmIJE25wBdka9mYN61GZ3u7acn/1CXd9cbTK0+uckQD2Uvoj2EzrksbmaECckSCp0+qz1wmZZQcNEYn1z1qoi49plglGcwHnUIkmDJMqqgt8UC0YapoWjzdPbkafpmBMJbe9fRtGTcl2M9gjOks31SSNUieeeuJiswqoydcad17YcVrM9e82mDKTz+VzdMKv1/7VCUbFV0yaaLx9Soa9nYKYUeMHjmRMUAkMYrRKll4WnEVZaReYeYOfFOVwVLypqxG09JmpCbLaGa5LOdvIknRVXTTr4zylaqqY1FARfh2tsxt/dsABAjM+mQlIHyht4+oQZG76RVM0E0UX1MyANyapTwE9JxEuEtr+zNG/ZGCaq9n6TlNpNZKuOXAZjDg7JwUkC7CbylUV8YQy2i4AOUwUVBGBefCjUvijEW1QmwxvxcVQCJ2k3Sojre50OLN4eKx1ZgvNuYLR6lhpY2bIoxFN5qWOfZOET5FHTdWijguwyo07j0pAZsT7lA9aWZgqxDsfpvbrDICx3MtSZsPuaWqSg38v/GiKsXiJOXLkQBmgxtiyeAKKZol84TzF9F8XwcgPZW8B544ZBE8ewkDIxxBl2mgjbybYrEJzbfKtblE/S2orUIDzphIyimot0uk6gdc7LWKg+rKTqpamDHDROk107rUXONUc70XZQEcRj4fLccYnDwOrn1gt5lqZXVdVpbB9F5qfKLCvsjBZ1gPqsoqaktmk0ajbeQz5sEJjOMrJShWp7HVTl+OU2myAV5wzKnJUPMHTJl0KLIDwJUBr+mUMvwIMYsTB6JeUJnM9E43jX45FWYMLHzXZ3fth1g0Vs+lmr+qq8aQAQxVws3Gu6Y8nCnV4PSlDCqBrDQx1YaBAuga8Rc1BEJrrnKyleofynUPtdnrBcQlGeJzLNX0Cy7NMa3x1Ke9TLoD0QGfZY+WZK/X7Fr4WF14yfmhhPtXd8GUBk1Czq0E+7WYBVhbVZONyKvcxr+lDU0ClvYyZZnin0sqSZNb9mNJBcOAJisaL5e3WARgvFzWz4fb4e5lftMH9jcywkmQX2OKWwmt+xrkTMS+1iwn9pwf0E3lTqYXkxmUc5Ymc5m1mmg545rCSdl2lkg1K+aHXsEmVWmPKooiQrDGFNArm6PkhUU5c1RmffoXm6gqYg6UNarYs5qZa9fPXM6QVZmWumjOukc66upU1EjfVSeHIhLM3mnvwvLm0WM9A/YHpbk+4q1LN8dpihUyvxn7dGltBX1D7IhYz9wcS+rxVkwj07Ueu52R9e4Vhn839I1+w2q0W50t0j90thynzopHTnkGpNxw1wOTIyvg0D86sGzeK+BIBYuY7X1DyyIaOSEAlD4k9oezAZS7uJPNWI3Hbnv0+LHjUoM6sFyTTcv8mOsoJ1arzQl+QoYcNXbDgG/dvfBh9n2LAmr9eFeX3zkb5jXqxW7IgOZLQsFFPfE4a+DEIkNRLGyor75/+5f+m6P33/Y/Hh6/PXh9WGlBjTMD6d+TKCxaT+9pHz05/PGkD/9nrf8njEu11bVk+EB/1a1kroi8ccX1IG44uKW/A1LPwen5NmWxHJATD5xI4POlvTgL//zh0wli1e48c1vwbxtQOP7wEd89f7azDT8OvjskV/FHw2hAvJWcCGGpsw+47qBNL9F3Eh/KHbKzT1/pki1Asff3q9n42qI0vP8h/fukYzgWYr9OeHpS7iS9gE/kiF2bV6Hg2t3eyTm0jjr4r3RAbbfbCPiqrfvePiMHZQZktSyAgGWm0m8c3aFbVnuLXwOTDv2x7h1+cwXSSs5PuI0+zgqnrayBNvo3txAQ5TCcD1kr26Uk4VqaiPazfB1rmxEgpdcpCUCovjtvJv7YH6RzzbtYA/Ncx4M8lfNuz988f/48h31uDLmD5giKRjXn9K3nYoBIHlAdG439213YsC/Ddb7XakBJR3cvvWn3Bea9KO9yWw4Tg2NVn+hjB/shna873OrFLE2jcF7V800AR3Miut/K9fhZjmo6z3aeeUPRZ+6/7pKf+S+/0Jt3E+Bj4dCL74zoge3tbSzzDYeBzwkc+Uf7XeB55PNc5QFtUPIz/LdkAgeDQckEGrOuzdOLljnqgtz1LCb8AV3DxaRDDyowxKrSSZseFa8h92biPm2dF3iT6W7GD+AbFpnuv76KogRzvPEeAmLlyY8nLHOQzwhlQ87lPXbRoxqr667ZtDyZEVnWHi0yVPnAF2L9a/tv8hmP9zaolKjBhM0ZekSNvYgMN5zhr4dWkP23UI/SDdJFai5gwmXIwRsBCGhMF1lyCUkfwFmF3zqXwAwL4WAcDK7hFSJFWMJBYG3/oz8CwrnisUAxfG+D64gm9M6L5BUCexok5Z9OsyMfVh2xcEgjFuYGiVajHCMsowfgwC9vlka4o9MlUWdrEWUeoim/IqTg3QlaIygjOLVRbFzI5TQCrN/HY1YlHqr4/VER8ElLwbUMdFREATIiHE6t1YGXaE1SCdi7MH3Ia7SaJH6IYRuffRPt5XBvALkKwH/FT5w6ElNj3xdy7F/6t+WQv09QkrwECSi2/FspjpkNCIKuJt4BMKv0Hd41IOj3Nb7g2wf8JEe7S6GJWT0Yj8VaYEoAKtchrUzXAABZsNklrCOGhtJ0rO1/Yh7g0ZpriizZqCxA6pCZ6r2pZXTNLVlm7A+Gj2hFTa0/0VWsVm/fAsFthgSHxz0R+fnq7mjYCIbOLhQfwTmIeM7Ui70JDOSccBVmYv7Bt/V2/9Q4O7OJU53BkZszlKrvsG+I77DKCt/F6HIRuYAKpZDG+4qSuTDRPZYk+vGHsizRLQU7cjmm45KCRIayYaRIrQwVWeAw4O7iJXfhwFIDojFHHgYBg6YOgeAcvZZS65mtc2pin8Ct4fUu1U1hp5a9pAmKe96NF6TWCN1REPAGcXgEvGsUHIqCMQnxjdzXpGfMyq6VuEEY+vGfT969RaQUAnjSazwauryPjP3wEs7fEiXL4js6UUX1gbYXBPo+KmyRCacyho9NBu4ofBZ4ZKsHaFB7GQzLkggCZz70YGBGvf0CpFFz5Gjtir88DrwTlczOG75RwoLHp+hMhr929arVE/uG3JFERW34nsIrGqENOTyNxHEt0UtMe4Ep/EVa2owUFgNcxg3fmS9p9zU5MbKRz+MLrBPugL+7KKfZhLJT0bOYXCaTaU8ub8YBaWFKnVmKhUjgn+hzR50RLCKcjce7CwNqOFwVqmB4uEODnITbP4E2OckIOBhiXmxwSSN/jWL087/nOsQB5iFsztnpp4sIw1EZSRalTj9OunOaIGpq/QR2FfiJxfTkEqQROLMXFBzc/c9PH967HB4fjO4aU2ex4kLHUY3d6Nr68gWWh4+KSgd2hji6YZUyaS7Fhy9foMGP/i8zzMbCKkudo4gRHN6TENnvmSnPncBm7V36hdkooUZzh9bpUfaV6BW5PJbMMIUuD51lsysAi8s6xPokQE+Jr8grtY5G7DItcmbB0yCKMc9ak7ZWbaeXZFLSFV08mCtih86MgniCeL4m+wte6gFzQlsAX2165cu6dKXrS+tE92MWBcdjocdSzvzEFnmId2vGTdtKtZGbr8DXxFD1er3WS+b1JF2QsQKXI0YXcNp6vPlPeJUyumhfoN4Sml3Fu5FVCgXwo2z4NZk3IYVbzVR9Is2gl3TFKyzGTUsK5u5rW7MgZTFruQ9wRlJykQiD5aOjUGLZRpJskZm0QXcysABmSiRNTepoYga3PkkUUgsvzBuqem1S+VIGiNRCh9dR4I8ztXcmIuMNSxI8tqdw4HDG2JexvKpUpubVJCYtGbkO2pZX6t04jZdddr1Sn59aNrwVn+1c1jl1xVpWoWm1yK5ujKBC8+i79x8+Hr4++HSonM34Bji+fKz63jjdfzF/aVzTuv/1ccWA2OoW1pPgMmuFf+lDubw1HT4mwVLZtHgIhG1Eu8ZYDgILLE3pD2K41smiwosr9SeVHniak4eeHV+WoyQjsimyLqM3nmAy0hdPWpSyvG6c0y1npMqS53fLU/KXNjqy59juQjXan4eLObS6MDJ8FTMfarnzzYsIR5njV1PmOW7qPLlHU2AEyVR4LmIcjOnlJ8JD6D4v1LXnHdAooEM2bscXbJ0dFXKf3eDCZr8d/cI8eU2gzMmClyVqqwTq5S6EkhfOr5hiTWm+RJwSO5B9f/Jm/TnfAWob2MzIuYLvAORb9pDNwMapLgs00dEGWc8EJwCZDr2mf/MMe51LNBdxEoHiEineMFh6DSDHUhevNcwmKkJncPumYpZGwn1WbtEi4YGcG6d4PZjsSKQC+aQJVjhXZv5z8t6AGrfFKo/Fle/nznuI1cW8a0ZntQjM8tpawJZzlqsSa/syaq7wCDHJGqm0hLSz1IwsE65MpcVMCE97EkqlF02OriVO5NEv6tb4r4hpWEqhBQLLBT4w7cg7I/Q7xTPmVLECBRmaK1DdWsPu/trqW7LySmlWrCW7zIlUUiyjyw6RfJmz2cUll6bnEOZVdhaSVs76M0zGGIjzFcgffz45ORaHIvEal0Z2les4uuyLY00DzrmjpvWk78WX5l3YFEGR1UEJvE8HNa7BbkNJ6qWzpNdptfS6KHjCAGJpdzibTBPhpghS0Sz2+14yCIIeh2JUp1HBZlxqFQSsKZwGAFdqrbQMH1MbxhEVLb/58+muMtLWNJgH9pbUH+guAdPC9wQO7wzn25K6HiyLdYQQR2SzDqN1tIX7hSazWsZFuPTthmiM+TA1qk/JMOp/d3hC8+GY/jNUl33Q0Qafd3oT84PG7urxr5gDnOqqQlWTQMnD8AxSM/pfOwPLhrNuSI3YqtzYkRYqP4DliRhhA8Fz1TCAlnU/iCaHYfSj67J4Mqlu1m5c1W9tA6C4ueFdqzpMR9+xgoSEPkPANBHAxMDIrUuufmuIm1ml+4TjnPMdrTDUXLoE4WymiCXMhSLS7lpmu7YYPu7hojwHpQrgQtYJ77ortEfaH4CL9ABVnEXT2jYos8SpMgNCtRtbra38ekKtV/2CUvGgGyTs4LBtiF2nEBla3mBd6qQiYbHqVcRvEUBB3Jwws7BA7JadXxZiAyZ2TLcdM5yYFgJJRkI9nj9f5uBk+WwU5WEEE22QdHjk+wzx4kO6ji2/+vim0txByKSXaumMNQ0CAcpVn+bp3zxB1p8E8lpePglkVnF1j6pdj8oq62k1/1J1GS+u08z+4MV+FqlRwCa79t3Q6OizEQ55NiiV2Vj7ZGoqbKdYItOglH0lPUwxBkUXwcRd96I4LxJCpmSTkt9ZZWLe46uOY80s3nvl827lJiNYCa/jrmzA5hbgBT8siiqPJQxrFWa1BcyK79p9d3zw+qT/9uj9Yf8TPB69/67/5ujHmqt3q3zwqlOaEEXP4vE4uHApW7FMEkI/+r/cP68JOtI1LeE619D86ZroSIdX4EEf+q8/oUcfOspuPGHafouZWz9xAkPrTXBrPdkQ3mjC9KrnabTa7ua29Yhx9cJUqqrRk8alHLCr15mKspqDkdVyt/xJrqwqIbJLlhZasCr1Ps6CIpvrb+wmWOclSON97MEkxt70Sh90P/7t3QUNd6rN0dZoR3o4dVqddmerxJ9QeLVNvCCcZ1lNdzotzVkNypCfiQl/NFJQOpnrmfIQ3KJX0JUrbxjddFsWevmRq983rVaL3RQ7c40SWgv3CrbXueaTpXlr0bVSRvpQcjojzcBKznimyyI6zD3PkBZ0pjmd+b6v4PNV03OE3m3XOIoJJ70KH7wX+VSk296LVkv5HT7Df4u3gpkufs8Lvm0VfntyXhmlLgyQdzH2h3Nxz02XR+8bPsvps8Awy1z4cqNfMw7uZRQN5Ty2N59tbm4uQEhRry42Ozttf8EeeeLdzs6O7mtnJkRF6uQV3VmyoqAAOdwpLxkkKfTSMf3vqn3uLIp25XgG2FYm0/SOnFSotYTEAtjVyA7FGbAvQHa7ToTXDDCUxEpxiPw4q2aJZLFomWdOduHD0YJVN5TX17X+hshEppN+6t3p8Qi6O6Dy30s0bz3uGr785z/+J/PSEV5I4v5Dw/9oFNziPcPkfIQbQQFlww1JNcxkg95nwIHWx5ij42xtGqHGzvDHm+7v0STvi7gdFM9YcUNh194g7Ys7eUFWE2MQk2BtedMpbAJ31pX3GSPfEwsvMJbjCMOccoAT5uYBOowDvAcUs8SKtBr4GQaMW5cDt0F0pHktLfG9YesnMLFelTuTcILJHGiUpX+5v02tAV6a3+tt7pqvRpCwOJwYVtmC6w10Jm/Rlg43mqeN7j6qeV0I/weEkbn7yBYm3rTRGDUDp7f/X4afmvQyZSc94QuHPBFJUWy1XEZQ9Z/mAV7cKt1R/zRn7cj3H48w4BNEUjiD8Q31DpaD4tKerBysyCsCvSD2TYdPBr0PIJOBgrF3EUs6lR8owdIiox/2p2PC/i+Hz0zCjYjGOnNqKBngGo8a5dcgTcmKFhGPxJkLbeMnvuAgcVQ418bpf+ztn60BlPONy+agt99A35D/EF0nN2Th67Qn341T+WpfvrpUrwgUvcMbC/jtGr2nl99svsB3i9PBuePslrgqKE6irZxBtm5+mfnxHfsoYb66M5vd/Gn6cUDOu9nc8ZBKT7OapSfYENRoXtSVA6YnoZL/hDNPlvgb8TZRIP0LV26kvTSe+buYDQKI/D0RMbu9FSADW4WpA4bMCeVUGj7Mqhcil5JeQiuwDnQj/Er3IJDwbm7oWu11OIvwyhpm/kLwFIrePB2wn6T0GFqFXX35AhxnGdf6MPVjPbwx41i58UQxQvlQlQys5vWhOXJovEs6ffAZUnp9UFnkXfJwP/z7LEl9VVr+Nsof5iWBjUwOYBFACA2ZUxCQVJiDwl/koqd+lfuWZAwlNyYgRpWSWam3FBGtiO2ca8Q7Qq3/7jL3lVwKd2nivppNvJAunW2EUqtChILWZICVXWWG6tMZHI5YVUeJ2/5C/31H/8X8YaaCj8HsUeCeJSujXgKKllttR/acKnXd9mhhzbHCQkvizgA3egRR5RfCiemDzHs9mxo+H3oKKBIDSaBQSU9m6DlDZACCjU4K2M9JBIsDzhmJSPd4ROUTaw/FdbUXorQD+w9FVOCHfbpnRQiSGCKVYNDZYDxDeU4Yb6+iWYIZ7KxoxM1v/OrHER/UrOwUztUx1zxSIVZLFEzp8DceA4KcmTIEwR3DKsMhHKetVx+hYZZtqTaMEEmU8N7yKNnrFCVavrSsJKGl0GTQ5Sv6ixm7pWTpI0zVasqOD1U+L6v705j5xVrwP8dMYERpgGRGJ7EyM4s4DmA/0+JpnkU2zR+u3YvGy97pz/vnT+gHTSg+JU96/KdxSkucdmTn9OfsB1egmceHwqe2Q2D3G+6Tlw6TBUPEO0jRacn6gn8+GVryIOkTLZD83CBpzExFFV343BO09Np7j9bXAfz6Ot1rSjleQ3J8GXuXSU9Ar6zM+Ima9LWkNN3pMAvl1Um5UnxtFTIC+pJbzAPKuakRiwtv/MsovmsMrspVv/DBDRK+ZYtj+b3UuFTvtS1fM/v5iWJQfyIr4E9T/thglIA/3yJbnXVarQv6s9OCPyN/NKpQHDO5kfG0QIRoXdKnipeUPl1krdfhhlFIt3VJyjSYojnVVNdFHcK00SkgJym7mF9FXl5rF/DVIcplIxamvi6Ey0CuL01Lc/dj78VQkU7YsBsvu0zMwOgE+YsllDzZeLnPD8680+Q7wenWqaYApIjzyDHXLfQu1EcYhONJH/eqPhHAfcaXalE+5J4xEG399gqQUnKfO7nPnVy3f16t30/FmkIQTVZ999olHS92PjeHWTeeMj7GNMqF3CB1SobOvgM8x8H2zQGUE1CCUMaLDF8I9NrK2bCbVpvC/BGFR1k6BzYsAIcW/XH0a4PF+b4/SJIaZ8zfadfQs+5iFtlqRROll8372lbC4hu8WANfeZ0XejlKZf1TunlaKoRtza3G5XzdwJJJPZZtEzxfRDHFgVJ8PFdp7E0uhp416QoUn1oTxQZqSEDlSsihRJs/0tbK+KgaaoPJUMpQofEgbSAOkkRV9CbrfB2mhhFaYCEBZWJBPTULpwHtjusk6eMNSf8fkar8wkMQixSTONpIiCaJUjrPJcMkrYNaIs8mcOwkBU5A0ULdB/sfrnqd92mQ3QBDHmAq89+5scs+IFvib5UpUWTISgrZh5a2p99r0SWxXl1uQZnTpJ/gKIC5NNpkbXdJfk19dsQtlrk7pVa4Ukry8fKUmtz20kuj5DEc00flBfZyL43yPFUPuS+KfACzzG5IZJWJ3XRPWKKgf2VSRbz0oWfpPhCV/qPw3fCPuNUzvGSpXhxniRcpDCRwWzkrxjm6Jhu6nEwQX2oyCWpCzmApFnQ7Sq9ccFgNE/TmITCVOeHy48ZJblYYIg253Ebx26BWk9jw3/kMf898hgoAyhn9CzRNyUUtX/w7EeIfmwhxyV7wh9yiJSyghdx+lpd+7T1aK+NwrzyDBQx+70u6zMu59IRpyxHV8xziHOtSTLXj2Kr+xDK7obqoKwfww6fV7m5X/Talbcn2zTPx/QMKyNkN148IDkDJvEmqAXimhbTcEd+IHkXRAqvfKzwAS94nOIAwe1gAAEai/av9/zn67Tdw/8+QpSnrtFpNigVY0VP/K73kpa/76ZzsfXZXZK+20a4DvzQjTyFxZ42DOwqqjrNgx3mRp1u401e50Ofd3OU+WfTpFS697EPfwHNNle9vP0QnkLEUC5UrcP9i7IXX075YZ9n7ojcKutRSQ/dw76fen9f5zWdTrYXlzHP++aUhOr+B0z41vl1ovOAX66zqwE8At1pbMILzszWCg+4Ca+/xyEkZW9YogPaezv2PmJZv7RUbjq6hVTJpNuuw+Jd7/KORnULu2L33gf7+4tiIwLhpWq9N69RGO1PrvNQ6Iv3zCxECfK3Bo54qUbOO5HpbzXVe6iJI/cF+FECXhZ16lfiD6tiDe8YaoNAHZECpdASa7IPii7tAQ0kjRTxXDGgv3ICmAtgNnmLcKKOOipmUUj8ghetHyzM0l2jWysfkkMqbkmnushqSSUWnoDdoV5YkM/Qx2ZwVlOmV9GNsU9PbLNUELt8cDaYVXQPH4qu68qECGG8oMIB3GTK2wAaDDPgJ3glPCXhnn1S6bcIGXOe6ueSC1KX8/L7xDIL7lQ4JAYd+lQQ7lCNRG49aFo6K8RIfD999+OGw/+rtwfu/yHiJVSIlkqtZGoxXv/6V/QnuGRXxl8PD4/7Rmz5eRXv4/iRvzxfW+mBy+SX5fPnlczD0oy/ebBhEX6KLvwNv+BLQDZVfJrCyvqToMPNl4AFzSxxp3chnEjk++Hjw3ceD4z/3Px7mm2u8PN5Lvcv9xsvu6cH6T976r/1z8hS4cdfPn3Sdly+njnAvON5DtUWyT9YQZx9fkAMO+wXAzx4AckzfAIUGG+a+/XBy8PZtdi9rwhJPX9E0B1tmqWNygyWtOXqpcoN33pZj+AhoEZ2inOkdkLMZC+cMdYSzhSmeo5SM12STp9fGGYqqS3MFysK26exDuk7DTqM5hpQkdYHVggso6amAKdUe+XixJlq38VMpbZyrbdACRN7Gn58o3dxs44AWN2KJzNda+zM2rVOyniMgw6upRi5nM1Iydd4iJLCsMwrJjsVRBOy7X5MLRb/ADckPKvBmS9MM4L3ZODXlfnlF3OB6NqXoXhJAcE/jd3b9NW85MVXcyVa6abrWSle1/Qb3sunXm2VBepzo3iBR/fogeeZrPdzoNioxjZn3kK1mI1tiHrMaSg8EhScBXfHjmAasZZe8KcOTOOTRZW45Y5cgqqWmqFVNTcbNZnX2Jexepr4Py3RrFUYppTJVIJqZoUirXqdDZcWcU2/Kqk3qYiwIzZ61snJbJqhczQBWlzOmCpXSmOCH27yyVVXYUWpv+JJOwavd8MVLdPkFX+ZKf9orbir3yGjyW1zz8/spzokfoGXoEjpwx+CX685z50XB0Znhl002S6Ygt03vOooJiuI5OZxLmvfdVBzRytl0+YU78loUVUVXPi27gqf+Gp7iVTmPcnfbvELhQ3dplmRrN01aM6uhE/3Gj5orvbzPTrsMhy80XHIxT8VdNehqgsNQPJLRBStjf5RW39djHssAfy8Ia673eUWTjSiJaceDDl+IzsedlWLBlx5pplES3OLcqDe3IBn7aez7rghbOYFnXGeHJ/c++zC+hz+eiEtcKi9IvAxG2UWJ+HAx4b+p+AB/R+rSFvzrfYYvCynEkSjLWZnwUNI1pXHv0o05SaCNfp1t53S9fU7Sw4IdkrxL9gOEB+2swvdC0rWuOpETw+XcVVeKqwvwLxl861y++Ea+MDBSo54JlAQV84khQtm4qSiH2B8xKtF0JNY4vpNI4TOea+BPoekCchW4oJaae6tekfIn+6luvRU4OAIJpzKWQWjPjIgGERLAFxT5TGTJBsCBRQTSZsLhsLyOcblxQVx85LZgXI39+/q3ZYEClVaAFXfx/Pk0O3+31l/018+fwtEb3gUTPlGzC+LLjZfyCJt3QTYdX8tamAZkVtUcGuHgvrehvU6ePBx6Gf40T1l7X4M8rHINceG6vCHeroo32aSqdMl5v5m8b/LLbhYcDz/WqXPOyy8of66Tsya/+iKi6vnHxEuuRVHGtHv68+58cf5kFpNraeP0Z4f9rh3xYbeiK06pXoOAPgV8knjwBdZl6sdfbsdBeN2ldZiPAFnjOC+OAFE/nuIfF4AAG355+QV48Bfgv1+Q934BvvsFee1L0kYhk8UsuKcvvznXITxxXlKoSD3uujKkYLJlfiEc+PmmOePy7N/0KvUwEk38+yb1cOlpu/Zm8FX9XGtvBP+D/VtpW5fah7lyxZUGYu5CkBcBRIB3djQXeyCZrauBVPEfvKxON85iZQmSUrxJ8CvZz0nx1AMRzcW9kxPsN9R5VW3XVWdscQM5QnHhR1x3wNZELbqdHOUtpUrC8za+rTtrT/xh4EkvLYZBhkR6v87qAqIK26l3ItXkngwKvpD1a0/CGRpGnBbN+Iaw6iOwJUdljZroio5KQa3CYn7iHqNBdjWPHb2xYZAMvHhYrqMB/tMHYa3EoVr+9i4SwlLnoffRZxkO1oq/VrhYC3SWKrbEqa4vsyy3vlLndS8n69/ecVq6WCLAbOZqCMrsf73e5X4qq3pN1X1FW3m75lJFVZlbdqlB3fAjquWZNS2W88alfHKFu+eRNuDUTxmEV+GT+bqDq2BMqQBoL2RIq9Qt8lyCdH+mW8E3Gdo9GGc9M9fAPYibFyYUL6RNxbk224YFR8WRoX7Q2f0+WK/A/jFBNLe+8uot+4enWmrCaHxW7L9w9l828Zgh7j4Tj+X7goXp80VuPA+fKQI7jaNpDiy+8uP07itAo55mgFmVSFeT4Y9ZDrJWe7LQ7z5BUzgXIjmEibD44aSctrtKz7KQehZSuIsCBpXNYThWIloAkDW3Qs+AscX+ZYDnQhokDkinOHkFZkn3BNsGSGkkGCTbQWUK9p4ySt9Oxv2hPxh7nD+lKpHxPUWeeoflFQJOjJ3535Env1fkyb8DSP74AJI/2hom9CHQkWJUxJI4EnZKM2NJKEPGsviSrNC/JATkPgEqetxH3haXVwZVmtx+LyNb3sJUNHuV1P9gXNIW1BisjkhLz2oVzVxnHGkqYFP2UOux2xlZ717Z1mOr4OSvn1KtDatBGZmeUBolFXKhdYsB0j91UPVeF6GuLf4f3Snv9Q=="
MODULE_SOURCES = json.loads(zlib.decompress(base64.b64decode(MODULES_B64)).decode("utf-8"))
MOD = {}
for filename, source in MODULE_SOURCES.items():
    ns = {"__name__": filename.replace(".py", "").replace(" ", "_"), "__file__": filename}
    exec(compile(source, filename, "exec"), ns)
    ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    MOD[filename] = ns

def set_download_dir(path):
    """Set Android's Download directory and discover files throughout shared storage."""
    global DOWNLOAD_DIR, STORAGE_ROOT
    if not path:
        raise ValueError("Direktori Download dari Android kosong.")
    DOWNLOAD_DIR = os.path.abspath(path)
    STORAGE_ROOT = os.path.dirname(DOWNLOAD_DIR.rstrip(os.sep)) or DOWNLOAD_DIR
    for module_ns in MOD.values():
        module_ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    return DOWNLOAD_DIR

def unique_output(path):
    if not os.path.exists(path): return path
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{stem}_{n}{ext}"): n += 1
    return f"{stem}_{n}{ext}"

def safe_file(name, exts):
    """Resolve a selected relative path safely inside Android shared internal storage."""
    if not name or not isinstance(name, str) or not name.lower().endswith(exts):
        raise ValueError("Pilihan file tidak valid.")
    relative = name.replace("\\", "/").lstrip("/")
    if any(part in ("", ".", "..") for part in relative.split("/")):
        raise ValueError("Lokasi file tidak valid.")
    root = os.path.realpath(STORAGE_ROOT)
    path = os.path.realpath(os.path.join(root, *relative.split("/")))
    if os.path.commonpath((root, path)) != root:
        raise ValueError("File harus berada di penyimpanan bersama Android.")
    if not os.path.isfile(path):
        raise FileNotFoundError("File tidak ditemukan atau tidak dapat diakses.")
    return path

def relative_storage_path(path):
    return os.path.relpath(path, STORAGE_ROOT).replace(os.sep, "/")

def run_captured(fn, *args):
    out = io.StringIO()
    old_input = builtins.input
    builtins.input = lambda *_a, **_k: "y"
    try:
        with contextlib.redirect_stdout(out):
            result = fn(*args)
    finally:
        builtins.input = old_input
    return result, out.getvalue()

def fix_no_preview(src):
    ns = MOD["FIX_NO_PREVIEW.py"]
    stem = os.path.splitext(src)[0]
    output = stem + "_FORMATTED.epub"
    if os.path.exists(output):
        os.remove(output)
    changed_files, total = {}, 0
    with zipfile.ZipFile(src, "r") as zin:
        for info in zin.infolist():
            if info.filename.lower().endswith((".xhtml", ".html", ".htm")):
                updated, changed = ns["process_xhtml"](zin.read(info.filename))
                if changed:
                    changed_files[info.filename] = updated
                    total += changed
        if total == 0:
            return {"message": "Tidak ada paragraf yang perlu diperbaiki.", "changed": 0}
        with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(output, "w") as zout:
            zout.comment = zin.comment
            for info in zin.infolist():
                zout.writestr(info, changed_files.get(info.filename, zin.read(info.filename)))
    return {"output": os.path.basename(output), "changed": total}

def epub_metadata_title(epub_path):
    """Read the first non-empty dc:title from an EPUB package document."""
    with zipfile.ZipFile(epub_path, "r") as book:
        try:
            container = ET.fromstring(book.read("META-INF/container.xml"))
        except KeyError:
            raise ValueError("EPUB tidak memiliki META-INF/container.xml.")
        rootfile = container.find(".//{urn:oasis:names:tc:opendocument:xmlns:container}rootfile")
        if rootfile is None or not rootfile.get("full-path"):
            raise ValueError("Lokasi metadata OPF tidak ditemukan.")
        opf_path = rootfile.get("full-path")
        try:
            package = ET.fromstring(book.read(opf_path))
        except KeyError:
            raise ValueError("File metadata OPF tidak ditemukan di dalam EPUB.")
        titles = package.findall(".//{http://purl.org/dc/elements/1.1/}title")
        for node in titles:
            title = " ".join("".join(node.itertext()).split())
            if title:
                return title
    raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")

def safe_epub_filename(title):
    # Remove path separators, control characters, and characters rejected by common filesystems.
    title = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", title)
    title = re.sub(r'\s+', " ", title).strip().rstrip(". ")
    if not title:
        raise ValueError("Judul metadata tidak menghasilkan nama file yang valid.")
    # Keep filenames manageable on Android and common desktop filesystems.
    return title[:180].rstrip(". ") + ".epub"

def validate_epub(path):
    with zipfile.ZipFile(path, "r") as book:
        names = book.namelist()
        if not names or names[0] != "mimetype" or "mimetype" not in names:
            raise ValueError("Struktur EPUB tidak valid: entri mimetype harus menjadi entri pertama.")
        if book.getinfo("mimetype").compress_type != zipfile.ZIP_STORED:
            raise ValueError("Struktur EPUB tidak valid: mimetype harus tanpa kompresi.")
        bad = book.testzip()
        if bad:
            raise ValueError("EPUB rusak setelah diproses: " + bad)

def commit_in_place(src, staged_output):
    """Safely overwrite the source using a same-directory temporary file.

    The processed file may live in the app cache (a different filesystem),
    so it must be copied into the destination directory before atomic replace.
    No persistent backup is created.
    """
    if not staged_output or not os.path.isfile(staged_output):
        raise RuntimeError("Proses tidak menghasilkan file. File asli tidak diubah.")
    if src.lower().endswith(".epub"):
        validate_epub(staged_output)

    destination_dir = os.path.dirname(os.path.abspath(src)) or "."
    fd, destination_temp = tempfile.mkstemp(
        prefix=".epub_toolkit_", suffix=".tmp", dir=destination_dir
    )
    os.close(fd)
    try:
        shutil.copy2(staged_output, destination_temp)
        if os.path.getsize(staged_output) != os.path.getsize(destination_temp):
            raise IOError("File hasil tidak berhasil disalin sepenuhnya.")
        if src.lower().endswith(".epub"):
            validate_epub(destination_temp)
        os.replace(destination_temp, src)
    finally:
        if os.path.exists(destination_temp):
            os.remove(destination_temp)
    return os.path.basename(src)


def reader_open_epub(relative_name, chapter_index=0, search_query=""):
    """Read one EPUB spine item for the built-in gallery-style reader."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            raise ValueError("Package OPF tidak ditemukan.")
        opf_data = book.read(rootfile)
        opf = ET.fromstring(opf_data)
        base = os.path.dirname(rootfile).replace("\\", "/")
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        spine = next((e for e in opf.iter() if e.tag.endswith("spine")), None)
        if spine is None:
            raise ValueError("Daftar bab EPUB tidak ditemukan.")
        chapters = []
        # ZIP paths in EPUBs may be percent-encoded; keep a normalized lookup so
        # relative image/resource references work across common EPUB exporters.
        zip_names = set(book.namelist())
        zip_names_folded = {unquote(n).replace("\\\\", "/").casefold(): n for n in zip_names}
        def resolve_zip_path(path):
            path = unquote(path or "").replace("\\\\", "/").lstrip("/")
            normalized = posixpath.normpath(path)
            if normalized in zip_names:
                return normalized
            return zip_names_folded.get(normalized.casefold())
        for ref in spine:
            if not ref.tag.endswith("itemref"):
                continue
            item = manifest.get(ref.attrib.get("idref"))
            if not item:
                continue
            href = item.get("href", "")
            media_type = (item.get("media-type") or "").split(";", 1)[0].strip().lower()
            # EPUB exporters often label spine documents as text/html. The
            # spine establishes reading order, so accept both common types.
            if media_type not in ("application/xhtml+xml", "text/html", "application/xml", "text/xml") and not href.lower().endswith((".xhtml", ".html", ".htm")):
                continue
            full = resolve_zip_path(posixpath.join(base, href))
            if not full:
                continue
            try:
                raw = book.read(full).decode("utf-8-sig", "replace")
            except KeyError:
                continue
            try:
                doc = ET.fromstring(raw)
                title = ""
                for el in doc.iter():
                    if el.tag.lower().endswith(("h1", "h2", "title")) and "".join(el.itertext()).strip():
                        title = " ".join("".join(el.itertext()).split())
                        break
                if not title:
                    title = os.path.splitext(os.path.basename(href))[0].replace("_", " ")
                body = next((el for el in doc.iter() if el.tag.lower().endswith("body")), doc)
                # Serialize XHTML using local tag names. ElementTree otherwise emits
                # ns0:p/ns1:div prefixes that are not HTML tags in the WebView.
                def to_reader_html(node):
                    tag = node.tag.split("}", 1)[-1] if isinstance(node.tag, str) else ""
                    if not tag:
                        return html.escape(node.text or "")
                    attrs = []
                    for key, value in node.attrib.items():
                        key = key.split("}", 1)[-1]
                        low_key = key.lower()
                        if low_key.startswith("on"):
                            continue
                        # Convert book-local images to data URIs: the reader
                        # HTML is rendered outside the EPUB ZIP filesystem.
                        if tag.lower() in ("img", "image", "source") and low_key == "src":
                            src_value = str(value).strip()
                            parts = urlsplit(src_value)
                            if src_value and not parts.scheme and not src_value.startswith("//"):
                                resource_path = resolve_zip_path(posixpath.join(posixpath.dirname(full), parts.path))
                                if resource_path:
                                    payload = book.read(resource_path)
                                    guessed = mimetypes.guess_type(resource_path)[0]
                                    ext = os.path.splitext(resource_path.lower())[1]
                                    mime = "image/webp" if ext == ".webp" else (guessed or "application/octet-stream")
                                    value = "data:" + mime + ";base64," + base64.b64encode(payload).decode("ascii")
                        # Avoid srcset overriding a resolved local src with a
                        # remote or unresolved candidate.
                        if low_key == "srcset" and tag.lower() in ("img", "source"):
                            continue
                        # Internal EPUB links must not escape the extracted reader into
                        # Android's asset/file namespace. Preserve them as data for the
                        # reader's chapter-aware navigation handler.
                        if tag.lower() == "a" and low_key == "href":
                            link_parts = urlsplit(str(value).strip())
                            if not link_parts.scheme and not link_parts.netloc and not str(value).strip().startswith("//"):
                                attrs.append(f' data-rd-href="{html.escape(str(value), quote=True)}"')
                                continue
                        attrs.append(f' {key}="{html.escape(str(value), quote=True)}"')
                    void = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
                    opening = "<" + tag + "".join(attrs) + ">"
                    if tag.lower() in void:
                        return opening
                    inner = html.escape(node.text or "")
                    for child in list(node):
                        inner += to_reader_html(child)
                        inner += html.escape(child.tail or "")
                    return opening + inner + "</" + tag + ">"
                # Stage 3.1: prepare only the requested chapter's reader HTML.
                # Chapter metadata is still collected for navigation, but converting
                # every chapter and embedding all of its images wastes CPU and memory
                # on each chapter change. The selected chapter is rendered lazily.
                try:
                    requested_index = max(0, int(chapter_index or 0))
                except (TypeError, ValueError):
                    requested_index = 0
                if len(chapters) == requested_index:
                    content = html.escape(body.text or "") + "".join(to_reader_html(child) + html.escape(child.tail or "") for child in list(body))
                    if not content.strip():
                        content = "<p>" + html.escape(" ".join(" ".join(body.itertext()).split())) + "</p>"
                else:
                    content = ""
            except Exception:
                title = os.path.splitext(os.path.basename(href))[0]
                content = "<p>" + html.escape(re.sub(r"<[^>]+>", " ", raw)) + "</p>"
            chapters.append({"title": title[:180], "content": content, "href": full})
        if not chapters:
            raise ValueError("Tidak ada bab XHTML yang dapat dibaca.")
        try:
            title = next((" ".join("".join(e.itertext()).split()) for e in opf.iter()
                          if e.tag.endswith("title") and "".join(e.itertext()).strip()), os.path.basename(src))
        except Exception:
            title = os.path.basename(src)
        index = max(0, min(int(chapter_index or 0), len(chapters)-1))
        # Invalid chapter requests are rare (for example, stale saved progress).
        # Re-run once for the clamped chapter so its content is populated rather
        # than returning an empty chapter from the lazy-render path above.
        if not chapters[index]["content"] and index != max(0, int(chapter_index or 0)):
            return reader_open_epub(relative_name, index)
        result = {"title": title, "chapters": [{"title": c["title"], "href": c["href"]} for c in chapters],
                  "index": index, "content": chapters[index]["content"]}
        if search_query:
            needle = search_query.casefold()
            found = []
            for chapter_no, chapter in enumerate(chapters):
                plain = html.unescape(re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", chapter["content"]))
                plain = re.sub(r"(?s)<[^>]*>", " ", plain)
                plain = re.sub(r"\s+", " ", plain).strip()
                folded = plain.casefold()
                pos = 0
                occurrence = 0
                while True:
                    pos = folded.find(needle, pos)
                    if pos < 0:
                        break
                    # V28.8: compact excerpts, with five words before and after the match.
                    before = plain[:pos]
                    after = plain[pos+len(search_query):]
                    before_words = list(re.finditer(r"\S+", before))
                    after_words = list(re.finditer(r"\S+", after))
                    start = before_words[-5].start() if len(before_words) >= 5 else 0
                    end = (pos+len(search_query)+after_words[4].end()) if len(after_words) >= 5 else len(plain)
                    snippet = ("…" if start else "") + plain[start:end] + ("…" if end < len(plain) else "")
                    found.append({"chapter": chapter_no, "chapter_title": chapter["title"], "occurrence": occurrence, "snippet": snippet})
                    occurrence += 1
                    pos += len(needle)
            result["matches"] = found
        return result


def reader_search_epub(relative_name, search_query, max_matches=1000):
    """Search EPUB spine text directly; avoid reader HTML rendering and image conversion."""
    src = safe_file(relative_name, (".epub",))
    query = str(search_query or "").strip()[:120]
    if not query:
        return {"matches": []}
    needle = query.casefold()
    matches = []
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                        if e.tag.endswith("rootfile")), None)
        if not rootfile:
            raise ValueError("Package OPF tidak ditemukan.")
        opf = ET.fromstring(book.read(rootfile))
        base = posixpath.dirname(rootfile).replace("\\", "/")
        manifest = {e.attrib.get("id"): e.attrib for e in opf.iter() if e.tag.endswith("item")}
        spine = next((e for e in opf.iter() if e.tag.endswith("spine")), None)
        if spine is None:
            raise ValueError("Daftar bab EPUB tidak ditemukan.")
        zip_names = set(book.namelist())
        folded = {n.casefold(): n for n in zip_names}
        def resolve(path):
            path = posixpath.normpath(posixpath.join(base, path)).replace("\\", "/")
            return path if path in zip_names else folded.get(path.casefold())
        for chapter_no, ref in enumerate(spine):
            if not ref.tag.endswith("itemref"):
                continue
            item = manifest.get(ref.attrib.get("idref"))
            if not item:
                continue
            href = item.get("href", "")
            media = (item.get("media-type") or "").split(";", 1)[0].strip().lower()
            if media not in ("application/xhtml+xml", "text/html", "application/xml", "text/xml") and not href.lower().endswith((".xhtml", ".html", ".htm")):
                continue
            full = resolve(unquote(href))
            if not full:
                continue
            try:
                doc = ET.fromstring(book.read(full))
                # Search visible text only; do not serialize links, CSS, images or base64.
                chapter_title = next((" ".join(" ".join(el.itertext()).split()) for el in doc.iter()
                                    if el.tag.split("}", 1)[-1].lower() in ("h1", "h2", "title") and " ".join(el.itertext()).strip()),
                                   posixpath.splitext(posixpath.basename(href))[0].replace("_", " "))
                text_parts = []
                for el in doc.iter():
                    local_tag = el.tag.split("}", 1)[-1].lower() if isinstance(el.tag, str) else ""
                    if local_tag in ("script", "style"):
                        continue
                    if el.text and el.text.strip():
                        text_parts.append(el.text.strip())
                    if el.tail and el.tail.strip():
                        text_parts.append(el.tail.strip())
                plain = " ".join(" ".join(text_parts).split())
            except Exception:
                raw = book.read(full).decode("utf-8-sig", "replace")
                raw = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", raw)
                plain = " ".join(html.unescape(re.sub(r"(?s)<[^>]*>", " ", raw)).split())
                chapter_title = posixpath.splitext(posixpath.basename(href))[0].replace("_", " ")
            folded_text = plain.casefold()
            # Build word boundaries once per chapter. The previous implementation
            # re-scanned the entire text before and after every hit, becoming
            # increasingly expensive for books with many matches.
            word_spans = [(m.start(), m.end()) for m in re.finditer(r"\S+", plain)]
            word_starts = [start for start, _ in word_spans]
            pos = 0
            occurrence = 0
            while len(matches) < max_matches:
                pos = folded_text.find(needle, pos)
                if pos < 0:
                    break
                left_idx = bisect.bisect_left(word_starts, pos)
                start = word_spans[max(0, left_idx - 5)][0] if left_idx >= 5 else 0
                after_start = pos + len(query)
                after_idx = bisect.bisect_left(word_starts, after_start)
                end_idx = after_idx + 4
                end = word_spans[end_idx][1] if end_idx < len(word_spans) else len(plain)
                snippet = ("…" if start else "") + plain[start:end] + ("…" if end < len(plain) else "")
                matches.append({"chapter": chapter_no, "chapter_title": chapter_title[:180], "occurrence": occurrence, "snippet": snippet})
                occurrence += 1
                pos += max(1, len(needle))
            if len(matches) >= max_matches:
                break
    return {"matches": matches}

def reader_cover_data(relative_name):
    """Return the embedded EPUB cover as a data URI for the library thumbnail."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            return {"cover": None}
        opf = ET.fromstring(book.read(rootfile))
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        cover_id = None
        for meta in opf.iter():
            if meta.tag.endswith("meta") and meta.attrib.get("name", "").lower() == "cover":
                cover_id = meta.attrib.get("content")
                break
        cover_item = manifest.get(cover_id) if cover_id else None
        if not cover_item:
            cover_item = next((item for item in manifest.values()
                               if "cover-image" in item.get("properties", "").split()), None)
        if not cover_item:
            # EPUB 2 guide references are a useful fallback for older files.
            for ref in opf.iter():
                if ref.tag.endswith("reference") and ref.attrib.get("type", "").lower() == "cover":
                    href = ref.attrib.get("href", "").split("#", 1)[0]
                    candidate = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
                    if candidate in book.namelist():
                        raw = book.read(candidate)
                        mime = mimetypes.guess_type(candidate)[0] or "image/jpeg"
                        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}
        if not cover_item:
            return {"cover": None}
        href = cover_item.get("href", "").split("#", 1)[0]
        image_path = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
        if image_path not in book.namelist():
            return {"cover": None}
        raw = book.read(image_path)
        if len(raw) > 4 * 1024 * 1024:
            return {"cover": None}
        mime = cover_item.get("media-type") or mimetypes.guess_type(image_path)[0] or "image/jpeg"
        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}

def api_action(path, d):
    name = d.get("file", "")
    if path == "/reader-cover":
        return reader_cover_data(name)
    if path == "/delete-book":
        src = safe_file(name, (".epub",))
        deleted_name = os.path.basename(src)
        os.remove(src)
        return {"deleted": True, "file": relative_storage_path(src), "name": deleted_name}
    if path == "/reader-open":
        return reader_open_epub(name, d.get("chapter", 0))
    if path == "/reader-search":
        query = str(d.get("query", "")).strip()[:120]
        if not query:
            return {"matches": []}
        return reader_search_epub(name, query)
    if path == "/rename-by-title":
        src = safe_file(name, (".epub",))
        title = epub_metadata_title(src)
        target_name = safe_epub_filename(title)
        target = os.path.join(os.path.dirname(src), target_name)
        if os.path.abspath(src) == os.path.abspath(target):
            return {"output": relative_storage_path(src), "title": title, "message": "Nama file sudah sesuai dengan judul metadata."}
        base, ext = os.path.splitext(target)
        n = 2
        while os.path.exists(target):
            target = f"{base}_{n}{ext}"
            n += 1
        os.rename(src, target)
        return {"output": relative_storage_path(target), "title": title, "previous_name": name}

    if path in ("/bulk-count", "/bulk-replace"):
        ns = MOD["BULK_FIND_REPLACE.py"]
        src = safe_file(name, (".epub", ".txt"))
        pat = ns["make_pattern"](d.get("find", ""), bool(d.get("case_sensitive")), bool(d.get("whole_word")), bool(d.get("regex")))
        if path == "/bulk-count":
            count, _ = ns["process_file"](src, pat, None)
            return {"count": count}
        if os.path.splitext(src)[1].lower() == ".epub":
            validate_epub(src)
        with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
            staged = os.path.join(work, os.path.basename(src))
            shutil.copy2(src, staged)
            count, generated = ns["process_file"](staged, pat, d.get("replace", ""))
            if count == 0:
                return {"count": 0, "output": os.path.basename(src), "message": "Tidak ada teks yang cocok; file tidak diubah."}
            output = commit_in_place(src, generated)
        return {"count": count, "output": output, "message": "File asli berhasil diperbarui."}

    src = safe_file(name, (".epub",))
    if path == "/cover-meta":
        ns = MOD["COVER MAKER.py"]
        with zipfile.ZipFile(src, "r") as z:
            opf = ns["find_opf"](z)
            title, author, _ = ns["read_metadata"](z.read(opf))
        return {"title": title, "author": author}

    with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
        staged = os.path.join(work, os.path.basename(src))
        shutil.copy2(src, staged)
        stem = os.path.splitext(staged)[0]
        details = {}
        generated = None

        if path == "/remove-cover":
            _, log = run_captured(MOD["REMOVE_EPUB_COVER.py"]["remove_epub_cover"], staged)
            generated = stem + "_no_cover.epub"
            details["details"] = log[-500:]
        elif path == "/no-preview":
            result = fix_no_preview(staged)
            if result.get("changed", 0) == 0:
                return result
            generated = os.path.join(work, result["output"])
            details["changed"] = result["changed"]
        elif path == "/make-cover":
            ns = MOD["COVER MAKER.py"]
            with zipfile.ZipFile(staged, "r") as z:
                opf = ns["find_opf"](z)
                metadata_title, author, root = ns["read_metadata"](z.read(opf))
            # A manually entered title remains supported in the single-file tool;
            # batch Cover Maker defaults to the EPUB's own dc:title metadata.
            title = (d.get("title") or metadata_title or "").strip()
            if not title:
                raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")
            ns["add_cover"](staged, opf, root, title, author)
            generated = stem + "_with_cover.epub"
            details.update({"title": title, "author": author})
        elif path == "/compress":
            ns = MOD["IMAGE_COMPRESSOR_15.py"]
            Image, ImageOps = ns["load_pillow"]()
            _, log = run_captured(ns["compress_epub"], staged, Image, ImageOps)
            generated = stem + "_compressed.epub"
            details["details"] = log[-700:]
        elif path == "/compact-spacing":
            ns = MOD["COMPACT_LINE_SPACING_FIXER.py"]
            generated = os.path.join(work, "processed.epub")
            adjusted, cleaned = ns["process_epub"](staged, generated)
            details.update({"adjusted": adjusted, "cleaned": cleaned})
        elif path == "/blank-spacing":
            ns = MOD["REMOVE_BLANK_SPACING.py"]
            _, log = run_captured(ns["process_epub"], staged)
            generated = stem + "_clean_default_spacing.epub"
            details["details"] = log[-500:]
        elif path == "/remove-images":
            ns = MOD["IMAGE_REMOVER.py"]
            _, log = run_captured(ns["remove_images"], staged)
            generated = stem + "_no_images.epub"
            details["details"] = log[-500:]
        else:
            raise ValueError("Endpoint tidak dikenal.")

        output = commit_in_place(src, generated)
        details.update({"output": output, "message": "File asli berhasil diperbarui."})
        return details

PAGE = r"""<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#08285f"><title>EPUB All-in-One Toolkit</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#eef2f8;color:#172033;font-family:Arial,sans-serif;padding:14px}main{max-width:760px;margin:auto}
.hero{background:linear-gradient(135deg,#08285f,#145da0);color:white;border-radius:18px;padding:20px;margin-bottom:14px}.hero h1{font-size:22px;margin:0 0 6px}.hero p{margin:0;color:#dce7ff;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0}.tab{border:0;border-radius:11px;padding:13px 9px;background:#dce4f1;color:#1b3155;font-weight:bold;font-size:13px;text-align:left;min-height:54px}.tab.active{background:#08285f;color:white}
.panel{background:white;border-radius:14px;padding:16px;margin:12px 0;box-shadow:0 2px 10px #13294b0d}.panel h2{margin:0 0 8px;font-size:19px}.hint{color:#596579;font-size:13px;line-height:1.5}
label{display:block;font-size:14px;font-weight:bold;margin:12px 0 6px}input[type=text],select{width:100%;padding:12px;border:1px solid #b8c3d3;border-radius:9px;font-size:16px;background:white;color:#172033}
.check{display:flex;align-items:center;gap:8px;font-weight:normal;margin:10px 0}.check input{width:19px;height:19px}.batch-file{display:flex;align-items:flex-start;gap:9px;padding:8px 4px;border-bottom:1px solid #edf1f6;font-size:13px;font-weight:normal;margin:0}.batch-file:last-child{border-bottom:0}.batch-file input{width:18px;height:18px;flex:0 0 auto;margin:1px 0 0}.batch-file span{overflow-wrap:anywhere}button.action{width:100%;border:0;border-radius:10px;background:#1265bd;color:white;font-weight:bold;padding:13px;margin-top:10px;font-size:15px}button.alt{background:#53657e}

.toolkit-home{padding:18px}
.mode-card{display:grid;grid-template-columns:48px 1fr 24px;grid-template-rows:auto auto;align-items:center;text-align:left;gap:2px 12px;width:100%;border:1px solid #d7e0eb;border-radius:14px;background:#fff;padding:15px;margin:10px 0;color:#172033;box-shadow:0 2px 7px #10243b0a}
.mode-card.batch-mode{border-color:#b8dfc5}
.mode-icon{grid-row:1/3;font-size:28px;text-align:center}
.mode-title{font-size:17px;font-weight:700}
.mode-desc{font-size:12px;color:#66748a}
.mode-arrow{grid-column:3;grid-row:1/3;font-size:26px;color:#64748b}
.menu-back{grid-column:1/-1;margin:0 0 10px}
.hide{display:none}.small{font-size:12px;color:#657187;overflow-wrap:anywhere}
footer{text-align:center;color:#718096;font-size:12px;padding:14px}
.status{
  white-space:pre-wrap;
  overflow-wrap:anywhere;
  background:#f5f7fb;
  border:1px solid #e2e8f0;
  border-radius:12px;
  padding:14px;
  margin-top:12px;
  min-height:42px;
  font-size:14px;
  line-height:1.6;
  color:#334155;
}@media(max-width:420px){.grid{grid-template-columns:1fr 1fr}.tab{font-size:12px;padding:10px 7px}}

/* Gallery-style top-level navigation and EPUB reader */
body{padding-bottom:88px}
#gallery-nav{position:fixed;z-index:1000;left:0;right:0;bottom:0;height:72px;background:#050505;border-top:1px solid #252525;display:flex;justify-content:space-around;align-items:center}
.gallery-btn{border:0;background:transparent;color:#777;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;min-width:110px;height:100%;font-weight:500}
.gallery-btn.active{color:#f2f2f2;font-weight:bold}
.gallery-btn svg{width:27px;height:27px;fill:currentColor}
.gallery-btn .gallery-emoji{font-size:25px;line-height:27px}
/* V25: recolor tab icons only; keep tab labels and active styling unchanged */
.gallery-btn .gallery-emoji{filter:grayscale(1);opacity:.82}
#reader-view{display:block;position:fixed;inset:0 0 72px;background:#050505;color:#eee;overflow:auto;padding:18px 18px 30px}
/* Startup: show My Library immediately; avoid Toolkit flash before navigation JS initializes. */
body>main{display:none}
#reader-view .reader-head{font-size:30px;font-weight:300;margin:8px 0 22px}
#reader-view .reader-tools{background:#1d1d1d;border-radius:14px;padding:14px;margin-bottom:16px}
#reader-view select,#reader-view input{width:100%;padding:10px;border-radius:8px;border:1px solid #555;background:#292929;color:#eee;font-size:15px}
#reader-view label{color:#ddd;font-size:13px;margin:10px 0 5px}
#reader-view .reader-actions{display:flex;gap:8px}
#reader-view button{border:0;border-radius:8px;padding:10px 12px;background:#3478df;color:white;font-weight:bold}
#reader-view button.secondary{background:#444}
#reader-view .reader-page{border-radius:12px;padding:20px 18px;min-height:48vh;background:#fff;color:#242424;font-family:Georgia,serif;font-size:19px;line-height:1.65}
#reader-view .reader-page p{margin:0 0 1em}
#reader-view .reader-page img{max-width:100%;height:auto}
#reader-view .reader-empty{color:#aaa;text-align:center;padding:55px 15px;line-height:1.6}
#reader-view .reader-settings{display:grid;grid-template-columns:1fr 1fr;gap:8px}
#reader-view .theme-row{display:flex;gap:7px;margin-top:10px}
#reader-view .theme-row button{flex:1}
@media(max-width:420px){#reader-view{padding:14px 12px 24px}.reader-page{font-size:18px}}

/* Horizontal page-by-page EPUB reading */
#reader-view .reader-page{height:62vh;min-height:360px;overflow-x:auto;overflow-y:hidden;column-width:100%;column-gap:30px;column-fill:auto;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch;touch-action:pan-y;overscroll-behavior-x:contain}
#reader-view .reader-page::-webkit-scrollbar{display:none}
#reader-view .reader-page>*{break-inside:auto}
#reader-view .reader-page p{break-inside:auto;orphans:2;widows:2}
#reader-view .reader-page img,#reader-view .reader-page figure{break-inside:avoid-column}
#reader-view .reader-page img{max-height:45vh;object-fit:contain}
#reader-view .page-nav{display:flex;align-items:center;gap:8px;margin:0 0 10px}
#reader-view .page-nav button{background:#444}
#reader-view .page-nav span{color:#aaa;font-size:12px;margin-left:auto}

/* Immersive reading: tap the page to toggle all controls */
#reader-view{inset:0;padding:12px 14px 18px;transition:padding .18s ease}
#reader-controls{opacity:1;max-height:1000px;overflow:hidden;transition:opacity .18s ease,max-height .22s ease,transform .18s ease}
#reader-view.controls-hidden{padding:0}
#reader-view.controls-hidden #reader-controls{opacity:0;max-height:0;transform:translateY(-12px);pointer-events:none;margin:0}
body.reader-reading #gallery-nav{display:none}
body.reader-reading{padding-bottom:0}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 8px);min-height:calc(100vh - 8px);border-radius:0;padding:28px 22px}
#reader-view #reader-content{cursor:pointer}
@media(max-width:420px){#reader-view{padding:10px 10px 14px}#reader-view.controls-hidden #reader-content{padding:28px 20px}}

/* Read Book: dedicated library and immersive reader */
#reader-view{background:#071d23;color:#f3f7f8;padding:0;inset:0;overflow-y:auto}
#library-view{min-height:100%;padding:0 14px 24px}
#library-refresh-indicator{height:0;overflow:hidden;display:flex;align-items:center;justify-content:center;color:#b9e7ec;font-size:12px;transition:height .12s ease;background:#064b5b;margin:0 -14px}
#library-refresh-indicator.visible{height:42px}
#library-top{position:sticky;top:0;z-index:5;background:#075b70;margin:0 -14px 14px;padding:17px 16px 14px;box-shadow:0 3px 12px #0003}
#library-top .lib-title{font-size:24px;font-weight:700;margin:0 0 10px}
#library-search{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #43808c;border-radius:10px;background:#064b5b;color:white;font-size:15px;outline:none}
#library-search::placeholder{color:#b5d1d6}
#library-sort-row{display:flex;align-items:center;gap:5px;margin-top:9px}
#library-sort-label{font-size:12px;color:#b5d1d6;white-space:nowrap}
#library-sort{flex:0 1 auto;min-width:0;box-sizing:border-box;padding:2px 0;border:0;border-radius:0;background:transparent;color:#a88bd7;font-size:14px;outline:none;appearance:none;-webkit-appearance:none;cursor:pointer}
#library-sort:focus{outline:none}
#library-sort option{background:#101421;color:#f1f2f5}
#library-stats{font-size:12px;color:#a9c2c7;margin:10px 2px}
.book-card{display:flex;gap:11px;align-items:center;background:#1a343a;border:1px solid #28474e;border-radius:11px;padding:9px;margin:0 0 9px;min-height:94px;box-shadow:0 2px 7px #0002;cursor:pointer}
.book-cover{width:58px;min-width:58px;height:78px;min-height:78px;border-radius:3px;background:linear-gradient(145deg,#275e6b,#102b34);display:flex;align-items:center;justify-content:center;color:#d7e6e9;font-size:27px;box-shadow:0 2px 5px #0005}
.book-cover span{font-size:27px}.book-cover img{width:100%;height:100%;object-fit:cover;border-radius:3px;display:block}
.book-info{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px;align-self:stretch;padding:1px 0}
.book-name{font-size:15px;line-height:1.25;font-weight:600;overflow-wrap:anywhere;color:#f5f8f9;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.book-meta{font-size:11px;color:#a9bdc1;overflow-wrap:anywhere}
.book-progress{height:3px;border-radius:9px;background:#496168;overflow:hidden;margin-top:auto}
.book-progress>i{display:block;height:100%;background:#21b6a6}
.book-open-hint{font-size:11px;color:#70d5ca;margin-top:1px}
#library-selection-toolbar{display:none;align-items:center;gap:7px;flex-wrap:wrap;background:#123c45;border:1px solid #2b6670;border-radius:10px;padding:9px;margin:0 0 10px}
#library-selection-toolbar.visible{display:flex}
#library-selection-count{font-size:12px;color:#c5e0e3;flex:1;min-width:95px}
#library-selection-toolbar button{border:1px solid #4b7c83;background:#204e57;color:#f5fbfc;border-radius:8px;padding:8px 10px;font-size:12px}
#library-selection-toolbar button.delete{background:#8b3030;border-color:#b34b4b}
.book-card.selected{border:2px solid #21b6a6;background:#21454b;padding:8px}
.book-select-mark{width:23px;height:23px;min-width:23px;border-radius:50%;border:2px solid #91aeb2;display:none;align-items:center;justify-content:center;color:#062a30;font-size:14px;font-weight:800}
.selection-mode .book-select-mark{display:flex}
.book-card.selected .book-select-mark{background:#46d4c4;border-color:#46d4c4}
@media(max-width:420px){.book-cover{width:54px;min-width:54px;height:74px;min-height:74px}.book-card{min-height:88px;padding:8px;gap:9px}.book-name{font-size:14px}}
#reader-screen{display:none;min-height:100%;background:#101719;padding:0 14px 22px}
#reader-screen-head{position:sticky;top:0;z-index:6;background:#101719;padding:12px 0 10px;display:flex;align-items:center;gap:14px;border-bottom:1px solid #29383b}
#reader-screen-head button{background:transparent;color:#f2f5f5;padding:8px;font-size:22px}
#reader-book-title{font-size:15px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
#reader-view #reader-controls{padding-top:10px}
/* V28.3: dedicated full-screen Find in Book UI, modeled after the supplied reference video. */
#reader-search-screen{display:none;position:fixed;inset:0;background:#071d23;color:#f2f5f5;z-index:40;overflow:hidden}
#reader-search-screen.active{display:flex;flex-direction:column}
#reader-search-head{height:54px;min-height:54px;background:#263437;display:flex;align-items:center;padding:6px 10px;gap:5px;box-sizing:border-box;border-bottom:1px solid #3b5960;box-shadow:0 2px 4px #0006}
#reader-search-head button{border:0;background:transparent;color:#eaf3f4;width:42px;height:42px;font-size:32px;font-weight:300;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;flex:0 0 42px}
#reader-search-head button.search-back{font-size:32px;margin-left:-3px}
#reader-search-head input{flex:1;min-width:0;height:40px;border:1px solid #47646b;border-radius:9px;outline:0;background:#1b292c;color:#f1f6f7;font-size:22px;font-weight:400;padding:0 10px;box-sizing:border-box}
#reader-search-head input::placeholder{color:#b8c9cc;opacity:1}
#reader-search-head button.search-clear{font-size:32px}
#reader-search-body{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:10px 0 24px}
#reader-search-history{display:none;border-bottom:1px solid #102f36;padding:0;color:#b7c3c5}
#reader-search-history.visible{display:flex;flex-direction:column}
.reader-search-history-item{display:flex;align-items:center;gap:8px;padding:9px 22px;min-height:48px;box-sizing:border-box;touch-action:pan-y}
.reader-search-history-item .history-icon{width:18px;height:18px;color:#8c989a;line-height:1;flex:0 0 18px;display:flex;align-items:center;justify-content:center}
.reader-search-history-item .history-icon svg{width:18px;height:18px;display:block}
.reader-search-history-item .history-query{font-size:20px;color:#29b7d0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.2}
.reader-search-history-item:active{background:#102d33}
#reader-search-results{padding:8px 9px 0}
.search-result-card.search-result-selected{border:2px solid #d9b94b!important;background:#24434a!important;box-shadow:0 0 0 1px #d9b94b33!important}
.search-result-card[aria-current="true"] .search-result-location{color:#d9b94b;font-weight:600}
.search-result-card{display:flex!important;align-items:stretch!important;width:calc(100% - 18px)!important;padding:0!important;text-align:left!important;font-family:Arial,sans-serif!important;font-weight:400!important;font-size:inherit!important;line-height:normal!important;color:#f0f3f3!important;background:#1c3439!important;border:1px solid #263f44!important;border-radius:7px!important;margin:0 9px 4px!important;min-height:48px!important;box-sizing:border-box!important;overflow:hidden!important;box-shadow:0 1px 1px #0004!important;appearance:none!important;-webkit-appearance:none!important;outline:none!important}
.search-result-text{flex:1;min-width:0;padding:5px 6px 6px 11px}
.search-result-chapter-title{font-size:11px;line-height:1.15;color:#8fc6d1;margin:0 0 3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.search-result-snippet{color:#f0f3f3;font-size:15px;line-height:1.22;word-break:break-word}
.search-result-snippet mark{background:transparent;color:#e6c94e;font-weight:400;padding:0}
.search-result-location{width:58px;flex:0 0 58px;display:flex;align-items:center;justify-content:center;color:#f2f5f5;font-size:14px;font-weight:500}
#reader-search-empty{display:none;padding:0;text-align:center;color:#8f9b9d;font-size:16px}
#reader-search-empty:not(:empty){display:block;padding:24px 25px}
#reader-search-loading{display:none;padding:55px 25px;text-align:center;color:#1290b2;font-size:48px}
#reader-search-loading.active{display:block}
#reader-search-tools{display:flex;gap:6px;align-items:center;margin:0 0 9px}
#reader-search-tools input{min-width:0;flex:1;background:#263437;border:1px solid #536367;color:#f3f7f8;border-radius:8px;padding:9px 10px;font-size:14px}
#reader-search-tools button{padding:8px 10px;white-space:nowrap}
#reader-search-status{font-size:12px;color:#b9c7ca;margin:0 0 8px;min-height:16px}
#reader-content mark.reader-search-hit{background:#ffdf65;color:#241d08;border-radius:2px;padding:0}
#reader-view .reader-tools{background:#1b292c;border:1px solid #33464a}
#reader-view .reader-head{display:none}
#reader-view .reader-page{height:calc(100vh - 260px);min-height:360px;border-radius:5px;padding:28px 23px;background:#f7f2e8;color:#28251f;font-family:Georgia,serif;font-size:19px;line-height:1.7;box-shadow:0 4px 18px #0005}
#reader-view .page-nav span{color:#b9c7ca}
#reader-view .reader-actions{align-items:center}
#reader-view .reader-actions button,#reader-view .page-nav button{padding:9px 13px}
#reader-view .reader-settings{margin-top:8px}
#reader-view .reader-tools label{display:block}
#reader-view input[type=range]{padding:0;background:transparent;border:0}
#reader-view .theme-row button{padding:9px 6px}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 12px);min-height:calc(100vh - 12px);margin:0}
@media(max-width:420px){.book-cover{width:78px;min-width:78px}.book-name{font-size:16px}#reader-view .reader-page{height:calc(100vh - 270px);padding:23px 19px}}


/* Reader rendering fixes v2: proper XHTML block tags and predictable page columns */
#reader-view #reader-content.reader-page {
  display:block; box-sizing:border-box; width:100%; max-width:100%;
  overflow-x:auto; overflow-y:hidden; white-space:normal;
  column-fill:auto; column-gap:28px; column-rule:0;
  column-width:auto; -webkit-column-width:auto;
  word-break:normal; overflow-wrap:break-word; text-align:left;
  touch-action:pan-y; overscroll-behavior-x:contain;
}
#reader-view #reader-content.reader-page p {
  display:block; margin:0 0 var(--rd-reader-para-spacing,1em); padding:0; text-indent:0 !important;
  line-height:inherit; white-space:normal; break-inside:auto;
}
#reader-view #reader-content.reader-page article,
#reader-view #reader-content.reader-page main,
#reader-view #reader-content.reader-page blockquote,
#reader-view #reader-content.reader-page ul,
#reader-view #reader-content.reader-page ol,
#reader-view #reader-content.reader-page li { display:block; }
#reader-view #reader-content.reader-page p + p { margin-top:0; }

#reader-view #reader-content.reader-page h1,
#reader-view #reader-content.reader-page h2,
#reader-view #reader-content.reader-page h3,
#reader-view #reader-content.reader-page h4 { display:block; white-space:normal; break-after:avoid; margin:1.1em 0 .65em; line-height:1.25; }
#reader-view #reader-content.reader-page div,
#reader-view #reader-content.reader-page section { display:block; max-width:100%; }
#reader-view #reader-content.reader-page img,
#reader-view #reader-content.reader-page svg,
#reader-view #reader-content.reader-page table { max-width:100%; }
#reader-view #reader-content.reader-page table { border-collapse:collapse; }
#reader-view #reader-content.reader-page a { overflow-wrap:anywhere; }
/* V29.5.8: make EPUB internal links visibly distinct while keeping book typography. */
#reader-view #reader-content.reader-page a[data-rd-href] {
  color:#1677b8; text-decoration:underline; text-decoration-thickness:1px; text-underline-offset:2px; cursor:pointer;
}
#reader-view #reader-content.reader-page a[data-rd-href]:active { color:#0b568a; }


/* Reader presentation v5: edge-to-edge text with floating controls; suppress Android WebView blue tap flash */
#reader-view, #reader-view *, #reader-view button, #reader-view input, #reader-view select {
  -webkit-tap-highlight-color: transparent;
}
#reader-screen {
  position:fixed; inset:0; z-index:20; display:none; overflow:hidden;
  min-height:100dvh; height:100dvh; padding:0; background:#101719;
}
#reader-screen-head {
  position:fixed; top:0; left:0; right:0; z-index:30;
  padding:calc(8px + env(safe-area-inset-top)) 12px 8px;
  margin:0; background:linear-gradient(180deg,rgba(8,19,23,.96),rgba(8,19,23,.78));
  border:0; min-height:54px; box-sizing:border-box;
  transition:opacity .14s ease, transform .14s ease;
}
#reader-content.reader-page {
  position:fixed; z-index:21; inset:0; width:100vw; height:100dvh !important;
  min-height:100dvh !important; max-height:none; box-sizing:border-box;
  margin:0 !important; border-radius:0 !important; box-shadow:none !important;
  padding:calc(76px + env(safe-area-inset-top)) 24px calc(96px + env(safe-area-inset-bottom)) !important;
  background:#f7f2e8; color:#28251f;
  -webkit-tap-highlight-color:transparent; outline:none;
}
#reader-view #reader-controls {
  position:fixed; left:0; right:0; bottom:0; z-index:32;
  box-sizing:border-box; max-height:62dvh; overflow-y:auto;
  padding:10px 14px calc(12px + env(safe-area-inset-bottom));
  background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));
  border-top:1px solid rgba(255,255,255,.12); border-radius:16px 16px 0 0;
  backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
  transition:opacity .14s ease, transform .14s ease, max-height .14s ease;
}
#reader-view #reader-controls {position:fixed;inset:auto 10px auto 10px;top:calc(62px + env(safe-area-inset-top));z-index:35;max-height:none;overflow:visible;padding:0;background:transparent;border:0;border-radius:0;backdrop-filter:none;-webkit-backdrop-filter:none;pointer-events:none}
#reader-view .reader-popup-menu{display:none;pointer-events:auto;position:absolute;top:0;right:0;width:min(92vw,440px);max-height:72dvh;overflow-y:auto;box-sizing:border-box;background:#253438;border:1px solid #43565a;border-radius:15px;padding:15px;box-shadow:0 12px 32px #0008}
#reader-view .reader-popup-menu.active{display:block}
#reader-view .reader-popup-title{font-size:17px;font-weight:700;color:#e5f0f1;margin:0 0 12px}
#reader-view .reader-popup-menu .reader-settings{margin:0;gap:10px}
#reader-view .reader-popup-menu .theme-row{margin-top:12px}
#reader-view .reader-popup-menu .reader-actions{margin:12px 0 6px;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .reader-actions button{flex:1;min-width:120px}
#reader-view .reader-popup-menu .page-nav{margin:6px 0 0;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .page-nav button{flex:1;min-width:90px}
#reader-view #reader-screen-head button{width:42px;font-size:24px}
#reader-view.controls-hidden #reader-controls{opacity:0;pointer-events:none}
#reader-view.controls-hidden #reader-settings-menu,#reader-view.controls-hidden #reader-navigation-menu,#reader-view.controls-hidden #reader-navigation-controls-menu{display:none!important}
#reader-view #reader-controls .reader-tools { margin:0 0 8px; padding:10px; }
#reader-view #reader-controls .reader-actions { margin:6px 0; }
#reader-view #reader-controls .page-nav { margin:5px 0 0; }
#reader-view #reader-bottom-navigation{display:none!important;position:fixed;left:0;right:0;bottom:0;z-index:34;box-sizing:border-box;padding:10px 14px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));border-top:1px solid rgba(255,255,255,.12);border-radius:16px 16px 0 0;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);transition:opacity .14s ease,transform .14s ease}
#reader-view #reader-bottom-navigation .reader-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 8px}
#reader-view #reader-bottom-navigation .reader-actions button{flex:1;min-width:120px}
#reader-view #reader-bottom-navigation .page-nav{display:flex;align-items:center;gap:8px;margin:0;flex-wrap:wrap}
#reader-view #reader-bottom-navigation .page-nav button{flex:1;min-width:90px}
#reader-view #reader-bottom-navigation #reader-page-count{margin-left:auto;color:#aab8ba}
#reader-view.controls-hidden #reader-bottom-navigation{opacity:0;transform:translateY(12px);pointer-events:none}

#reader-view.controls-hidden #reader-controls {
  opacity:0; max-height:0; padding-top:0; padding-bottom:0;
  transform:translateY(12px); pointer-events:none; border:0;
}
#reader-view.controls-hidden #reader-screen-head {
  opacity:0; transform:translateY(-10px); pointer-events:none;
}
/* Keep the reading viewport identical in both states. Controls float above it. */
#reader-view.controls-hidden #reader-content.reader-page {
  padding-top:calc(76px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(96px + env(safe-area-inset-bottom)) !important;
}
#reader-content, #reader-content * { -webkit-tap-highlight-color:transparent; }
@media(max-width:420px) {
  #reader-content.reader-page { padding-left:20px !important; padding-right:20px !important; }
  #reader-view #reader-controls { max-height:68dvh; }
}
/* V17 reader spacing: stronger, explicit override of the original reader viewport padding. */
#reader-screen #reader-content.reader-page,
#reader-view.controls-hidden #reader-screen #reader-content.reader-page {
  padding-top:calc(48px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(48px + env(safe-area-inset-bottom)) !important;
  padding-left:32px !important;
  padding-right:32px !important;
}
/* Prevent EPUB-supplied first-paragraph spacing or indentation from reintroducing a blank offset. */
#reader-screen #reader-content.reader-page p,
#reader-screen #reader-content.reader-page p * {
  text-indent:0 !important;
}
#reader-screen #reader-content.reader-page > :first-child,
#reader-screen #reader-content.reader-page > :first-child > :first-child {
  margin-top:0 !important;
}
/* V19: horizontal page isolation is calculated from the full reader viewport in setReaderStyle(). */
#reader-screen #reader-content.reader-page {
  column-fill:auto !important;
  -webkit-column-fill:auto !important;
  overflow-x:auto !important;
  overflow-y:hidden !important;
}

/* V4.1.2: harmonize Toolkit screens with the dark My Library control-menu palette. Reader page colors are intentionally untouched. */
main, main .panel, main .toolkit-home { background:#101421 !important; color:#eef1f5 !important; }
main .hero { background:#101421 !important; color:#eef1f5 !important; border:1px solid #28313d; }
main .hero p, main .hint, main .mode-desc, main .panel p { color:#aeb7c5 !important; }
main .mode-card { background:#202a30 !important; color:#eef1f5 !important; border-color:#303b46 !important; }
main .mode-card .mode-title, main .mode-card .mode-arrow { color:#eef1f5 !important; }
main .tab { background:#202a30 !important; color:#c7d0dc !important; border:1px solid #303b46 !important; }
main .tab.active { background:#101421 !important; color:#ffffff !important; border-color:#687787 !important; }
main .panel h2, main label, main strong { color:#eef1f5 !important; }
main input[type=text], main input[type=search], main select, main textarea { background:#202a30 !important; color:#eef1f5 !important; border-color:#3a4652 !important; }
main input::placeholder, main textarea::placeholder { color:#8793a2 !important; }
main .batch-file { border-color:#303b46 !important; color:#e2e7ee !important; }
main button.action { background:#202a30 !important; color:#f3f5f8 !important; border:1px solid #3a4652 !important; }
main button.alt { background:#303b46 !important; color:#f3f5f8 !important; }
main button, main select, main input { color-scheme:dark; }

/* V4.1.4: correct the previous incomplete theme pass. My Library now uses the same
   navy/charcoal control palette, and sorting is a text-only native control. */
html, body { background:#101421 !important; color:#eef1f5 !important; }
body { color-scheme:dark; }
main { background:#101421 !important; }
main .panel { border-color:#303b46 !important; box-shadow:none !important; }
main #folder-picker-panel, main #batch-panel { border-color:#303b46 !important; }
main .mode-card { border-color:#303b46 !important; }
#reader-view { background:#101421 !important; }
#library-view { background:#101421 !important; }
#library-top { background:#101421 !important; box-shadow:none !important; }
#library-top .lib-title { color:#eef1f5 !important; }
#library-search { background:#202a30 !important; border:1px solid #303b46 !important; color:#eef1f5 !important; }
#library-search::placeholder { color:#aeb7c5 !important; }
#library-sort-row { gap:7px !important; }
#reader-view #library-sort { width:auto !important; flex:0 1 auto !important; min-width:0 !important; padding:0 !important; margin:0 !important; border:0 !important; border-radius:0 !important; background:transparent !important; box-shadow:none !important; color:#a88bd7 !important; font-size:14px !important; appearance:none !important; -webkit-appearance:none !important; outline:none !important; }
#reader-view #library-sort:focus, #reader-view #library-sort:focus-visible { outline:none !important; box-shadow:none !important; }
#reader-view #library-sort option { background:#101421 !important; color:#eef1f5 !important; }
#library-sort-label { color:#aeb7c5 !important; }
.book-card { background:#202a30 !important; border-color:#303b46 !important; box-shadow:none !important; }

/* V4.1.6: compact Library header only; book cards remain unchanged. */
#library-top { margin-bottom:2px !important; padding-top:10px !important; padding-bottom:4px !important; }
#library-top .lib-title { margin-bottom:5px !important; }
#library-search { padding-top:7px !important; padding-bottom:7px !important; }
#library-sort-row { margin-top:5px !important; gap:6px !important; align-items:center !important; min-height:24px !important; }
#library-sort-label, #reader-view #library-sort { font-size:14px !important; line-height:24px !important; height:24px !important; vertical-align:middle !important; }
#library-stats { margin:2px 2px 4px !important; line-height:1.3 !important; }
#library-view .book-card { background:#202a30 !important; border-color:#303b46 !important; }
#library-view .book-meta { color:#aeb7c5 !important; }
#library-view .book-open-hint { color:#a88bd7 !important; }
#library-view .book-progress { background:#3a4652 !important; }
.status { background:#202a30 !important; border:1px solid #303b46 !important; color:#aeb7c5 !important; border-radius:12px !important; }
.status div, .status .summary { background:#202a30 !important; border-color:#303b46 !important; color:#eef1f5 !important; }


/* V4.2.0 UI refinements: balanced library spacing, centered tool tiles, safe bottom scroll. */
#library-top .lib-title{font-size:clamp(28px, 7vw, 34px)!important;}
#library-top{padding-bottom:8px!important;margin-bottom:0!important;}
#library-top .lib-title{margin:0 0 10px!important;}
#library-search{margin:0!important;}
#library-sort-row{margin:12px 0 0!important;align-items:center!important;min-height:28px!important;}
#library-sort-label,#reader-view #library-sort{height:28px!important;line-height:28px!important;font-size:15px!important;display:flex!important;align-items:center!important;}
#library-stats{margin:12px 2px 8px!important;}
#library-view{padding-bottom:calc(112px + env(safe-area-inset-bottom))!important;}
.mode-card{text-align:center!important;}
.mode-card>*{text-align:center!important;}

/* V4.2.1: definitive compact library header and alignment corrections */
#library-top{padding:10px 12px 4px!important;margin-bottom:4px!important}
#reader-view #library-top .lib-title{font-size:28px!important;line-height:1.15!important;margin:0 0 6px!important}
#reader-view #library-search{padding:8px 10px!important;line-height:1.2!important}
#reader-view #library-sort-row{display:flex!important;align-items:center!important;gap:6px!important;margin:4px 0 0!important;min-height:24px!important}
#reader-view #library-sort-label,#reader-view #library-sort{display:flex!important;align-items:center!important;height:24px!important;line-height:24px!important;margin:0!important;padding:0!important;font-size:15px!important;vertical-align:middle!important}
#reader-view #library-stats{margin:4px 2px 6px!important;line-height:1.3!important}
#single-feature-menu .tab{display:flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;font-size:14px!important;font-weight:700!important;line-height:1.25!important}
#batch-panel .tab{display:flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;font-size:14px!important;font-weight:700!important;line-height:1.25!important}
</style></head><body><main>
<header class="hero"><h1>RED DUST - EPUB Toolkit</h1><p>Semua fitur · Batch processing · Android offline standalone</p></header>
<section id="toolkit-home" class="panel toolkit-home">
 <h2>Choose Feature Mode</h2><p class="hint">Choose how you want to process your EPUB files.</p>
 <button class="mode-card" onclick="showSingleMenu()"><span class="mode-icon">📄</span><span class="mode-title">Single Feature</span><span class="mode-desc">Process one EPUB at a time</span><span class="mode-arrow">›</span></button>
 <button class="mode-card batch-mode" onclick="showBatchMenu()"><span class="mode-icon">📚</span><span class="mode-title">Batch Feature</span><span class="mode-desc">Process multiple files in one operation</span><span class="mode-arrow">›</span></button>
</section>
<nav id="single-feature-menu" class="grid hide">

<button class="tab" onclick="showTab('rename-title',this)">1. Rename File</button><button class="tab" onclick="showTab('remove-cover',this)">2. Remove Cover</button>
<button class="tab" onclick="showTab('cover-maker',this)">3. Add Cover</button><button class="tab" onclick="showTab('images',this)">4. Remove All Images</button>
<button class="tab" onclick="showTab('no-preview',this)">5. Add Paragraph</button><button class="tab" onclick="showTab('blank',this)">6. Remove Blank Spacing</button>
<button class="tab" onclick="showTab('compact',this)">7. Compact Line Spacing</button><button class="tab" onclick="showTab('compress',this)">8. Compress Image</button><button class="tab" onclick="showTab('bulk',this)">9. Bulk Find & Replace</button>
<button type="button" class="action alt menu-back" onclick="showToolkitHome()">‹ Back to Feature Menu</button>
</nav>
<section id="remove-cover" class="panel"><h2>Remove EPUB Cover</h2><p class="hint">Menghapus gambar cover, halaman cover yang dikenali, dan metadata thumbnail.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-cover','remove-cover')">Remove Cover</button><div class="status" id="remove-cover-status">Pilih EPUB untuk diproses.</div></section>
<section id="no-preview" class="panel hide"><h2>Add Paragraph</h2><p class="hint">Merapikan paragraf XHTML pada file asli. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/no-preview','no-preview')">Fix Preview</button><div class="status" id="no-preview-status">Pilih EPUB untuk diproses.</div></section>
<section id="cover-maker" class="panel hide"><h2>Add Cover</h2><p class="hint">Membuat cover SVG dan halaman cover dari metadata judul dan penulis EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action alt" onclick="meta()">Baca Metadata</button><label>Judul cover</label><input id="title" type="text" placeholder="Judul cover"><div id="author" class="small"></div><button class="action" onclick="run('/make-cover','cover-maker',{title:val('title')})">Buat Cover</button><div class="status" id="cover-maker-status">Pilih EPUB lalu baca metadata.</div></section>
<section id="compress" class="panel hide"><h2>Compress Image</h2><p class="hint">Mengompres gambar JPEG, PNG, dan WebP di dalam EPUB. GIF dan SVG dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compress','compress')">Compress Images</button><div class="status" id="compress-status">Pilih EPUB untuk diproses. Memerlukan Pillow.</div></section>
<section id="bulk" class="panel hide"><h2>Bulk Find &amp; Replace</h2><p class="hint">Cari dan ganti teks pada EPUB atau TXT secara langsung. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB/TXT</label><select id="bulkfile"></select><label>Teks yang dicari</label><input id="find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="regex" type="checkbox"> Regular expression</label><button class="action alt" onclick="bulk('/bulk-count')">Hitung Kecocokan</button><button class="action" onclick="bulk('/bulk-replace')">Ganti Semua</button><div class="status" id="bulk-status">Pilih file dan masukkan teks pencarian.</div></section>
<section id="compact" class="panel hide"><h2>Compact Line Spacing Fixer</h2><p class="hint">Membersihkan baris kosong/BR berulang, lalu mengatur line-height dan margin paragraf sesuai script asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compact-spacing','compact')">Perbaiki Line Spacing</button><div class="status" id="compact-status">Pilih EPUB untuk diproses.</div></section>
<section id="blank" class="panel hide"><h2>Remove Blank Spacing</h2><p class="hint">Menghapus paragraf kosong saja. CSS dan jarak paragraf asli tetap dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/blank-spacing','blank')">Remove Blank Paragraphs</button><div class="status" id="blank-status">Pilih EPUB untuk diproses.</div></section>
<section id="images" class="panel hide"><h2>Remove All Images</h2><p class="hint">Menghapus file gambar dan referensi gambar dari EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-images','images')">Remove Images</button><div class="status" id="images-status">Pilih EPUB untuk diproses.</div></section>
<section id="rename-title" class="panel hide"><h2>Rename File</h2><p class="hint">Mengganti nama file EPUB berdasarkan judul (dc:title) di metadata EPUB. Isi EPUB tidak diubah. Jika nama sudah dipakai, aplikasi menambahkan akhiran angka agar file lain tidak tertimpa.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="renameByTitle()">Rename File</button><div class="status" id="rename-title-status">Pilih EPUB untuk membaca judul dan mengganti nama file.</div></section>
<section id="folder-picker-panel" class="panel hide" style="margin:0 0 14px;padding:16px;border:2px solid #1265bd"><h2 style="font-size:17px;margin:0 0 8px">Pilih folder EPUB</h2><label for="folderFilter" style="margin-top:0">Tampilkan file dari folder</label><select id="folderFilter" onchange="renderFileChoices()" aria-label="Pilih folder untuk menyaring file"><option value="">Memuat folder…</option></select><p id="folderFilterHelp" class="hint" style="margin-bottom:0">Pilih Download untuk menampilkan EPUB dari folder Download saja. Pilih Semua folder untuk mencari di seluruh penyimpanan.</p></section>
<section id="batch-panel" class="panel hide" style="border:2px solid #15803d">
 <button type="button" class="action alt menu-back" onclick="showToolkitHome()">‹ Back to Feature Menu</button>
<h2>Batch Processing</h2><p class="hint">Jalankan salah satu fitur toolkit pada banyak file sekaligus. Pilih file manual atau gunakan tombol pilih semua pada folder aktif. File diproses satu per satu; file yang gagal tidak menghentikan file lainnya.</p>
<label for="batchOperation">Fitur yang dijalankan</label>
<select id="batchOperation" onchange="updateBatchOptions()">
<option value="/rename-by-title">1. Rename File</option><option value="/remove-cover">2. Remove Cover</option><option value="/make-cover">3. Add Cover</option><option value="/remove-images">4. Remove All Images</option><option value="/no-preview">5. Add Paragraph</option><option value="/blank-spacing">6. Remove Blank Spacing</option><option value="/compact-spacing">7. Compact Line Spacing</option><option value="/compress">8. Compress Image</option><option value="/batch-unzip">9. Batch Unzip (ZIP)</option><option value="/bulk-count">10. Bulk Find &amp; Replace — Count Matches</option><option value="/bulk-replace">11. Bulk Find &amp; Replace — Execute</option>
</select>
<div id="batch-options"></div>
<div class="row" style="display:flex;gap:8px;margin-top:12px"><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(true)">Pilih semua di folder aktif</button><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(false)">Kosongkan pilihan</button></div>
<div id="batch-selection-count" class="small" style="margin:10px 0">0 file dipilih</div><div id="batch-file-list" style="max-height:200px;overflow:auto;border:1px solid #d8e0eb;border-radius:9px;padding:8px"><span class="small">Memuat daftar file…</span></div>
<button class="action" onclick="runBatch()">Jalankan Batch</button><div class="status" id="batch-status">Pilih fitur dan satu atau beberapa file.</div>
</section>
<footer>EPUB Toolkit · Berjalan sepenuhnya offline melalui Android WebView bridge. Pilih folder atau file satu per satu untuk batch. Perubahan disimpan langsung ke file asli; tidak ada backup yang dibuat.</footer></main>

<div id="reader-view">
  <section id="library-view">
    <div id="library-refresh-indicator" aria-live="polite">Tarik ke bawah untuk scan ulang</div>
    <div id="library-top">
      <div class="lib-title">My Library</div>
      <input id="library-search" type="search" placeholder="Search your EPUB books…" oninput="renderLibrary()">
      <div id="library-sort-row"><label id="library-sort-label" for="library-sort">Sort:</label><select id="library-sort" onchange="setLibrarySort(this.value)"><option value="name">Name (A–Z)</option><option value="added">Date added</option><option value="recent">Recently opened</option></select></div>
    </div>
    <div id="library-stats">Your EPUB collection</div>
    <div id="library-selection-toolbar"><span id="library-selection-count">0 selected</span><button onclick="selectAllVisibleBooks()">Select all</button><button onclick="cancelBookSelection()">Cancel</button><button class="delete" onclick="deleteSelectedBooks()">Delete</button></div>
    <div id="library-books"></div>
  </section>
  <section id="reader-search-screen" aria-label="Find in Book">
    <div id="reader-search-head">
      <button class="search-back" onclick="closeReaderSearch()" aria-label="Back">‹</button>
      <input id="reader-dedicated-search-input" type="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="Text search" oninput="showReaderSearchHistory()" onkeydown="if(event.key==='Enter'){event.preventDefault();searchDedicatedBook();}">
      <button class="search-clear" onclick="clearDedicatedSearch()" aria-label="Clear search">×</button>
    </div>
    <div id="reader-search-body">
      <div id="reader-search-history"></div>
      <div id="reader-search-loading">◔</div>
      <div id="reader-search-empty"></div>
      <div id="reader-search-results"></div>
    </div>
  </section>
  <section id="reader-screen">
    <div id="reader-screen-head">
      <button onclick="closeReaderBook()" aria-label="Back to library">‹</button>
      <div id="reader-book-title">Reading</div>
      <button onclick="openReaderSearch()" aria-label="Find in book">⌕</button><button onclick="toggleReaderMenu('settings')" aria-label="Display settings">⚙</button><button onclick="toggleReaderMenu('navigation-controls')" aria-label="Navigation"><svg viewBox="0 0 64 64" width="25" height="25" style="vertical-align:middle"><rect x="10" y="12" width="44" height="40" rx="8" fill="none" stroke="currentColor" stroke-width="3"/><path d="M25 22 L16 32 L25 42 M39 22 L48 32 L39 42" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><button onclick="toggleReaderMenu('navigation')" aria-label="Table of contents">☷</button>
    </div>
    <div id="reader-controls">
      <div id="reader-search-status" aria-live="polite"></div>
      <div id="reader-settings-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Display settings</div>
        <div class="reader-settings">
          <div><label for="reader-font">Font size: <span id="font-value">19</span> px</label><input id="reader-font" type="range" min="14" max="32" value="19" oninput="setReaderStyle()"></div>
          <div><label for="reader-line">Line spacing: <span id="line-value">1.65</span></label><input id="reader-line" type="range" min="1.2" max="2.4" step="0.05" value="1.65" oninput="setReaderStyle()"></div>
          <div><label for="reader-para">Paragraph spacing: <span id="para-value">1.0</span> em</label><input id="reader-para" type="range" min="0" max="2.5" step="0.1" value="1" oninput="setReaderStyle()"></div>
          <div><label for="reader-letter">Font spacing: <span id="letter-value">0</span> px</label><input id="reader-letter" type="range" min="-0.5" max="2" step="0.1" value="0" oninput="setReaderStyle()"></div>
          <div><label for="reader-family">Font type</label><select id="reader-family" onchange="setReaderStyle()"><option value="Georgia,serif">Georgia / Serif</option><option value="'Noto Serif',serif">Noto Serif</option><option value="'Noto Sans',Arial,sans-serif">Noto Sans</option><option value="Roboto,Arial,sans-serif">Roboto</option><option value="Arial,sans-serif">Arial</option><option value="Verdana,sans-serif">Verdana</option><option value="'Times New Roman',serif">Times New Roman</option><option value="monospace">Monospace</option></select></div>
          <div><label for="reader-weight">Font thickness: <span id="weight-value">400</span></label><input id="reader-weight" type="range" min="300" max="900" step="100" value="400" oninput="setReaderStyle()"></div>
        </div>
        <div class="theme-row"><button onclick="readerTheme('light')">Light</button><button onclick="readerTheme('sepia')">Sepia</button><button onclick="readerTheme('night')">Night</button></div>
      </div>
      <div id="reader-navigation-controls-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Navigation</div>
        <div class="reader-actions"><button class="secondary" onclick="readerPrev()">Previous chapter</button><button class="secondary" onclick="readerNext()">Next chapter</button><span id="reader-progress" style="color:#aaa;font-size:12px;align-self:center;margin-left:auto"></span></div>
        <div class="page-nav"><button class="secondary" onclick="readerPagePrev()">‹ Page</button><button class="secondary" onclick="readerPageNext()">Page ›</button><span id="reader-page-count">Page 1</span></div>
      </div>
      <div id="reader-navigation-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Table of contents</div>
        <label for="reader-chapter">Choose chapter</label><select id="reader-chapter" onchange="loadReaderChapter()"><option value="0">Chapter</option></select>
      </div>
    </div>
    <article id="reader-content" class="reader-page"><div class="reader-empty">Choose a book from your library to start reading.</div></article>
  </section>
</div>
<nav id="gallery-nav">
 <button id="gallery-albums" class="gallery-btn active" onclick="switchGallery('albums')"><span class="gallery-emoji" aria-hidden="true">📖</span>Read Book</button>
 <button id="gallery-photos" class="gallery-btn" onclick="switchGallery('photos')"><span class="gallery-emoji" aria-hidden="true">🛠️</span>Tools</button>
</nav>

<script>
const $=id=>document.getElementById(id), val=id=>$(id).value;let files=[];const readerCoverCache={};
// Stage 3.3: bound retained cover data to prevent library browsing from growing
// the JavaScript cache indefinitely. Large covers are displayed but not retained.
const READER_COVER_CACHE_MAX_ENTRIES=10, READER_COVER_CACHE_MAX_CHARS=4*1024*1024, READER_COVER_CACHE_MAX_ITEM_CHARS=1536*1024;
function readerCoverCacheChars(){return Object.values(readerCoverCache).reduce((sum,value)=>sum+(typeof value==='string'?value.length:0),0);}
function readerCoverCacheSet(key,value){delete readerCoverCache[key];if(typeof value==='string'&&value.length>READER_COVER_CACHE_MAX_ITEM_CHARS)return;readerCoverCache[key]=value;while(Object.keys(readerCoverCache).length>READER_COVER_CACHE_MAX_ENTRIES||readerCoverCacheChars()>READER_COVER_CACHE_MAX_CHARS){const first=Object.keys(readerCoverCache)[0];if(first===undefined)break;delete readerCoverCache[first];}}
function readerCoverCacheTouch(key){if(!Object.prototype.hasOwnProperty.call(readerCoverCache,key))return;const value=readerCoverCache[key];delete readerCoverCache[key];readerCoverCache[key]=value;}
let selectedBookPaths=new Set(),bookLongPressTimer=null,suppressBookClick=false;

// Startup destination is explicitly Read Book / My Library.
const DEFAULT_GALLERY_SCREEN='albums';
function switchGallery(which=DEFAULT_GALLERY_SCREEN){
  const albums=which==='albums';
  document.body.classList.toggle('reader-active',albums);
  $('reader-view').classList.remove('controls-hidden');
  document.querySelector('main').style.display=albums?'none':'block';
  $('reader-view').style.display=albums?'block':'none';
  $('library-view').style.display='block';$('reader-screen').style.display='none';if(!albums)showToolkitHome();
  $('gallery-photos').classList.toggle('active',!albums);
  $('gallery-albums').classList.toggle('active',albums);
  if(albums)populateReaderFiles();
}
let readerBook=null, readerFileLoaded='', readerSearchMatches=[], readerSearchIndex=-1, readerSearchQuery='';
let readerSearchPanelScrollTop=0;
let readerSearchHistory=[];
let libraryPullStartY=0,libraryPullStartX=0,libraryPullArmed=false,libraryPullDistance=0,libraryRefreshBusy=false;
const libraryScrollArea=$('reader-view');
if(libraryScrollArea){
 libraryScrollArea.addEventListener('touchstart',e=>{
  if($('library-view').style.display==='none'||$('reader-screen').style.display==='block'||libraryRefreshBusy||e.touches.length!==1)return;
  const t=e.touches[0];libraryPullStartY=t.clientY;libraryPullStartX=t.clientX;libraryPullArmed=libraryScrollArea.scrollTop<=2;libraryPullDistance=0;
 },{passive:true});
 libraryScrollArea.addEventListener('touchmove',e=>{
  if(!libraryPullArmed||e.touches.length!==1)return;
  const t=e.touches[0],dy=t.clientY-libraryPullStartY,dx=t.clientX-libraryPullStartX;
  if(Math.abs(dx)>Math.abs(dy)*.8){libraryPullArmed=false;return;}
  if(dy>0&&libraryScrollArea.scrollTop<=2){libraryPullDistance=Math.min(100,dy);const ind=$('library-refresh-indicator');if(ind){ind.classList.toggle('visible',dy>12);ind.textContent=dy>=76?'Lepaskan untuk scan ulang':'Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchend',()=>{
  const shouldRefresh=libraryPullArmed&&libraryPullDistance>=76;libraryPullArmed=false;libraryPullDistance=0;
  if(shouldRefresh)refreshLibraryScan();else{const ind=$('library-refresh-indicator');if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchcancel',()=>{libraryPullArmed=false;libraryPullDistance=0;const ind=$('library-refresh-indicator');if(ind)ind.classList.remove('visible');},{passive:true});
}
async function refreshLibraryScan(){
 if(libraryRefreshBusy)return;libraryRefreshBusy=true;const ind=$('library-refresh-indicator');
 if(ind){ind.classList.add('visible');ind.textContent='Memindai ulang EPUB…';}
 try{
  Object.keys(readerCoverCache).forEach(k=>delete readerCoverCache[k]);
  await new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,30)));
  await loadFiles();
  if(ind)ind.textContent='Scan selesai · My Library diperbarui';
 }catch(e){if(ind)ind.textContent='Gagal scan ulang: '+e.message;}
 setTimeout(()=>{if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}libraryRefreshBusy=false;},900);
}
function savedReaderState(){try{return JSON.parse(localStorage.getItem('redDustReaderProgress')||'{}')}catch(e){return {}}}
let readerPendingFragment='';
function readerLinkPath(raw,current){try{const u=new URL(String(raw||''),'https://rd-epub.invalid/'+String(current||'').replace(/^\//,''));let p=decodeURIComponent(u.pathname).replace(/^\//,'');const parts=[];p.split('/').forEach(seg=>{if(!seg||seg==='.')return;if(seg==='..')parts.pop();else parts.push(seg);});return parts.join('/');}catch(e){return '';}}
function readerLandOnFragment(fragment){if(!fragment)return;const el=$('reader-content');let target=null;try{target=el.querySelector('[id="'+CSS.escape(fragment)+'"]')||el.querySelector('[name="'+CSS.escape(fragment)+'"]');}catch(e){}if(target){const rect=target.getBoundingClientRect();const base=el.getBoundingClientRect();el.scrollLeft=Math.max(0,el.scrollLeft+rect.left-base.left);updateReaderPageCount();saveReaderState();}}
function readerFragmentFromHref(raw){const i=String(raw||'').indexOf('#');if(i<0)return '';try{return decodeURIComponent(String(raw).slice(i+1));}catch(e){return String(raw).slice(i+1);}}
function handleReaderInternalLink(event){const anchor=event.target&&event.target.closest?event.target.closest('a[data-rd-href]'):null;if(!anchor)return;event.preventDefault();const raw=(anchor.getAttribute('data-rd-href')||'').trim();if(!raw)return;const current=readerBook&&readerBook.chapters[readerBook.index]?readerBook.chapters[readerBook.index].href:'';const targetPath=readerLinkPath(raw.split('#')[0]||current,current);const fragment=readerFragmentFromHref(raw);const currentPath=readerLinkPath(current,current);if(!targetPath||targetPath===currentPath){readerLandOnFragment(fragment);return;}const chapters=readerBook&&readerBook.chapters||[];let idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href)===targetPath);if(idx<0){const base=targetPath.split('/').pop().toLowerCase();if(base)idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href).split('/').pop().toLowerCase()===base);}if(idx>=0){readerPendingFragment=fragment;navigateReaderChapter(idx,'start');}else{console.warn('EPUB internal link target was not found in reading chapters:',raw,targetPath);}}
function readerCurrentPage(){const el=$('reader-content');return el&&el.clientWidth>0?Math.max(0,Math.round(el.scrollLeft/Math.max(1,el.clientWidth))):0;}
function saveReaderState(){if(!readerFileLoaded||!readerBook)return;const all=savedReaderState();all[readerFileLoaded]={chapter:readerBook.index||0,page:readerCurrentPage(),title:readerBook.title||''};try{localStorage.setItem('redDustReaderProgress',JSON.stringify(all));}catch(e){}}
function populateReaderFiles(){renderLibrary();}
function libraryTimestamps(){
 try{return JSON.parse(localStorage.getItem('redDustLibraryTimestamps')||'{"added":{},"recent":{}}');}
 catch(e){return {added:{},recent:{}};}
}
function setLibrarySort(mode){
 try{localStorage.setItem('redDustLibrarySort',mode);}catch(e){}
 renderLibrary();
}
function isBookSelectionMode(){return selectedBookPaths.size>0;}
function updateBookSelectionUI(){
 const toolbar=$('library-selection-toolbar'),count=$('library-selection-count');
 if(toolbar)toolbar.classList.toggle('visible',isBookSelectionMode());
 if(count)count.textContent=selectedBookPaths.size+' book'+(selectedBookPaths.size===1?'':'s')+' selected';
 $('library-view').classList.toggle('selection-mode',isBookSelectionMode());
}
function toggleBookSelection(path){if(selectedBookPaths.has(path))selectedBookPaths.delete(path);else selectedBookPaths.add(path);updateBookSelectionUI();renderLibrary();}
function beginBookSelection(path){if(!selectedBookPaths.has(path))selectedBookPaths.add(path);suppressBookClick=true;updateBookSelectionUI();renderLibrary();setTimeout(()=>{suppressBookClick=false;},450);}
function cancelBookSelection(){selectedBookPaths.clear();updateBookSelectionUI();renderLibrary();}
function selectAllVisibleBooks(){const q=($('library-search')?.value||'').toLowerCase().trim();files.filter(f=>/\.epub$/i.test(f.name)&&(!q||librarySearchText(f).includes(q))).forEach(f=>selectedBookPaths.add(f.path));updateBookSelectionUI();renderLibrary();}
async function deleteSelectedBooks(){
 const targets=[...selectedBookPaths];if(!targets.length)return;
 if(!confirm('Delete '+targets.length+' selected book'+(targets.length===1?'':'s')+' from your device? This cannot be undone.'))return;
 let deleted=0,failed=[];const progress=savedReaderState(),stamps=libraryTimestamps();
 for(const file of targets){try{await api('/delete-book',{file});deleted++;delete progress[file];delete stamps.added[file];delete stamps.recent[file];selectedBookPaths.delete(file);}catch(e){failed.push(file.split('/').pop()+': '+e.message);}}
 try{localStorage.setItem('redDustReaderProgress',JSON.stringify(progress));localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 updateBookSelectionUI();await loadFiles();
 if(failed.length)alert(deleted+' book(s) deleted. Could not delete '+failed.length+':\n'+failed.join('\n'));
 else alert(deleted+' book(s) deleted.');
}
function renderLibrary(){
 const box=$('library-books');if(!box)return;box.innerHTML='';
 const q=($('library-search')?.value||'').toLowerCase().trim();
 const books=files.filter(f=>/\.epub$/i.test(f.name)&&(!q||librarySearchText(f).includes(q)));
 const stamps=libraryTimestamps(),now=Date.now();
 books.forEach(f=>{if(!stamps.added[f.path])stamps.added[f.path]=(Number(f.added)>0?Number(f.added)*1000:now);});
 try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 const sortControl=$('library-sort');let sort=localStorage.getItem('redDustLibrarySort')||'name';
 if(!['name','added','recent'].includes(sort))sort='name';
 if(sortControl)sortControl.value=sort;
 books.sort((a,b)=>{
  if(sort==='added')return (stamps.added[b.path]||0)-(stamps.added[a.path]||0)||a.name.localeCompare(b.name);
  if(sort==='recent')return (stamps.recent[b.path]||0)-(stamps.recent[a.path]||0)||a.name.localeCompare(b.name);
  return a.name.localeCompare(b.name,undefined,{sensitivity:'base'});
 });
 $('library-stats').textContent=books.length+' EPUB book'+(books.length===1?'':'s')+' · Tap to read · Hold to select';
 updateBookSelectionUI();
 if(!books.length){box.innerHTML='<div class="reader-empty">No EPUB books found. Add EPUB files to your device storage and refresh the app.</div>';return;}
 const progress=savedReaderState();
 books.forEach(f=>{const state=progress[f.path],card=document.createElement('div');card.className='book-card'+(selectedBookPaths.has(f.path)?' selected':'');
 card.onclick=()=>{if(suppressBookClick){suppressBookClick=false;return;}if(isBookSelectionMode())toggleBookSelection(f.path);else openReaderBook(f.path,state?.chapter||0);};
 let pressMoved=false;
 card.addEventListener('touchstart',()=>{pressMoved=false;clearTimeout(bookLongPressTimer);bookLongPressTimer=setTimeout(()=>beginBookSelection(f.path),560);},{passive:true});
 card.addEventListener('touchmove',()=>{pressMoved=true;clearTimeout(bookLongPressTimer);},{passive:true});
 card.addEventListener('touchend',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('touchcancel',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('contextmenu',e=>{e.preventDefault();beginBookSelection(f.path);});
 const selectMark=document.createElement('div');selectMark.className='book-select-mark';selectMark.textContent=selectedBookPaths.has(f.path)?'✓':'';
 const cover=document.createElement('div');cover.className='book-cover';cover.innerHTML='<span>▤</span>';
 if(Object.prototype.hasOwnProperty.call(readerCoverCache,f.path)){
  readerCoverCacheTouch(f.path);
  if(readerCoverCache[f.path]){const img=document.createElement('img');img.alt='Book cover';img.src=readerCoverCache[f.path];cover.replaceChildren(img);}
 }else{
  readerCoverCacheSet(f.path,null);
  api('/reader-cover',{file:f.path}).then(result=>{
   if(result.cover){readerCoverCacheSet(f.path,result.cover);
    if(card.isConnected){const img=document.createElement('img');img.alt='Book cover';img.src=result.cover;cover.replaceChildren(img);}
   }
  }).catch(()=>{});
 }
 const info=document.createElement('div');info.className='book-info';
 const name=document.createElement('div');name.className='book-name';name.textContent=f.name.replace(/\.epub$/i,'');
 const meta=document.createElement('div');meta.className='book-meta';meta.textContent='EPUB · '+(f.size||'');
 const hint=document.createElement('div');hint.className='book-open-hint';hint.textContent=state?'Continue reading · Chapter '+(state.chapter+1):'Tap to start reading';
 const bar=document.createElement('div');bar.className='book-progress';const fill=document.createElement('i');fill.style.width=state?'12%':'0%';bar.appendChild(fill);
 info.append(name,meta,hint,bar);card.append(selectMark,cover,info);box.appendChild(card);
 });
}
async function openReaderBook(file,chapter,page=0){
 file=file||'';if(!file)return;readerRestorePage=Math.max(0,Number(page)||0);try{localStorage.setItem('redDustLastOpenedBook',file);}catch(e){}
 readerSearchMatches=[];readerSearchIndex=-1;readerSearchQuery='';$('reader-dedicated-search-input').value='';$('reader-search-status').textContent='';
 $('library-view').style.display='none';$('reader-search-screen').classList.remove('active');$('reader-screen').style.display='block';
 $('reader-view').classList.remove('controls-hidden');
 document.body.classList.add('reader-reading');
 $('reader-content').innerHTML='<div class="reader-empty">Opening book…</div>';
 $('reader-book-title').textContent=file.split('/').pop().replace(/\.epub$/i,'');
 try{readerBook=await api('/reader-open',{file,chapter:chapter||0});readerFileLoaded=file;const stamps=libraryTimestamps();stamps.recent[file]=Date.now();try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}renderReaderChapter();}catch(e){$('reader-content').textContent='Could not open EPUB: '+e.message;}
}
function closeReaderBook(){saveReaderState();document.body.classList.remove('reader-reading');$('reader-screen').style.display='none';$('library-view').style.display='block';$('reader-view').classList.remove('controls-hidden');renderLibrary();}
function restoreReaderAfterWebViewError(){try{const file=localStorage.getItem('redDustLastOpenedBook');if(!file)return;const state=savedReaderState();openReaderBook(file,state[file]?.chapter||0,state[file]?.page||0);}catch(e){console.warn('Reader restore failed',e);}}
function handleAndroidBack(){if(isBookSelectionMode()&&$('library-view').style.display!=='none'){cancelBookSelection();return true;}if($('reader-search-screen').classList.contains('active')){closeReaderSearch();return true;}if($('reader-view').style.display==='block'&&document.querySelector('#reader-view .reader-popup-menu.active')){closeReaderMenus();return true;}if($('reader-screen').style.display==='block'){closeReaderBook();return true;}if($('reader-view').style.display==='block'){return false;}if(document.querySelector('main').style.display!=='none'){switchGallery('albums');return true;}return false;}
async function loadReaderChapter(position='start'){
 if(!readerFileLoaded)return;
 try{
  readerChapterLanding=position;
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:parseInt(val('reader-chapter')||0)});
  renderReaderChapter();
 }catch(e){$('reader-content').textContent='Could not load chapter: '+e.message;}
}
let readerChapterLanding='start';
let readerRestorePage=0;
async function navigateReaderChapter(index,position){
 if(!readerBook||index<0||index>=readerBook.chapters.length)return;
 $('reader-chapter').value=String(index);
 await loadReaderChapter(position);
}
function renderReaderChapter(){
 /* Preserve the reader chrome state when moving between chapters. */
 const landing=readerChapterLanding;readerChapterLanding='start';
 const s=$('reader-chapter');s.innerHTML='';
 readerBook.chapters.forEach((c,i)=>s.add(new Option((i+1)+'. '+c.title,i)));
 s.value=String(readerBook.index);
 $('reader-content').innerHTML=readerBook.content;
 const readerContent=$('reader-content');if(!readerContent.dataset.rdLinkHandler){readerContent.addEventListener('click',handleReaderInternalLink);readerContent.dataset.rdLinkHandler='1';}
 $('reader-book-title').textContent=readerBook.title||'Reading';
 if(readerSearchQuery)highlightReaderSearch();
 $('reader-content').scrollLeft=0;
 saveReaderState();
 $('reader-progress').textContent=(readerBook.index+1)+' / '+readerBook.chapters.length;
 setReaderStyle();
 initReaderSwipe();
 /* Wait for WebView to lay out the new chapter columns before landing. */
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const el=$('reader-content');
  if(landing==='end'){el.scrollLeft=el.scrollWidth;}else{el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,Math.max(0,readerRestorePage)*readerPageWidth());readerRestorePage=0;}
  if(readerPendingFragment){const fragment=readerPendingFragment;readerPendingFragment='';readerLandOnFragment(fragment);}
  updateReaderPageCount();saveReaderState();
 }));
}
let readerTouchX=0,readerTouchY=0,readerTouchStart=0;
function readerPageWidth(){const el=$('reader-content');return Math.max(120,el.clientWidth);}
function updateReaderPageCount(){const el=$('reader-content');if(!el)return;const page=Math.max(1,Math.round(el.scrollLeft/readerPageWidth())+1);$('reader-page-count').textContent='Page '+page;}
function readerPageNext(){const el=$('reader-content');const atEnd=el.scrollLeft+el.clientWidth>=el.scrollWidth-36;if(atEnd){if(readerBook&&readerBook.index<readerBook.chapters.length-1){navigateReaderChapter(readerBook.index+1,'start');return;}return;}el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,el.scrollLeft+readerPageWidth());updateReaderPageCount();}
function readerPagePrev(){const el=$('reader-content');if(el.scrollLeft<=4){if(readerBook&&readerBook.index>0){navigateReaderChapter(readerBook.index-1,'end');return;}return;}el.scrollLeft=Math.max(0,el.scrollLeft-readerPageWidth());updateReaderPageCount();}
function toggleReaderControls(){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.toggle('controls-hidden');closeReaderMenus();}
function closeReaderMenus(){['reader-settings-menu','reader-navigation-menu','reader-navigation-controls-menu'].forEach(id=>$(id).classList.remove('active'));}
function toggleReaderMenu(which){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.remove('controls-hidden');const map={settings:'reader-settings-menu',navigation:'reader-navigation-menu','navigation-controls':'reader-navigation-controls-menu'};const target=map[which]||'reader-navigation-menu';const wasOpen=$(target).classList.contains('active');closeReaderMenus();if(!wasOpen)$(target).classList.add('active');}
function initReaderSwipe(){
 const el=$('reader-content');
 if(!el)return;
 if(el.dataset.swipeReady)return;
 el.dataset.swipeReady='1';
 el.addEventListener('touchstart',e=>{if(e.touches.length===1){readerTouchX=e.touches[0].clientX;readerTouchY=e.touches[0].clientY;readerTouchStart=Date.now();}},{passive:true});
 el.addEventListener('touchend',e=>{
  if(!e.changedTouches.length)return;
  const t=e.changedTouches[0],dx=t.clientX-readerTouchX,dy=t.clientY-readerTouchY;
  /* Keep the existing swipe navigation unchanged. */
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){if(dx<0)readerPageNext();else readerPagePrev();return;}
  if(Date.now()-readerTouchStart>600||Math.abs(dx)>18||Math.abs(dy)>18)return;
  if(e.target.closest('a,button,input,select,textarea'))return;
  const rect=el.getBoundingClientRect(),relativeX=(t.clientX-rect.left)/Math.max(1,rect.width);
  /* Center toggles the overlay; screen edges turn pages in either direction. */
  if(relativeX>=0.35&&relativeX<=0.65){toggleReaderControls();return;}
  if(relativeX>0.65){readerPageNext();return;}
  readerPagePrev();
 },{passive:true});
 el.addEventListener('scroll',()=>{updateReaderPageCount();saveReaderState();},{passive:true});
}

function readerSearchHistoryKey(){return String(readerFileLoaded||'').trim()||'__no_book__';}
function loadReaderSearchHistory(){try{const raw=JSON.parse(localStorage.getItem('epubToolkitReaderSearchHistoryByBook')||'{}');const saved=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw[readerSearchHistoryKey()]:[];readerSearchHistory=Array.isArray(saved)?saved.filter(x=>typeof x==='string'&&x.trim()).slice(0,20):[];}catch(e){readerSearchHistory=[];}}
function saveReaderSearchHistory(){try{const raw=JSON.parse(localStorage.getItem('epubToolkitReaderSearchHistoryByBook')||'{}');const store=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};store[readerSearchHistoryKey()]=readerSearchHistory.slice(0,20);localStorage.setItem('epubToolkitReaderSearchHistoryByBook',JSON.stringify(store));}catch(e){}}
function showReaderSearchHistory(){
 const input=$('reader-dedicated-search-input'),box=$('reader-search-history');if(!input||!box)return;
 if(!input.value.trim()){box.classList.remove('visible');box.innerHTML='';return;}
 loadReaderSearchHistory();box.innerHTML='';if(!readerSearchHistory.length){box.classList.remove('visible');return;}
 readerSearchHistory.forEach((q,i)=>{const row=document.createElement('div');row.className='reader-search-history-item';row.innerHTML='<span class="history-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"></path><path d="M3 3v5h5"></path></svg></span><span class="history-query"></span>';row.querySelector('.history-query').textContent=q;let wasLongPressed=false;row.onclick=()=>{if(wasLongPressed){wasLongPressed=false;return;}input.value=q;searchDedicatedBook();};
  let pressTimer=null;const cancel=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
  row.addEventListener('touchstart',()=>{wasLongPressed=false;pressTimer=setTimeout(()=>{wasLongPressed=true;readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();pressTimer=null;},550);},{passive:true});row.addEventListener('touchend',cancel,{passive:true});row.addEventListener('touchmove',cancel,{passive:true});row.addEventListener('contextmenu',e=>{e.preventDefault();readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();});box.appendChild(row);
 });box.classList.add('visible');
}
function openReaderSearch(){
 const screen=$('reader-search-screen');if(!screen)return;
 const body=$('reader-search-body'),input=$('reader-dedicated-search-input');screen.classList.add('active');
 // Preserve query/results/selection/scroll on return; otherwise open a clean search view.
 if(readerSearchMatches.length&&readerSearchQuery){input.value=readerSearchQuery;$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='';}
 else if(!readerSearchQuery){input.value='';$('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';$('reader-search-loading').classList.remove('active');}
 if(readerSearchMatches.length&&readerSearchQuery){$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';}else{showReaderSearchHistory();}
 requestAnimationFrame(()=>{if(readerSearchMatches.length&&readerSearchQuery){body.scrollTop=readerSearchPanelScrollTop;}else{input.focus();try{input.setSelectionRange(input.value.length,input.value.length);}catch(e){}}});
}
function closeReaderSearch(){
 const screen=$('reader-search-screen'),body=$('reader-search-body');
 if(body)readerSearchPanelScrollTop=body.scrollTop;
 if(screen)screen.classList.remove('active');
 try{if(document.activeElement)document.activeElement.blur();}catch(e){}
}
function clearDedicatedSearch(){
 const input=$('reader-dedicated-search-input');
 input.value='';input.focus();
 $('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';
 $('reader-search-loading').classList.remove('active');
}
function escapeHtmlText(text){return String(text||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderDedicatedSearchResults(matches,query){
 const box=$('reader-search-results');box.innerHTML='';
 if(!matches.length){$('reader-search-empty').textContent='No results found';return;}
 const needle=query.toLocaleLowerCase();
 matches.forEach((m,i)=>{
  const card=document.createElement('div');card.className='search-result-card'+(i===readerSearchIndex?' search-result-selected':'');card.setAttribute('role','button');card.setAttribute('tabindex','0');if(i===readerSearchIndex)card.setAttribute('aria-current','true');
  const textWrap=document.createElement('div');textWrap.className='search-result-text';
  const chapterTitle=document.createElement('div');chapterTitle.className='search-result-chapter-title';
  const chapter=Number(m.chapter)||0;chapterTitle.textContent='Chapter '+(chapter+1)+(m.chapter_title?' · '+m.chapter_title:'');
  const snippet=document.createElement('div');snippet.className='search-result-snippet';
  const raw=String(m.snippet||'');const lower=raw.toLocaleLowerCase();let from=0,html='';
  while(true){const at=lower.indexOf(needle,from);if(at<0){html+=escapeHtmlText(raw.slice(from));break;}html+=escapeHtmlText(raw.slice(from,at))+'<mark>'+escapeHtmlText(raw.slice(at,at+query.length))+'</mark>';from=at+query.length;}
  snippet.innerHTML=html;textWrap.append(chapterTitle,snippet);
  const loc=document.createElement('div');loc.className='search-result-location';loc.textContent='Ch. '+(chapter+1);
  card.append(textWrap,loc);card.onclick=async()=>{readerSearchIndex=i;readerSearchPanelScrollTop=card.offsetTop;renderDedicatedSearchResults(readerSearchMatches,readerSearchQuery);closeReaderSearch();await goToReaderSearchMatch();};card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}};
  box.appendChild(card);
 });
}
async function searchDedicatedBook(){
 const input=$('reader-dedicated-search-input');const query=(input?.value||'').trim();
 if(!readerFileLoaded||!query)return;
 readerSearchQuery=query;readerSearchMatches=[];readerSearchIndex=-1;readerSearchPanelScrollTop=0;$('reader-search-body').scrollTop=0;
 try{localStorage.setItem('redDustLastReaderSearch',query);}catch(e){}
 loadReaderSearchHistory();readerSearchHistory=[query,...readerSearchHistory.filter(x=>x.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,20);saveReaderSearchHistory();$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';
 $('reader-search-empty').textContent='';$('reader-search-results').innerHTML='';$('reader-search-loading').classList.add('active');
 try{
  const result=await api('/reader-search',{file:readerFileLoaded,query});
  readerSearchMatches=Array.isArray(result?.matches)?result.matches:[];
  $('reader-search-loading').classList.remove('active');
  renderDedicatedSearchResults(readerSearchMatches,query);
 }catch(e){$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='Search failed: '+(e?.message||String(e));}
}
async function searchInsideBook(){
 openReaderSearch();
}
function clearReaderSearchMarks(){document.querySelectorAll('#reader-content mark.reader-search-hit').forEach(mark=>mark.replaceWith(document.createTextNode(mark.textContent)));}
function highlightReaderSearch(){
 const root=$('reader-content');clearReaderSearchMarks();if(!readerSearchQuery)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(node){return node.nodeValue.toLocaleLowerCase().includes(readerSearchQuery.toLocaleLowerCase())?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 const needle=readerSearchQuery.toLocaleLowerCase();
 nodes.forEach(node=>{const text=node.nodeValue,lower=text.toLocaleLowerCase(),frag=document.createDocumentFragment();let from=0,at;
  while((at=lower.indexOf(needle,from))!==-1){if(at>from)frag.appendChild(document.createTextNode(text.slice(from,at)));const mark=document.createElement('mark');mark.className='reader-search-hit';mark.textContent=text.slice(at,at+readerSearchQuery.length);frag.appendChild(mark);from=at+readerSearchQuery.length;}
  if(from<text.length)frag.appendChild(document.createTextNode(text.slice(from)));node.parentNode.replaceChild(frag,node);
 });
}
async function goToReaderSearchMatch(){
 const match=readerSearchMatches[readerSearchIndex];if(!match)return;
 const targetChapter=Number(match.chapter)||0;
 if(readerBook.index!==targetChapter){
  $('reader-chapter').value=String(targetChapter);
  readerChapterLanding='start';
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:targetChapter});
  renderReaderChapter();
 }else{
  // Same chapter: preserve the current pagination/column geometry. Only refresh marks.
  highlightReaderSearch();
 }
 const page=$('reader-content');
 // Allow WebView's column layout to settle before measuring the highlighted text.
 requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const marks=page.querySelectorAll('mark.reader-search-hit');
  const occurrence=Math.max(0,Number(match.occurrence)||0),target=marks[occurrence];
  if(target){
   const rect=target.getBoundingClientRect(),base=page.getBoundingClientRect();
   /* Search navigation must land on a whole reader column/page. WebView's
      mandatory snap can otherwise restore at an intermediate offset and show
      slivers of two columns (the broken layout seen after selecting a result). */
   const stride=Math.max(1,page.clientWidth);
   const targetX=Math.max(0,page.scrollLeft+rect.left-base.left);
   const destination=Math.floor(targetX/stride)*stride;
   page.style.scrollSnapType='none';
   page.style.scrollBehavior='auto';
   page.scrollLeft=destination;
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
    page.scrollLeft=destination;
    page.style.scrollSnapType='x mandatory';
    updateReaderPageCount();
   }));
  }
  $('reader-search-status').textContent='Match '+(readerSearchIndex+1)+' of '+readerSearchMatches.length+' · '+(readerBook.chapters[targetChapter]?.title||'Chapter '+(targetChapter+1));
 })));
}

function readerSearchNext(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex+1)%readerSearchMatches.length;goToReaderSearchMatch();}
function readerSearchPrev(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex-1+readerSearchMatches.length)%readerSearchMatches.length;goToReaderSearchMatch();}

function readerPrev(){if(readerBook&&readerBook.index>0){$('reader-chapter').value=readerBook.index-1;loadReaderChapter();}}
function readerNext(){if(readerBook&&readerBook.index<readerBook.chapters.length-1){$('reader-chapter').value=readerBook.index+1;loadReaderChapter();}}
let readerStyleSignature='';
function setReaderStyle(){
 const page=$('reader-content'),font=val('reader-font'),line=val('reader-line'),para=val('reader-para'),letter=val('reader-letter'),weight=val('reader-weight'),family=val('reader-family');
 const cs=getComputedStyle(page);
 const padLeft=parseFloat(cs.paddingLeft)||0, padRight=parseFloat(cs.paddingRight)||0;
 const contentWidth=Math.max(120,page.clientWidth-padLeft-padRight);
 const pageGap=Math.max(0,padLeft+padRight);
 const signature=[font,line,para,letter,weight,family,contentWidth,pageGap,page.clientHeight].join('|');
 $('font-value').textContent=font;$('line-value').textContent=line;$('para-value').textContent=para;$('letter-value').textContent=letter;$('weight-value').textContent=weight;
 if(signature===readerStyleSignature)return;
 const currentPage=page.clientWidth>0?Math.max(0,Math.round(page.scrollLeft/page.clientWidth)):0;
 readerStyleSignature=signature;
 /* CSS variables avoid walking every paragraph for each slider update. */
 page.style.setProperty('--rd-reader-para-spacing',para+'em');
 page.style.columnWidth=contentWidth+'px';page.style.webkitColumnWidth=contentWidth+'px';
 page.style.columnGap=pageGap+'px';page.style.webkitColumnGap=pageGap+'px';
 page.style.columnFill='auto';page.style.webkitColumnFill='auto';
 page.style.fontSize=font+'px';page.style.lineHeight=line;page.style.letterSpacing=letter+'px';page.style.fontWeight=weight;page.style.fontFamily=family;
 requestAnimationFrame(()=>{if(page.clientWidth>0){page.scrollLeft=Math.min(page.scrollWidth-page.clientWidth,currentPage*page.clientWidth);updateReaderPageCount();saveReaderState();}});
}

function readerTheme(theme){
 const p=$('reader-content');
 const styles={light:['#fff','#242424'],sepia:['#f2e4c9','#5b4632'],night:['#171717','#ddd']};
 p.style.background=styles[theme][0];p.style.color=styles[theme][1];
}

function hideToolkitSections(){document.querySelectorAll('main>section').forEach(x=>x.classList.add('hide'));$('single-feature-menu').classList.add('hide');$('folder-picker-panel').classList.add('hide');}
function showToolkitHome(){hideToolkitSections();$('toolkit-home').classList.remove('hide');}
function showSingleMenu(){hideToolkitSections();$('single-feature-menu').classList.remove('hide');}
function showBatchMenu(){hideToolkitSections();$('folder-picker-panel').classList.remove('hide');$('batch-panel').classList.remove('hide');}
function showTab(id,b){hideToolkitSections();$('single-feature-menu').classList.remove('hide');$('folder-picker-panel').classList.remove('hide');$(id).classList.remove('hide');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));if(b)b.classList.add('active')}
async function api(path,data){let d=JSON.parse(AndroidBridge.post(path,JSON.stringify(data)));if(d.error)throw Error(d.error||'Operasi gagal');return d}
function fileFor(id){return $(id).querySelector('select.epub')?.value || ''}
function renderFileChoices(){
  const filter=$('folderFilter')?.value||'';
  const visible=files.filter(f=>!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter);
  const help=$('folderFilterHelp');
  if(help) help.textContent=(filter ? 'Folder aktif: '+filter : 'Menampilkan semua folder')+' · '+visible.length+' file ditemukan. Pilih folder lain kapan saja.';
  document.querySelectorAll('select.epub').forEach(s=>{
    const old=s.value;s.innerHTML='<option value="">Pilih EPUB</option>';
    visible.filter(f=>/\.epub$/i.test(f.name)).forEach(f=>s.add(new Option(f.path+' ('+f.size+')',f.path)));
    if(old&&Array.from(s.options).some(o=>o.value===old))s.value=old;
  });
  const b=$('bulkfile'),old=b.value;b.innerHTML='<option value="">Pilih EPUB/TXT</option>';
  visible.filter(f=>/\.(epub|txt)$/i.test(f.name)).forEach(f=>b.add(new Option(f.path+' ('+f.size+')',f.path)));
  if(old&&Array.from(b.options).some(o=>o.value===old))b.value=old;
  renderBatchFiles();
}
function updateBatchOptions(){
  const op=val('batchOperation'), box=$('batch-options');box.innerHTML='';
  if(op==='/bulk-count'||op==='/bulk-replace'){
    box.innerHTML='<label>Teks yang dicari</label><input id="batch-find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="batch-replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="batch-case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="batch-whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="batch-regex" type="checkbox"> Regular expression</label>';
  }else if(op==='/make-cover'){
    box.innerHTML='<p class="hint">Judul cover dan nama penulis akan diambil otomatis dari metadata setiap EPUB (dc:title dan creator). Tidak perlu mengisi judul secara manual.</p>';
  }else if(op==='/batch-unzip'){
    const dirs=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    box.innerHTML='<label>Password ZIP (default)</label><input id="unzip-password" type="password" autocomplete="off" value="taiwanandnorthkorea" placeholder="Password yang sama untuk semua ZIP"><label>Folder tujuan (semua hasil digabung ke sini)</label><select id="unzip-destination"></select><p class="hint">Password default sudah diisi otomatis. Ubah jika ZIP menggunakan password lain, atau hapus jika ZIP tidak dikunci. Daftar ZIP dicari di semua folder penyimpanan, tidak mengikuti filter folder EPUB di atas. Mendukung AES dan ZipCrypto. Jika nama file bentrok, file berikutnya otomatis diberi akhiran _2, _3, dan seterusnya. Nama asli tetap dipakai jika tidak bentrok. File ZIP asli tidak diubah.</p>';
    const dest=box.querySelector('#unzip-destination');dirs.forEach(d=>dest.add(new Option(d,d)));if(dirs.includes('Download'))dest.value='Download';
  }else if(op==='/cover-meta'){
    box.innerHTML='<p class="hint">Hanya membaca metadata judul dan penulis; file tidak diubah.</p>';
  }else{
    box.innerHTML='<p class="hint">Tidak memerlukan pengaturan tambahan. Setiap EPUB yang dipilih akan diproses dengan fitur ini.</p>';
  }
  renderBatchFiles();
}
function selectedBatchFiles(){return Array.from(document.querySelectorAll('.batch-file input:checked')).map(x=>x.value)}
function updateBatchCount(){$('batch-selection-count').textContent=selectedBatchFiles().length+' file dipilih';}
function renderBatchFiles(){
  const filter=val('folderFilter'), op=val('batchOperation'), isText=op==='/bulk-count'||op==='/bulk-replace', isZip=op==='/batch-unzip';
  // ZIP extraction searches every discovered folder, regardless of the active EPUB folder filter.
  // This prevents archives in Documents, Telegram, or another folder from being hidden by e.g. Download/Novel.
  const visible=files.filter(f=>(isZip||!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter)&& (isZip?/\.zip$/i.test(f.name):(isText?/\.(epub|txt)$/i.test(f.name):/\.epub$/i.test(f.name))));
  const list=$('batch-file-list');list.innerHTML='';
  if(!visible.length){list.textContent='Tidak ada file yang cocok pada folder aktif.';updateBatchCount();return;}
  visible.forEach(f=>{const label=document.createElement('label');label.className='batch-file';const cb=document.createElement('input');cb.type='checkbox';cb.value=f.path;cb.addEventListener('change',updateBatchCount);const span=document.createElement('span');span.textContent=f.path+' ('+f.size+')';label.append(cb,span);list.appendChild(label);});updateBatchCount();
}
function selectVisibleBatch(checked){document.querySelectorAll('#batch-file-list input[type=checkbox]').forEach(x=>x.checked=checked);updateBatchCount();}
async function runBatch(){
  const operation=val('batchOperation'), chosen=selectedBatchFiles();
  if(!chosen.length)return $('batch-status').textContent='Pilih minimal satu file.';
  if(operation==='/batch-unzip'){
    const destination=val('unzip-destination');if(!destination)return $('batch-status').textContent='Pilih folder tujuan.';
    if(!confirm('Ekstrak '+chosen.length+' ZIP ke folder '+destination+'? File ZIP asli tetap disimpan.'))return;
    $('batch-status').textContent='Mengekstrak '+chosen.length+' arsip…';
    try{const result=JSON.parse(AndroidBridge.unzipBatch(JSON.stringify({files:chosen,destination,password:val('unzip-password')})));if(result.error)throw Error(result.error);
      const box=$('batch-status');box.textContent='';const summary=document.createElement('div');summary.style.cssText='padding:12px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e3a8a;margin-top:10px';summary.textContent='Batch Unzip selesai: '+result.succeeded+' berhasil · '+result.failed+' gagal · '+result.total+' ZIP';box.appendChild(summary);
      result.results.forEach(r=>addResultCard(box,r.file,r.ok,r.result||{},r.error||''));await loadFiles();
    }catch(e){$('batch-status').textContent='Error: '+e.message;}return;
  }
  const options={};
  if(operation==='/bulk-count'||operation==='/bulk-replace'){
    options.find=val('batch-find');options.replace=val('batch-replace');options.case_sensitive=$('batch-case').checked;options.whole_word=$('batch-whole').checked;options.regex=$('batch-regex').checked;
    if(!options.find)return $('batch-status').textContent='Isi teks yang dicari terlebih dahulu.';
  }
  const readOnly=operation==='/bulk-count'||operation==='/cover-meta';
  const prompt=readOnly?'Jalankan fitur pada '+chosen.length+' file terpilih?':'Proses '+chosen.length+' file terpilih? File yang berhasil diproses akan langsung menimpa file asli tanpa backup.';
  if(!confirm(prompt))return;
  $('batch-status').textContent='Memproses '+chosen.length+' file…';
  try{
    const d=await api('/batch',{operation,files:chosen,options});
    const box=$('batch-status');box.textContent='';
    box.style.cssText='padding:0;margin-top:12px;border:0;background:transparent;min-height:0;overflow:visible;';
    const resultsList=document.createElement('div');
    resultsList.style.cssText='max-height:200px;overflow-y:auto;overflow-x:hidden;border:1px solid #d8e0eb;border-radius:12px;padding:10px;background:#fff;';
    const summary=document.createElement('div');
    summary.style.cssText='background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px;margin:8px 0 12px;color:#1e3a8a;';
    const heading=document.createElement('div');heading.textContent='Batch selesai diproses';
    heading.style.cssText='font-size:17px;font-weight:700;margin-bottom:6px;';
    const count=document.createElement('div');
    count.textContent='✓ '+d.succeeded+' berhasil   ·   ✕ '+d.failed+' gagal   ·   Total '+d.total+' file';
    count.style.cssText='font-size:14px;';
    summary.append(heading,count);resultsList.appendChild(summary);
    d.results.forEach(item=>addResultCard(resultsList,item.file,item.ok,item.result||{},item.error||''));
    box.appendChild(resultsList);
    await loadFiles();
  }catch(e){$('batch-status').textContent='Error: '+e.message;}
}
const librarySearchTextCache=new Map();
function librarySearchText(file){const key=String(file.path||'');const cached=librarySearchTextCache.get(key);if(cached&&cached.name===file.name)return cached.text;const text=(String(file.name||'')+' '+key).toLowerCase();librarySearchTextCache.set(key,{name:file.name,text});return text;}
async function loadFiles(){try{
  let d=JSON.parse(AndroidBridge.getFiles());if(d.error)throw Error(d.error);files=d.files;librarySearchTextCache.clear();
  const available=new Set(files.filter(f=>/\.epub$/i.test(f.name)).map(f=>f.path));selectedBookPaths=new Set([...selectedBookPaths].filter(path=>available.has(path)));updateBookSelectionUI();
  const folder=$('folderFilter'),previous=folder.value;
  const folders=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  folder.innerHTML='<option value="">Semua folder</option>';
  folders.forEach(f=>folder.add(new Option(f,f)));
  if(folders.includes(previous)) folder.value=previous;
  else if(folders.includes('Download')) folder.value='Download';
  else folder.value='';
  renderFileChoices();if($('reader-file')||document.body.classList.contains('reader-active'))populateReaderFiles();
}catch(e){document.querySelectorAll('.status').forEach(x=>x.textContent='Gagal memuat file: '+e.message)}}
function currentFile(panel){return $(panel).querySelector('select').value}
function addResultCard(parent, fileName, ok, result={}, errorText=''){
  const card=document.createElement('div');
  card.style.cssText='background:#fff;border:1px solid '+(ok?'#bbf7d0':'#fecaca')+';border-radius:12px;padding:12px;margin:9px 0;color:#172033;';
  const head=document.createElement('div');
  head.style.cssText='display:flex;gap:8px;align-items:flex-start;font-weight:700;';
  const mark=document.createElement('span');mark.textContent=ok?'✓':'✕';
  mark.style.cssText='font-size:18px;color:'+(ok?'#15803d':'#dc2626')+';';
  const name=document.createElement('div');name.textContent=fileName||'File';
  name.style.cssText='overflow-wrap:anywhere;flex:1;';
  head.append(mark,name);card.appendChild(head);
  if(ok){
    const out=document.createElement('div');out.textContent='Hasil: '+(result.output||fileName||'Selesai');
    out.style.cssText='font-size:13px;color:#334155;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(out);
    const labels={message:'Status',title:'Judul',changed:'Paragraf diperbarui',count:'Jumlah perubahan',removed:'Item dihapus',images:'Gambar',matches:'Kecocokan',author:'Penulis'};
    const notes=[];
    for(const [key,value] of Object.entries(result)){
      if(key==='output'||value===null||value===undefined||value==='')continue;
      if(!Object.prototype.hasOwnProperty.call(labels,key))continue;
      const val=typeof value==='object'?JSON.stringify(value):String(value);
      if(/cache|chaquopy|tmp|backup/i.test(val))continue;
      notes.push(labels[key]+': '+val);
    }
    if(notes.length){const note=document.createElement('div');note.textContent=notes.join(' · ');
      note.style.cssText='font-size:12px;color:#64748b;margin:6px 0 0 26px;line-height:1.5;overflow-wrap:anywhere;';card.appendChild(note);}
  }else{
    const err=document.createElement('div');err.textContent='Gagal: '+(errorText||'Terjadi kesalahan');
    err.style.cssText='font-size:13px;color:#b91c1c;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(err);
  }
  parent.appendChild(card);
}
function showSuccess(panel,d){
  const box=$(panel+'-status');box.textContent='';
  const summary=document.createElement('div');
  summary.style.cssText='background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px;color:#166534;';
  const title=document.createElement('div');title.textContent='✓ Selesai diproses';
  title.style.cssText='font-size:17px;font-weight:700;margin-bottom:5px;';
  const output=document.createElement('div');output.textContent=d.output?'File hasil: '+d.output:'Proses berhasil diselesaikan.';
  output.style.cssText='font-size:14px;overflow-wrap:anywhere;';
  summary.append(title,output);box.appendChild(summary);
  addResultCard(box,d.output||'File EPUB',true,d);
}
async function run(path,panel,extra={}){let f=currentFile(panel);if(!f){$(panel+'-status').textContent='Pilih EPUB terlebih dahulu.';return}if(!confirm('Jalankan proses ini? File asli akan diperbarui langsung dan tidak ada backup yang dibuat.'))return;$(panel+'-status').textContent='Memproses…';try{let d=await api(path,{file:f,...extra});showSuccess(panel,d);await loadFiles()}catch(e){$(panel+'-status').textContent='Error: '+e.message}}
async function meta(){let f=currentFile('cover-maker');if(!f)return $('cover-maker-status').textContent='Pilih EPUB.';try{let d=await api('/cover-meta',{file:f});$('title').value=d.title;$('author').textContent='Penulis: '+d.author;$('cover-maker-status').textContent='Metadata berhasil dibaca.'}catch(e){$('cover-maker-status').textContent='Error: '+e.message}}
async function bulk(path){let p={file:val('bulkfile'),find:val('find'),replace:val('replace'),case_sensitive:$('case').checked,whole_word:$('whole').checked,regex:$('regex').checked};if(!p.file||!p.find)return $('bulk-status').textContent='Pilih file dan isi teks pencarian.';if(path==='/bulk-replace'&&!confirm('Ganti teks pada file asli? Perubahan akan langsung menimpa file tersebut.'))return;$('bulk-status').textContent='Memproses…';try{let d=await api(path,p);$('bulk-status').textContent=path==='/bulk-count'?'Jumlah kecocokan: '+d.count:(d.count?'Selesai. Penggantian: '+d.count+'\nFile diperbarui: '+d.output:'Tidak ada teks yang cocok.');await loadFiles()}catch(e){$('bulk-status').textContent='Error: '+e.message}}
async function renameByTitle(){
  const file=currentFile('rename-title');
  if(!file)return $('rename-title-status').textContent='Pilih EPUB terlebih dahulu.';
  if(!confirm('Nama file akan diganti sesuai judul metadata. Isi EPUB tidak diubah. Lanjutkan?'))return;
  $('rename-title-status').textContent='Membaca metadata dan mengganti nama…';
  try{const d=await api('/rename-by-title',{file});$('rename-title-status').textContent='Berhasil!\nJudul metadata: '+d.title+'\nNama file baru: '+d.output+(d.message?'\n'+d.message:'');await loadFiles();}
  catch(e){$('rename-title-status').textContent='Error: '+e.message;}
}
// Initialize directly into My Library (Read Book), not Toolkit.
switchGallery(DEFAULT_GALLERY_SCREEN);updateBatchOptions();loadFiles();
</script></body></html>"""

def batch_action(d):
    """Run one existing toolkit operation over multiple selected files."""
    operation = d.get("operation", "")
    files = d.get("files", [])
    options = d.get("options", {}) or {}
    allowed = {
        "/remove-cover", "/no-preview", "/make-cover", "/compress",
        "/bulk-count", "/bulk-replace", "/compact-spacing",
        "/blank-spacing", "/remove-images", "/rename-by-title", "/cover-meta"
    }
    if operation not in allowed:
        raise ValueError("Operasi batch tidak dikenal.")
    if not isinstance(files, list) or not files:
        raise ValueError("Pilih minimal satu file.")
    if len(files) > 500:
        raise ValueError("Maksimal 500 file dalam satu batch.")
    results = []
    for selected in files:
        item = {**options, "file": selected}
        try:
            result = api_action(operation, item) or {}
            results.append({"file": selected, "ok": True, "result": result})
        except Exception as exc:
            results.append({"file": selected, "ok": False,
                            "error": type(exc).__name__ + ": " + str(exc)})
    succeeded = sum(1 for item in results if item["ok"])
    return {"total": len(results), "succeeded": succeeded,
            "failed": len(results) - succeeded, "results": results}

def get_files_payload():
    """Return EPUB/TXT inventory directly to the Android WebView bridge."""
    try:
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        arr = []
        for current, dirs, names in os.walk(STORAGE_ROOT, topdown=True, followlinks=False):
            if os.path.basename(current) == "Android":
                dirs[:] = [d for d in dirs if d not in ("data", "obb")]
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for n in names:
                if n.lower().endswith((".epub", ".txt", ".zip")):
                    path = os.path.join(current, n)
                    try:
                        if os.path.isfile(path):
                            stat = os.stat(path)
                            # Prefer true creation time when the filesystem exposes it;
                            # otherwise use inode-change time as the closest available added-date proxy.
                            added_at = getattr(stat, "st_birthtime", stat.st_ctime)
                            arr.append({"name": n, "path": relative_storage_path(path),
                                        "size": f"{stat.st_size/1048576:.2f} MB",
                                        "added": float(added_at)})
                    except (OSError, PermissionError):
                        continue
        arr.sort(key=lambda f: f["path"].lower())
        return {"files": arr}
    except Exception as e:
        return {"error": type(e).__name__ + ": " + str(e)}

def bridge_get_files():
    return json.dumps(get_files_payload(), ensure_ascii=False)

def bridge_post(path, data_json):
    try:
        data = json.loads(data_json or "{}")
        result = batch_action(data) if path == "/batch" else (api_action(path, data) or {})
        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": type(e).__name__ + ": " + str(e)}, ensure_ascii=False)

def main():
    print("EPUB Toolkit Android menggunakan komunikasi WebView lokal tanpa server jaringan.")

if __name__ == "__main__":
    main()
