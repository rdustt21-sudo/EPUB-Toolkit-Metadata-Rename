#!/usr/bin/env python3
# EPUB Toolkit V11 - Offline Android Edition
# Batch processing is performed locally through the Android WebView bridge.
import os, re, json, zipfile, tempfile, io, contextlib, builtins, shutil, html
import base64, zlib, mimetypes, posixpath, bisect
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET

DOWNLOAD_DIR = "/storage/emulated/0/Download"  # Android Download directory, retained for module compatibility.
STORAGE_ROOT = "/storage/emulated/0"  # Shared internal storage root for EPUB discovery.
MODULES_B64 = 'eNrtfWt32ziS6F9hnMlSTGRakh9JZMs5Ttrp8U4evom7p6dtt5aWKJtjidSQVGy3onP2h+z9uj9sf8mtBwACfEl2uqfP3jPdM22KBAoFoFAo1AvztU+H7z/+eNg/PP7hdf8NPH1yp3dr3bVgMo3i1IqSs1A8JlezNBirn78G01Ew9tXvaZQEt1MvvVJvUn9iFrmdjF0/jX3fPRz7Ez9MT+DZ8hLr8OQs/O7jXz+8+3jwXf+7o09Wz7I3kjSKvUt/w5/Mxl7qDzdaG99FN+E48ob2WXgWDv2RNY4G3rgfehO/kXqXTvcstOCf2E9ncWjBGzdOpuMgbdgLu2m1ndP19rkVjCz4aQVUwPLHiY8PEmKY9KNRObDTdvfcNeG1CBw2lKRenCY3QXrVsOe2w3BthejgKhgPG1Mvhl43LURYwh9FMRRGdMZBkooi8iP+Exjd9McuImf1egRFK6ch648N3D9EoS8RuYr9UR+nqRFN+aFJ72SL+AzDj39kXx/LvsoXr+QLoxVFAG4YxRNqInv19ygItZ/DIKbeSBwcgYQj0Yz9SfTF7/vT2UV/AE9xI4lm8cDn0gLXCy/xm5Z/mwLCUeISZEIRXhnluXg0S6ezlN5ABaxsPbPsfhhxCy42ZkvIg+vZVBbVQGENl7+KojA9sm3/FmYwaWjt6PM4jYMQBu8jfbW8cex7wzuL63RtJ19Qh5J988Lkxo8BpyCErw37kz8dewPfCtJXVuNuI3S6lu0AMcbBtOG44wgKNxyDlgSER7DE7uwc+QgU33jhwB+P/aGro5VNNb9DWpdcwP05mL6Fv/qoNy07hoUAy/vXINQawolPcFT9tAFfXPxNpO9ojQ2iMPWC0I+J6pEfvD88OVg/+vB2Q31ygZ/YRt9ytcIoxXVFDeYXihfA9P/ojWf+YRxHccM+uQqAEQEXtK4A5TCyyhs0hiRrL44ipMLDE3cURxMc//CSeoez3DDx0vuJ9XAAoS6vUvkhYwtmIy5QN0xprjuVPMKWDeSnOte45Bj6PxeA+7UxvqoCDBWiawGSOMjyvXsJc2qPZuPxOlKA7Swd9TfRbDwkGKMgHFrplc9zMIUlBszfanw8futYBFsfeMk3APPKtg3MVYV70oRvAQIKG9n3SZAkMMGw1oAfKB5mojf0Ug/QUzRQUqyUaGRdnSFw8/0Qlw1vUEQKOMlZqX/Ax7E3uRh6vDNYsA8BelrlZ7TxPaPPOCjaJ9qu8H0Gb+KFwchPEEPevbBNWNTyvT7CyRQINF+QXuqlLmfBsFCKXuZmSzUt6GyliTLoRqxhCcggHvmyD0tpgkN6ekvL7VZtwrKEk1tYt9m6wrr2uYb1sJ9GBBEAzm+ZGoMhLAFLg55rGqBrJRcaZfD2Fwwlo3QK35AWS77SVgaEdllRG1EhLAvYFPaCaIr1G/iRkcRXfpwGfgJ8HeDYttpihGiQ2y4m/jDwTBj0aj29m/oFGAWWZlNn1oMJ9IYENsKpjJGp4XK94VBrDYe1CNcL7xoNO72aTS5CLxgzaBqZqWrFcb6hnYmfemL9m0tHvM+TuyweJMSfSkg+JyXKGmVIjsWOWdwQygda7h9crcdYlm0XcvPGCQWI1HH8vWQidYLSqwpquluxOqCoMCS6sGEeh5aEhrskCM62U4F4yfQVqla3nCMWQgSRztEQ9KimeTlpLuMB7Zc0CKKQPhfjILyumosYCEIbT/i5+lDmMIe6D0UcgDFfrydePFZI6qXyZRNlcls8gmRyjD/y4WQ08HnaJQkASCpHI1DKVSRnquifOO8oGPjbrh43/FwzUpL7kmRSedSqrr8ydy5BLeNG3AcapzIc8gVpgDPMl7RUaI02ueV1ipvTcl5dsnhp26OaGcYVtYjMJM2a447MBGjVxKeEaleei0n6wG1Oo8HCBFK9YnEcAsGHsxM1Hmdp1RCF1XL6CUnADdubwsoYeGkQhRu3V+lk/AwPVLBN4fl5A18IIlINUjU+LFMFLMw/5a80SMc+DmhWIHvFILuVi2tlmnooHRVoqHKJOmWymDubAhv0G2bzOeFKvFbMLlc4L2XRe5YaMxGSOiKqFMUXpNysnjiCqRc6BZUMIW52QTjzS9CoYVul0IuYZWAqjlj4TxrfVUwtVa8/SasWqqaYCgyD2FgcUt2U1S6vPKLBHBKhK2TKT9xLJC6EskTmKshetLqCySUuGpZ5l/HVJB7giRDbonmB38w2slfzqzSddjc2bm5u3JtNN4ovN9ovX77cuEXJYlG322n4AdwVOHxhda2gERSz1cQmnLI59W8H/jS1DukPcKpK0kmSvKoqj03F5OekwuKyW3kjKLAwFq3UUQ556QpLdCUuVViMv+eRolS9JCl76ZlByNekZcpJ3JVbgaxjDOBDRVR9As3zfa0ajYbYPPDnprA4x2WigdRBCNSwujlZrD2pnymspcvQVGf5XIlqZjeQYFRPlOQbDFnqWGXIqXW9QwXxKtMt5UAAY4/9S+iC0IYmUNJv2HZTq5LfUgF6cNu0ZnFATLJhDwfIJAVrm87iMTG24WDDZ8NSstF22xu20wSOCmtGK4x8MBhOR1Sh02o938DvVHA4AJwmSQVk+gYgnZX6o6GsdSb0b/rQHG9vaSQ2N1YOwNkmGsLPnj1LR+svAAuQxvpDfzD2YpLReifxzNeAkf5d2tjcD9D08MRHQ5sX35EufgiDkfq9t94YzSTJbAQY9Ww2czQt4Lo9abiQ+6NuMyHNfTrJH2ixQSkpwFfX1BkW9/ZSK4ECAkN9I2wE0Swtp2Z7EsDqRkm6TqqgwuEoEipXoGj81cgqV/AabNe9iYGGYTYaWKeZ6Wy12k1gSROY1STp44ue6tLRcf/zycdPh9+VNEALF5ECxBEoPrOpo169guVcKXUvV4coLGtF5jK5Lw8tW/u0+zwYnlB+SXrXkFWKeNI4q5Emu8jqM5RTkK9EaMIYNbjyB9clHbvwhqSug68uNvUrWtBKCRJKVmlkShXTMAqsnB55gBNy3cQCsoHBTv1L6NedwImsCQC8XOLPGRk1C2UZMbGx3h1E07uOaZTTK5r1RB3i6drAlRsiR0Hojcd3xQ00h6cCVIYllBV7SFaMSwlL5NlZ+DYIg+RKs0WKTx/EqHbtMhSlsTUOLhFRZbmZhYMrL7wsgntNw4LAigMkZiAnyTW0d7RaSoy9H6LU78KWDuUG0WUY/OpdAB50JLQ01p5YIEn5wC5m4XA3M4JNvDtlJ77yvqBBk+sq5HERFVv9REgNueyG0vStxz45UsBWAxsPrG7oLLCYRtYvBwhQe8O9ctaaa2+Pfup/+Ng//nT449HhX9lD5Iz+JUSPoR+XsTe9st4Gt9A15HvHd8M4gnPwprVhHYT07HIV5Q8SA/fAQ56FYz0OLizx/pi8SNgRgLR3fbLo43/kGKds9cc/QEJkA0dqiYFgcP/GP47xQb016se+m8wusMDZ2Wyz1Wo9E+UYDrUoPAJAqLpORBV2g8BKIf4neUqPooK0vjvSOyKZjVMyM51nHh8EDtktw9XmkL/0+K+EVdBc0dfciiqyZAlLdrPxau/RLw7+lxB2Gl1GH171Ts/W/uc//+vc4QE4O2ur7mHHCJJTA5mq/99zhwA+Q3gH6z+fn3rrvz4cpPvo1f/853/rMO+FI4mOgT8Q21rNtHHNvGqGqvb4b3EipJyLX0sPcTTtrjed+iGcKrGYY/jLiBKS0KdxNEDpgvRmDf0kZgpVkWRpPdoFXWAjcNhvCKlR8gU+Nf8QBvjxOypCO1JX12sRGtRU02pJduilIMmGPA8o8uA2ajf2pjhWF6e/7J8/3Xca7tNXTmNvY8rDuI8TAsWPrK/457MAJTgtgGqdCZ8Rdu3hVTnx0oGxK4RRSCcXWVG3p/shiMZNeSyEh3GEFniATWDcyziaTZPcQrH3bOlAgWdJVKfu598guxM/HWvP2myVe1RprTRahmk+prWtsSkJzfTg8lHZAWWhkZ7Vvl8jciCfQc3C/BFXY21KQ4wTWf2Bjz5Tw8SKyThlxRaiIcCzRhPnSEw8rT0xRU1FbCblNkQtl84sGe01JabKjQvEcPbhIu2FnGzeBt6iwwfLRWTKhkOIP0jHd4ij2DDsxJIuf9CF8RC2Fth1Yc0Nrv3YUdsJUZYs16Pto1HvP2hu7LKuGySojDKk8xFIOSgRCLjuVQTnJAf2NFvAt/FZQkhMfyRZuQxwDmlZNCuQ29tN/yxE2xsgwyBxITdKuLNL2E4piIPxOLrR9mgJKxKTkc2B9dlPYVu5TJrYUojcyPIuPRDcy53DND+miyiiLTOBTd0fNhqajT0bciA6GhpipjhQiECDDQ9Tl0+thqqJD7BAbNf+XU84vEy7Fh9FZUlzggmRMunMImCiz5kMBhhWDCHXPFt7D/KRdQdyNVMwvIxoIqZX0PsSssXexLNQjNzZmlNYx9mwZbKvtjpgzCRM5SzIx8uhf9ukHmIZP5xN/BiNFNRn9NMs9HtkW9ac6i1ca47laOgW2qpAdkUAaMjbxaED5H4gzoKdBr59J1Yyjh4J0VgZXUZzBzvRWflZeBJeoXSO6o2uzvSiYOArT8cRjQdwVhhLCzp5gbygvT7PMF04yK+sFhLxgDwYdV9I009QwAZqatndJVRs1AECHQJLTAWBtpGb44DwV2LuGUblkLnveqV1q31eGOHjsY8eqj51mXztRjTYqD8Ahs1DkNAizHitOAgx0eX47Wc8QQCXURKpN45gWaPpHuHyIVGSsyI2g8mKHqzCYOHQQN7k1vuDv1T7lKOsU+0vvtzF/H+DRzkIdpeoN2oMZjG7f6dR6o3h7OVd+OOe/XoWjFHxR0MPQG+CYXrV22wp8Q9Lk6Bz2xA123I/xtMjfoLNHz+LFmBHEgVbTlb4wkOjmP3Ytp4SyVI78ExA8ORnr+Mn8X69pEz+bB7PF9bpfHFuzbvbbnu0eGK7wJJAimlQ1/AoHTcFkk+tdguxAWG4h8re0XiWXOkqTVxiAv39HuNfYDuK1tFZFDVLjV+V47rhVjwqehXjJFX4EJfpFcvNkCOhF6wA5OROH9KWuKrjrrIaLnXdFRrYzM5X6vhq6OPrrbK6Iz+tMNkKnVxD7o4CQBur8rCBORWRDy4p08+NzZeA6CNbUJKZHr8Iw2GXYNxNlJihYcdbh4wU8IZ9af4xzk2lU6hpDskxAQp4s/QqorVhZ/tq/dThOl/V3vsFe4reIVwGFQ/CIaRsayLIPeE1wVYaBqBUTvQlT0eyL1RWlyE1kAMYKuCApUB5DPJQ1choYMWsUoO1s/oaRRLGK3OZtkjfw9otabLLTXCD6jRl4zhWP4TXITBq64Be4WETZkUxg5vYm/ZvoniYNAhP4KzBJFCqIvoi+2D6qY5h5SZN+oMTdHrexHnJiACrIhEQiG7hQIevHWufmytZ2EFYphmgRqVeAH845WU0gjSrAgVhVWr+NOgGqLRDDM5ZICSqxWNYo9XM0JSDkrexF5VGIDsNAzzf4ZAQIrA1kG6aAJVSLRVDYqLjtARQNTbLRkD0HpurPQ6Jcqq9THw1R76qPUFw9Bnp7NS2FVuZeNc+xwX1ky+XJk2actUnhuKhQjfCze4LFETpBJZEus4bovX5x++F6laXp7jlnk7BoqH2C1MYp5I4ns/z/UI+hH9PuzvnMEenMFWsDeC3O91zR+kdw7SfBL/imLXbOznQILlusuzyslP8tM2fnu9orLNPMW8IrPWyJQSGhlYNxFoH9v2s2adWy93RmW8fWWJeNRqIBWmcZhikzoGz+nJm7T1irre9s7X2dutszbqDp/kCHgZjL0ngB1U6W9ufL/Y2sOy+Elj0Dj2jngQ51Ntup4NhaimKnMnAmzJSakExafRLppS/NC0Q6U67nXOjuBoAA/mtMuS5Rin27ZcvWog2oLmzVYZj9cDqaEtCkUotQApoH4XsEBEoehJ1Wq3WBhQBLFlqBeR3Wjj0V35weZXC7872Dv7+Evg3ryPsXQtOaFjIEl/QpurHX/yDZOoP0k8oLEKp2/fB8G/wf9gl/BT6jBrfPViXCT8hul78fewNA/ISGUKVC0Tjto1N4PDJh9sOYoVvxANDgLPAFI5UIxAXRUF8sz6IxlEMLx63n7e3O0ArG2XF3a0XhQqbw8329nZFhXahuLezPdrpqOIbZo+qe3kJR7sV+tlatZ+jF8ORN1wZ7eHLlxfPX9ajjT+8cQ5tEItWRcl/efHixXP5OgLBMEhxNbibWyvjWQWjlaFuoskvpfabcB5GaaJRNq1KRdf0SxT/IQxSXCAzIOTP6P7xMfwh8WV3B0E8QKMfEj9WGtyJB0QUKAAVPGOaitEIfmn9bWvYiqZk7+/GPj26/p1/EUc3c2RV6yNvEozvugcxdKyZeGGyDhgFo136iHysu9ma3u6OfYS1jp4qGMXW3oR3iET38Wh7+MIbLggysUQD7vc+LPrAa2pAb2g8uhdAlVorT4YZxNHohX+Rb9Ldnt7CiflJxmGxReZFq3ZlS0MbiPhimG+E2kC4ycQbj1cF29kqjtAL1ZLvDTZfegueE56GvY2ML6EGexkrFNM9i8eNxxeXjpri+9ZF8sxq61TW7rxsSULbJjhIajudPARclPeBsPVcgxCiggzXVxxd+0S+wAG9HfVqXXZl0yTqzRf3aHHz5UNa7JgtdjKuTKdgXNvvYRPabresN9CC1d7stKwXsCW1n2+Jzam9udmy3ql9ynrHf3/WlqvcISo6lzUFwoi1Dc38ub213dI7wJMAS8cp9iFjdSVyAQ+QFAwECwB+c2ChK9LfpHigb+fy1KDJTU7J51MT8S0YEsR8++XKiO8Q4udlwHWZp6Lxks52Ott6b2kxQ18t2Uu1drDa9gs5RC90oWTrhcG8O1tbxIAlS/5Gkt4uIzAYNhy5TSAy8fwjPRPZdWApAT0AzesvfhRdvS862yY6zzN0UDjLJqNoMWRbYN6OJ89AszD4xwwdQ4SLIsaYSBkc9jo0W80zDRQ5w1aoTlhroJdc6N4RTanRhxMnJ3XoOLppgEshTGzWsGHTBzgpzxfr84USiBkIA9X9L7mVzI5qmOJlt73hUOScEA5Qyumah4FPhaUnQgrergg+yAWAl/qr1eVNQM+3RLg3Zo6E98yrQHEF0n8z54wvkMeYbD+k08Fwnc+sQEW2I8PosX+c3aSsmG4af0BLtyLsaGlbXFDrPbTS0ZxjiW603laoPh80HkBp1FdJbaGzHOFiHRORMGfdL+3P0via6QN7w6N53/7ka9X3SMsnEKKfREOLi8+xivKQ+yzxQJPMcyX5Bx4GWCQqKEDVwrgfiLGK9y7ALslygCooFQogX+iBHCulQmADXqZwlQCaqr2masgw4VN2CZlXojLXkSxQkfCo1ss+z4YC3EHym0yB0EQoVI6xrFZ3mqt6eOJ+nl0IW2EjGxBOlSFSZFCkR9Oa4z7VVahiVAAGSHS1hRX7Y3JsybhIU60a1Fu7OPF6LGhXRHbhviyjLbWsCl0z5cHi2zCfLkd8ujre5dGii5zFi9IdLI0pMhcM1akIKWILBZeoTjigJQUoC8DJxQYRtOqhVevFGFrCBoeWEJATxQGwHMyUkcrC2HDJUB1E5jj1MdwlQPcNbB75CIhiid8IIvf1XeonRx8bxcwxaD79gtEtvYZNy289TOxmISJFD5fpUTM5W1FpAGZdHAsPdz6aRXM0zBhQqa1Sj80rUklpKNNKJGIEM2lEIkOZej25CMpc5PUYpjxN8McgTGBloh0FRkcSSGHFYVu86MQyU+uOtWNILWEES+X3igRiupOZ2zTlbz2nqouPzdjAP2ZR6udbRLVwL28jKZOL8wp7xA7F9b2LGI4owm2xoK8mIpG6ak2TbrTQaRnGLHG4/LYGlKq+Q6p6Hf6tgvwKpsMCRBKcCjhcunhmU5MGp2OctbO1V/t7j777+Obkb8eHNCn7ewShWpvOcbnkErPGxbronWaWze+qqKEce9SuH3K9rvYbGgUWsr9HY7Y/pz9oPqCfe8jU0GczZjWqQHxDfECSgLeoukcehmdwZnXwko+eQ/9LMBDn0CYMZZAG3ngdxnns92hYABQpySyKmTpbo8wCA2AHa/vYz+ZFNLybzydefAlHndbuFI5eqG9r7RLIbrvVerI7CcJ1Prnz78WCa6G3JPrKhsOu0MXskvpX6RyrVZeLhUukBECiW1T7YaMXQAGw9cKbXVwZFGxMERPBF38XS4+A9XSvguHQD6vx+3KletHeeWK9fGK1O092NVyZJ6xfCr1zo721PfQvm6ILVutJU5gSrO0OPLOdAJ1nnji7jCIqNq0Ezn9D67H/YvDypY8diuKL+Vwh7l1AgVnqC0R3tr/c7Aok6Xni3fK0dbe2UCWMv8V3fhHT83oHOphG0+7zJ7Lxjmo8vrzwGp2tzWan3W62d3aa7uYLieM6dm+WdLdpwhC5rjdKccQFDXXRCrpbxBdZLgzklmqvXdNep6q9eDb253PRIcBYnwA5Zkx1MN9pGk26HX+iT+picdWezzWtsLu5DSVw8tRku53Obka6lSSzjvyl64V3N1d+nKdRwJV5zjqjzChsAgailc1a5HFqNgEvBYZx7lruS0B3o+1uWwVVd14V38auS6xYka5Bh17C54q+LBaZEpz5DC5NWPP+AMfCQvbVFUufFpymxxO/9/eGwRf1EugEX23AO/MDjk725aq9T36rfcnP4IVRXBvTrNa0xJRKUPgngJlCUYE7PHFfKBFKzlDc0zcUbVNy2PGVf/SyHU+85nZ62k5VonpTMQ+cJ7Qksylt0Hgcw+yleAAr5i+tS0xaImmJZKJnZ2FpdlLXWinNaHlO0ZXyiuZzi5KgOGySSyiFeYko58l1gs9CLO3ZWX7Yvq2FOKeTaUWEs/wN/EYcgFCu1oc9cTFowm+MdHGwKDJLr0z0dyDNHHpQdlYMSaWw5yY640Y38H5ni+Wrmjho5UTaEu6jVdHGTRVwnNn4Cb+cK3h9tK4RgFwTtmuUq4rfDUhpqUbhCOOyjYoUz+vDqgF5gz6on5UgMTRpQs608AyLIuY0g1hZfaFf9K0aDMbgAmWM+16axhJY9kYBzZWToLN3NZii253fT+4SkeaHkNRfVidEyk/DSqHePDpZrLo+/Cpavaa6EW/9a1AabV3jlXUPVL47fPvu4OT+yNQF40uYWZkxHJrHvZfVaQl5ZQXVKysXgq6doeDcswoyTs2KNjhIe1UkNM3NLW8x34aFcBgva1xybwxSl37qlhfDkfmL77oFXl7H9f6QGPwDRhUdQNFNEAUTjsSvirhXER+IR2ZGwS33kb4GLVJlYKGSdBM5wn9UtghX7sJRSMgLx1nRBpoBZwPYNP3CHFBgPYdZ8siLrf9h8fvLQ/cLUftvKMQdDkL+ELZlCi5DD/W7R7mwey7HzsS2YVozy7HnLxYxFAtGTvUsE0BFEgAavRuP8+xkeQDWmmtH7w++P+y/+fj++NPh588fP/Xb21UhK6jJe3jACjD8ewem/Pvx4ff9//PDwbujk7+ht+X2WfjXw9fHuVfvD37qcze+O3p/+OHz0ccP+AX9SFRoizfsTwMUOhrlscXknH189E5qLY+Q0zX5z8dpUowdzhUwo4+PCEgh7JiI+9MsxP2dyfts7ZiwshrQtiMTIcFJEHgRSovWUZiFKjYpGtg6DoCqEx/ZEAk+NoOwm7IeyKoiYhHj7lLM7p4MQF5N9Rg8Hhhm6MDbhg0ly3RlV1LDlKaEcFkwl2Y0uxvBOW2b9yNALXUbhGQN1LKIwM6kofyoGu7G/Cycjhsos12gwjiLvXW5xF98f8rReZL8qTGLSltwfgt9XHpwHBeqLOuGcrH74RhOfxwTRuyq2DgPStmoKZ9lLCJSrTds9+9TSmoHf31+mIb898a/mBo50MygdEpd5JRRKm0yNEAukoOuNydphbYZ/OIPiywOuDWKbA3+jtn2kr4HKxSXni1bJZ1yoWTYH8WoHKdZtvYLkdz1fTAUtjCEcoaR2Y76IKiGyRTPHtxcWSUXF3F+T5Qz3BfO5iC0MgRxaJXWktl0WppnO19fTRxyHpyn4w/0B7lORca6pT0eUfwa9wE1Kjh4JSyrLAUU1VFZTBqNkmrNMliOWELuJz/xJrA8w0v33cGHNz9//JwfQHnW1sho+TChPE4jVJ63ivGeoDOMGtBP32OEn/2uLguqfUABaVwdCPACCDGpzT+Z6YckTbnAF2Rr2Zg3rUZne7tpyf/Updv1xtMrT65yRAPZS+iPYSuuSxiZoQJSRIJnT6rPXCZllBw0RSfXPWqiLjGmWCUZzAedQSSYMkyqqC3xQLBhqmhaPN09uRr+MQNRLL3r6dsybkqwn8EY00m+qeRqkDvzthMVl1VGT7jSuvfCitdmrnm1wZSffSqbpxV+v/apSjYqumTSRNPrVTTs7RSCjhg9ciFjgEhiFKFVsvC04irGSL3CrB34pip3peRNWY2mpc1ITX7RzG5Zzt9EgqKr6KZfGeMrFVXHooCK7+1smdv6dwEIEJjvyUpA+EJfH1GD4nbTK5igmyi+pkQAuDVLeQjoOYlwl9b2Z4z5I/XUXs/S85lInZVwyoHNYMB5OSkYXQTfUqCujCCWsXABymGioIwJzgUbl0QZi2qFyGJ+LyqAROwm6VAdbnOBxZvDxROrMV9szBeOUsJKCzfFF4tuNC1z7J0ifIo5bqwUb1yGVWjceFICNifcoXLSzL1WIdj9NvdYZQSOp1qSNh9yP1WVEvh/4xVVisVJypcjAcwGN8SSwRVSNEvmCecuovm+DkB6KnkPPHHIInj2EgZGuIEu0z8bGTfFYhN6b5Vlc4nyW1Bbhf6bMZGUU1Bul0jVD7jSaxX31JVdVLUgY4aJ0mumc6m5wKnmYi/K/zeMfD5ajjE0eRxc+8BuM8XK6pqsLHfpvZT4RIV9kX3PsB1UlVXUlswmjUbbyGTMgxMYx1dKTaxOY6udvhyn0mADvOCY05Kh3g+YMmlQZAeAKwNe0yll9xFiFqcMRK2gMpjpnW4a/XIqjBhY+K7PztoPsWesnkU1f0lXjRkDGKqEm413TXk4U6rB6UsZVAJZaWKqzQIF0DXiL2oIhM5c5WMr1T+U6x5q89YLiEtyw+dYqukVXJpdWuOpz3qZdAeiAz7LHi3JW69ZtfCxuvCS80MJ96/ugikNmoScWwn2GzELsLaqJhuRV1mNf0sLmgQsrWXKLsU/l1SSBrfsx5IKhvlMVjReLm+xCMB4uayfD7fC3cv4pg/sb2SCkyC/xRC3Elr3NceZiH2rUU7sOT+ik8qdTC0mcyfn7EzmMms10W7GNYWLsu0skWpWzAy9gkWq0hpVFEWEYI3Jn1c2RsmrinLGqMz29E82UFVEHChbVLFnNTPXrp+5nBmrMiF10Zh1j0TU1Umokb6rTg5FJJi9096F5c2jx3oG7A9KcH3EW5dujNMUK2R8M/bp0toK+obYEbGeuTmW1OOtmEamaz1xOyPr/WsM/m7oG/2G1Wi3Olukf+hsOU6dDY9c8gxIueGuByZHVsChf3Rg2bxXwJEKFjHb+4aWRTRyQgAoeUjsD2cDKHdxJ5uxGk/c9ujJE8elBnVguSablvkx11FOq1abDfyEDDlq7IYB37d74cPs+xaF0/rxri6/cybMa9SL3ZABzZeEgot64nHGwIlFhqKYLaivf3j3l/7bow/f9T8dHr87eHNYZT+NM/Po35MoLNpOyQiJHs8u5QWJpTHytZf4fz45Of7k/2MGnPjPXjgco1iF7z5TyXtbVk8Ofzrpw//ZXvAZ41ltdZUZPtBfdZOZKyJ2XHGliBsObunvgBR7cO6+TVmgh46JB05A8OXSXpyFf/74+QSxaneeuy34tw0oHH/8hO9ePN/Zhh8H3x+Si/mjYTQgrkzOh8Ak2Hdcd+yml+hziQ/ljtzZp2905Rag2Gv89Wx8bVHy3n+TfoHSoRwLsT8oPD0td65ewCdy4K7Nx1BwCW/v5BxhRx38VzquttttBHzV1n12n5NjMwOyWhZAwDJT6W+ObtQtq73Fr4G9h/5Y9yq/uQI5J+df3EbfaIXTVtZAG/2iWwiIch/Oh6zP7VJqcS29RPt5vo61zQiQuuyURCdU/J03E3/sD9K55pWsgXmh40Eeznl36ccvXrzIYZ8bQ+6gOYKiUc2pfeuFGCCSJFTHRmP/dhe2+stwne/CGlCq0t1Lb9p9ifkyyrvclsPE4FhJKPrYwX5Ip+0Ot3oxS9MonFf1fBPA0ZyI7rdyPX6eo5rO853n3lD0mfuvu/Jnfs8v9eaBE8F6GXrxnRF1sL29jWUec/j4nMCRX7XfBW5JvtJVntMGJT/Hf0smcDAYlEygMevaPL1smaMuyF3PfsIf0KVcTDr0oAJDrCqdu+lR8Rpyiybu09Z5gTeZ7mb8AL5hken+m6soSjA3HO8+IJCe/HTC0goxesqhnMuW7KInNlbXXbppeTIjsqw9WmSoLIIvtG2s7b/N50ne26BSogYTNmf2ETX2IjL5cGbAHtpP9t9BPUpTSJevuYAJlyHHcAQgoDFdZEkpJH0AZxX+7lwCMzOEg3EwuIZXiBRhCUeItf1P/ggI54rHAgX4vQ2uI5rQOy+SXgjsaZCUXzvNjnxYdcTCIY1YmBskWo1yjLCMHrgDv7xZGqEsQBdLna1FlLGIpvyKkIJ3J2jHoDzi1EaxcSHR0wiwZQAPaJV4qOL3R0XAJ/0G1zLQUZEIyIhwOLVWB16iNUklYO/CtCNv0N6S+CGGe3zxTbSXw70B5CoA/xU/ccpJTKh9X8ixf+nflkP+IUEZ9BIkoNjyb6UgZzYgCLqaeAfArNL3eEOBoN83+ILvLPCTHO0uhSZm9WA8FmuBKQGoXIe0Ml0DAGTBZpewjhgaSu+xtv+ZeYBHa64pcmujmgGpQ+a396aW0TW3ZJmxJxk+ov01tf5E17davX0LBLcZEhweFEXE6Ou7o2EjGDq7UHwEJyjiOVMv9iYwkHPCVRiY+Qff8Nv9U+PszCZOdQaHdc5sqr7DviG+wyorfBejy0XkAiqUQhrvK0rmwkT3WJLoxx/KskS3FCTJ5ZiOSwoSGcqGkSK1MlRkgcOAu4uX3IUDSw2Ixhx5GAQMmjoEgnP0RkqtZ7bOqYl9AreG17tUN4WdWvaSJijueTdekFojdGRBwBvE4RHwrlFwKArGJMQ3cl+TnjEru1biBmHox38+ef8OkVII4Bmx8Wjo8j4y9sNLOLlLlCyL7/VE5dZH2l4Q6IeosEUmnAIZPjYZuKPwWeBhrx6gQe1lMCxLIgic+dCDgRn19guQRs2Ro7Ur/vI48E5UMjtv+R4KCx6foRsa/trVq1ZP7FtyZBIVteF7Bq9ohDbk8DQSx7VELzFdBib+F+lsM1JYDHAZN3xnvqTdN+T+yOZBjy+9TrgD/u6inGYTympFz2JymUymPbm8GQekhSl1ZikWIu1/os8ddUawiHA2Hu8uDKjhcFWoguHhDg1yEm7/BNrkJCPgYIh5scEljfw1ijE+4J7rEAeYh7A5Z3ehLiIMR2UkWZQ6/TjpzmmCqKn1E9hV4CcW05NSkDbhzF5QUHH33z9//OByWH0wumtMncWKCx1HNXaja+vrV1gePqo4HdgZ4uiGldGk8xQfvn6FBoU+Qig7dY4iRnB4T0Jkj2mmPHcCm7V36Rdmo4QazR1ap0fZV6JX5PJYMsMUujx0ls2uACyu+BDrkwA9I74iL+I6GrGztci1BU+DKMb8bE3aWrWdXpJJSVd08WCuiB06MwriCeL5hiw3eBUIzAltAXwd6pUv69I1sK+sE90DWhQcj4UGTAUBEFvkId6tGTdtK9VGbr4CXxND1ev1Wq+Y15N0QWYOXI4YlcDp7vG2QOGPyuiiZYJ6S2h2Fe9GVilUx4+y4ddk3oRUdTVT9Zl0il7SFa+wGDctKZi7r23NgpTFrOU+wBlJyUUifJaPjkKJZRvJtUVG0wbd5cACmCmRNDWpo4mZ3/okUUj9vTCMqOq1yehLGSBSCx1eR4E/zhTmmYiM9zJJ8NiewoHDIGNfxgCrUpmCWJOYtCTmOmhbXsR34zReddlpS31+ZtnwVny2c9nq1MVsWYWm1SKLvDGCCs2j7z98/HT45uDzoXJT43vj+Mqy6tvmdM/H/FVzTev+l84VA2mrW1hPgsusFf6lD+Xy1nT4mDxLZeHiIRBWFe3qYzkILLA0pSeJ4ZQniwr/r9SfVPruae4helZ9WY6Sk8imyC6NfnyCyUgvPmmLyvLBcS64nHkrS7rfLU/lX9royJ5juwvVaH8eLubQ6sLIDFbMmKjl3DevLxxlLmNNmR+5qfPkHk2BEV5T4fOIETSmf6AILKFbwFDXnnddo1AQ2bgdX7Bdd1TImXaDC5s9fvRr9uTlgjKXC16xqK0SqJe7RkpeUr9iajal+RIRTux69sPJ2/UXfHOobWAzI7cMvjmQ7+ZDNgMbp7pi0ERHG2Q9g5wAZLoCm57RM+x1LkFdxMkHikukeC9h6eWBHINdvAwxm6gI3cjtm4pZGgnHW7lFi0QJcm6c4qVisiORCgCUxlvhlpl53sn7BmocHqt8HVe+0zvvW1YXK6+Zq9UiMMtrawFbzlmuSuz0y6i5wpfEJGuk0hLSzlI6sky4MpUWMyg860kolf43ObqWOFEsgKhb4/kipmEphRYILBcywbQj75rQ7yHPmFPFChRkaK5AddsNBwpoq2/JyiulWbGW7DL3U0mxjC67UvIF0GYXl1y0nkOYV9lZSFo5S1hjG+VGWlwa2QWw4+iyL441DTjnjprW074XX5r3Z1PsRVYHJfA+HdS4BjscJamXzpJep9XS66LgCQOIpd3hbDJNhIMjSEWz2O97ySAIehzEUZ1+BZtxqVUQsKZwGgBcqbXSMnxMbRhHVLT85s+nu8pIW9NgHtg7Un+gowVMC98uOLwz3HZL6nqwLNYRQhyRzTqM1tEW7heazGoZ1+fStxuiMebD1Kg+JcOo//3hCc2HY3reUF32XkcbfN5dTswPGrurx79iDnCqqwpVTQIlHcMzSM3of+sMLBvOuiE1orJyY0daqPwAlidwhA0Ez1XDAFrW/SCaHMDRj67LItGkulm7p1W/7Q2A4uaGN7TqMB19xwoSEvoMAdNEABMKI7cuuTKuIe5zle4TjnPON7vCUHPpEoSzmSKWMBeKSLtrme3aYvi4h4vy3JUq9AtZJ7zrrtAeaX8ALtIDVHEWTWvboMwSd8wMCNVubLW28usJtV71C0pFkm6QsIPDtiF2nUJMaXmDdSmXioTFqlcR+UUABXFzos3CArFbdn5ZiA2Y2DHdkcxwYloIJBkJ9Xj+fJmDk+XBUZSHsU+0QdLhke9BxAsT6Rq3/Orj+01zByGTXqqlM9Y0CAQox32ap3/zBFl/EshrefkkkFnF1e2rdj0qq6yn1TxT1RW+uE4z+4MX+1mMRwGb7LJ4Q6Ojz0Y45NmgFGhj7ZOpqbCdYolMg1L2lfQwxegVXQTrWXpxXiSETMkmJb+zysS8/Vcdx5pZpPjK593KTUawEl7HXdmAzS3AC35YFFUeSxjWKsxqC5gV3dD7/vjgzUn/3dGHw/5neDz68H3/7dFP1Rf2VnnvVadC+RZ3Pqo7i8fj4MKl/MiyMv3o/+P+uVTQBa9pCae7huaJ10QXPLx0D7rff/MZfQHROXfjKa+Kd5gr9jOnTLTeBrfW0w3hxyaMtnpmSKvtbm5bjxhXL0ylkht9cFzKOrt6nakoq7kmWS13y5/kyqoSIp9laaEFK2Hv42Yo8sf+xg6Gdf6FNN7HHkxi7E2v9EH349/e0dBwxNocbY12pG9Up9Vpd7ZKPBGFP9zEC8J5lkd1p9PS3NygDHmomPBHIwWlkzmtKd/CLXoFXbnyhtFNt2WhfyA5CT5utVrs4NiZa5TQWrhXsDHPNW8uzc+LLrIyEpaSuxrpFFZy4zOdHdHV7kWGtKAzzV3N930Fny+3niP0brvGxUy491V4773MJz/d9l62Wspj8Tn+W7yHzHQOfFHwiqvw+JPzyih1YYC8i7E/nIubdbo8eo/5FKjPAsMsc/7LjX7NOLiXUTSU89jefL65ubkA8Ua9utjs7LT9BfvyiXc7Ozu6l56ZghWpk1d0Z8mKggLkqqf8a5Ck0L/H9Nyr9tazKMKWYyhgQ5pM0ztyb6HWEhIoYD8kCxbn3L4Aqe86Ef42wFASK8Uhgr1BVbNEelq06TMnu/DhUMJKH8ok7Fp/Q2QiMzAg9e70GAjdkVB5/iWanx93DV/+z3/+d+bfI/yXxI2LhufSKLjFm43JbQk3ggLKhgOTapjJBv3WgAOtjzEvyNnaNEJdn+HJN93fo0neF7FCKNixyodCvb1B2he3AIOUJ8YgJpHc8qZT2ATurCvvC0bbJxZemSzHEYY55aAqzAcEdBgHePMo5qUVqTzwMwwYty4HboPoSPN3WuK1w3ZTYGK9Kkco4T6Tud4oH4Hlnjq1pntpuK+31mteHkHCgnRi2HMLTjvQmbwtXLrqaD46uuOp5q8hPCcQRuYoJFuYeNNGY9QMnN7+fxgebtI/ld37hBcd8kQkRbHVchlB1X+aB3hVrHRk/dOc9So/fDrCIFMQZuH0NqJIMQfLQXFpiVauWeRPgf4T+6arKIPeB5DJQMHYu4glncoPlNRpkdEPe+IxYf+Hw6ct4YBEY525Q5QMcI0vjvKIkEZoRYuIR+LMhZ7yM1+pkDgqhGzj9N/29s/WAMr5xmVz0NtvoFfJv4mukwOz8JLak+/GqXy1L19dqlcEit7hHQn8do3e08vHmy/x3eJ0cO44uyVODoqTaCtnkK0bEIvjO/Zuwhx5ZzYHCND044Ccd7O54yGVPmo1S0+wIajRvKgrB0xPQiXPC2eeLPFU4m2iQPoXrtxIe2k883cxAwUQ+QciYnaYK0AGtgpTBwyZk9ip1H+YyS9ELiX9i1ZgHeiA+I2ORSDh3dzQRd7rcBbhlTXMPI3gKRS9eTZgD0vpa7QKu/r6FTjOMq71cerHekhlxrFy44lihPK+KhlYzV9EcwHReJd0F+HTp/QXobLIu6RaYPj3WZL6qrT8bZQ/zEsCG5kcwCKAEBoydyIgqTAHhb/IRU/9KvdKyRhKbkxAjCols1I/KyJaEU8614h3hPaC3WWOL7mk8dI4fjWbeCFdc9sIpT6GCAXt0AAruzwNFa8zOByxko+Sxf2F/vue/os5y0zVIIPZo2BBS1ZGjQYULbf3juw5Veq67dHCmmOFhZY2ngFu9AiiymmEE9MHmfd6NjW8RfS0UyQGkkChEq3M0OeGyAAEG50UsJ+TCBYHnDMSkWLyiMon1h6K62ovRGkH9h+KxcAP+3SzixAkMbgqwXC1wXiG8pww+15FswSz5lnRiJvf+NWPIz6oWdkpnKtjdnukQqyWKJjSVXA8BgQ5G2YIgjuGcoZDOE5brz9BwyzbUm0YIZIo4b3lUXrZKUq0fE1aSRJNocmg6170FzN2aMlSVphK2ZRdJqq8ZVb3xDFzmrXgf46ZNIlSD8ksUmJlZrZ0HMB+pv/TfJJsmj9cuxeNV73TX/bPn9IPmlB8Sp72+E/jlJY47cjO6S/ZD65AM48PhU9th8DuN9ynrxwmC4aIt56iu5P1Ff98NvTrQdInWiD5uUHSmJn+KrrwuSdoI7b3Hq2vA/j1dbpJlfLKhuQyM/Yuk56AXlmZ8RM16WtJabpFYhbKy5pypfiiLGQE9CW3mAeU51MjFhfe+JdRfNcYXJUrjeGDGyR8rxfnD/BS4xq/N7Z8zeznZ4pe/Znshz9P+WODUQL+fItsddZptS7oz04L/oz80ahC5czkRmbXAhGiXUqfKl5S+nSRnV+HG0Yh3Q8mKdNgiuZUU10XdQjTRqeAnKTsYk4XeV2uXcBXhyiXjViY+roQzga5vjQtzVGQ/R5DRTphw2686jIxA6MT5C+WUPJ049U+PzjzTpNvIad7rpoCkCLOI8dct9C7UB9hEI4nfdyr+kQA9xlfqkU5mHvGQLT1+zJASsl97uQ+d3Ld/mW1fj8TawpBNFlp3muXdLzY+dwcZt14xvgY0ygXcoPUKRk6+w7wHAfbNwdQTkAJQhkvMrwo0N8rZ/1uWm1KLYAoPMpSSLBJAji06I+jX1Qszvf9QZLUuHH+TruGnukXM9dWK5oopW3eS7cSFt8Zxhr4ygvE0D9SKuuf0V3XUiFsaw45LucIB5ZM6rFsm+D5IoopDpTi47lKY29yMfSsSVeg+MyaKDZQQwIqP0MOJdr8kbZWxkfVUBtMhlKGCo0HaQNxkCSqojdZ5+swNczXAgsJKBML6qlZuBtot2onSR/vZPr/iFTlFx6CWKS1xNFGQjRJlFKILhkmaVfUkoc2gWMnKXACijPqPthzcdULxE+D7M4Z8h1T2QbPjV32ARkaf6vsjCIrV1LIeLS0Pf0mjS6J9eo6DcrWJj0MRwHMpdEma7tLcnrqsyPuzczdYrXCJVaSj5en8eS2l15TJY/hmLIqL7CX+3eU58Z6yA1V5D2YZZNDIqtMJqf70BIF/TMTOeJFEz1L956o9DyF74Znxa2eGyZLEuM4S/xPYSCB28pZMc7RNRnY5WSC+FKTvVATcgZLsaD7WHrlgsNqmKAfEIGpzEOXHzdOj7PCEGnI5TaK3wa1mmSK/8qh+HvmUFQAUM7oX6BpSi5q+eJfyRf/2OSLS/aCP+TeLmEBLeQTtLz0W2/uWhmHe+U2LGDwe18LZl4HpidpW46onlsR51iXYqpdzlb1RJYZFdXVYDmAHz+vdlu86rcpbUu2b56J7x+KQG5yuH5EWAFK5k1SDcAzLaTlLvxG3CmKFlj9XoEFWPI+YQWE2cNCBzCG7Z8dOcBxc79B4ECGLE1Zp9VqUhTBij7+3+hfL73kT+dk77O7ImO2jXYd+KUZeQrJQmtc41FQdZwFu9yL3ODCEb/K+T7vIC/3yaI3sHAGZu/7Bp5rqryG+yE6gYylWKiciPsXYy+8nvbFOsveF71R0BmXGrpHYAD1/rzO4z6bai2gZ57z7C8N7vkN3P2p8e1C4wWPWmdV138CuNXaghGcn60RHHQXWPuAR07K9bJGobf3DAt4xLR8a6/YcHQNrZJJs1mHxT89VgCN7BSsx+69D4wUEMdGBMZN03ptWqc22pla56XWEenZX4gt4KsUHvVUiZp1JNfbak73UhdB6g/2owC6LOzUq0QuVEct3DNKAYU+IANKwiPQZB8UX9w+GkoaKeK5Yih84dY1Ffpu8BTjFht1VMyklPoBKVx4Wp4VukSzVj4mh1TelExzF+SQTCo6Bb1Bu7IkmaGPaeqsoEyvpB9jm5reZqkmcPnmaDCt6Bo4Fl8Plg8ywEhFgQG8y5CxBTYYnsBP8E54SsA7+6TSbRM24DrXzSVXsi7l5/eNhBDcr3RICDj0qyRMohyJ2kjWskDWtebap8P3H3887L9+d/DhLzLSYoUYi+Rqlgbj1S+cZW+Ce8ZE/OXw8Lh/9LaPd98efjjJW/OFrT6YXH5Nvlx+/RIM/eirNxsG0dfo4u/AGb4GdCfm1wmsq68pust8HXjA2hJH2jbyGUiODz4dfP/p4PjP/U+H+eYar473Uu9yv/Gqe3qw/rO3/mv/nPwEbtz186dd59WrqSOcC473UGmR7JMtxNnHF+R+w14B8LMHgBzTM0ChwWa57z6eHLx7l90Em7C801cUzUGaWcqZ3GBJW45eqtzcnbfkGB4CWiSoKGf6BuQsxsI1Qx3gbGGI5+gm4zVZ5Om1cYKi6tJYgZKwbbr6kKbTsNJobiElyWBgreDySXoq0Eq1Rx5erIfWLfxUShvnagu0AJG38OcnSjc22zigxW1YIvOttv6MSeuUrOcWyPBqqpHLWYyURJ23Bwks60xCsmNxFAHz7tfkUNGvjEPygwq81dI0A3hvNk5NqV9eSje4nk0pKpjED9zR+J1df7FcTkgVt8CVbpmutdLlcL/BTXD6hWpZcB+n1jdIVL+wSJ74Wg83uY1KDGPmzWerWciWGMeshtICQeFJQJcKOab5atm1csrsJI54dH1cztQliGqpIWpVQ5Nxl1qddQm7lynvwzLNWoVJSilMFYhmZibSqtdpUFkt59QbsmqTwRgLQrNmrazaloktVzN/1eWaqUKlNJb44RavbFUVdpTaO8WkS/Bqd4rxEl1+pZi50p/1ipvKPTKh/BYXC/1+anPiB2gXuoQO3DH45Zrz3GlRcHRm+GWTzZIpyG3Tu45igqJ4TgrnkuYNOxUHtHI2XX7Fj7yIRVXRVU/LLv2pv/ineDnPo9xtOq9R+NAdmiXZ2k2T1sxq6EK/8ZPmSC9v0NOu3+ErFJdcBVRxOw46muAwFA9kdKXL2B+l1TcEmYcywN8LwpoLhV7TZCNKYtrhmMM3sPNhZ5UY8qUHmmmUBLc4M+rNLcjFfhr7vitCVk7gGVfZ4cm9Tz6M7uFPJ+Lql8oLGS+DUXYxIz5cTPhvKj7A35G66gX/el/gy0KKcCTIci4nPJJ0TVncu3RjTi1oo09n2zldb5+T7LBgZyTvkn0A4UE7qfA9lHSNrE7ixG4549WV4ukC/CsG3zqXLx7LFwZGatQzcZKgYhYyRCgbNxXhEPsjRiWajsQKx3cSKXzGUw38KTRdQK4CF9RQc2/VK1L8ZD/VLbsCB0cg4VTGMQjNmRHNIMIB+EIkn4ks2QA4sIRA1kw4FJZXMS42LohLj1wWjKu4f1/ftixIoNICsOIenj+dZqfv1vrL/vr5Mzh4w7tgwudpdj98tfFKHmDz7sem02tZC9OATKqaMyMc2/c2tNfJ04dDL8Of5ilr71uQh1WuIS7cljfE21XxJntUlR457zOT90t+1c0C4+HHOnXOefUVpc91ctTkV19FRD3/mHjJtSjKmHZPf9mdL86fzmJyK22c/uKwz7UjPuxWdMUp1WoQ0GeATxIPvsK6TP346+04CK+7tA7z0R9rHOPF0R/qxzP84wIQYMOvLr8CD/4K/Pcr8t6vwHe/Iq99RbooZLKYO/f01eNzHcJT5xWFidTjrqtCCuZa5hfCeZ9vtjMu6/5Nr24PI9HEv25uD5eetWtvIl/Vx7X2BvI/2LeVtnWpe5grN1xpHOYuBHkRQAR3ZwdzsQeSyboaSBX/wSvudMMsVpYgKTGcBL+S7ZzUTj0Q0VzcOzktf0OdVtV2XXXCFjeeIxQXfsR1x2tN1KLb0FHeUookPG3j27qT9sQfBp700GIYZESk9+usLCCqsJ16B1JN7smg4AtZv/YcnKFhxGjRjG8Iiz4CW3JQ1qiJLvaoFNQqrOUn7jEaY1fz1tEbGwbJwIuH5Roa4D99ENZKnKnlb+8iISx1HnofbZbhXK34a4V7tUBnqVpLnOn6Mjdz6xs1XvdysP7tnaaleyUCzGauhqDM/tdrXe6nsKrXU91XtJV3ci5VU5W5ZJca0w0folqeWdNiOW9cyidXuOseaQPO/JR3eBU+ma87uArGlAaA9kKGtErdIs8lSPdnuhV8k6Hdg3HWM3MN3IO4eWFC8QLcVJxrs21YcFQcGeoHnd3vg/UK7B/TSnPrK6/esn94qqUejMZnxf4LR/9lE4/Z4e4z8Vi+L1iYPl/kwvPwmSKw0zia5sDiKz9O774BNOppBphRiXQ1Gf6Y4SBrtScL/e4TNIVzIZJDmAh7H07Kabur9CwLqWchdbsoYFDZHIZjJaIFAFlzK/QMGFvsXwZ4LqRB4mB0ipFXYJZ0T7BtgJRGgkGyFVQmbu8pk/TtZNwf+oOxx7lTqtIf31PkqXdWXiHYxNiZ/xV18ntFnfwreOSPDx75o21hQh8CHSlGRCyJIWGHNDOOhLJjLIstyQr9U8I/7hOcosd85C1xeWVQpcHt9zKx5e1LRaNXSf2PxtVuQY256oi09KxW0Yx1xpGmAjZlDrWeuJ2R9f61bT2xCg7++inV2rAalI3pKaVQUuEWWrcYIP1TB1XvdRHq2uL/AXyVGuo='
MODULE_SOURCES = json.loads(zlib.decompress(base64.b64decode(MODULES_B64)).decode("utf-8"))
MOD = {}
for filename, source in MODULE_SOURCES.items():
    ns = {"__name__": filename.replace(".py", "").replace(" ", "_"), "__file__": filename}
    exec(compile(source, filename, "exec"), ns)
    ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    MOD[filename] = ns

def set_download_dir(path):
    """Set Android's Download directory and discover files throughout shared storage."""
    global DOWNLOAD_DIR, STORAGE_ROOT
    if not path:
        raise ValueError("Direktori Download dari Android kosong.")
    DOWNLOAD_DIR = os.path.abspath(path)
    STORAGE_ROOT = os.path.dirname(DOWNLOAD_DIR.rstrip(os.sep)) or DOWNLOAD_DIR
    for module_ns in MOD.values():
        module_ns["DOWNLOAD_DIR"] = DOWNLOAD_DIR
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    return DOWNLOAD_DIR

def unique_output(path):
    if not os.path.exists(path): return path
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{stem}_{n}{ext}"): n += 1
    return f"{stem}_{n}{ext}"

def safe_file(name, exts):
    """Resolve a selected relative path safely inside Android shared internal storage."""
    if not name or not isinstance(name, str) or not name.lower().endswith(exts):
        raise ValueError("Pilihan file tidak valid.")
    relative = name.replace("\\", "/").lstrip("/")
    if any(part in ("", ".", "..") for part in relative.split("/")):
        raise ValueError("Lokasi file tidak valid.")
    root = os.path.realpath(STORAGE_ROOT)
    path = os.path.realpath(os.path.join(root, *relative.split("/")))
    if os.path.commonpath((root, path)) != root:
        raise ValueError("File harus berada di penyimpanan bersama Android.")
    if not os.path.isfile(path):
        raise FileNotFoundError("File tidak ditemukan atau tidak dapat diakses.")
    return path

def relative_storage_path(path):
    return os.path.relpath(path, STORAGE_ROOT).replace(os.sep, "/")

def run_captured(fn, *args):
    out = io.StringIO()
    old_input = builtins.input
    builtins.input = lambda *_a, **_k: "y"
    try:
        with contextlib.redirect_stdout(out):
            result = fn(*args)
    finally:
        builtins.input = old_input
    return result, out.getvalue()

def fix_no_preview(src):
    ns = MOD["FIX_NO_PREVIEW.py"]
    stem = os.path.splitext(src)[0]
    output = stem + "_FORMATTED.epub"
    if os.path.exists(output):
        os.remove(output)
    changed_files, total = {}, 0
    with zipfile.ZipFile(src, "r") as zin:
        for info in zin.infolist():
            if info.filename.lower().endswith((".xhtml", ".html", ".htm")):
                updated, changed = ns["process_xhtml"](zin.read(info.filename))
                if changed:
                    changed_files[info.filename] = updated
                    total += changed
        if total == 0:
            return {"message": "Tidak ada paragraf yang perlu diperbaiki.", "changed": 0}
        with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(output, "w") as zout:
            zout.comment = zin.comment
            for info in zin.infolist():
                zout.writestr(info, changed_files.get(info.filename, zin.read(info.filename)))
    return {"output": os.path.basename(output), "changed": total}

def epub_metadata_title(epub_path):
    """Read the first non-empty dc:title from an EPUB package document."""
    with zipfile.ZipFile(epub_path, "r") as book:
        try:
            container = ET.fromstring(book.read("META-INF/container.xml"))
        except KeyError:
            raise ValueError("EPUB tidak memiliki META-INF/container.xml.")
        rootfile = container.find(".//{urn:oasis:names:tc:opendocument:xmlns:container}rootfile")
        if rootfile is None or not rootfile.get("full-path"):
            raise ValueError("Lokasi metadata OPF tidak ditemukan.")
        opf_path = rootfile.get("full-path")
        try:
            package = ET.fromstring(book.read(opf_path))
        except KeyError:
            raise ValueError("File metadata OPF tidak ditemukan di dalam EPUB.")
        titles = package.findall(".//{http://purl.org/dc/elements/1.1/}title")
        for node in titles:
            title = " ".join("".join(node.itertext()).split())
            if title:
                return title
    raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")

def safe_epub_filename(title):
    # Remove path separators, control characters, and characters rejected by common filesystems.
    title = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "", title)
    title = re.sub(r'\s+', " ", title).strip().rstrip(". ")
    if not title:
        raise ValueError("Judul metadata tidak menghasilkan nama file yang valid.")
    # Keep filenames manageable on Android and common desktop filesystems.
    return title[:180].rstrip(". ") + ".epub"

def validate_epub(path):
    with zipfile.ZipFile(path, "r") as book:
        names = book.namelist()
        if not names or names[0] != "mimetype" or "mimetype" not in names:
            raise ValueError("Struktur EPUB tidak valid: entri mimetype harus menjadi entri pertama.")
        if book.getinfo("mimetype").compress_type != zipfile.ZIP_STORED:
            raise ValueError("Struktur EPUB tidak valid: mimetype harus tanpa kompresi.")
        bad = book.testzip()
        if bad:
            raise ValueError("EPUB rusak setelah diproses: " + bad)

def commit_in_place(src, staged_output):
    """Safely overwrite the source using a same-directory temporary file.

    The processed file may live in the app cache (a different filesystem),
    so it must be copied into the destination directory before atomic replace.
    No persistent backup is created.
    """
    if not staged_output or not os.path.isfile(staged_output):
        raise RuntimeError("Proses tidak menghasilkan file. File asli tidak diubah.")
    if src.lower().endswith(".epub"):
        validate_epub(staged_output)

    destination_dir = os.path.dirname(os.path.abspath(src)) or "."
    fd, destination_temp = tempfile.mkstemp(
        prefix=".epub_toolkit_", suffix=".tmp", dir=destination_dir
    )
    os.close(fd)
    try:
        shutil.copy2(staged_output, destination_temp)
        if os.path.getsize(staged_output) != os.path.getsize(destination_temp):
            raise IOError("File hasil tidak berhasil disalin sepenuhnya.")
        if src.lower().endswith(".epub"):
            validate_epub(destination_temp)
        os.replace(destination_temp, src)
    finally:
        if os.path.exists(destination_temp):
            os.remove(destination_temp)
    return os.path.basename(src)


def reader_open_epub(relative_name, chapter_index=0, search_query=""):
    """Read one EPUB spine item for the built-in gallery-style reader."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            raise ValueError("Package OPF tidak ditemukan.")
        opf_data = book.read(rootfile)
        opf = ET.fromstring(opf_data)
        base = os.path.dirname(rootfile).replace("\\", "/")
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        spine = next((e for e in opf.iter() if e.tag.endswith("spine")), None)
        if spine is None:
            raise ValueError("Daftar bab EPUB tidak ditemukan.")
        chapters = []
        # ZIP paths in EPUBs may be percent-encoded; keep a normalized lookup so
        # relative image/resource references work across common EPUB exporters.
        zip_names = set(book.namelist())
        zip_names_folded = {unquote(n).replace("\\\\", "/").casefold(): n for n in zip_names}
        def resolve_zip_path(path):
            path = unquote(path or "").replace("\\\\", "/").lstrip("/")
            normalized = posixpath.normpath(path)
            if normalized in zip_names:
                return normalized
            return zip_names_folded.get(normalized.casefold())
        for ref in spine:
            if not ref.tag.endswith("itemref"):
                continue
            item = manifest.get(ref.attrib.get("idref"))
            if not item:
                continue
            href = item.get("href", "")
            media_type = (item.get("media-type") or "").split(";", 1)[0].strip().lower()
            # EPUB exporters often label spine documents as text/html. The
            # spine establishes reading order, so accept both common types.
            if media_type not in ("application/xhtml+xml", "text/html", "application/xml", "text/xml") and not href.lower().endswith((".xhtml", ".html", ".htm")):
                continue
            full = resolve_zip_path(posixpath.join(base, href))
            if not full:
                continue
            try:
                raw = book.read(full).decode("utf-8-sig", "replace")
            except KeyError:
                continue
            try:
                doc = ET.fromstring(raw)
                title = ""
                for el in doc.iter():
                    if el.tag.lower().endswith(("h1", "h2", "title")) and "".join(el.itertext()).strip():
                        title = " ".join("".join(el.itertext()).split())
                        break
                if not title:
                    title = os.path.splitext(os.path.basename(href))[0].replace("_", " ")
                body = next((el for el in doc.iter() if el.tag.lower().endswith("body")), doc)
                # Serialize XHTML using local tag names. ElementTree otherwise emits
                # ns0:p/ns1:div prefixes that are not HTML tags in the WebView.
                def to_reader_html(node):
                    tag = node.tag.split("}", 1)[-1] if isinstance(node.tag, str) else ""
                    if not tag:
                        return html.escape(node.text or "")
                    attrs = []
                    for key, value in node.attrib.items():
                        key = key.split("}", 1)[-1]
                        low_key = key.lower()
                        if low_key.startswith("on"):
                            continue
                        # Convert book-local images to data URIs: the reader
                        # HTML is rendered outside the EPUB ZIP filesystem.
                        if tag.lower() in ("img", "image", "source") and low_key == "src":
                            src_value = str(value).strip()
                            parts = urlsplit(src_value)
                            if src_value and not parts.scheme and not src_value.startswith("//"):
                                resource_path = resolve_zip_path(posixpath.join(posixpath.dirname(full), parts.path))
                                if resource_path:
                                    payload = book.read(resource_path)
                                    guessed = mimetypes.guess_type(resource_path)[0]
                                    ext = os.path.splitext(resource_path.lower())[1]
                                    mime = "image/webp" if ext == ".webp" else (guessed or "application/octet-stream")
                                    value = "data:" + mime + ";base64," + base64.b64encode(payload).decode("ascii")
                        # Avoid srcset overriding a resolved local src with a
                        # remote or unresolved candidate.
                        if low_key == "srcset" and tag.lower() in ("img", "source"):
                            continue
                        # Internal EPUB links must not escape the extracted reader into
                        # Android's asset/file namespace. Preserve them as data for the
                        # reader's chapter-aware navigation handler.
                        if tag.lower() == "a" and low_key == "href":
                            link_parts = urlsplit(str(value).strip())
                            if not link_parts.scheme and not link_parts.netloc and not str(value).strip().startswith("//"):
                                attrs.append(f' data-rd-href="{html.escape(str(value), quote=True)}"')
                                continue
                        attrs.append(f' {key}="{html.escape(str(value), quote=True)}"')
                    void = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
                    opening = "<" + tag + "".join(attrs) + ">"
                    if tag.lower() in void:
                        return opening
                    inner = html.escape(node.text or "")
                    for child in list(node):
                        inner += to_reader_html(child)
                        inner += html.escape(child.tail or "")
                    return opening + inner + "</" + tag + ">"
                # Stage 3.1: prepare only the requested chapter's reader HTML.
                # Chapter metadata is still collected for navigation, but converting
                # every chapter and embedding all of its images wastes CPU and memory
                # on each chapter change. The selected chapter is rendered lazily.
                try:
                    requested_index = max(0, int(chapter_index or 0))
                except (TypeError, ValueError):
                    requested_index = 0
                if len(chapters) == requested_index:
                    content = html.escape(body.text or "") + "".join(to_reader_html(child) + html.escape(child.tail or "") for child in list(body))
                    if not content.strip():
                        content = "<p>" + html.escape(" ".join(" ".join(body.itertext()).split())) + "</p>"
                else:
                    content = ""
            except Exception:
                title = os.path.splitext(os.path.basename(href))[0]
                content = "<p>" + html.escape(re.sub(r"<[^>]+>", " ", raw)) + "</p>"
            chapters.append({"title": title[:180], "content": content, "href": full})
        if not chapters:
            raise ValueError("Tidak ada bab XHTML yang dapat dibaca.")
        try:
            title = next((" ".join("".join(e.itertext()).split()) for e in opf.iter()
                          if e.tag.endswith("title") and "".join(e.itertext()).strip()), os.path.basename(src))
        except Exception:
            title = os.path.basename(src)
        index = max(0, min(int(chapter_index or 0), len(chapters)-1))
        # Invalid chapter requests are rare (for example, stale saved progress).
        # Re-run once for the clamped chapter so its content is populated rather
        # than returning an empty chapter from the lazy-render path above.
        if not chapters[index]["content"] and index != max(0, int(chapter_index or 0)):
            return reader_open_epub(relative_name, index)
        result = {"title": title, "chapters": [{"title": c["title"], "href": c["href"]} for c in chapters],
                  "index": index, "content": chapters[index]["content"]}
        if search_query:
            needle = search_query.casefold()
            found = []
            for chapter_no, chapter in enumerate(chapters):
                plain = html.unescape(re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", chapter["content"]))
                plain = re.sub(r"(?s)<[^>]*>", " ", plain)
                plain = re.sub(r"\s+", " ", plain).strip()
                folded = plain.casefold()
                pos = 0
                occurrence = 0
                while True:
                    pos = folded.find(needle, pos)
                    if pos < 0:
                        break
                    # V28.8: compact excerpts, with five words before and after the match.
                    before = plain[:pos]
                    after = plain[pos+len(search_query):]
                    before_words = list(re.finditer(r"\S+", before))
                    after_words = list(re.finditer(r"\S+", after))
                    start = before_words[-5].start() if len(before_words) >= 5 else 0
                    end = (pos+len(search_query)+after_words[4].end()) if len(after_words) >= 5 else len(plain)
                    snippet = ("…" if start else "") + plain[start:end] + ("…" if end < len(plain) else "")
                    found.append({"chapter": chapter_no, "chapter_title": chapter["title"], "occurrence": occurrence, "snippet": snippet})
                    occurrence += 1
                    pos += len(needle)
            result["matches"] = found
        return result


def reader_search_epub(relative_name, search_query, max_matches=1000):
    """Search EPUB spine text directly; avoid reader HTML rendering and image conversion."""
    src = safe_file(relative_name, (".epub",))
    query = str(search_query or "").strip()[:120]
    if not query:
        return {"matches": []}
    needle = query.casefold()
    matches = []
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                        if e.tag.endswith("rootfile")), None)
        if not rootfile:
            raise ValueError("Package OPF tidak ditemukan.")
        opf = ET.fromstring(book.read(rootfile))
        base = posixpath.dirname(rootfile).replace("\\", "/")
        manifest = {e.attrib.get("id"): e.attrib for e in opf.iter() if e.tag.endswith("item")}
        spine = next((e for e in opf.iter() if e.tag.endswith("spine")), None)
        if spine is None:
            raise ValueError("Daftar bab EPUB tidak ditemukan.")
        zip_names = set(book.namelist())
        folded = {n.casefold(): n for n in zip_names}
        def resolve(path):
            path = posixpath.normpath(posixpath.join(base, path)).replace("\\", "/")
            return path if path in zip_names else folded.get(path.casefold())
        for chapter_no, ref in enumerate(spine):
            if not ref.tag.endswith("itemref"):
                continue
            item = manifest.get(ref.attrib.get("idref"))
            if not item:
                continue
            href = item.get("href", "")
            media = (item.get("media-type") or "").split(";", 1)[0].strip().lower()
            if media not in ("application/xhtml+xml", "text/html", "application/xml", "text/xml") and not href.lower().endswith((".xhtml", ".html", ".htm")):
                continue
            full = resolve(unquote(href))
            if not full:
                continue
            try:
                doc = ET.fromstring(book.read(full))
                # Search visible text only; do not serialize links, CSS, images or base64.
                chapter_title = next((" ".join(" ".join(el.itertext()).split()) for el in doc.iter()
                                    if el.tag.split("}", 1)[-1].lower() in ("h1", "h2", "title") and " ".join(el.itertext()).strip()),
                                   posixpath.splitext(posixpath.basename(href))[0].replace("_", " "))
                text_parts = []
                for el in doc.iter():
                    local_tag = el.tag.split("}", 1)[-1].lower() if isinstance(el.tag, str) else ""
                    if local_tag in ("script", "style"):
                        continue
                    if el.text and el.text.strip():
                        text_parts.append(el.text.strip())
                    if el.tail and el.tail.strip():
                        text_parts.append(el.tail.strip())
                plain = " ".join(" ".join(text_parts).split())
            except Exception:
                raw = book.read(full).decode("utf-8-sig", "replace")
                raw = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", raw)
                plain = " ".join(html.unescape(re.sub(r"(?s)<[^>]*>", " ", raw)).split())
                chapter_title = posixpath.splitext(posixpath.basename(href))[0].replace("_", " ")
            folded_text = plain.casefold()
            # Build word boundaries once per chapter. The previous implementation
            # re-scanned the entire text before and after every hit, becoming
            # increasingly expensive for books with many matches.
            word_spans = [(m.start(), m.end()) for m in re.finditer(r"\S+", plain)]
            word_starts = [start for start, _ in word_spans]
            pos = 0
            occurrence = 0
            while len(matches) < max_matches:
                pos = folded_text.find(needle, pos)
                if pos < 0:
                    break
                left_idx = bisect.bisect_left(word_starts, pos)
                start = word_spans[max(0, left_idx - 5)][0] if left_idx >= 5 else 0
                after_start = pos + len(query)
                after_idx = bisect.bisect_left(word_starts, after_start)
                end_idx = after_idx + 4
                end = word_spans[end_idx][1] if end_idx < len(word_spans) else len(plain)
                snippet = ("…" if start else "") + plain[start:end] + ("…" if end < len(plain) else "")
                matches.append({"chapter": chapter_no, "chapter_title": chapter_title[:180], "occurrence": occurrence, "snippet": snippet})
                occurrence += 1
                pos += max(1, len(needle))
            if len(matches) >= max_matches:
                break
    return {"matches": matches}

def reader_cover_data(relative_name):
    """Return the embedded EPUB cover as a data URI for the library thumbnail."""
    src = safe_file(relative_name, (".epub",))
    with zipfile.ZipFile(src, "r") as book:
        container = ET.fromstring(book.read("META-INF/container.xml"))
        rootfile = next((e.attrib.get("full-path") for e in container.iter()
                         if e.tag.endswith("rootfile")), None)
        if not rootfile:
            return {"cover": None}
        opf = ET.fromstring(book.read(rootfile))
        manifest = {}
        for item in opf.iter():
            if item.tag.endswith("item"):
                manifest[item.attrib.get("id")] = item.attrib
        cover_id = None
        for meta in opf.iter():
            if meta.tag.endswith("meta") and meta.attrib.get("name", "").lower() == "cover":
                cover_id = meta.attrib.get("content")
                break
        cover_item = manifest.get(cover_id) if cover_id else None
        if not cover_item:
            cover_item = next((item for item in manifest.values()
                               if "cover-image" in item.get("properties", "").split()), None)
        if not cover_item:
            # EPUB 2 guide references are a useful fallback for older files.
            for ref in opf.iter():
                if ref.tag.endswith("reference") and ref.attrib.get("type", "").lower() == "cover":
                    href = ref.attrib.get("href", "").split("#", 1)[0]
                    candidate = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
                    if candidate in book.namelist():
                        raw = book.read(candidate)
                        mime = mimetypes.guess_type(candidate)[0] or "image/jpeg"
                        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}
        if not cover_item:
            return {"cover": None}
        href = cover_item.get("href", "").split("#", 1)[0]
        image_path = posixpath.normpath(posixpath.join(posixpath.dirname(rootfile), unquote(href)))
        if image_path not in book.namelist():
            return {"cover": None}
        raw = book.read(image_path)
        if len(raw) > 4 * 1024 * 1024:
            return {"cover": None}
        mime = cover_item.get("media-type") or mimetypes.guess_type(image_path)[0] or "image/jpeg"
        return {"cover": "data:" + mime + ";base64," + base64.b64encode(raw).decode("ascii")}

def api_action(path, d):
    name = d.get("file", "")
    if path == "/reader-cover":
        return reader_cover_data(name)
    if path == "/delete-book":
        src = safe_file(name, (".epub",))
        deleted_name = os.path.basename(src)
        os.remove(src)
        return {"deleted": True, "file": relative_storage_path(src), "name": deleted_name}
    if path == "/reader-open":
        return reader_open_epub(name, d.get("chapter", 0))
    if path == "/reader-search":
        query = str(d.get("query", "")).strip()[:120]
        if not query:
            return {"matches": []}
        return reader_search_epub(name, query)
    if path == "/rename-by-title":
        src = safe_file(name, (".epub",))
        title = epub_metadata_title(src)
        target_name = safe_epub_filename(title)
        target = os.path.join(os.path.dirname(src), target_name)
        if os.path.abspath(src) == os.path.abspath(target):
            return {"output": relative_storage_path(src), "title": title, "message": "Nama file sudah sesuai dengan judul metadata."}
        base, ext = os.path.splitext(target)
        n = 2
        while os.path.exists(target):
            target = f"{base}_{n}{ext}"
            n += 1
        os.rename(src, target)
        return {"output": relative_storage_path(target), "title": title, "previous_name": name}

    if path in ("/bulk-count", "/bulk-replace"):
        ns = MOD["BULK_FIND_REPLACE.py"]
        src = safe_file(name, (".epub", ".txt"))
        pat = ns["make_pattern"](d.get("find", ""), bool(d.get("case_sensitive")), bool(d.get("whole_word")), bool(d.get("regex")))
        if path == "/bulk-count":
            count, _ = ns["process_file"](src, pat, None)
            return {"count": count}
        if os.path.splitext(src)[1].lower() == ".epub":
            validate_epub(src)
        with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
            staged = os.path.join(work, os.path.basename(src))
            shutil.copy2(src, staged)
            count, generated = ns["process_file"](staged, pat, d.get("replace", ""))
            if count == 0:
                return {"count": 0, "output": os.path.basename(src), "message": "Tidak ada teks yang cocok; file tidak diubah."}
            output = commit_in_place(src, generated)
        return {"count": count, "output": output, "message": "File asli berhasil diperbarui."}

    src = safe_file(name, (".epub",))
    if path == "/cover-meta":
        ns = MOD["COVER MAKER.py"]
        with zipfile.ZipFile(src, "r") as z:
            opf = ns["find_opf"](z)
            title, author, _ = ns["read_metadata"](z.read(opf))
        return {"title": title, "author": author}

    with tempfile.TemporaryDirectory(prefix="epub_toolkit_") as work:
        staged = os.path.join(work, os.path.basename(src))
        shutil.copy2(src, staged)
        stem = os.path.splitext(staged)[0]
        details = {}
        generated = None

        if path == "/remove-cover":
            _, log = run_captured(MOD["REMOVE_EPUB_COVER.py"]["remove_epub_cover"], staged)
            generated = stem + "_no_cover.epub"
            details["details"] = log[-500:]
        elif path == "/no-preview":
            result = fix_no_preview(staged)
            if result.get("changed", 0) == 0:
                return result
            generated = os.path.join(work, result["output"])
            details["changed"] = result["changed"]
        elif path == "/make-cover":
            ns = MOD["COVER MAKER.py"]
            with zipfile.ZipFile(staged, "r") as z:
                opf = ns["find_opf"](z)
                metadata_title, author, root = ns["read_metadata"](z.read(opf))
            # A manually entered title remains supported in the single-file tool;
            # batch Cover Maker defaults to the EPUB's own dc:title metadata.
            title = (d.get("title") or metadata_title or "").strip()
            if not title:
                raise ValueError("Metadata EPUB tidak memiliki judul (dc:title).")
            ns["add_cover"](staged, opf, root, title, author)
            generated = stem + "_with_cover.epub"
            details.update({"title": title, "author": author})
        elif path == "/compress":
            ns = MOD["IMAGE_COMPRESSOR_15.py"]
            Image, ImageOps = ns["load_pillow"]()
            _, log = run_captured(ns["compress_epub"], staged, Image, ImageOps)
            generated = stem + "_compressed.epub"
            details["details"] = log[-700:]
        elif path == "/compact-spacing":
            ns = MOD["COMPACT_LINE_SPACING_FIXER.py"]
            generated = os.path.join(work, "processed.epub")
            adjusted, cleaned = ns["process_epub"](staged, generated)
            details.update({"adjusted": adjusted, "cleaned": cleaned})
        elif path == "/blank-spacing":
            ns = MOD["REMOVE_BLANK_SPACING.py"]
            _, log = run_captured(ns["process_epub"], staged)
            generated = stem + "_clean_default_spacing.epub"
            details["details"] = log[-500:]
        elif path == "/remove-images":
            ns = MOD["IMAGE_REMOVER.py"]
            _, log = run_captured(ns["remove_images"], staged)
            generated = stem + "_no_images.epub"
            details["details"] = log[-500:]
        else:
            raise ValueError("Endpoint tidak dikenal.")

        output = commit_in_place(src, generated)
        details.update({"output": output, "message": "File asli berhasil diperbarui."})
        return details

PAGE = r"""<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#08285f"><title>EPUB All-in-One Toolkit</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#eef2f8;color:#172033;font-family:Arial,sans-serif;padding:14px}main{max-width:760px;margin:auto}
.hero{background:linear-gradient(135deg,#08285f,#145da0);color:white;border-radius:18px;padding:20px;margin-bottom:14px}.hero h1{font-size:22px;margin:0 0 6px}.hero p{margin:0;color:#dce7ff;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:12px 0}.tab{border:0;border-radius:11px;padding:13px 9px;background:#dce4f1;color:#1b3155;font-weight:bold;font-size:13px;text-align:left;min-height:54px}.tab.active{background:#08285f;color:white}
.panel{background:white;border-radius:14px;padding:16px;margin:12px 0;box-shadow:0 2px 10px #13294b0d}.panel h2{margin:0 0 8px;font-size:19px}.hint{color:#596579;font-size:13px;line-height:1.5}
label{display:block;font-size:14px;font-weight:bold;margin:12px 0 6px}input[type=text],select{width:100%;padding:12px;border:1px solid #b8c3d3;border-radius:9px;font-size:16px;background:white;color:#172033}
.check{display:flex;align-items:center;gap:8px;font-weight:normal;margin:10px 0}.check input{width:19px;height:19px}.batch-file{display:flex;align-items:flex-start;gap:9px;padding:8px 4px;border-bottom:1px solid #edf1f6;font-size:13px;font-weight:normal;margin:0}.batch-file:last-child{border-bottom:0}.batch-file input{width:18px;height:18px;flex:0 0 auto;margin:1px 0 0}.batch-file span{overflow-wrap:anywhere}button.action{width:100%;border:0;border-radius:10px;background:#1265bd;color:white;font-weight:bold;padding:13px;margin-top:10px;font-size:15px}button.alt{background:#53657e}

.toolkit-home{padding:18px}
.mode-card{display:grid;grid-template-columns:48px 1fr 24px;grid-template-rows:auto auto;align-items:center;text-align:left;gap:2px 12px;width:100%;border:1px solid #d7e0eb;border-radius:14px;background:#fff;padding:15px;margin:10px 0;color:#172033;box-shadow:0 2px 7px #10243b0a}
.mode-card.batch-mode{border-color:#b8dfc5}
.mode-icon{grid-row:1/3;font-size:28px;text-align:center}
.mode-title{font-size:17px;font-weight:700}
.mode-desc{font-size:12px;color:#66748a}
.mode-arrow{grid-column:3;grid-row:1/3;font-size:26px;color:#64748b}
.menu-back{grid-column:1/-1;margin:0 0 10px}
.hide{display:none}.small{font-size:12px;color:#657187;overflow-wrap:anywhere}
footer{text-align:center;color:#718096;font-size:12px;padding:14px}
.status{
  white-space:pre-wrap;
  overflow-wrap:anywhere;
  background:#f5f7fb;
  border:1px solid #e2e8f0;
  border-radius:12px;
  padding:14px;
  margin-top:12px;
  min-height:42px;
  font-size:14px;
  line-height:1.6;
  color:#334155;
}@media(max-width:420px){.grid{grid-template-columns:1fr 1fr}.tab{font-size:12px;padding:10px 7px}}

/* Gallery-style top-level navigation and EPUB reader */
body{padding-bottom:88px}
#gallery-nav{position:fixed;z-index:1000;left:0;right:0;bottom:0;height:72px;background:#050505;border-top:1px solid #252525;display:flex;justify-content:space-around;align-items:center}
.gallery-btn{border:0;background:transparent;color:#777;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;min-width:110px;height:100%;font-weight:500}
.gallery-btn.active{color:#f2f2f2;font-weight:bold}
.gallery-btn svg{width:27px;height:27px;fill:currentColor}
.gallery-btn .gallery-emoji{font-size:25px;line-height:27px}
/* V25: recolor tab icons only; keep tab labels and active styling unchanged */
.gallery-btn .gallery-emoji{filter:grayscale(1);opacity:.82}
#reader-view{display:block;position:fixed;inset:0 0 72px;background:#050505;color:#eee;overflow:auto;padding:18px 18px 30px}
/* Startup: show My Library immediately; avoid Toolkit flash before navigation JS initializes. */
body>main{display:none}
#reader-view .reader-head{font-size:30px;font-weight:300;margin:8px 0 22px}
#reader-view .reader-tools{background:#1d1d1d;border-radius:14px;padding:14px;margin-bottom:16px}
#reader-view select,#reader-view input{width:100%;padding:10px;border-radius:8px;border:1px solid #555;background:#292929;color:#eee;font-size:15px}
#reader-view label{color:#ddd;font-size:13px;margin:10px 0 5px}
#reader-view .reader-actions{display:flex;gap:8px}
#reader-view button{border:0;border-radius:8px;padding:10px 12px;background:#3478df;color:white;font-weight:bold}
#reader-view button.secondary{background:#444}
#reader-view .reader-page{border-radius:12px;padding:20px 18px;min-height:48vh;background:#fff;color:#242424;font-family:Georgia,serif;font-size:19px;line-height:1.65}
#reader-view .reader-page p{margin:0 0 1em}
#reader-view .reader-page img{max-width:100%;height:auto}
#reader-view .reader-empty{color:#aaa;text-align:center;padding:55px 15px;line-height:1.6}
#reader-view .reader-settings{display:grid;grid-template-columns:1fr 1fr;gap:8px}
#reader-view .theme-row{display:flex;gap:7px;margin-top:10px}
#reader-view .theme-row button{flex:1}
@media(max-width:420px){#reader-view{padding:14px 12px 24px}.reader-page{font-size:18px}}

/* Horizontal page-by-page EPUB reading */
#reader-view .reader-page{height:62vh;min-height:360px;overflow-x:auto;overflow-y:hidden;column-width:100%;column-gap:30px;column-fill:auto;scroll-snap-type:x mandatory;scrollbar-width:none;-webkit-overflow-scrolling:touch;touch-action:pan-y;overscroll-behavior-x:contain}
#reader-view .reader-page::-webkit-scrollbar{display:none}
#reader-view .reader-page>*{break-inside:auto}
#reader-view .reader-page p{break-inside:auto;orphans:2;widows:2}
#reader-view .reader-page img,#reader-view .reader-page figure{break-inside:avoid-column}
#reader-view .reader-page img{max-height:45vh;object-fit:contain}
#reader-view .page-nav{display:flex;align-items:center;gap:8px;margin:0 0 10px}
#reader-view .page-nav button{background:#444}
#reader-view .page-nav span{color:#aaa;font-size:12px;margin-left:auto}

/* Immersive reading: tap the page to toggle all controls */
#reader-view{inset:0;padding:12px 14px 18px;transition:padding .18s ease}
#reader-controls{opacity:1;max-height:1000px;overflow:hidden;transition:opacity .18s ease,max-height .22s ease,transform .18s ease}
#reader-view.controls-hidden{padding:0}
#reader-view.controls-hidden #reader-controls{opacity:0;max-height:0;transform:translateY(-12px);pointer-events:none;margin:0}
body.reader-reading #gallery-nav{display:none}
body.reader-reading{padding-bottom:0}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 8px);min-height:calc(100vh - 8px);border-radius:0;padding:28px 22px}
#reader-view #reader-content{cursor:pointer}
@media(max-width:420px){#reader-view{padding:10px 10px 14px}#reader-view.controls-hidden #reader-content{padding:28px 20px}}

/* Read Book: dedicated library and immersive reader */
#reader-view{background:#071d23;color:#f3f7f8;padding:0;inset:0;overflow-y:auto}
#library-view{min-height:100%;padding:0 14px 24px}
#library-refresh-indicator{height:0;overflow:hidden;display:flex;align-items:center;justify-content:center;color:#b9e7ec;font-size:12px;transition:height .12s ease;background:#064b5b;margin:0 -14px}
#library-refresh-indicator.visible{height:42px}
#library-top{position:sticky;top:0;z-index:5;background:#075b70;margin:0 -14px 14px;padding:17px 16px 14px;box-shadow:0 3px 12px #0003}
#library-top .lib-title{font-size:24px;font-weight:700;margin:0 0 10px}
#library-search{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #43808c;border-radius:10px;background:#064b5b;color:white;font-size:15px;outline:none}
#library-search::placeholder{color:#b5d1d6}
#library-sort-row{display:flex;align-items:center;gap:5px;margin-top:9px}
#library-sort-label{font-size:12px;color:#b5d1d6;white-space:nowrap}
#library-sort{flex:0 1 auto;min-width:0;box-sizing:border-box;padding:2px 0;border:0;border-radius:0;background:transparent;color:#a88bd7;font-size:14px;outline:none;appearance:none;-webkit-appearance:none;cursor:pointer}
#library-sort:focus{outline:none}
#library-sort option{background:#101421;color:#f1f2f5}
#library-stats{font-size:12px;color:#a9c2c7;margin:10px 2px}
.book-card{display:flex;gap:11px;align-items:center;background:#1a343a;border:1px solid #28474e;border-radius:11px;padding:9px;margin:0 0 9px;min-height:94px;box-shadow:0 2px 7px #0002;cursor:pointer}
.book-cover{width:58px;min-width:58px;height:78px;min-height:78px;border-radius:3px;background:linear-gradient(145deg,#275e6b,#102b34);display:flex;align-items:center;justify-content:center;color:#d7e6e9;font-size:27px;box-shadow:0 2px 5px #0005}
.book-cover span{font-size:27px}.book-cover img{width:100%;height:100%;object-fit:cover;border-radius:3px;display:block}
.book-info{min-width:0;flex:1;display:flex;flex-direction:column;gap:4px;align-self:stretch;padding:1px 0}
.book-name{font-size:15px;line-height:1.25;font-weight:600;overflow-wrap:anywhere;color:#f5f8f9;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.book-meta{font-size:11px;color:#a9bdc1;overflow-wrap:anywhere}
.book-progress{height:3px;border-radius:9px;background:#496168;overflow:hidden;margin-top:auto}
.book-progress>i{display:block;height:100%;background:#21b6a6}
.book-open-hint{font-size:11px;color:#70d5ca;margin-top:1px}
#library-selection-toolbar{display:none;align-items:center;gap:7px;flex-wrap:wrap;background:#123c45;border:1px solid #2b6670;border-radius:10px;padding:9px;margin:0 0 10px}
#library-selection-toolbar.visible{display:flex}
#library-selection-count{font-size:12px;color:#c5e0e3;flex:1;min-width:95px}
#library-selection-toolbar button{border:1px solid #4b7c83;background:#204e57;color:#f5fbfc;border-radius:8px;padding:8px 10px;font-size:12px}
#library-selection-toolbar button.delete{background:#8b3030;border-color:#b34b4b}
.book-card.selected{border:2px solid #21b6a6;background:#21454b;padding:8px}
.book-select-mark{width:23px;height:23px;min-width:23px;border-radius:50%;border:2px solid #91aeb2;display:none;align-items:center;justify-content:center;color:#062a30;font-size:14px;font-weight:800}
.selection-mode .book-select-mark{display:flex}
.book-card.selected .book-select-mark{background:#46d4c4;border-color:#46d4c4}
@media(max-width:420px){.book-cover{width:54px;min-width:54px;height:74px;min-height:74px}.book-card{min-height:88px;padding:8px;gap:9px}.book-name{font-size:14px}}
#reader-screen{display:none;min-height:100%;background:#101719;padding:0 14px 22px}
#reader-screen-head{position:sticky;top:0;z-index:6;background:#101719;padding:12px 0 10px;display:flex;align-items:center;gap:14px;border-bottom:1px solid #29383b}
#reader-screen-head button{background:transparent;color:#f2f5f5;padding:8px;font-size:22px}
#reader-book-title{font-size:15px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
#reader-view #reader-controls{padding-top:10px}
/* V28.3: dedicated full-screen Find in Book UI, modeled after the supplied reference video. */
#reader-search-screen{display:none;position:fixed;inset:0;background:#071d23;color:#f2f5f5;z-index:40;overflow:hidden}
#reader-search-screen.active{display:flex;flex-direction:column}
#reader-search-head{height:54px;min-height:54px;background:#263437;display:flex;align-items:center;padding:6px 10px;gap:5px;box-sizing:border-box;border-bottom:1px solid #3b5960;box-shadow:0 2px 4px #0006}
#reader-search-head button{border:0;background:transparent;color:#eaf3f4;width:42px;height:42px;font-size:32px;font-weight:300;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;flex:0 0 42px}
#reader-search-head button.search-back{font-size:32px;margin-left:-3px}
#reader-search-head input{flex:1;min-width:0;height:40px;border:1px solid #47646b;border-radius:9px;outline:0;background:#1b292c;color:#f1f6f7;font-size:22px;font-weight:400;padding:0 10px;box-sizing:border-box}
#reader-search-head input::placeholder{color:#b8c9cc;opacity:1}
#reader-search-head button.search-clear{font-size:32px}
#reader-search-body{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:10px 0 24px}
#reader-search-history{display:none;flex:0 0 auto;max-height:34vh;overflow-y:auto;border-bottom:1px solid #102f36;padding:0;color:#b7c3c5;background:#071d23}
#reader-search-history.visible{display:flex;flex-direction:column}
.reader-search-history-item{display:flex;align-items:center;gap:8px;padding:9px 22px;min-height:48px;box-sizing:border-box;touch-action:pan-y}
.reader-search-history-item .history-icon{width:18px;height:18px;color:#8c989a;line-height:1;flex:0 0 18px;display:flex;align-items:center;justify-content:center}
.reader-search-history-item .history-icon svg{width:18px;height:18px;display:block}
.reader-search-history-item .history-query{font-size:20px;color:#29b7d0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.2}
.reader-search-history-item:active{background:#102d33}
#reader-search-results{padding:8px 9px 0}
.search-result-card.search-result-selected{border:2px solid #d9b94b!important;background:#24434a!important;box-shadow:0 0 0 1px #d9b94b33!important}
.search-result-card[aria-current="true"] .search-result-location{color:#d9b94b;font-weight:600}
.search-result-card{display:flex!important;align-items:stretch!important;width:calc(100% - 18px)!important;padding:0!important;text-align:left!important;font-family:Arial,sans-serif!important;font-weight:400!important;font-size:inherit!important;line-height:normal!important;color:#f0f3f3!important;background:#1c3439!important;border:1px solid #263f44!important;border-radius:7px!important;margin:0 9px 4px!important;min-height:48px!important;box-sizing:border-box!important;overflow:hidden!important;box-shadow:0 1px 1px #0004!important;appearance:none!important;-webkit-appearance:none!important;outline:none!important}
.search-result-text{flex:1;min-width:0;padding:5px 6px 6px 11px}
.search-result-chapter-title{font-size:11px;line-height:1.15;color:#8fc6d1;margin:0 0 3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.search-result-snippet{color:#f0f3f3;font-size:15px;line-height:1.22;word-break:break-word}
.search-result-snippet mark{background:transparent;color:#e6c94e;font-weight:400;padding:0}
.search-result-location{width:58px;flex:0 0 58px;display:flex;align-items:center;justify-content:center;color:#f2f5f5;font-size:14px;font-weight:500}
#reader-search-empty{display:none;padding:0;text-align:center;color:#8f9b9d;font-size:16px}
#reader-search-empty:not(:empty){display:block;padding:24px 25px}
#reader-search-loading{display:none;padding:55px 25px;text-align:center;color:#1290b2;font-size:48px}
#reader-search-loading.active{display:block}
#reader-search-tools{display:flex;gap:6px;align-items:center;margin:0 0 9px}
#reader-search-tools input{min-width:0;flex:1;background:#263437;border:1px solid #536367;color:#f3f7f8;border-radius:8px;padding:9px 10px;font-size:14px}
#reader-search-tools button{padding:8px 10px;white-space:nowrap}
#reader-search-status{font-size:12px;color:#b9c7ca;margin:0 0 8px;min-height:16px}
#reader-content mark.reader-search-hit{background:#ffdf65;color:#241d08;border-radius:2px;padding:0}
#reader-view .reader-tools{background:#1b292c;border:1px solid #33464a}
#reader-view .reader-head{display:none}
#reader-view .reader-page{height:calc(100vh - 260px);min-height:360px;border-radius:5px;padding:28px 23px;background:#f7f2e8;color:#28251f;font-family:Georgia,serif;font-size:19px;line-height:1.7;box-shadow:0 4px 18px #0005}
#reader-view .page-nav span{color:#b9c7ca}
#reader-view .reader-actions{align-items:center}
#reader-view .reader-actions button,#reader-view .page-nav button{padding:9px 13px}
#reader-view .reader-settings{margin-top:8px}
#reader-view .reader-tools label{display:block}
#reader-view input[type=range]{padding:0;background:transparent;border:0}
#reader-view .theme-row button{padding:9px 6px}
#reader-view.controls-hidden #reader-content{height:calc(100vh - 12px);min-height:calc(100vh - 12px);margin:0}
@media(max-width:420px){.book-cover{width:78px;min-width:78px}.book-name{font-size:16px}#reader-view .reader-page{height:calc(100vh - 270px);padding:23px 19px}}


/* Reader rendering fixes v2: proper XHTML block tags and predictable page columns */

/* V4.2.8: compact two-line chapter/page footer */
#reader-screen #reader-reading-footer{position:fixed;left:0;right:0;bottom:calc(7px + env(safe-area-inset-bottom));z-index:24;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;pointer-events:none;color:#5b554d;font:16px/0.94 Georgia,serif;text-align:center;}
#reader-screen #reader-reading-footer span{display:block;margin:0;padding:0;}
#reader-screen #reader-content.reader-page{padding-bottom:calc(78px + env(safe-area-inset-bottom)) !important;}

#reader-view #reader-content.reader-page {
  display:block; box-sizing:border-box; width:100%; max-width:100%;
  overflow-x:auto; overflow-y:hidden; white-space:normal;
  column-fill:auto; column-gap:28px; column-rule:0;
  column-width:auto; -webkit-column-width:auto;
  word-break:normal; overflow-wrap:break-word; text-align:left;
  touch-action:pan-y; overscroll-behavior-x:contain;
}
#reader-view #reader-content.reader-page p {
  display:block; margin:0 0 var(--rd-reader-para-spacing,1em); padding:0; text-indent:0 !important;
  line-height:inherit; white-space:normal; break-inside:auto;
}
#reader-view #reader-content.reader-page article,
#reader-view #reader-content.reader-page main,
#reader-view #reader-content.reader-page blockquote,
#reader-view #reader-content.reader-page ul,
#reader-view #reader-content.reader-page ol,
#reader-view #reader-content.reader-page li { display:block; }
#reader-view #reader-content.reader-page p + p { margin-top:0; }

#reader-view #reader-content.reader-page h1,
#reader-view #reader-content.reader-page h2,
#reader-view #reader-content.reader-page h3,
#reader-view #reader-content.reader-page h4 { display:block; white-space:normal; break-after:avoid; margin:1.1em 0 .65em; line-height:1.25; }
#reader-view #reader-content.reader-page div,
#reader-view #reader-content.reader-page section { display:block; max-width:100%; }
#reader-view #reader-content.reader-page img,
#reader-view #reader-content.reader-page svg,
#reader-view #reader-content.reader-page table { max-width:100%; }
#reader-view #reader-content.reader-page table { border-collapse:collapse; }
#reader-view #reader-content.reader-page a { overflow-wrap:anywhere; }
/* V29.5.8: make EPUB internal links visibly distinct while keeping book typography. */
#reader-view #reader-content.reader-page a[data-rd-href] {
  color:#1677b8; text-decoration:underline; text-decoration-thickness:1px; text-underline-offset:2px; cursor:pointer;
}
#reader-view #reader-content.reader-page a[data-rd-href]:active { color:#0b568a; }


/* Reader presentation v5: edge-to-edge text with floating controls; suppress Android WebView blue tap flash */
#reader-view, #reader-view *, #reader-view button, #reader-view input, #reader-view select {
  -webkit-tap-highlight-color: transparent;
}
#reader-screen {
  position:fixed; inset:0; z-index:20; display:none; overflow:hidden;
  min-height:100dvh; height:100dvh; padding:0; background:#101719;
}
#reader-screen-head {
  position:fixed; top:0; left:0; right:0; z-index:30;
  padding:calc(8px + env(safe-area-inset-top)) 12px 8px;
  margin:0; background:linear-gradient(180deg,rgba(8,19,23,.96),rgba(8,19,23,.78));
  border:0; min-height:54px; box-sizing:border-box;
  transition:opacity .14s ease, transform .14s ease;
}
#reader-content.reader-page {
  position:fixed; z-index:21; inset:0; width:100vw; height:100dvh !important;
  min-height:100dvh !important; max-height:none; box-sizing:border-box;
  margin:0 !important; border-radius:0 !important; box-shadow:none !important;
  padding:calc(76px + env(safe-area-inset-top)) 24px calc(96px + env(safe-area-inset-bottom)) !important;
  background:#f7f2e8; color:#28251f;
  -webkit-tap-highlight-color:transparent; outline:none;
}
#reader-view #reader-controls {
  position:fixed; left:0; right:0; bottom:0; z-index:32;
  box-sizing:border-box; max-height:62dvh; overflow-y:auto;
  padding:10px 14px calc(12px + env(safe-area-inset-bottom));
  background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));
  border-top:1px solid rgba(255,255,255,.12); border-radius:16px 16px 0 0;
  backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
  transition:opacity .14s ease, transform .14s ease, max-height .14s ease;
}
#reader-view #reader-controls {position:fixed;inset:auto 10px auto 10px;top:calc(62px + env(safe-area-inset-top));z-index:35;max-height:none;overflow:visible;padding:0;background:transparent;border:0;border-radius:0;backdrop-filter:none;-webkit-backdrop-filter:none;pointer-events:none}
#reader-view .reader-popup-menu{display:none;pointer-events:auto;position:absolute;top:0;right:0;width:min(92vw,440px);max-height:72dvh;overflow-y:auto;box-sizing:border-box;background:#253438;border:1px solid #43565a;border-radius:15px;padding:15px;box-shadow:0 12px 32px #0008}
#reader-view .reader-popup-menu.active{display:block}
#reader-view .reader-popup-title{font-size:17px;font-weight:700;color:#e5f0f1;margin:0 0 12px}
#reader-view .reader-popup-menu .reader-settings{margin:0;gap:10px}
#reader-view .reader-popup-menu .theme-row{margin-top:12px}
#reader-view .reader-popup-menu .reader-actions{margin:12px 0 6px;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .reader-actions button{flex:1;min-width:120px}
#reader-view .reader-popup-menu .page-nav{margin:6px 0 0;gap:6px;flex-wrap:wrap}
#reader-view .reader-popup-menu .page-nav button{flex:1;min-width:90px}
#reader-view #reader-screen-head button{width:42px;font-size:24px}
#reader-view.controls-hidden #reader-controls{opacity:0;pointer-events:none}
#reader-view.controls-hidden #reader-settings-menu,#reader-view.controls-hidden #reader-navigation-menu,#reader-view.controls-hidden #reader-navigation-controls-menu{display:none!important}
#reader-view #reader-controls .reader-tools { margin:0 0 8px; padding:10px; }
#reader-view #reader-controls .reader-actions { margin:6px 0; }
#reader-view #reader-controls .page-nav { margin:5px 0 0; }
#reader-view #reader-bottom-navigation{display:none!important;position:fixed;left:0;right:0;bottom:0;z-index:34;box-sizing:border-box;padding:10px 14px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(12,25,29,.88),rgba(7,17,20,.98));border-top:1px solid rgba(255,255,255,.12);border-radius:16px 16px 0 0;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);transition:opacity .14s ease,transform .14s ease}
#reader-view #reader-bottom-navigation .reader-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 8px}
#reader-view #reader-bottom-navigation .reader-actions button{flex:1;min-width:120px}
#reader-view #reader-bottom-navigation .page-nav{display:flex;align-items:center;gap:8px;margin:0;flex-wrap:wrap}
#reader-view #reader-bottom-navigation .page-nav button{flex:1;min-width:90px}
#reader-view #reader-bottom-navigation #reader-page-count{margin-left:auto;color:#aab8ba}
#reader-view.controls-hidden #reader-bottom-navigation{opacity:0;transform:translateY(12px);pointer-events:none}

#reader-view.controls-hidden #reader-controls {
  opacity:0; max-height:0; padding-top:0; padding-bottom:0;
  transform:translateY(12px); pointer-events:none; border:0;
}
#reader-view.controls-hidden #reader-screen-head {
  opacity:0; transform:translateY(-10px); pointer-events:none;
}
/* Keep the reading viewport identical in both states. Controls float above it. */
#reader-view.controls-hidden #reader-content.reader-page {
  padding-top:calc(76px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(96px + env(safe-area-inset-bottom)) !important;
}
#reader-content, #reader-content * { -webkit-tap-highlight-color:transparent; }
@media(max-width:420px) {
  #reader-content.reader-page { padding-left:20px !important; padding-right:20px !important; }
  #reader-view #reader-controls { max-height:68dvh; }
}
/* V17 reader spacing: stronger, explicit override of the original reader viewport padding. */
#reader-screen #reader-content.reader-page,
#reader-view.controls-hidden #reader-screen #reader-content.reader-page {
  padding-top:calc(48px + env(safe-area-inset-top)) !important;
  padding-bottom:calc(48px + env(safe-area-inset-bottom)) !important;
  padding-left:32px !important;
  padding-right:32px !important;
}
/* Prevent EPUB-supplied first-paragraph spacing or indentation from reintroducing a blank offset. */
#reader-screen #reader-content.reader-page p,
#reader-screen #reader-content.reader-page p * {
  text-indent:0 !important;
}
#reader-screen #reader-content.reader-page > :first-child,
#reader-screen #reader-content.reader-page > :first-child > :first-child {
  margin-top:0 !important;
}
/* V19: horizontal page isolation is calculated from the full reader viewport in setReaderStyle(). */
#reader-screen #reader-content.reader-page {
  column-fill:auto !important;
  -webkit-column-fill:auto !important;
  overflow-x:auto !important;
  overflow-y:hidden !important;
}

/* V4.1.2: harmonize Toolkit screens with the dark My Library control-menu palette. Reader page colors are intentionally untouched. */
main, main .panel, main .toolkit-home { background:#101421 !important; color:#eef1f5 !important; }
main .hero { background:#101421 !important; color:#eef1f5 !important; border:1px solid #28313d; }
main .hero p, main .hint, main .mode-desc, main .panel p { color:#aeb7c5 !important; }
main .mode-card { background:#202a30 !important; color:#eef1f5 !important; border-color:#303b46 !important; }
main .mode-card .mode-title, main .mode-card .mode-arrow { color:#eef1f5 !important; }
main .tab { background:#202a30 !important; color:#c7d0dc !important; border:1px solid #303b46 !important; }
main .tab.active { background:#101421 !important; color:#ffffff !important; border-color:#687787 !important; }
main .panel h2, main label, main strong { color:#eef1f5 !important; }
main input[type=text], main input[type=search], main select, main textarea { background:#202a30 !important; color:#eef1f5 !important; border-color:#3a4652 !important; }
main input::placeholder, main textarea::placeholder { color:#8793a2 !important; }
main .batch-file { border-color:#303b46 !important; color:#e2e7ee !important; }
main button.action { background:#202a30 !important; color:#f3f5f8 !important; border:1px solid #3a4652 !important; }
main button.alt { background:#303b46 !important; color:#f3f5f8 !important; }
main button, main select, main input { color-scheme:dark; }

/* V4.1.4: correct the previous incomplete theme pass. My Library now uses the same
   navy/charcoal control palette, and sorting is a text-only native control. */
html, body { background:#101421 !important; color:#eef1f5 !important; }
body { color-scheme:dark; }
main { background:#101421 !important; }
main .panel { border-color:#303b46 !important; box-shadow:none !important; }
main #folder-picker-panel, main #batch-panel { border-color:#303b46 !important; }
main .mode-card { border-color:#303b46 !important; }
#reader-view { background:#101421 !important; }
#library-view { background:#101421 !important; }
#library-top { background:#101421 !important; box-shadow:none !important; }
#library-top .lib-title { color:#eef1f5 !important; }
#library-search { background:#202a30 !important; border:1px solid #303b46 !important; color:#eef1f5 !important; }
#library-search::placeholder { color:#aeb7c5 !important; }
#library-sort-row { gap:7px !important; }
#reader-view #library-sort { width:auto !important; flex:0 1 auto !important; min-width:0 !important; padding:0 !important; margin:0 !important; border:0 !important; border-radius:0 !important; background:transparent !important; box-shadow:none !important; color:#a88bd7 !important; font-size:14px !important; appearance:none !important; -webkit-appearance:none !important; outline:none !important; }
#reader-view #library-sort:focus, #reader-view #library-sort:focus-visible { outline:none !important; box-shadow:none !important; }
#reader-view #library-sort option { background:#101421 !important; color:#eef1f5 !important; }
#library-sort-label { color:#aeb7c5 !important; }
.book-card { background:#202a30 !important; border-color:#303b46 !important; box-shadow:none !important; }

/* V4.1.6: compact Library header only; book cards remain unchanged. */
#library-top { margin-bottom:2px !important; padding-top:10px !important; padding-bottom:4px !important; }
#library-top .lib-title { margin-bottom:5px !important; }
#library-search { padding-top:7px !important; padding-bottom:7px !important; }
#library-sort-row { margin-top:5px !important; gap:6px !important; align-items:center !important; min-height:24px !important; }
#library-sort-label, #reader-view #library-sort { font-size:14px !important; line-height:24px !important; height:24px !important; vertical-align:middle !important; }
#library-stats { margin:2px 2px 4px !important; line-height:1.3 !important; }
#library-view .book-card { background:#202a30 !important; border-color:#303b46 !important; }
#library-view .book-meta { color:#aeb7c5 !important; }
#library-view .book-open-hint { color:#a88bd7 !important; }
#library-view .book-progress { background:#3a4652 !important; }
.status { background:#202a30 !important; border:1px solid #303b46 !important; color:#aeb7c5 !important; border-radius:12px !important; }
.status div, .status .summary { background:#202a30 !important; border-color:#303b46 !important; color:#eef1f5 !important; }


/* V4.2.0 UI refinements: balanced library spacing, centered tool tiles, safe bottom scroll. */
#library-top .lib-title{font-size:clamp(28px, 7vw, 34px)!important;}
#library-top{padding-bottom:8px!important;margin-bottom:0!important;}
#library-top .lib-title{margin:0 0 10px!important;}
#library-search{margin:0!important;}
#library-sort-row{margin:12px 0 0!important;align-items:center!important;min-height:28px!important;}
#library-sort-label,#reader-view #library-sort{height:28px!important;line-height:28px!important;font-size:15px!important;display:flex!important;align-items:center!important;}
#library-stats{margin:12px 2px 8px!important;}
#library-view{padding-bottom:calc(112px + env(safe-area-inset-bottom))!important;}
.mode-card{text-align:center!important;}
.mode-card>*{text-align:center!important;}

/* V4.2.1: definitive compact library header and alignment corrections */
#library-top{padding:10px 12px 4px!important;margin-bottom:4px!important}
#reader-view #library-top .lib-title{font-size:28px!important;line-height:1.15!important;margin:0 0 6px!important}
#reader-view #library-search{padding:8px 10px!important;line-height:1.2!important}
#reader-view #library-sort-row{display:flex!important;align-items:center!important;gap:6px!important;margin:4px 0 0!important;min-height:24px!important}
#reader-view #library-sort-label,#reader-view #library-sort{display:flex!important;align-items:center!important;height:24px!important;line-height:24px!important;margin:0!important;padding:0!important;font-size:15px!important;vertical-align:middle!important}
#reader-view #library-stats{margin:4px 2px 6px!important;line-height:1.3!important}
#single-feature-menu .tab{display:flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;font-size:14px!important;font-weight:700!important;line-height:1.25!important}
#batch-panel .tab{display:flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;font-size:14px!important;font-weight:700!important;line-height:1.25!important}
.toolkit-pull-indicator{height:0;overflow:hidden;display:flex;align-items:center;justify-content:center;background:#064b5b;color:#b9e7ec;font-size:12px;transition:height .12s ease;margin:0 -2px}.toolkit-pull-indicator.visible{height:38px}
#single-feature-menu .toolkit-pull-indicator{grid-column:1/-1;width:100%;}
</style></head><body><main>
<header class="hero"><h1>RED DUST - EPUB Toolkit</h1><p>Semua fitur · Batch processing · Android offline standalone</p></header>
<section id="toolkit-home" class="panel toolkit-home">
 <h2>Choose Feature Mode</h2><p class="hint">Choose how you want to process your EPUB files.</p>
 <button class="mode-card" onclick="showSingleMenu()"><span class="mode-icon">📄</span><span class="mode-title">Single Feature</span><span class="mode-desc">Process one EPUB at a time</span><span class="mode-arrow">›</span></button>
 <button class="mode-card batch-mode" onclick="showBatchMenu()"><span class="mode-icon">📚</span><span class="mode-title">Batch Feature</span><span class="mode-desc">Process multiple files in one operation</span><span class="mode-arrow">›</span></button>
</section>
<nav id="single-feature-menu" class="grid hide">

<button class="tab" onclick="showTab('rename-title',this)">1. Rename File</button><button class="tab" onclick="showTab('remove-cover',this)">2. Remove Cover</button>
<button class="tab" onclick="showTab('cover-maker',this)">3. Add Cover</button><button class="tab" onclick="showTab('images',this)">4. Remove All Images</button>
<button class="tab" onclick="showTab('no-preview',this)">5. Add Paragraph</button><button class="tab" onclick="showTab('blank',this)">6. Remove Blank Spacing</button>
<button class="tab" onclick="showTab('compact',this)">7. Compact Line Spacing</button><button class="tab" onclick="showTab('compress',this)">8. Compress Image</button><button class="tab" onclick="showTab('bulk',this)">9. Bulk Find & Replace</button><button class="tab" onclick="showTab('unzip-single',this)">10. Unzip File</button>
<button type="button" class="action alt menu-back" onclick="showToolkitHome()">‹ Back to Feature Menu</button>
</nav>
<section id="remove-cover" class="panel"><h2>Remove EPUB Cover</h2><p class="hint">Menghapus gambar cover, halaman cover yang dikenali, dan metadata thumbnail.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-cover','remove-cover')">Remove Cover</button><div class="status" id="remove-cover-status">Pilih EPUB untuk diproses.</div></section>
<section id="no-preview" class="panel hide"><h2>Add Paragraph</h2><p class="hint">Merapikan paragraf XHTML pada file asli. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/no-preview','no-preview')">Fix Preview</button><div class="status" id="no-preview-status">Pilih EPUB untuk diproses.</div></section>
<section id="cover-maker" class="panel hide"><h2>Add Cover</h2><p class="hint">Membuat cover SVG dan halaman cover dari metadata judul dan penulis EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action alt" onclick="meta()">Baca Metadata</button><label>Judul cover</label><input id="title" type="text" placeholder="Judul cover"><div id="author" class="small"></div><button class="action" onclick="run('/make-cover','cover-maker',{title:val('title')})">Buat Cover</button><div class="status" id="cover-maker-status">Pilih EPUB lalu baca metadata.</div></section>
<section id="compress" class="panel hide"><h2>Compress Image</h2><p class="hint">Mengompres gambar JPEG, PNG, dan WebP di dalam EPUB. GIF dan SVG dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compress','compress')">Compress Images</button><div class="status" id="compress-status">Pilih EPUB untuk diproses. Memerlukan Pillow.</div></section>
<section id="bulk" class="panel hide"><h2>Bulk Find &amp; Replace</h2><p class="hint">Cari dan ganti teks pada EPUB atau TXT secara langsung. Perubahan akan langsung menimpa file asli.</p><label>Pilih EPUB/TXT</label><select id="bulkfile"></select><label>Teks yang dicari</label><input id="find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="regex" type="checkbox"> Regular expression</label><button class="action alt" onclick="bulk('/bulk-count')">Hitung Kecocokan</button><button class="action" onclick="bulk('/bulk-replace')">Ganti Semua</button><div class="status" id="bulk-status">Pilih file dan masukkan teks pencarian.</div></section>
<section id="compact" class="panel hide"><h2>Compact Line Spacing Fixer</h2><p class="hint">Membersihkan baris kosong/BR berulang, lalu mengatur line-height dan margin paragraf sesuai script asli.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/compact-spacing','compact')">Perbaiki Line Spacing</button><div class="status" id="compact-status">Pilih EPUB untuk diproses.</div></section>
<section id="blank" class="panel hide"><h2>Remove Blank Spacing</h2><p class="hint">Menghapus paragraf kosong saja. CSS dan jarak paragraf asli tetap dipertahankan.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/blank-spacing','blank')">Remove Blank Paragraphs</button><div class="status" id="blank-status">Pilih EPUB untuk diproses.</div></section>
<section id="images" class="panel hide"><h2>Remove All Images</h2><p class="hint">Menghapus file gambar dan referensi gambar dari EPUB.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="run('/remove-images','images')">Remove Images</button><div class="status" id="images-status">Pilih EPUB untuk diproses.</div></section>
<section id="rename-title" class="panel hide"><h2>Rename File</h2><p class="hint">Mengganti nama file EPUB berdasarkan judul (dc:title) di metadata EPUB. Isi EPUB tidak diubah. Jika nama sudah dipakai, aplikasi menambahkan akhiran angka agar file lain tidak tertimpa.</p><label>Pilih EPUB</label><select class="epub"></select><button class="action" onclick="renameByTitle()">Rename File</button><div class="status" id="rename-title-status">Pilih EPUB untuk membaca judul dan mengganti nama file.</div></section>
<section id="unzip-single" class="panel hide"><h2>Unzip File</h2><p class="hint">Ekstrak satu ZIP ke folder pilihan. File ZIP asli tetap disimpan; file yang sudah ada tidak ditimpa dan otomatis diberi akhiran angka.</p><label>Pilih ZIP</label><select id="single-unzip-file" onchange="updateSingleUnzipDestination()"><option value="">Pilih ZIP</option></select><label>Password ZIP (default)</label><input id="single-unzip-password" type="password" autocomplete="off" value="taiwanandnorthkorea" placeholder="Password ZIP"><label>Folder tujuan</label><select id="single-unzip-destination"></select><button type="button" class="action" onclick="runSingleUnzip()">Unzip File</button><div class="status" id="unzip-single-status">Pilih ZIP dan folder tujuan.</div></section>
<section id="folder-picker-panel" class="panel hide" style="margin:0 0 14px;padding:16px;border:2px solid #1265bd"><h2 style="font-size:17px;margin:0 0 8px">Pilih folder EPUB</h2><label for="folderFilter" style="margin-top:0">Tampilkan file dari folder</label><select id="folderFilter" onchange="renderFileChoices()" aria-label="Pilih folder untuk menyaring file"><option value="">Memuat folder…</option></select><p id="folderFilterHelp" class="hint" style="margin-bottom:0">Pilih Download untuk menampilkan EPUB dari folder Download saja. Pilih Semua folder untuk mencari di seluruh penyimpanan.</p></section>
<section id="batch-panel" class="panel hide" style="border:2px solid #15803d">
 <button type="button" class="action alt menu-back" onclick="showToolkitHome()">‹ Back to Feature Menu</button>
<h2>Batch Processing</h2><p class="hint">Jalankan salah satu fitur toolkit pada banyak file sekaligus. Pilih file manual atau gunakan tombol pilih semua pada folder aktif. File diproses satu per satu; file yang gagal tidak menghentikan file lainnya.</p>
<label for="batchOperation">Fitur yang dijalankan</label>
<select id="batchOperation" onchange="updateBatchOptions()">
<option value="/rename-by-title">1. Rename File</option><option value="/remove-cover">2. Remove Cover</option><option value="/make-cover">3. Add Cover</option><option value="/remove-images">4. Remove All Images</option><option value="/no-preview">5. Add Paragraph</option><option value="/blank-spacing">6. Remove Blank Spacing</option><option value="/compact-spacing">7. Compact Line Spacing</option><option value="/compress">8. Compress Image</option><option value="/batch-unzip">9. Batch Unzip (ZIP)</option><option value="/bulk-count">10. Bulk Find &amp; Replace — Count Matches</option><option value="/bulk-replace">11. Bulk Find &amp; Replace — Execute</option>
</select>
<div id="batch-options"></div>
<div class="row" style="display:flex;gap:8px;margin-top:12px"><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(true)">Pilih semua di folder aktif</button><button type="button" class="action alt" style="margin:0" onclick="selectVisibleBatch(false)">Kosongkan pilihan</button></div>
<div id="batch-selection-count" class="small" style="margin:10px 0">0 file dipilih</div><div id="batch-file-list" style="max-height:200px;overflow:auto;border:1px solid #d8e0eb;border-radius:9px;padding:8px"><span class="small">Memuat daftar file…</span></div>
<button class="action" onclick="runBatch()">Jalankan Batch</button><div class="status" id="batch-status">Pilih fitur dan satu atau beberapa file.</div>
</section>
<footer>EPUB Toolkit · Berjalan sepenuhnya offline melalui Android WebView bridge. Pilih folder atau file satu per satu untuk batch. Perubahan disimpan langsung ke file asli; tidak ada backup yang dibuat.</footer></main>

<div id="reader-view">
  <section id="library-view">
    <div id="library-refresh-indicator" aria-live="polite">Tarik ke bawah untuk scan ulang</div>
    <div id="library-top">
      <div class="lib-title">My Library</div>
      <input id="library-search" type="search" placeholder="Search your EPUB books…" oninput="renderLibrary()">
      <div id="library-sort-row"><label id="library-sort-label" for="library-sort">Sort:</label><select id="library-sort" onchange="setLibrarySort(this.value)"><option value="name">Name (A–Z)</option><option value="added">Date added</option><option value="recent">Recently opened</option></select></div>
    </div>
    <div id="library-stats">Your EPUB collection</div>
    <div id="library-selection-toolbar"><span id="library-selection-count">0 selected</span><button onclick="selectAllVisibleBooks()">Select all</button><button onclick="cancelBookSelection()">Cancel</button><button class="delete" onclick="deleteSelectedBooks()">Delete</button></div>
    <div id="library-books"></div>
  </section>
  <section id="reader-search-screen" aria-label="Find in Book">
    <div id="reader-search-head">
      <button class="search-back" onclick="closeReaderSearch()" aria-label="Back">‹</button>
      <input id="reader-dedicated-search-input" type="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="Text search" oninput="showReaderSearchHistory()" onkeydown="if(event.key==='Enter'){event.preventDefault();searchDedicatedBook();}">
      <button class="search-clear" onclick="clearDedicatedSearch()" aria-label="Clear search">×</button>
    </div>
    <div id="reader-search-history"></div>
    <div id="reader-search-body">
      <div id="reader-search-loading">◔</div>
      <div id="reader-search-empty"></div>
      <div id="reader-search-results"></div>
    </div>
  </section>
  <section id="reader-screen">
    <div id="reader-screen-head">
      <button onclick="closeReaderBook()" aria-label="Back to library">‹</button>
      <div id="reader-book-title">Reading</div>
      <button onclick="openReaderSearch()" aria-label="Find in book">⌕</button><button onclick="toggleReaderMenu('settings')" aria-label="Display settings">⚙</button><button onclick="toggleReaderMenu('navigation-controls')" aria-label="Navigation"><svg viewBox="0 0 64 64" width="25" height="25" style="vertical-align:middle"><rect x="10" y="12" width="44" height="40" rx="8" fill="none" stroke="currentColor" stroke-width="3"/><path d="M25 22 L16 32 L25 42 M39 22 L48 32 L39 42" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button><button onclick="toggleReaderMenu('navigation')" aria-label="Table of contents">☷</button>
    </div>
    <div id="reader-controls">
      <div id="reader-search-status" aria-live="polite"></div>
      <div id="reader-settings-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Display settings</div>
        <div class="reader-settings">
          <div><label for="reader-font">Font size: <span id="font-value">19</span> px</label><input id="reader-font" type="range" min="14" max="32" value="19" oninput="setReaderStyle()"></div>
          <div><label for="reader-line">Line spacing: <span id="line-value">1.65</span></label><input id="reader-line" type="range" min="1.2" max="2.4" step="0.05" value="1.65" oninput="setReaderStyle()"></div>
          <div><label for="reader-para">Paragraph spacing: <span id="para-value">1.0</span> em</label><input id="reader-para" type="range" min="0" max="2.5" step="0.1" value="1" oninput="setReaderStyle()"></div>
          <div><label for="reader-letter">Font spacing: <span id="letter-value">0</span> px</label><input id="reader-letter" type="range" min="-0.5" max="2" step="0.1" value="0" oninput="setReaderStyle()"></div>
          <div><label for="reader-family">Font type</label><select id="reader-family" onchange="setReaderStyle()"><option value="Georgia,serif">Georgia / Serif</option><option value="'Noto Serif',serif">Noto Serif</option><option value="'Noto Sans',Arial,sans-serif">Noto Sans</option><option value="Roboto,Arial,sans-serif">Roboto</option><option value="Arial,sans-serif">Arial</option><option value="Verdana,sans-serif">Verdana</option><option value="'Times New Roman',serif">Times New Roman</option><option value="monospace">Monospace</option></select></div>
          <div><label for="reader-weight">Font thickness: <span id="weight-value">400</span></label><input id="reader-weight" type="range" min="300" max="900" step="100" value="400" oninput="setReaderStyle()"></div>
        </div>
        <div class="theme-row"><button onclick="readerTheme('light')">Light</button><button onclick="readerTheme('sepia')">Sepia</button><button onclick="readerTheme('night')">Night</button></div>
      </div>
      <div id="reader-navigation-controls-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Navigation</div>
        <div class="reader-actions"><button class="secondary" onclick="readerPrev()">Previous chapter</button><button class="secondary" onclick="readerNext()">Next chapter</button><span id="reader-progress" style="color:#aaa;font-size:12px;align-self:center;margin-left:auto"></span></div>
        <div class="page-nav"><button class="secondary" onclick="readerPagePrev()">‹ Page</button><button class="secondary" onclick="readerPageNext()">Page ›</button><span id="reader-page-count">Page 1</span></div>
      </div>
      <div id="reader-navigation-menu" class="reader-popup-menu">
        <div class="reader-popup-title">Table of contents</div>
        <label for="reader-chapter">Choose chapter</label><select id="reader-chapter" onchange="loadReaderChapter()"><option value="0">Chapter</option></select>
      </div>
    </div>
    <article id="reader-content" class="reader-page"><div class="reader-empty">Choose a book from your library to start reading.</div></article>
    <div id="reader-reading-footer" aria-hidden="true"><span id="reader-footer-chapter">Chapter 1</span><span id="reader-footer-page">Page 1</span></div>
  </section>
</div>
<nav id="gallery-nav">
 <button id="gallery-albums" class="gallery-btn active" onclick="switchGallery('albums')"><span class="gallery-emoji" aria-hidden="true">📖</span>Read Book</button>
 <button id="gallery-photos" class="gallery-btn" onclick="switchGallery('photos')"><span class="gallery-emoji" aria-hidden="true">🛠️</span>Tools</button>
</nav>

<script>
const $=id=>document.getElementById(id), val=id=>$(id).value;let files=[];const readerCoverCache={};
// Stage 3.3: bound retained cover data to prevent library browsing from growing
// the JavaScript cache indefinitely. Large covers are displayed but not retained.
const READER_COVER_CACHE_MAX_ENTRIES=10, READER_COVER_CACHE_MAX_CHARS=4*1024*1024, READER_COVER_CACHE_MAX_ITEM_CHARS=1536*1024;
function readerCoverCacheChars(){return Object.values(readerCoverCache).reduce((sum,value)=>sum+(typeof value==='string'?value.length:0),0);}
function readerCoverCacheSet(key,value){delete readerCoverCache[key];if(typeof value==='string'&&value.length>READER_COVER_CACHE_MAX_ITEM_CHARS)return;readerCoverCache[key]=value;while(Object.keys(readerCoverCache).length>READER_COVER_CACHE_MAX_ENTRIES||readerCoverCacheChars()>READER_COVER_CACHE_MAX_CHARS){const first=Object.keys(readerCoverCache)[0];if(first===undefined)break;delete readerCoverCache[first];}}
function readerCoverCacheTouch(key){if(!Object.prototype.hasOwnProperty.call(readerCoverCache,key))return;const value=readerCoverCache[key];delete readerCoverCache[key];readerCoverCache[key]=value;}
let selectedBookPaths=new Set(),bookLongPressTimer=null,suppressBookClick=false;

// Startup destination is explicitly Read Book / My Library.
const DEFAULT_GALLERY_SCREEN='albums';
function switchGallery(which=DEFAULT_GALLERY_SCREEN){
  const albums=which==='albums';
  document.body.classList.toggle('reader-active',albums);
  $('reader-view').classList.remove('controls-hidden');
  document.querySelector('main').style.display=albums?'none':'block';
  $('reader-view').style.display=albums?'block':'none';
  $('library-view').style.display='block';$('reader-screen').style.display='none';if(!albums)showToolkitHome();
  $('gallery-photos').classList.toggle('active',!albums);
  $('gallery-albums').classList.toggle('active',albums);
  if(albums)populateReaderFiles();
}
let readerBook=null, readerFileLoaded='', readerSearchMatches=[], readerSearchIndex=-1, readerSearchQuery='';
let readerSearchPanelScrollTop=0;
let readerSearchHistory=[];
let libraryPullStartY=0,libraryPullStartX=0,libraryPullArmed=false,libraryPullDistance=0,libraryRefreshBusy=false;
const libraryScrollArea=$('reader-view');
if(libraryScrollArea){
 libraryScrollArea.addEventListener('touchstart',e=>{
  if($('library-view').style.display==='none'||$('reader-screen').style.display==='block'||libraryRefreshBusy||e.touches.length!==1)return;
  const t=e.touches[0];libraryPullStartY=t.clientY;libraryPullStartX=t.clientX;libraryPullArmed=libraryScrollArea.scrollTop<=2;libraryPullDistance=0;
 },{passive:true});
 libraryScrollArea.addEventListener('touchmove',e=>{
  if(!libraryPullArmed||e.touches.length!==1)return;
  const t=e.touches[0],dy=t.clientY-libraryPullStartY,dx=t.clientX-libraryPullStartX;
  if(Math.abs(dx)>Math.abs(dy)*.8){libraryPullArmed=false;return;}
  if(dy>0&&libraryScrollArea.scrollTop<=2){libraryPullDistance=Math.min(100,dy);const ind=$('library-refresh-indicator');if(ind){ind.classList.toggle('visible',dy>12);ind.textContent=dy>=76?'Lepaskan untuk scan ulang':'Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchend',()=>{
  const shouldRefresh=libraryPullArmed&&libraryPullDistance>=76;libraryPullArmed=false;libraryPullDistance=0;
  if(shouldRefresh)refreshLibraryScan();else{const ind=$('library-refresh-indicator');if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}}
 },{passive:true});
 libraryScrollArea.addEventListener('touchcancel',()=>{libraryPullArmed=false;libraryPullDistance=0;const ind=$('library-refresh-indicator');if(ind)ind.classList.remove('visible');},{passive:true});
}
// V4.2.14: reliable toolkit pull-to-refresh. The previous threshold was unreachable
// (distance capped at 100px while requiring 130px), and the indicator was not in the DOM.
(function(){
 const panels=[$('single-feature-menu'),$('batch-panel')].filter(Boolean);
 panels.forEach(panel=>{
  let startY=0,startX=0,distance=0,armed=false;
  let ind=panel.querySelector('.toolkit-pull-indicator');
  if(!ind){ind=document.createElement('div');ind.className='toolkit-pull-indicator';ind.textContent='Pull down to scan files';panel.prepend(ind);}
  const atTop=()=>panel.scrollTop<=2&&window.scrollY<=2;
  panel.addEventListener('touchstart',e=>{if(e.touches.length!==1||libraryRefreshBusy)return;const t=e.touches[0];startY=t.clientY;startX=t.clientX;distance=0;armed=atTop();},{passive:true});
  panel.addEventListener('touchmove',e=>{if(!armed||e.touches.length!==1)return;const t=e.touches[0],dy=t.clientY-startY,dx=t.clientX-startX;if(Math.abs(dx)>Math.abs(dy)*.8){armed=false;return;}if(dy>0&&atTop()){distance=Math.min(220,dy);ind.classList.toggle('visible',dy>35);ind.textContent=dy>=150?'Release to scan files':'Pull down to scan files';}},{passive:true});
  panel.addEventListener('touchend',()=>{const refresh=armed&&distance>=150;armed=false;distance=0;if(refresh)refreshToolkitFiles(panel);else{ind.classList.remove('visible');ind.textContent='Pull down to scan files';}},{passive:true});
  panel.addEventListener('touchcancel',()=>{armed=false;distance=0;ind.classList.remove('visible');},{passive:true});
 });
})();
async function refreshToolkitFiles(panel){if(libraryRefreshBusy)return;libraryRefreshBusy=true;const ind=panel&&panel.querySelector('.toolkit-pull-indicator');if(ind){ind.classList.add('visible');ind.textContent='Scanning files…';}try{await new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,30)));await loadFiles();if(ind)ind.textContent='Scan complete';}catch(e){if(ind)ind.textContent='Scan failed: '+e.message;}setTimeout(()=>{if(ind){ind.classList.remove('visible');ind.textContent='Pull down to scan files';}libraryRefreshBusy=false;},900);}
async function refreshLibraryScan(){
 if(libraryRefreshBusy)return;libraryRefreshBusy=true;const ind=$('library-refresh-indicator');
 if(ind){ind.classList.add('visible');ind.textContent='Memindai ulang EPUB…';}
 try{
  Object.keys(readerCoverCache).forEach(k=>delete readerCoverCache[k]);
  await new Promise(resolve=>requestAnimationFrame(()=>setTimeout(resolve,30)));
  await loadFiles();
  if(ind)ind.textContent='Scan selesai · My Library diperbarui';
 }catch(e){if(ind)ind.textContent='Gagal scan ulang: '+e.message;}
 setTimeout(()=>{if(ind){ind.classList.remove('visible');ind.textContent='Tarik ke bawah untuk scan ulang';}libraryRefreshBusy=false;},900);
}
function savedReaderState(){try{return JSON.parse(localStorage.getItem('redDustReaderProgress')||'{}')}catch(e){return {}}}
let readerPendingFragment='';
function readerLinkPath(raw,current){try{const u=new URL(String(raw||''),'https://rd-epub.invalid/'+String(current||'').replace(/^\//,''));let p=decodeURIComponent(u.pathname).replace(/^\//,'');const parts=[];p.split('/').forEach(seg=>{if(!seg||seg==='.')return;if(seg==='..')parts.pop();else parts.push(seg);});return parts.join('/');}catch(e){return '';}}
function readerLandOnFragment(fragment){if(!fragment)return;const el=$('reader-content');let target=null;try{target=el.querySelector('[id="'+CSS.escape(fragment)+'"]')||el.querySelector('[name="'+CSS.escape(fragment)+'"]');}catch(e){}if(target){const rect=target.getBoundingClientRect();const base=el.getBoundingClientRect();el.scrollLeft=Math.max(0,el.scrollLeft+rect.left-base.left);updateReaderPageCount();saveReaderState();}}
function readerFragmentFromHref(raw){const i=String(raw||'').indexOf('#');if(i<0)return '';try{return decodeURIComponent(String(raw).slice(i+1));}catch(e){return String(raw).slice(i+1);}}
function handleReaderInternalLink(event){const anchor=event.target&&event.target.closest?event.target.closest('a[data-rd-href]'):null;if(!anchor)return;event.preventDefault();const raw=(anchor.getAttribute('data-rd-href')||'').trim();if(!raw)return;const current=readerBook&&readerBook.chapters[readerBook.index]?readerBook.chapters[readerBook.index].href:'';const targetPath=readerLinkPath(raw.split('#')[0]||current,current);const fragment=readerFragmentFromHref(raw);const currentPath=readerLinkPath(current,current);if(!targetPath||targetPath===currentPath){readerLandOnFragment(fragment);return;}const chapters=readerBook&&readerBook.chapters||[];let idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href)===targetPath);if(idx<0){const base=targetPath.split('/').pop().toLowerCase();if(base)idx=chapters.findIndex(c=>readerLinkPath(c.href,c.href).split('/').pop().toLowerCase()===base);}if(idx>=0){readerPendingFragment=fragment;navigateReaderChapter(idx,'start');}else{console.warn('EPUB internal link target was not found in reading chapters:',raw,targetPath);}}
function readerCurrentPage(){const el=$('reader-content');return el&&el.clientWidth>0?Math.max(0,Math.round(el.scrollLeft/Math.max(1,el.clientWidth))):0;}
function saveReaderState(){if(!readerFileLoaded||!readerBook)return;const all=savedReaderState();all[readerFileLoaded]={chapter:readerBook.index||0,page:readerCurrentPage(),title:readerBook.title||''};try{localStorage.setItem('redDustReaderProgress',JSON.stringify(all));}catch(e){}}
function populateReaderFiles(){renderLibrary();}
function libraryTimestamps(){
 try{return JSON.parse(localStorage.getItem('redDustLibraryTimestamps')||'{"added":{},"recent":{}}');}
 catch(e){return {added:{},recent:{}};}
}
function setLibrarySort(mode){
 try{localStorage.setItem('redDustLibrarySort',mode);}catch(e){}
 renderLibrary();
}
function isBookSelectionMode(){return selectedBookPaths.size>0;}
function updateBookSelectionUI(){
 const toolbar=$('library-selection-toolbar'),count=$('library-selection-count');
 if(toolbar)toolbar.classList.toggle('visible',isBookSelectionMode());
 if(count)count.textContent=selectedBookPaths.size+' book'+(selectedBookPaths.size===1?'':'s')+' selected';
 $('library-view').classList.toggle('selection-mode',isBookSelectionMode());
}
function toggleBookSelection(path){if(selectedBookPaths.has(path))selectedBookPaths.delete(path);else selectedBookPaths.add(path);updateBookSelectionUI();renderLibrary();}
function beginBookSelection(path){if(!selectedBookPaths.has(path))selectedBookPaths.add(path);suppressBookClick=true;updateBookSelectionUI();renderLibrary();setTimeout(()=>{suppressBookClick=false;},450);}
function cancelBookSelection(){selectedBookPaths.clear();updateBookSelectionUI();renderLibrary();}
function selectAllVisibleBooks(){const q=($('library-search')?.value||'').toLowerCase().trim();files.filter(f=>/\.epub$/i.test(f.name)&&(!q||librarySearchText(f).includes(q))).forEach(f=>selectedBookPaths.add(f.path));updateBookSelectionUI();renderLibrary();}
async function deleteSelectedBooks(){
 const targets=[...selectedBookPaths];if(!targets.length)return;
 if(!confirm('Delete '+targets.length+' selected book'+(targets.length===1?'':'s')+' from your device? This cannot be undone.'))return;
 let deleted=0,failed=[];const progress=savedReaderState(),stamps=libraryTimestamps();
 for(const file of targets){try{await api('/delete-book',{file});deleted++;delete progress[file];delete stamps.added[file];delete stamps.recent[file];selectedBookPaths.delete(file);}catch(e){failed.push(file.split('/').pop()+': '+e.message);}}
 try{localStorage.setItem('redDustReaderProgress',JSON.stringify(progress));localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 updateBookSelectionUI();await loadFiles();
 if(failed.length)alert(deleted+' book(s) deleted. Could not delete '+failed.length+':\n'+failed.join('\n'));
 else alert(deleted+' book(s) deleted.');
}
function renderLibrary(){
 const box=$('library-books');if(!box)return;box.innerHTML='';
 const q=($('library-search')?.value||'').toLowerCase().trim();
 const books=files.filter(f=>/\.epub$/i.test(f.name)&&(!q||librarySearchText(f).includes(q)));
 const stamps=libraryTimestamps(),now=Date.now();
 books.forEach(f=>{if(!stamps.added[f.path])stamps.added[f.path]=(Number(f.added)>0?Number(f.added)*1000:now);});
 try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}
 const sortControl=$('library-sort');let sort=localStorage.getItem('redDustLibrarySort')||'name';
 if(!['name','added','recent'].includes(sort))sort='name';
 if(sortControl)sortControl.value=sort;
 books.sort((a,b)=>{
  if(sort==='added')return (stamps.added[b.path]||0)-(stamps.added[a.path]||0)||a.name.localeCompare(b.name);
  if(sort==='recent')return (stamps.recent[b.path]||0)-(stamps.recent[a.path]||0)||a.name.localeCompare(b.name);
  return a.name.localeCompare(b.name,undefined,{sensitivity:'base'});
 });
 $('library-stats').textContent=books.length+' EPUB book'+(books.length===1?'':'s')+' · Tap to read · Hold to select';
 updateBookSelectionUI();
 if(!books.length){box.innerHTML='<div class="reader-empty">No EPUB books found. Add EPUB files to your device storage and refresh the app.</div>';return;}
 const progress=savedReaderState();
 books.forEach(f=>{const state=progress[f.path],card=document.createElement('div');card.className='book-card'+(selectedBookPaths.has(f.path)?' selected':'');
 card.onclick=()=>{if(suppressBookClick){suppressBookClick=false;return;}if(isBookSelectionMode())toggleBookSelection(f.path);else openReaderBook(f.path,state?.chapter||0);};
 let pressMoved=false;
 card.addEventListener('touchstart',()=>{pressMoved=false;clearTimeout(bookLongPressTimer);bookLongPressTimer=setTimeout(()=>beginBookSelection(f.path),560);},{passive:true});
 card.addEventListener('touchmove',()=>{pressMoved=true;clearTimeout(bookLongPressTimer);},{passive:true});
 card.addEventListener('touchend',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('touchcancel',()=>clearTimeout(bookLongPressTimer),{passive:true});
 card.addEventListener('contextmenu',e=>{e.preventDefault();beginBookSelection(f.path);});
 const selectMark=document.createElement('div');selectMark.className='book-select-mark';selectMark.textContent=selectedBookPaths.has(f.path)?'✓':'';
 const cover=document.createElement('div');cover.className='book-cover';cover.innerHTML='<span>▤</span>';
 if(Object.prototype.hasOwnProperty.call(readerCoverCache,f.path)){
  readerCoverCacheTouch(f.path);
  if(readerCoverCache[f.path]){const img=document.createElement('img');img.alt='Book cover';img.src=readerCoverCache[f.path];cover.replaceChildren(img);}
 }else{
  readerCoverCacheSet(f.path,null);
  api('/reader-cover',{file:f.path}).then(result=>{
   if(result.cover){readerCoverCacheSet(f.path,result.cover);
    if(card.isConnected){const img=document.createElement('img');img.alt='Book cover';img.src=result.cover;cover.replaceChildren(img);}
   }
  }).catch(()=>{});
 }
 const info=document.createElement('div');info.className='book-info';
 const name=document.createElement('div');name.className='book-name';name.textContent=f.name.replace(/\.epub$/i,'');
 const meta=document.createElement('div');meta.className='book-meta';meta.textContent='EPUB · '+(f.size||'');
 const hint=document.createElement('div');hint.className='book-open-hint';hint.textContent=state?'Continue reading · Chapter '+(state.chapter+1):'Tap to start reading';
 const bar=document.createElement('div');bar.className='book-progress';const fill=document.createElement('i');fill.style.width=state?'12%':'0%';bar.appendChild(fill);
 info.append(name,meta,hint,bar);card.append(selectMark,cover,info);box.appendChild(card);
 });
}
async function openReaderBook(file,chapter,page=0){
 file=file||'';if(!file)return;readerRestorePage=Math.max(0,Number(page)||0);try{localStorage.setItem('redDustLastOpenedBook',file);}catch(e){}
 readerSearchMatches=[];readerSearchIndex=-1;readerSearchQuery='';$('reader-dedicated-search-input').value='';$('reader-search-status').textContent='';
 $('library-view').style.display='none';$('reader-search-screen').classList.remove('active');$('reader-screen').style.display='block';
 $('reader-view').classList.remove('controls-hidden');
 document.body.classList.add('reader-reading');
 $('reader-content').innerHTML='<div class="reader-empty">Opening book…</div>';
 $('reader-book-title').textContent=file.split('/').pop().replace(/\.epub$/i,'');
 try{readerBook=await api('/reader-open',{file,chapter:chapter||0});readerFileLoaded=file;const stamps=libraryTimestamps();stamps.recent[file]=Date.now();try{localStorage.setItem('redDustLibraryTimestamps',JSON.stringify(stamps));}catch(e){}renderReaderChapter();}catch(e){$('reader-content').textContent='Could not open EPUB: '+e.message;}
}
function closeReaderBook(){saveReaderState();document.body.classList.remove('reader-reading');$('reader-screen').style.display='none';$('library-view').style.display='block';$('reader-view').classList.remove('controls-hidden');renderLibrary();}
function restoreReaderAfterWebViewError(){try{const file=localStorage.getItem('redDustLastOpenedBook');if(!file)return;const state=savedReaderState();openReaderBook(file,state[file]?.chapter||0,state[file]?.page||0);}catch(e){console.warn('Reader restore failed',e);}}
function handleAndroidBack(){if(isBookSelectionMode()&&$('library-view').style.display!=='none'){cancelBookSelection();return true;}if($('reader-search-screen').classList.contains('active')){closeReaderSearch();return true;}if($('reader-view').style.display==='block'&&document.querySelector('#reader-view .reader-popup-menu.active')){closeReaderMenus();return true;}if($('reader-screen').style.display==='block'){closeReaderBook();return true;}if(document.querySelector('main').style.display!=='none'&&(!$('single-feature-menu').classList.contains('hide')||!$('batch-panel').classList.contains('hide'))){showToolkitHome();return true;}if($('reader-view').style.display==='block'){return false;}if(document.querySelector('main').style.display!=='none'){switchGallery('albums');return true;}return false;}
async function loadReaderChapter(position='start'){
 if(!readerFileLoaded)return;
 try{
  readerChapterLanding=position;
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:parseInt(val('reader-chapter')||0)});
  renderReaderChapter();
 }catch(e){$('reader-content').textContent='Could not load chapter: '+e.message;}
}
let readerChapterLanding='start';
let readerRestorePage=0;
async function navigateReaderChapter(index,position){
 if(!readerBook||index<0||index>=readerBook.chapters.length)return;
 $('reader-chapter').value=String(index);
 await loadReaderChapter(position);
}
function renderReaderChapter(){
 /* Preserve the reader chrome state when moving between chapters. */
 const landing=readerChapterLanding;readerChapterLanding='start';
 const s=$('reader-chapter');s.innerHTML='';
 readerBook.chapters.forEach((c,i)=>s.add(new Option((i+1)+'. '+c.title,i)));
 s.value=String(readerBook.index);
 $('reader-content').innerHTML=readerBook.content;
 const readerContent=$('reader-content');if(!readerContent.dataset.rdLinkHandler){readerContent.addEventListener('click',handleReaderInternalLink);readerContent.dataset.rdLinkHandler='1';}
 $('reader-book-title').textContent=readerBook.title||'Reading';
 if(readerSearchQuery)highlightReaderSearch();
 $('reader-content').scrollLeft=0;
 saveReaderState();
 $('reader-progress').textContent=(readerBook.index+1)+' / '+readerBook.chapters.length;
 setReaderStyle();
 initReaderSwipe();
 /* Wait for WebView to lay out the new chapter columns before landing. */
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const el=$('reader-content');
  if(landing==='end'){el.scrollLeft=el.scrollWidth;}else{el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,Math.max(0,readerRestorePage)*readerPageWidth());readerRestorePage=0;}
  if(readerPendingFragment){const fragment=readerPendingFragment;readerPendingFragment='';readerLandOnFragment(fragment);}
  updateReaderPageCount();saveReaderState();
 }));
}
let readerTouchX=0,readerTouchY=0,readerTouchStart=0;
function readerPageWidth(){const el=$('reader-content');return Math.max(120,el.clientWidth);}
function updateReaderPageCount(){const el=$('reader-content');if(!el)return;const page=Math.max(1,Math.round(el.scrollLeft/readerPageWidth())+1);$('reader-page-count').textContent='Page '+page;const footerPage=$('reader-footer-page');if(footerPage)footerPage.textContent='Page '+page;const footerChapter=$('reader-footer-chapter');if(footerChapter)footerChapter.textContent='Chapter '+((readerBook?.index||0)+1);}
function readerPageNext(){const el=$('reader-content');const atEnd=el.scrollLeft+el.clientWidth>=el.scrollWidth-36;if(atEnd){if(readerBook&&readerBook.index<readerBook.chapters.length-1){navigateReaderChapter(readerBook.index+1,'start');return;}return;}el.scrollLeft=Math.min(el.scrollWidth-el.clientWidth,el.scrollLeft+readerPageWidth());updateReaderPageCount();}
function readerPagePrev(){const el=$('reader-content');if(el.scrollLeft<=4){if(readerBook&&readerBook.index>0){navigateReaderChapter(readerBook.index-1,'end');return;}return;}el.scrollLeft=Math.max(0,el.scrollLeft-readerPageWidth());updateReaderPageCount();}
function toggleReaderControls(){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.toggle('controls-hidden');closeReaderMenus();}
function closeReaderMenus(){['reader-settings-menu','reader-navigation-menu','reader-navigation-controls-menu'].forEach(id=>$(id).classList.remove('active'));}
function toggleReaderMenu(which){const view=$('reader-view');if(view.style.display!=='block')return;view.classList.remove('controls-hidden');const map={settings:'reader-settings-menu',navigation:'reader-navigation-menu','navigation-controls':'reader-navigation-controls-menu'};const target=map[which]||'reader-navigation-menu';const wasOpen=$(target).classList.contains('active');closeReaderMenus();if(!wasOpen)$(target).classList.add('active');}
function initReaderSwipe(){
 const el=$('reader-content');
 if(!el)return;
 if(el.dataset.swipeReady)return;
 el.dataset.swipeReady='1';
 el.addEventListener('touchstart',e=>{if(e.touches.length===1){readerTouchX=e.touches[0].clientX;readerTouchY=e.touches[0].clientY;readerTouchStart=Date.now();}},{passive:true});
 el.addEventListener('touchend',e=>{
  if(!e.changedTouches.length)return;
  const t=e.changedTouches[0],dx=t.clientX-readerTouchX,dy=t.clientY-readerTouchY;
  /* Keep the existing swipe navigation unchanged. */
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.25){if(dx<0)readerPageNext();else readerPagePrev();return;}
  if(Date.now()-readerTouchStart>600||Math.abs(dx)>18||Math.abs(dy)>18)return;
  if(e.target.closest('a,button,input,select,textarea'))return;
  const rect=el.getBoundingClientRect(),relativeX=(t.clientX-rect.left)/Math.max(1,rect.width);
  /* Center toggles the overlay; screen edges turn pages in either direction. */
  if(relativeX>=0.35&&relativeX<=0.65){toggleReaderControls();return;}
  if(relativeX>0.65){readerPageNext();return;}
  readerPagePrev();
 },{passive:true});
 el.addEventListener('scroll',()=>{updateReaderPageCount();saveReaderState();},{passive:true});
}

function readerSearchHistoryKey(){return String(readerFileLoaded||'').trim()||'__no_book__';}
function loadReaderSearchHistory(){try{const raw=JSON.parse(localStorage.getItem('epubToolkitReaderSearchHistoryByBook')||'{}');const saved=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw[readerSearchHistoryKey()]:[];readerSearchHistory=Array.isArray(saved)?saved.filter(x=>typeof x==='string'&&x.trim()).slice(0,20):[];}catch(e){readerSearchHistory=[];}}
function saveReaderSearchHistory(){try{const raw=JSON.parse(localStorage.getItem('epubToolkitReaderSearchHistoryByBook')||'{}');const store=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};store[readerSearchHistoryKey()]=readerSearchHistory.slice(0,20);localStorage.setItem('epubToolkitReaderSearchHistoryByBook',JSON.stringify(store));}catch(e){}}
function showReaderSearchHistory(){
 const input=$('reader-dedicated-search-input'),box=$('reader-search-history');if(!input||!box)return;
 if(!input.value.trim()){box.classList.remove('visible');box.innerHTML='';return;}
 loadReaderSearchHistory();box.innerHTML='';if(!readerSearchHistory.length){box.classList.remove('visible');return;}
 readerSearchHistory.forEach((q,i)=>{const row=document.createElement('div');row.className='reader-search-history-item';row.innerHTML='<span class="history-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8"></path><path d="M3 3v5h5"></path></svg></span><span class="history-query"></span>';row.querySelector('.history-query').textContent=q;let wasLongPressed=false;row.onclick=()=>{if(wasLongPressed){wasLongPressed=false;return;}input.value=q;searchDedicatedBook();};
  let pressTimer=null;const cancel=()=>{if(pressTimer){clearTimeout(pressTimer);pressTimer=null;}};
  row.addEventListener('touchstart',()=>{wasLongPressed=false;pressTimer=setTimeout(()=>{wasLongPressed=true;readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();pressTimer=null;},550);},{passive:true});row.addEventListener('touchend',cancel,{passive:true});row.addEventListener('touchmove',cancel,{passive:true});row.addEventListener('contextmenu',e=>{e.preventDefault();readerSearchHistory.splice(i,1);saveReaderSearchHistory();showReaderSearchHistory();});box.appendChild(row);
 });box.classList.add('visible');
}
function openReaderSearch(){
 const screen=$('reader-search-screen');if(!screen)return;
 const body=$('reader-search-body'),input=$('reader-dedicated-search-input');screen.classList.add('active');
 // Preserve query/results/selection/scroll on return; otherwise open a clean search view.
 if(readerSearchMatches.length&&readerSearchQuery){input.value=readerSearchQuery;$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='';}
 else if(!readerSearchQuery){input.value='';$('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';$('reader-search-loading').classList.remove('active');}
 if(readerSearchMatches.length&&readerSearchQuery){$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';}else{showReaderSearchHistory();}
 requestAnimationFrame(()=>{if(readerSearchMatches.length&&readerSearchQuery){body.scrollTop=readerSearchPanelScrollTop;}else{input.focus();try{input.setSelectionRange(input.value.length,input.value.length);}catch(e){}}});
}
function closeReaderSearch(){
 const screen=$('reader-search-screen'),body=$('reader-search-body');
 if(body)readerSearchPanelScrollTop=body.scrollTop;
 if(screen)screen.classList.remove('active');
 try{if(document.activeElement)document.activeElement.blur();}catch(e){}
}
function clearDedicatedSearch(){
 const input=$('reader-dedicated-search-input');
 input.value='';input.focus();
 $('reader-search-results').innerHTML='';$('reader-search-empty').textContent='';
 $('reader-search-loading').classList.remove('active');
}
function escapeHtmlText(text){return String(text||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderDedicatedSearchResults(matches,query){
 const box=$('reader-search-results');box.innerHTML='';
 if(!matches.length){$('reader-search-empty').textContent='No results found';return;}
 const needle=query.toLocaleLowerCase();
 matches.forEach((m,i)=>{
  const card=document.createElement('div');card.className='search-result-card'+(i===readerSearchIndex?' search-result-selected':'');card.setAttribute('role','button');card.setAttribute('tabindex','0');if(i===readerSearchIndex)card.setAttribute('aria-current','true');
  const textWrap=document.createElement('div');textWrap.className='search-result-text';
  const chapterTitle=document.createElement('div');chapterTitle.className='search-result-chapter-title';
  const chapter=Number(m.chapter)||0;chapterTitle.textContent='Chapter '+(chapter+1)+(m.chapter_title?' · '+m.chapter_title:'');
  const snippet=document.createElement('div');snippet.className='search-result-snippet';
  const raw=String(m.snippet||'');const lower=raw.toLocaleLowerCase();let from=0,html='';
  while(true){const at=lower.indexOf(needle,from);if(at<0){html+=escapeHtmlText(raw.slice(from));break;}html+=escapeHtmlText(raw.slice(from,at))+'<mark>'+escapeHtmlText(raw.slice(at,at+query.length))+'</mark>';from=at+query.length;}
  snippet.innerHTML=html;textWrap.append(chapterTitle,snippet);
  const loc=document.createElement('div');loc.className='search-result-location';loc.textContent='Ch. '+(chapter+1);
  card.append(textWrap,loc);card.onclick=async()=>{readerSearchIndex=i;readerSearchPanelScrollTop=card.offsetTop;renderDedicatedSearchResults(readerSearchMatches,readerSearchQuery);closeReaderSearch();await goToReaderSearchMatch();};card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}};
  box.appendChild(card);
 });
}
async function searchDedicatedBook(){
 const input=$('reader-dedicated-search-input');const query=(input?.value||'').trim();
 if(!readerFileLoaded||!query)return;
 readerSearchQuery=query;readerSearchMatches=[];readerSearchIndex=-1;readerSearchPanelScrollTop=0;$('reader-search-body').scrollTop=0;
 try{localStorage.setItem('redDustLastReaderSearch',query);}catch(e){}
 loadReaderSearchHistory();readerSearchHistory=[query,...readerSearchHistory.filter(x=>x.toLocaleLowerCase()!==query.toLocaleLowerCase())].slice(0,20);saveReaderSearchHistory();$('reader-search-history').classList.remove('visible');$('reader-search-history').innerHTML='';
 $('reader-search-empty').textContent='';$('reader-search-results').innerHTML='';$('reader-search-loading').classList.add('active');
 try{
  const result=await api('/reader-search',{file:readerFileLoaded,query});
  readerSearchMatches=Array.isArray(result?.matches)?result.matches:[];
  $('reader-search-loading').classList.remove('active');
  renderDedicatedSearchResults(readerSearchMatches,query);
 }catch(e){$('reader-search-loading').classList.remove('active');$('reader-search-empty').textContent='Search failed: '+(e?.message||String(e));}
}
async function searchInsideBook(){
 openReaderSearch();
}
function clearReaderSearchMarks(){document.querySelectorAll('#reader-content mark.reader-search-hit').forEach(mark=>mark.replaceWith(document.createTextNode(mark.textContent)));}
function highlightReaderSearch(){
 const root=$('reader-content');clearReaderSearchMarks();if(!readerSearchQuery)return;
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(node){return node.nodeValue.toLocaleLowerCase().includes(readerSearchQuery.toLocaleLowerCase())?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
 const needle=readerSearchQuery.toLocaleLowerCase();
 nodes.forEach(node=>{const text=node.nodeValue,lower=text.toLocaleLowerCase(),frag=document.createDocumentFragment();let from=0,at;
  while((at=lower.indexOf(needle,from))!==-1){if(at>from)frag.appendChild(document.createTextNode(text.slice(from,at)));const mark=document.createElement('mark');mark.className='reader-search-hit';mark.textContent=text.slice(at,at+readerSearchQuery.length);frag.appendChild(mark);from=at+readerSearchQuery.length;}
  if(from<text.length)frag.appendChild(document.createTextNode(text.slice(from)));node.parentNode.replaceChild(frag,node);
 });
}
async function goToReaderSearchMatch(){
 const match=readerSearchMatches[readerSearchIndex];if(!match)return;
 const targetChapter=Number(match.chapter)||0;
 if(readerBook.index!==targetChapter){
  $('reader-chapter').value=String(targetChapter);
  readerChapterLanding='start';
  readerBook=await api('/reader-open',{file:readerFileLoaded,chapter:targetChapter});
  renderReaderChapter();
 }else{
  // Same chapter: preserve the current pagination/column geometry. Only refresh marks.
  highlightReaderSearch();
 }
 const page=$('reader-content');
 // Allow WebView's column layout to settle before measuring the highlighted text.
 requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{
  const marks=page.querySelectorAll('mark.reader-search-hit');
  const occurrence=Math.max(0,Number(match.occurrence)||0),target=marks[occurrence];
  if(target){
   const rect=target.getBoundingClientRect(),base=page.getBoundingClientRect();
   /* Search navigation must land on a whole reader column/page. WebView's
      mandatory snap can otherwise restore at an intermediate offset and show
      slivers of two columns (the broken layout seen after selecting a result). */
   const stride=Math.max(1,page.clientWidth);
   const targetX=Math.max(0,page.scrollLeft+rect.left-base.left);
   const destination=Math.floor(targetX/stride)*stride;
   page.style.scrollSnapType='none';
   page.style.scrollBehavior='auto';
   page.scrollLeft=destination;
   requestAnimationFrame(()=>requestAnimationFrame(()=>{
    page.scrollLeft=destination;
    page.style.scrollSnapType='x mandatory';
    updateReaderPageCount();
   }));
  }
  $('reader-search-status').textContent='Match '+(readerSearchIndex+1)+' of '+readerSearchMatches.length+' · '+(readerBook.chapters[targetChapter]?.title||'Chapter '+(targetChapter+1));
 })));
}

function readerSearchNext(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex+1)%readerSearchMatches.length;goToReaderSearchMatch();}
function readerSearchPrev(){if(!readerSearchMatches.length)return;readerSearchIndex=(readerSearchIndex-1+readerSearchMatches.length)%readerSearchMatches.length;goToReaderSearchMatch();}

function readerPrev(){if(readerBook&&readerBook.index>0){$('reader-chapter').value=readerBook.index-1;loadReaderChapter();}}
function readerNext(){if(readerBook&&readerBook.index<readerBook.chapters.length-1){$('reader-chapter').value=readerBook.index+1;loadReaderChapter();}}
let readerStyleSignature='';
function setReaderStyle(){
 const page=$('reader-content'),font=val('reader-font'),line=val('reader-line'),para=val('reader-para'),letter=val('reader-letter'),weight=val('reader-weight'),family=val('reader-family');
 const cs=getComputedStyle(page);
 const padLeft=parseFloat(cs.paddingLeft)||0, padRight=parseFloat(cs.paddingRight)||0;
 const contentWidth=Math.max(120,page.clientWidth-padLeft-padRight);
 const pageGap=Math.max(0,padLeft+padRight);
 const signature=[font,line,para,letter,weight,family,contentWidth,pageGap,page.clientHeight].join('|');
 $('font-value').textContent=font;$('line-value').textContent=line;$('para-value').textContent=para;$('letter-value').textContent=letter;$('weight-value').textContent=weight;
 if(signature===readerStyleSignature)return;
 const currentPage=page.clientWidth>0?Math.max(0,Math.round(page.scrollLeft/page.clientWidth)):0;
 readerStyleSignature=signature;
 /* CSS variables avoid walking every paragraph for each slider update. */
 page.style.setProperty('--rd-reader-para-spacing',para+'em');
 page.style.columnWidth=contentWidth+'px';page.style.webkitColumnWidth=contentWidth+'px';
 page.style.columnGap=pageGap+'px';page.style.webkitColumnGap=pageGap+'px';
 page.style.columnFill='auto';page.style.webkitColumnFill='auto';
 page.style.fontSize=font+'px';page.style.lineHeight=line;page.style.letterSpacing=letter+'px';page.style.fontWeight=weight;page.style.fontFamily=family;
 requestAnimationFrame(()=>{if(page.clientWidth>0){page.scrollLeft=Math.min(page.scrollWidth-page.clientWidth,currentPage*page.clientWidth);updateReaderPageCount();saveReaderState();}});
}

function readerTheme(theme){
 const p=$('reader-content');
 const styles={light:['#fff','#242424'],sepia:['#f2e4c9','#5b4632'],night:['#171717','#ddd']};
 p.style.background=styles[theme][0];p.style.color=styles[theme][1];
}

function hideToolkitSections(){document.querySelectorAll('main>section').forEach(x=>x.classList.add('hide'));$('single-feature-menu').classList.add('hide');$('folder-picker-panel').classList.add('hide');}
function showToolkitHome(){hideToolkitSections();$('toolkit-home').classList.remove('hide');}
function showSingleMenu(){hideToolkitSections();$('single-feature-menu').classList.remove('hide');}
function showBatchMenu(){hideToolkitSections();$('folder-picker-panel').classList.remove('hide');$('batch-panel').classList.remove('hide');}
function showTab(id,b){hideToolkitSections();$('single-feature-menu').classList.remove('hide');$('folder-picker-panel').classList.remove('hide');$(id).classList.remove('hide');document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));if(b)b.classList.add('active')}
async function api(path,data){let d=JSON.parse(AndroidBridge.post(path,JSON.stringify(data)));if(d.error)throw Error(d.error||'Operasi gagal');return d}
function fileFor(id){return $(id).querySelector('select.epub')?.value || ''}
function renderFileChoices(){
  const filter=$('folderFilter')?.value||'';
  const visible=files.filter(f=>!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter);
  const help=$('folderFilterHelp');
  if(help) help.textContent=(filter ? 'Folder aktif: '+filter : 'Menampilkan semua folder')+' · '+visible.length+' file ditemukan. Pilih folder lain kapan saja.';
  document.querySelectorAll('select.epub').forEach(s=>{
    const old=s.value;s.innerHTML='<option value="">Pilih EPUB</option>';
    visible.filter(f=>/\.epub$/i.test(f.name)).forEach(f=>s.add(new Option(f.path+' ('+f.size+')',f.path)));
    if(old&&Array.from(s.options).some(o=>o.value===old))s.value=old;
  });
  const b=$('bulkfile'),old=b.value;b.innerHTML='<option value="">Pilih EPUB/TXT</option>';
  visible.filter(f=>/\.(epub|txt)$/i.test(f.name)).forEach(f=>b.add(new Option(f.path+' ('+f.size+')',f.path)));
  if(old&&Array.from(b.options).some(o=>o.value===old))b.value=old;
  renderBatchFiles();
}
function updateBatchOptions(){
  const op=val('batchOperation'), box=$('batch-options');box.innerHTML='';
  if(op==='/bulk-count'||op==='/bulk-replace'){
    box.innerHTML='<label>Teks yang dicari</label><input id="batch-find" type="text" placeholder="Teks pencarian"><label>Ganti dengan</label><input id="batch-replace" type="text" placeholder="Teks pengganti"><label class="check"><input id="batch-case" type="checkbox"> Peka huruf besar/kecil</label><label class="check"><input id="batch-whole" type="checkbox"> Kata utuh saja</label><label class="check"><input id="batch-regex" type="checkbox"> Regular expression</label>';
  }else if(op==='/make-cover'){
    box.innerHTML='<p class="hint">Judul cover dan nama penulis akan diambil otomatis dari metadata setiap EPUB (dc:title dan creator). Tidak perlu mengisi judul secara manual.</p>';
  }else if(op==='/batch-unzip'){
    const dirs=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    box.innerHTML='<label>Password ZIP (default)</label><input id="unzip-password" type="password" autocomplete="off" value="taiwanandnorthkorea" placeholder="Password yang sama untuk semua ZIP"><label>Folder tujuan (semua hasil digabung ke sini)</label><select id="unzip-destination"></select><p class="hint">Password default sudah diisi otomatis. Ubah jika ZIP menggunakan password lain, atau hapus jika ZIP tidak dikunci. Daftar ZIP dicari di semua folder penyimpanan, tidak mengikuti filter folder EPUB di atas. Mendukung AES dan ZipCrypto. Jika nama file bentrok, file berikutnya otomatis diberi akhiran _2, _3, dan seterusnya. Nama asli tetap dipakai jika tidak bentrok. File ZIP asli tidak diubah.</p>';
    const dest=box.querySelector('#unzip-destination');dirs.forEach(d=>dest.add(new Option(d,d)));if(dirs.includes('Download'))dest.value='Download';
  }else if(op==='/cover-meta'){
    box.innerHTML='<p class="hint">Hanya membaca metadata judul dan penulis; file tidak diubah.</p>';
  }else{
    box.innerHTML='<p class="hint">Tidak memerlukan pengaturan tambahan. Setiap EPUB yang dipilih akan diproses dengan fitur ini.</p>';
  }
  renderBatchFiles();
}
function selectedBatchFiles(){return Array.from(document.querySelectorAll('.batch-file input:checked')).map(x=>x.value)}
function updateBatchCount(){$('batch-selection-count').textContent=selectedBatchFiles().length+' file dipilih';}
function renderBatchFiles(){
  const filter=val('folderFilter'), op=val('batchOperation'), isText=op==='/bulk-count'||op==='/bulk-replace', isZip=op==='/batch-unzip';
  // ZIP extraction searches every discovered folder, regardless of the active EPUB folder filter.
  // This prevents archives in Documents, Telegram, or another folder from being hidden by e.g. Download/Novel.
  const visible=files.filter(f=>(isZip||!filter||f.path.startsWith(filter+'/')||f.path.substring(0,f.path.lastIndexOf('/'))===filter)&& (isZip?/\.zip$/i.test(f.name):(isText?/\.(epub|txt)$/i.test(f.name):/\.epub$/i.test(f.name))));
  const list=$('batch-file-list');list.innerHTML='';
  if(!visible.length){list.textContent='Tidak ada file yang cocok pada folder aktif.';updateBatchCount();return;}
  visible.forEach(f=>{const label=document.createElement('label');label.className='batch-file';const cb=document.createElement('input');cb.type='checkbox';cb.value=f.path;cb.addEventListener('change',updateBatchCount);const span=document.createElement('span');span.textContent=f.path+' ('+f.size+')';label.append(cb,span);list.appendChild(label);});updateBatchCount();
}
function selectVisibleBatch(checked){document.querySelectorAll('#batch-file-list input[type=checkbox]').forEach(x=>x.checked=checked);updateBatchCount();}
async function runBatch(){
  const operation=val('batchOperation'), chosen=selectedBatchFiles();
  if(!chosen.length)return $('batch-status').textContent='Pilih minimal satu file.';
  if(operation==='/batch-unzip'){
    const destination=val('unzip-destination');if(!destination)return $('batch-status').textContent='Pilih folder tujuan.';
    if(!confirm('Ekstrak '+chosen.length+' ZIP ke folder '+destination+'? File ZIP asli tetap disimpan.'))return;
    $('batch-status').textContent='Mengekstrak '+chosen.length+' arsip…';
    try{const result=JSON.parse(AndroidBridge.unzipBatch(JSON.stringify({files:chosen,destination,password:val('unzip-password')})));if(result.error)throw Error(result.error);
      const box=$('batch-status');box.textContent='';const summary=document.createElement('div');summary.style.cssText='padding:12px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e3a8a;margin-top:10px';summary.textContent='Batch Unzip selesai: '+result.succeeded+' berhasil · '+result.failed+' gagal · '+result.total+' ZIP';box.appendChild(summary);
      result.results.forEach(r=>addResultCard(box,r.file,r.ok,r.result||{},r.error||''));await loadFiles();
    }catch(e){$('batch-status').textContent='Error: '+e.message;}return;
  }
  const options={};
  if(operation==='/bulk-count'||operation==='/bulk-replace'){
    options.find=val('batch-find');options.replace=val('batch-replace');options.case_sensitive=$('batch-case').checked;options.whole_word=$('batch-whole').checked;options.regex=$('batch-regex').checked;
    if(!options.find)return $('batch-status').textContent='Isi teks yang dicari terlebih dahulu.';
  }
  const readOnly=operation==='/bulk-count'||operation==='/cover-meta';
  const prompt=readOnly?'Jalankan fitur pada '+chosen.length+' file terpilih?':'Proses '+chosen.length+' file terpilih? File yang berhasil diproses akan langsung menimpa file asli tanpa backup.';
  if(!confirm(prompt))return;
  $('batch-status').textContent='Memproses '+chosen.length+' file…';
  try{
    const d=await api('/batch',{operation,files:chosen,options});
    const box=$('batch-status');box.textContent='';
    box.style.cssText='padding:0;margin-top:12px;border:0;background:transparent;min-height:0;overflow:visible;';
    const resultsList=document.createElement('div');
    resultsList.style.cssText='max-height:200px;overflow-y:auto;overflow-x:hidden;border:1px solid #d8e0eb;border-radius:12px;padding:10px;background:#fff;';
    const summary=document.createElement('div');
    summary.style.cssText='background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:14px;margin:8px 0 12px;color:#1e3a8a;';
    const heading=document.createElement('div');heading.textContent='Batch selesai diproses';
    heading.style.cssText='font-size:17px;font-weight:700;margin-bottom:6px;';
    const count=document.createElement('div');
    count.textContent='✓ '+d.succeeded+' berhasil   ·   ✕ '+d.failed+' gagal   ·   Total '+d.total+' file';
    count.style.cssText='font-size:14px;';
    summary.append(heading,count);resultsList.appendChild(summary);
    d.results.forEach(item=>addResultCard(resultsList,item.file,item.ok,item.result||{},item.error||''));
    box.appendChild(resultsList);
    await loadFiles();
  }catch(e){$('batch-status').textContent='Error: '+e.message;}
}
const librarySearchTextCache=new Map();
function librarySearchText(file){const key=String(file.path||'');const cached=librarySearchTextCache.get(key);if(cached&&cached.name===file.name)return cached.text;const text=(String(file.name||'')+' '+key).toLowerCase();librarySearchTextCache.set(key,{name:file.name,text});return text;}
async function loadFiles(){try{
  let d=JSON.parse(AndroidBridge.getFiles());if(d.error)throw Error(d.error);files=d.files;librarySearchTextCache.clear();
  const available=new Set(files.filter(f=>/\.epub$/i.test(f.name)).map(f=>f.path));selectedBookPaths=new Set([...selectedBookPaths].filter(path=>available.has(path)));updateBookSelectionUI();
  const folder=$('folderFilter'),previous=folder.value;
  const folders=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):'' ).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  folder.innerHTML='<option value="">Semua folder</option>';
  folders.forEach(f=>folder.add(new Option(f,f)));
  if(folders.includes(previous)) folder.value=previous;
  else if(folders.includes('Download')) folder.value='Download';
  else folder.value='';
  renderFileChoices();populateSingleUnzip();if($('reader-file')||document.body.classList.contains('reader-active'))populateReaderFiles();
}catch(e){document.querySelectorAll('.status').forEach(x=>x.textContent='Gagal memuat file: '+e.message)}}
function populateSingleUnzip(){
  const zipSelect=$('single-unzip-file'),destSelect=$('single-unzip-destination');if(!zipSelect||!destSelect)return;
  const previousZip=zipSelect.value,previousDest=destSelect.value;
  zipSelect.innerHTML='<option value="">Pilih ZIP</option>';
  files.filter(f=>/\.zip$/i.test(f.name)).forEach(f=>zipSelect.add(new Option(f.path+' ('+f.size+')',f.path)));
  const dirs=[...new Set(files.map(f=>f.path.includes('/')?f.path.substring(0,f.path.lastIndexOf('/')):''))].sort((a,b)=>a.localeCompare(b));
  destSelect.innerHTML='';dirs.forEach(d=>destSelect.add(new Option(d||'Internal storage',d)));
  if(previousZip&&Array.from(zipSelect.options).some(o=>o.value===previousZip))zipSelect.value=previousZip;
  if(previousDest&&Array.from(destSelect.options).some(o=>o.value===previousDest))destSelect.value=previousDest;
  else updateSingleUnzipDestination();
}
function updateSingleUnzipDestination(){
  const zip=val('single-unzip-file'),dest=$('single-unzip-destination');if(!zip||!dest)return;
  const parent=zip.includes('/')?zip.substring(0,zip.lastIndexOf('/')):'';
  if(Array.from(dest.options).some(o=>o.value===parent))dest.value=parent;
}
async function runSingleUnzip(){
  const file=val('single-unzip-file'),destination=val('single-unzip-destination');
  if(!file)return $('unzip-single-status').textContent='Pilih file ZIP terlebih dahulu.';
  if(!confirm('Ekstrak ZIP ini ke folder '+(destination||'Internal storage')+'? File ZIP asli tetap disimpan.'))return;
  $('unzip-single-status').textContent='Mengekstrak ZIP…';
  try{
    const payload={files:[file],destination,password:val('single-unzip-password')};
    const result=JSON.parse(AndroidBridge.unzipBatch(JSON.stringify(payload)));if(result.error)throw Error(result.error);
    const r=result.results&&result.results[0];if(!r||!r.ok)throw Error(r?.error||'Ekstraksi gagal');
    $('unzip-single-status').textContent='Selesai: '+(r.result?.message||'ZIP berhasil diekstrak.');await loadFiles();
  }catch(e){$('unzip-single-status').textContent='Error: '+e.message;}
}
function currentFile(panel){return $(panel).querySelector('select').value}
function addResultCard(parent, fileName, ok, result={}, errorText=''){
  const card=document.createElement('div');
  card.style.cssText='background:#fff;border:1px solid '+(ok?'#bbf7d0':'#fecaca')+';border-radius:12px;padding:12px;margin:9px 0;color:#172033;';
  const head=document.createElement('div');
  head.style.cssText='display:flex;gap:8px;align-items:flex-start;font-weight:700;';
  const mark=document.createElement('span');mark.textContent=ok?'✓':'✕';
  mark.style.cssText='font-size:18px;color:'+(ok?'#15803d':'#dc2626')+';';
  const name=document.createElement('div');name.textContent=fileName||'File';
  name.style.cssText='overflow-wrap:anywhere;flex:1;';
  head.append(mark,name);card.appendChild(head);
  if(ok){
    const out=document.createElement('div');out.textContent='Hasil: '+(result.output||fileName||'Selesai');
    out.style.cssText='font-size:13px;color:#334155;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(out);
    const labels={message:'Status',title:'Judul',changed:'Paragraf diperbarui',count:'Jumlah perubahan',removed:'Item dihapus',images:'Gambar',matches:'Kecocokan',author:'Penulis'};
    const notes=[];
    for(const [key,value] of Object.entries(result)){
      if(key==='output'||value===null||value===undefined||value==='')continue;
      if(!Object.prototype.hasOwnProperty.call(labels,key))continue;
      const val=typeof value==='object'?JSON.stringify(value):String(value);
      if(/cache|chaquopy|tmp|backup/i.test(val))continue;
      notes.push(labels[key]+': '+val);
    }
    if(notes.length){const note=document.createElement('div');note.textContent=notes.join(' · ');
      note.style.cssText='font-size:12px;color:#64748b;margin:6px 0 0 26px;line-height:1.5;overflow-wrap:anywhere;';card.appendChild(note);}
  }else{
    const err=document.createElement('div');err.textContent='Gagal: '+(errorText||'Terjadi kesalahan');
    err.style.cssText='font-size:13px;color:#b91c1c;margin:7px 0 0 26px;overflow-wrap:anywhere;';card.appendChild(err);
  }
  parent.appendChild(card);
}
function showSuccess(panel,d){
  const box=$(panel+'-status');box.textContent='';
  const summary=document.createElement('div');
  summary.style.cssText='background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px;color:#166534;';
  const title=document.createElement('div');title.textContent='✓ Selesai diproses';
  title.style.cssText='font-size:17px;font-weight:700;margin-bottom:5px;';
  const output=document.createElement('div');output.textContent=d.output?'File hasil: '+d.output:'Proses berhasil diselesaikan.';
  output.style.cssText='font-size:14px;overflow-wrap:anywhere;';
  summary.append(title,output);box.appendChild(summary);
  addResultCard(box,d.output||'File EPUB',true,d);
}
async function run(path,panel,extra={}){let f=currentFile(panel);if(!f){$(panel+'-status').textContent='Pilih EPUB terlebih dahulu.';return}if(!confirm('Jalankan proses ini? File asli akan diperbarui langsung dan tidak ada backup yang dibuat.'))return;$(panel+'-status').textContent='Memproses…';try{let d=await api(path,{file:f,...extra});showSuccess(panel,d);await loadFiles()}catch(e){$(panel+'-status').textContent='Error: '+e.message}}
async function meta(){let f=currentFile('cover-maker');if(!f)return $('cover-maker-status').textContent='Pilih EPUB.';try{let d=await api('/cover-meta',{file:f});$('title').value=d.title;$('author').textContent='Penulis: '+d.author;$('cover-maker-status').textContent='Metadata berhasil dibaca.'}catch(e){$('cover-maker-status').textContent='Error: '+e.message}}
async function bulk(path){let p={file:val('bulkfile'),find:val('find'),replace:val('replace'),case_sensitive:$('case').checked,whole_word:$('whole').checked,regex:$('regex').checked};if(!p.file||!p.find)return $('bulk-status').textContent='Pilih file dan isi teks pencarian.';if(path==='/bulk-replace'&&!confirm('Ganti teks pada file asli? Perubahan akan langsung menimpa file tersebut.'))return;$('bulk-status').textContent='Memproses…';try{let d=await api(path,p);$('bulk-status').textContent=path==='/bulk-count'?'Jumlah kecocokan: '+d.count:(d.count?'Selesai. Penggantian: '+d.count+'\nFile diperbarui: '+d.output:'Tidak ada teks yang cocok.');await loadFiles()}catch(e){$('bulk-status').textContent='Error: '+e.message}}
async function renameByTitle(){
  const file=currentFile('rename-title');
  if(!file)return $('rename-title-status').textContent='Pilih EPUB terlebih dahulu.';
  if(!confirm('Nama file akan diganti sesuai judul metadata. Isi EPUB tidak diubah. Lanjutkan?'))return;
  $('rename-title-status').textContent='Membaca metadata dan mengganti nama…';
  try{const d=await api('/rename-by-title',{file});$('rename-title-status').textContent='Berhasil!\nJudul metadata: '+d.title+'\nNama file baru: '+d.output+(d.message?'\n'+d.message:'');await loadFiles();}
  catch(e){$('rename-title-status').textContent='Error: '+e.message;}
}
// Initialize directly into My Library (Read Book), not Toolkit.
switchGallery(DEFAULT_GALLERY_SCREEN);updateBatchOptions();loadFiles();
</script></body></html>"""

def batch_action(d):
    """Run one existing toolkit operation over multiple selected files."""
    operation = d.get("operation", "")
    files = d.get("files", [])
    options = d.get("options", {}) or {}
    allowed = {
        "/remove-cover", "/no-preview", "/make-cover", "/compress",
        "/bulk-count", "/bulk-replace", "/compact-spacing",
        "/blank-spacing", "/remove-images", "/rename-by-title", "/cover-meta"
    }
    if operation not in allowed:
        raise ValueError("Operasi batch tidak dikenal.")
    if not isinstance(files, list) or not files:
        raise ValueError("Pilih minimal satu file.")
    if len(files) > 500:
        raise ValueError("Maksimal 500 file dalam satu batch.")
    results = []
    for selected in files:
        item = {**options, "file": selected}
        try:
            result = api_action(operation, item) or {}
            results.append({"file": selected, "ok": True, "result": result})
        except Exception as exc:
            results.append({"file": selected, "ok": False,
                            "error": type(exc).__name__ + ": " + str(exc)})
    succeeded = sum(1 for item in results if item["ok"])
    return {"total": len(results), "succeeded": succeeded,
            "failed": len(results) - succeeded, "results": results}

def get_files_payload():
    """Return EPUB/TXT inventory directly to the Android WebView bridge."""
    try:
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        arr = []
        for current, dirs, names in os.walk(STORAGE_ROOT, topdown=True, followlinks=False):
            if os.path.basename(current) == "Android":
                dirs[:] = [d for d in dirs if d not in ("data", "obb")]
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for n in names:
                if n.lower().endswith((".epub", ".txt", ".zip")):
                    path = os.path.join(current, n)
                    try:
                        if os.path.isfile(path):
                            stat = os.stat(path)
                            # Prefer true creation time when the filesystem exposes it;
                            # otherwise use inode-change time as the closest available added-date proxy.
                            added_at = getattr(stat, "st_birthtime", stat.st_ctime)
                            arr.append({"name": n, "path": relative_storage_path(path),
                                        "size": f"{stat.st_size/1048576:.2f} MB",
                                        "added": float(added_at)})
                    except (OSError, PermissionError):
                        continue
        arr.sort(key=lambda f: f["path"].lower())
        return {"files": arr}
    except Exception as e:
        return {"error": type(e).__name__ + ": " + str(e)}

def bridge_get_files():
    return json.dumps(get_files_payload(), ensure_ascii=False)

def bridge_post(path, data_json):
    try:
        data = json.loads(data_json or "{}")
        result = batch_action(data) if path == "/batch" else (api_action(path, data) or {})
        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": type(e).__name__ + ": " + str(e)}, ensure_ascii=False)

def main():
    print("EPUB Toolkit Android menggunakan komunikasi WebView lokal tanpa server jaringan.")

if __name__ == "__main__":
    main()
