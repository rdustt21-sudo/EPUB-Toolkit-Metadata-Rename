# V4.2.21 – Safe Code Cleanup

Based on V4.2.20 Blank Startup (user-confirmed working).

Cleanup only:
- Removed unused `dp()` helper from MainActivity.
- Removed unused `displayName` parameter from `resolveZipParent` and its call.
- Removed generated Python `__pycache__` / `.pyc` artifact from source ZIP.
- Updated app version to 2.0.12 (versionCode 21).

No intended behavior changes. UI, Library, EPUB reader, Single/Batch features, ZIP extraction, Python initialization, back navigation, refresh and scan logic were not modified.
Gradle build and device testing were not performed.
