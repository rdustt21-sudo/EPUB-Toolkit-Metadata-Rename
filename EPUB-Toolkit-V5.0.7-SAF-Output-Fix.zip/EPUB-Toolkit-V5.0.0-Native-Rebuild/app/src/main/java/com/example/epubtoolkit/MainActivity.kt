package com.example.epubtoolkit

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Xml
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import com.example.epubtoolkit.core.epub.NativeEpubProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ToolkitApp() }
    }
}


private val Background = Color(0xFF0D121E)
private val SurfaceDark = Color(0xFF171F2D)
private val SurfaceRaised = Color(0xFF202B3B)
private val TextPrimary = Color(0xFFE8EDF5)
private val TextMuted = Color(0xFF9AA9BC)
private val Accent = Color(0xFF8EBBFF)


private data class EpubBook(
    val uri: Uri,
    val fileName: String,
    val title: String,
    val author: String,
    val lastModified: Long = 0L,
    val size: Long = 0L
)
private enum class LibrarySort { TITLE, FILE_NAME }


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolkitApp() {
    var screen by rememberSaveable { mutableStateOf("Library") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Background, surface = SurfaceDark, primary = Accent,
        onBackground = TextPrimary, onSurface = TextPrimary
    )) {
        Scaffold(
            containerColor = Background,
            topBar = {
                TopAppBar(
                    title = { Text(screen, fontWeight = FontWeight.SemiBold) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                    navigationIcon = { Icon(Icons.Default.Book, contentDescription = null, modifier = Modifier.padding(start = 16.dp), tint = Accent) }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    listOf("Library", "Single", "Batch").forEach { label ->
                        val icon = when (label) { "Library" -> Icons.Default.Folder; "Single" -> Icons.Default.Tune; else -> Icons.Default.Build }
                        NavigationBarItem(
                            selected = screen == label, onClick = { screen = label },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent,
                                indicatorColor = SurfaceRaised, unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "Library" -> LibraryHome()
                    "Single" -> FeatureList(singleFeatures, "Single Feature")
                    "Batch" -> FeatureList(batchFeatures, "Batch Feature")
                }
            }
        }
    }
}


@Composable
private fun LibraryHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("native_library", 0) }
    val savedTree = remember { prefs.getString("tree_uri", null)?.let(Uri::parse) }
    var selectedTree by remember { mutableStateOf(savedTree) }
    var books by remember { mutableStateOf(loadCachedBooks(prefs)) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(if (savedTree == null) "Choose a folder to scan for EPUB books." else "Showing saved library…") }
    var sort by rememberSaveable { mutableStateOf(LibrarySort.TITLE) }
    val scope = rememberCoroutineScope()

    fun sorted(items: List<EpubBook>): List<EpubBook> = items.sortedBy {
        if (sort == LibrarySort.TITLE) it.title.lowercase() else it.fileName.lowercase()
    }

    fun scan(treeUri: Uri?) {
        if (treeUri == null) { status = "Choose a folder first."; return }
        if (scanning) return
        scanning = true
        status = "Refreshing library…"
        scope.launch {
            val progressive = mutableListOf<EpubBook>()
            try {
                withContext(Dispatchers.IO) {
                    scanEpubTree(context, treeUri, loadCachedBooks(prefs)) { book ->
                        withContext(Dispatchers.Main) {
                            progressive.add(book)
                            // Publish discoveries without sorting each item; sort once after the scan.
                            books = progressive.toList()
                            status = "Scanning… ${progressive.size} EPUB found"
                        }
                    }
                }
                books = sorted(progressive)
                saveCachedBooks(prefs, progressive)
                status = if (progressive.isEmpty()) "No EPUB files found in this folder." else "${progressive.size} EPUB book${if (progressive.size == 1) "" else "s"} found."
            } catch (_: Exception) {
                if (progressive.isNotEmpty()) books = sorted(progressive)
                status = "Scan incomplete. Showing ${progressive.size} books found so far. Check folder access and try again."
            } finally {
                scanning = false
            }
        }
    }


    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: SecurityException) { }
            selectedTree = uri
            prefs.edit().putString("tree_uri", uri.toString()).apply()
            books = emptyList()
            scan(uri)
        }
    }


    LaunchedEffect(Unit) { if (savedTree != null) scan(savedTree) }
    LaunchedEffect(sort) { if (books.isNotEmpty()) books = sorted(books) }


    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("My Library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (selectedTree == null) "No folder selected" else "${books.size} books", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { scan(selectedTree) }, enabled = selectedTree != null && !scanning) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh library", tint = Accent)
            }
            IconButton(onClick = { sort = if (sort == LibrarySort.TITLE) LibrarySort.FILE_NAME else LibrarySort.TITLE }) {
                Icon(Icons.Default.Sort, contentDescription = "Sort library", tint = Accent)
            }
            FilledTonalButton(onClick = { folderPicker.launch(null) }) {
                Icon(Icons.Default.Folder, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Folder")
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Sort: ${if (sort == LibrarySort.TITLE) "Title" else "File name"}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            if (scanning) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        if (status.isNotBlank()) Text(status, color = TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp))
        if (books.isEmpty() && !scanning) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Book, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(if (selectedTree == null) "Select your EPUB folder" else "Your library is empty", fontWeight = FontWeight.Medium)
                    Text("Choose a folder containing EPUB files. Subfolders are scanned too.", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(books, key = { it.uri.toString() }) { book -> BookRow(book) }
            }
        }
    }
}


private fun loadCachedBooks(prefs: android.content.SharedPreferences): List<EpubBook> {
    return try {
        val array = JSONArray(prefs.getString("cached_books", "[]"))
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val uri = obj.optString("uri").takeIf { it.isNotBlank() }?.let(Uri::parse) ?: continue
                add(EpubBook(uri, obj.optString("fileName"), obj.optString("title"), obj.optString("author"), obj.optLong("lastModified"), obj.optLong("size")))
            }
        }
    } catch (_: Exception) { emptyList() }
}


private fun saveCachedBooks(prefs: android.content.SharedPreferences, books: List<EpubBook>) {
    val array = JSONArray()
    books.forEach { book ->
        array.put(JSONObject().put("uri", book.uri.toString()).put("fileName", book.fileName)
            .put("title", book.title).put("author", book.author)
            .put("lastModified", book.lastModified).put("size", book.size))
    }
    prefs.edit().putString("cached_books", array.toString()).apply()
}


@Composable
private fun BookRow(book: EpubBook) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 54.dp, height = 72.dp).background(SurfaceRaised, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Book, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(book.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                if (book.author.isNotBlank()) Text(book.author, color = TextMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Text(book.fileName, color = TextMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }
    }
}


private suspend fun scanEpubTree(
    context: android.content.Context,
    treeUri: Uri,
    cachedBooks: List<EpubBook>,
    onBookFound: suspend (EpubBook) -> Unit
): List<EpubBook> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    val cachedByUri = cachedBooks.associateBy { it.uri.toString() }
    val found = mutableListOf<EpubBook>()

    suspend fun visit(folder: DocumentFile) {
        for (file in folder.listFiles()) {
            if (file.isDirectory) {
                visit(file)
            } else if (file.isFile && file.name?.endsWith(".epub", ignoreCase = true) == true) {
                val name = file.name ?: "Unknown.epub"
                val modified = file.lastModified()
                val fileSize = file.length()
                val cached = cachedByUri[file.uri.toString()]
                val book = if (cached != null && cached.fileName == name && cached.lastModified == modified && cached.size == fileSize && cached.title.isNotBlank() && (modified > 0L || fileSize > 0L)) {
                    cached
                } else {
                    val meta = readEpubMetadata(context.contentResolver, file.uri)
                    EpubBook(file.uri, name, meta.first.ifBlank { name.removeSuffixIgnoreCase(".epub") }, meta.second, modified, fileSize)
                }
                found.add(book)
                onBookFound(book)
            }
        }
    }

    visit(root)
    return found
}


private fun String.removeSuffixIgnoreCase(suffix: String): String =
    if (endsWith(suffix, ignoreCase = true)) dropLast(suffix.length) else this


private fun readEpubMetadata(resolver: android.content.ContentResolver, uri: Uri): Pair<String, String> {
    fun readEntry(entryName: String): ByteArray? {
        return try {
            resolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name == entryName) return zip.readBytes()
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
            null
        } catch (_: Exception) { null }
    }
    val containerBytes = readEntry("META-INF/container.xml") ?: return "" to ""
    var opfPath: String? = null
    try {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(containerBytes), null)
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG && parser.name == "rootfile") {
                opfPath = parser.getAttributeValue(null, "full-path")
                if (!opfPath.isNullOrBlank()) break
            }
        }
    } catch (_: Exception) { return "" to "" }
    val opfBytes = opfPath?.let { readEntry(it) } ?: return "" to ""
    var title = ""
    var author = ""
    try {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(opfBytes), null)
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG) {
                when (parser.name.lowercase()) {
                    "title" -> if (title.isBlank()) title = parser.nextText().trim()
                    "creator" -> if (author.isBlank()) author = parser.nextText().trim()
                }
            }
        }
    } catch (_: Exception) { }
    return title to author
}


private val singleFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace", "Unzip File"
)
private val batchFeatures = listOf(
    "Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph",
    "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Batch Unzip (ZIP)",
    "Bulk Find & Replace — Count Matches", "Bulk Find & Replace — Execute"
)

@Composable
private fun FeatureList(features: List<String>, heading: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedTool by remember { mutableStateOf<String?>(null) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var pendingOutput by remember { mutableStateOf<NativeEpubProcessor.PreparedOutput?>(null) }
    val scope = rememberCoroutineScope()

    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/epub+zip")) { targetUri ->
        val prepared = pendingOutput
        if (targetUri != null && prepared != null) {
            scope.launch {
                val message = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(targetUri, "wt")?.use { out -> prepared.file.inputStream().use { it.copyTo(out) } }
                            ?: error("Unable to open destination for writing")
                        prepared.file.delete()
                        "Finished\nSaved: ${prepared.suggestedName}\n${prepared.detail}"
                    } catch (e: Exception) {
                        "Failed to save: ${e.message ?: "Unknown error"}"
                    }
                }
                resultMessage = message
                pendingOutput = null
            }
        } else {
            prepared?.file?.delete()
            pendingOutput = null
        }
    }


    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val feature = selectedTool ?: return@rememberLauncherForActivityResult
            resultMessage = "Processing…"
            scope.launch {
                val preparedResult: Result<NativeEpubProcessor.PreparedOutput> = withContext(Dispatchers.IO) {
                    val name = queryDisplayName(context, uri) ?: "book.epub"
                    if (feature == "Rename File") NativeEpubProcessor.prepareRename(context, uri, name)
                    else if (feature in listOf("Remove All Images", "Remove Blank Spacing", "Compact Line Spacing", "Add Paragraph"))
                        NativeEpubProcessor.prepareOperation(context, uri, name, feature)
                    else Result.failure(IllegalArgumentException("$feature is not migrated yet."))
                }
                preparedResult.fold(
                    { prepared ->
                        pendingOutput = prepared
                        resultMessage = "Choose where to save the processed EPUB.\n${prepared.suggestedName}"
                        savePicker.launch(prepared.suggestedName)
                    },
                    { error -> resultMessage = "Failed: ${error.message ?: "Unknown error"}" }
                )
            }
        }
    }


    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(heading, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Native tools · Migrating V4 functionality", color = TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        }
        items(features) { feature ->
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable {
                selectedTool = feature
                resultMessage = null
                filePicker.launch(arrayOf("application/epub+zip", "application/zip", "application/octet-stream"))
            }) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(feature, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text("›", color = TextMuted, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
    if (selectedTool != null && resultMessage != null && !resultMessage!!.startsWith("Choose where to save")) {
        AlertDialog(
            onDismissRequest = { selectedTool = null; resultMessage = null },
            title = { Text(selectedTool ?: "Tool") },
            text = { Text(resultMessage ?: "") },
            confirmButton = { TextButton(onClick = { selectedTool = null; resultMessage = null }) { Text("OK") } }
        )
    }
}


private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }
}
