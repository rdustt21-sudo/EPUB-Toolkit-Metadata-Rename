# EPUB Toolkit V4.2.7 — Single Feature: Unzip File

Added a new tenth Single Feature entry named **Unzip File**. It lists ZIP archives detected in storage, provides a password field (default password prefilled), and a destination-folder selector. The destination defaults to the ZIP's containing folder when that folder is available.

Extraction reuses the existing Android `unzipBatch` bridge with a single selected archive, preserving the existing safe path validation and collision-avoidance behavior. The existing Batch Unzip and external Open-with background ZIP handler are unchanged.

Source change is limited to the embedded toolkit UI and JavaScript in `epub_app.py`.
