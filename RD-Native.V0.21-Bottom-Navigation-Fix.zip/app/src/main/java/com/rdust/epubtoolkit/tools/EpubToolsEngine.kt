package com.rdust.epubtoolkit.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import net.lingala.zip4j.ZipFile as SecureZipFile
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.regex.Pattern
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader

/** Native, offline EPUB/ZIP processing. All EPUB rewrites are staged and validated before commit. */
object EpubToolsEngine {
    data class Result(val message: String, val output: String? = null, val changed: Int = 0)
    val singleTools = listOf("Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph", "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace", "Unzip File")
    val batchTools = listOf("Rename File", "Remove Cover", "Add Cover", "Remove All Images", "Add Paragraph", "Remove Blank Spacing", "Compact Line Spacing", "Compress Image", "Bulk Find & Replace Count", "Bulk Find & Replace Execute", "Batch Unzip")

    fun run(context: Context, file: File, tool: String, options: Map<String, String> = emptyMap()): Result {
        require(file.exists() && file.isFile) { "File tidak ditemukan." }
        return when (tool) {
            "Rename File" -> renameByTitle(file)
            "Remove Cover" -> rewriteEpub(file, "_no_cover") { entries -> removeCover(entries) }
            "Add Cover" -> addCover(file, options["title"].orEmpty())
            "Remove All Images" -> rewriteEpub(file, "_no_images") { entries -> removeImages(entries) }
            "Add Paragraph" -> rewriteEpub(file, "_formatted") { entries -> fixParagraphs(entries) }
            "Remove Blank Spacing" -> rewriteEpub(file, "_clean_default_spacing") { entries -> removeBlankSpacing(entries) }
            "Compact Line Spacing" -> rewriteEpub(file, "_compact_lines") { entries -> compactSpacing(entries) }
            "Compress Image" -> rewriteEpub(file, "_compressed") { entries -> compressImages(context, entries) }
            "Bulk Find & Replace Count", "Bulk Find & Replace Execute", "Bulk Find & Replace" -> bulkFindReplace(file, options, tool.contains("Count"))
            "Unzip File", "Batch Unzip" -> unzip(file, options["password"] ?: "taiwanandnorthkorea", options["destination"]?.takeIf { it.isNotBlank() }?.let(::File))
            else -> error("Fitur tidak dikenal: $tool")
        }
    }

    private data class Entry(val name: String, val bytes: ByteArray, val method: Int = ZipEntry.DEFLATED, val time: Long = System.currentTimeMillis())
    private fun readEntries(file: File): MutableList<Entry> = ZipFile(file).use { z ->
        require(z.getEntry("mimetype") != null) { "File bukan EPUB yang valid (mimetype tidak ditemukan)." }
        z.entries().asSequence().map { e -> Entry(e.name, z.getInputStream(e).use { it.readBytes() }, if (e.name == "mimetype") ZipEntry.STORED else ZipEntry.DEFLATED, e.time) }.toMutableList()
    }
    private fun writeEntries(source: File, entries: List<Entry>, suffix: String): Result {
        val output = unique(File(source.parentFile, source.nameWithoutExtension + suffix + ".epub"))
        val temp = File(output.parentFile, output.name + ".tmp")
        try {
            ZipOutputStream(temp.outputStream().buffered()).use { out ->
                val ordered = entries.sortedBy { if (it.name == "mimetype") 0 else 1 }
                ordered.forEach { e ->
                    val ze = ZipEntry(e.name).apply { time = e.time }
                    if (e.name == "mimetype") { ze.method = ZipEntry.STORED; ze.size = e.bytes.size.toLong(); ze.compressedSize = e.bytes.size.toLong(); val crc = java.util.zip.CRC32().apply { update(e.bytes) }; ze.crc = crc.value }
                    out.putNextEntry(ze); out.write(e.bytes); out.closeEntry()
                }
            }
            ZipFile(temp).use { check -> check.entries().asSequence().forEach { entry -> check.getInputStream(entry).use { input -> val buf = ByteArray(8192); while (input.read(buf) >= 0) { /* read through every entry to validate decompression */ } } } }
            if (!temp.renameTo(output)) temp.copyTo(output, overwrite = true)
        } finally { temp.delete() }
        return Result("Selesai. File asli tetap disimpan.", output.absolutePath, entries.size)
    }
    private fun rewriteEpub(file: File, suffix: String, transform: (MutableList<Entry>) -> Int): Result {
        val entries = readEntries(file); val changed = transform(entries)
        if (changed == 0) return Result("Tidak ada bagian yang perlu diubah.", null, 0)
        val result = writeEntries(file, entries, suffix)
        return result.copy(message = "Selesai. $changed perubahan dibuat. File asli tidak ditimpa.", changed = changed)
    }
    private fun unique(file: File): File { if (!file.exists()) return file; var i=2; var f:File; do { f=File(file.parentFile, file.nameWithoutExtension+"_$i"+file.extension.let { ".$it" }); i++ } while(f.exists()); return f }
    private fun xmlDoc(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply { isNamespaceAware=true; runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }; runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }; runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } }.newDocumentBuilder().parse(InputSource(StringReader(bytes.toString(Charsets.UTF_8))))
    private fun local(n: String?) = n?.substringAfterLast(':')?.substringAfterLast('}')?.lowercase(Locale.ROOT).orEmpty()
    private fun removeCover(entries: MutableList<Entry>): Int {
        val opf = entries.firstOrNull { it.name.endsWith(".opf", true) } ?: return 0
        val doc = xmlDoc(opf.bytes)
        val base = opf.name.substringBeforeLast('/', "")
        val removePaths = mutableSetOf<String>()
        val removeIds = mutableSetOf<String>()
        val all = doc.getElementsByTagName("*")
        for (i in 0 until all.length) {
            val el = all.item(i) as? org.w3c.dom.Element ?: continue
            if (local(el.localName ?: el.tagName) == "item") {
                val id = el.getAttribute("id")
                val href = el.getAttribute("href")
                val props = el.getAttribute("properties")
                val media = el.getAttribute("media-type")
                val isCover = props.contains("cover-image") || id.contains("cover", true) || href.contains("cover", true)
                if (isCover) {
                    removeIds += id
                    if (href.isNotBlank()) removePaths += normalize(if (base.isBlank()) href else "$base/$href")
                    el.parentNode?.removeChild(el)
                } else if (media.startsWith("image/") && id.contains("cover", true)) {
                    removeIds += id
                    removePaths += normalize(if (base.isBlank()) href else "$base/$href")
                    el.parentNode?.removeChild(el)
                }
            }
        }
        val spine = doc.getElementsByTagNameNS("*", "itemref")
        for (i in spine.length - 1 downTo 0) {
            val ref = spine.item(i) as? org.w3c.dom.Element ?: continue
            if (ref.getAttribute("idref") in removeIds) ref.parentNode?.removeChild(ref)
        }
        val meta = doc.getElementsByTagName("*")
        for (i in meta.length - 1 downTo 0) {
            val el = meta.item(i) as? org.w3c.dom.Element ?: continue
            if (local(el.localName ?: el.tagName) == "meta" && (el.getAttribute("name").contains("cover", true) || el.getAttribute("property").contains("cover", true))) el.parentNode?.removeChild(el)
        }
        val before = entries.size
        entries.removeAll { it.name in removePaths }
        entries.replaceAll { if (it.name == opf.name) it.copy(bytes = serialize(doc)) else it }
        return (before - entries.size) + removeIds.size + 1
    }
    private fun removeImages(entries: MutableList<Entry>): Int {
        val imageExt= setOf("jpg","jpeg","png","gif","webp","bmp","tif","tiff","svg","avif")
        val removed=entries.filter { it.name.substringAfterLast('.',"").lowercase() in imageExt }.map { it.name }.toSet()
        val changed=mutableListOf<Entry>(); entries.forEach { e ->
            if(e.name in removed) return@forEach
            var b=e.bytes
            if(e.name.endsWith(".xhtml",true)||e.name.endsWith(".html",true)||e.name.endsWith(".htm",true)) { val d=Jsoup.parse(b.toString(Charsets.UTF_8), "", Parser.xmlParser()); d.select("img,picture,svg image").remove(); b=d.outerHtml().toByteArray(Charsets.UTF_8) }
            if(e.name.endsWith(".css",true)) { val s=b.toString(Charsets.UTF_8).replace(Regex("(?i)(background(?:-image)?|list-style-image|border-image|mask-image)\\s*:[^;{}]*url\\([^)]*\\)[^;{}]*;"), ""); b=s.toByteArray(Charsets.UTF_8) }
            if(e.name.endsWith(".opf",true)) { val d=xmlDoc(b); val all=d.getElementsByTagName("*"); for(i in all.length-1 downTo 0) { val el=all.item(i) as? org.w3c.dom.Element ?: continue; if(local(el.localName ?: el.tagName)=="item" && el.getAttribute("media-type").startsWith("image/")) el.parentNode?.removeChild(el); if(local(el.localName ?: el.tagName)=="meta" && el.getAttribute("name").contains("cover",true)) el.parentNode?.removeChild(el) }; b=serialize(d) }
            changed += e.copy(bytes=b)
        }
        entries.clear(); entries.addAll(changed); return removed.size+1
    }
    private fun fixParagraphs(entries: MutableList<Entry>): Int {
        var changed=0
        entries.indices.forEach { i -> val e=entries[i]; if(e.name.endsWith(".xhtml",true)||e.name.endsWith(".html",true)||e.name.endsWith(".htm",true)) {
            val raw=e.bytes.toString(Charsets.UTF_8); val regex=Regex("(?is)(<p\\b[^>]*>)(.*?)(</p\\s*>)")
            val updated=regex.replace(raw) { m -> val content=m.groupValues[2]; if(content.length<30 || '<' in content || '>' in content) m.value else { val pieces=content.replace("\r\n","\n").split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }; if(pieces.size<2) m.value else { changed++; pieces.joinToString("\n") { m.groupValues[1]+it+m.groupValues[3] } } } }
            if(updated!=raw) entries[i]=e.copy(bytes=updated.toByteArray(Charsets.UTF_8))
        } }
        return changed
    }
    private fun removeBlankSpacing(entries: MutableList<Entry>): Int {
        var removed=0
        entries.indices.forEach { i -> val e=entries[i]; if(e.name.endsWith(".xhtml",true)||e.name.endsWith(".html",true)||e.name.endsWith(".htm",true)) { val d=Jsoup.parse(e.bytes.toString(Charsets.UTF_8), "", Parser.xmlParser()); d.select("p").toList().forEach { p -> if(p.text().replace("\u200b","").replace("\ufeff","").isBlank() && p.select("img,svg,video,audio,object,iframe,math,table,canvas").isEmpty()) { p.remove(); removed++ } }; entries[i]=e.copy(bytes=d.outerHtml().toByteArray(Charsets.UTF_8)) } }
        return removed
    }
    private fun compactSpacing(entries: MutableList<Entry>): Int {
        var changed=0
        entries.indices.forEach { i -> val e=entries[i]; if(e.name.endsWith(".xhtml",true)||e.name.endsWith(".html",true)||e.name.endsWith(".htm",true)) { val d=Jsoup.parse(e.bytes.toString(Charsets.UTF_8), "", Parser.xmlParser()); d.select("p:matchesOwn(^\\s*$)").remove(); d.select("br + br").remove(); val css="\n/* RED DUST compact line spacing */\nbody { line-height: 1.35 !important; } p { margin-top: .4em !important; margin-bottom: .4em !important; }\n"; val head=d.selectFirst("head"); if(head!=null) head.appendElement("style").attr("type","text/css").appendText(css); entries[i]=e.copy(bytes=d.outerHtml().toByteArray(Charsets.UTF_8)); changed++ } }
        return changed
    }
    private fun compressImages(context: Context, entries: MutableList<Entry>): Int {
        var count=0
        entries.indices.forEach { i -> val e=entries[i]; val ext=e.name.substringAfterLast('.',"").lowercase(); if(ext in setOf("jpg","jpeg","png","webp")) { val bitmap=BitmapFactory.decodeByteArray(e.bytes,0,e.bytes.size) ?: return@forEach; val out=java.io.ByteArrayOutputStream(); val fmt=when(ext){"jpg","jpeg"->Bitmap.CompressFormat.JPEG;"webp"->if(android.os.Build.VERSION.SDK_INT>=30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP;else->Bitmap.CompressFormat.PNG}; bitmap.compress(fmt, if(fmt==Bitmap.CompressFormat.JPEG) 84 else 100,out); bitmap.recycle(); if(out.size()<e.bytes.size) { entries[i]=e.copy(bytes=out.toByteArray()); count++ } } }
        return count
    }
    private fun addCover(file: File, customTitle: String): Result {
        val entries=readEntries(file)
        removeCover(entries)
        val opfEntry=entries.firstOrNull { it.name.endsWith(".opf",true) } ?: error("OPF EPUB tidak ditemukan.")
        val doc=xmlDoc(opfEntry.bytes); val titleNodes=doc.getElementsByTagNameNS("*","title"); val title=customTitle.ifBlank { if(titleNodes.length>0) titleNodes.item(0).textContent else file.nameWithoutExtension }; require(title.isNotBlank())
        val authorNodes=doc.getElementsByTagNameNS("*","creator"); val author=if(authorNodes.length>0) authorNodes.item(0).textContent else ""
        val ns=doc.documentElement.namespaceURI; val manifest=doc.getElementsByTagNameNS("*","manifest").item(0); val spine=doc.getElementsByTagNameNS("*","spine").item(0); require(manifest!=null&&spine!=null)
        val id="rd-dust-cover"; val href="rd-dust-cover.xhtml"; val img="rd-dust-cover.svg"; val opfDir=opfEntry.name.substringBeforeLast('/',""); val xPath=if(opfDir.isBlank())href else "$opfDir/$href"; val imgPath=if(opfDir.isBlank())img else "$opfDir/$img"
        fun el(name:String)=if(ns.isNullOrBlank()) doc.createElement(name) else doc.createElementNS(ns,name)
        val item=el("item").apply { setAttribute("id",id);setAttribute("href",href);setAttribute("media-type","application/xhtml+xml"); }; manifest.appendChild(item)
        val imgItem=el("item").apply { setAttribute("id","rd-dust-cover-image");setAttribute("href",img);setAttribute("media-type","image/svg+xml");setAttribute("properties","cover-image") }; manifest.appendChild(imgItem)
        val ref=el("itemref").apply { setAttribute("idref",id);setAttribute("linear","yes") }; spine.insertBefore(ref,spine.firstChild)
        val updated=serialize(doc); entries.replaceAll { if(it.name==opfEntry.name) it.copy(bytes=updated) else it }
        val safeTitle=esc(title); val safeAuthor=esc(author)
        entries += Entry(xPath,"<?xml version=\"1.0\" encoding=\"utf-8\"?><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>$safeTitle</title><meta name=\"viewport\" content=\"width=device-width,height=device-height\"/></head><body style=\"margin:0;text-align:center\"><img src=\"$img\" alt=\"Cover\" style=\"width:100%;height:100%;object-fit:contain\"/></body></html>".toByteArray())
        entries += Entry(imgPath,"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"900\" height=\"1400\" viewBox=\"0 0 900 1400\"><defs><linearGradient id=\"g\" x2=\"1\" y2=\"1\"><stop stop-color=\"#08285f\"/><stop offset=\"1\" stop-color=\"#145da0\"/></linearGradient></defs><rect width=\"900\" height=\"1400\" fill=\"url(#g)\"/><path d=\"M80 150H820M80 1250H820\" stroke=\"#a88bd7\" stroke-width=\"5\"/><text x=\"450\" y=\"620\" text-anchor=\"middle\" fill=\"white\" font-size=\"62\" font-family=\"serif\">$safeTitle</text><text x=\"450\" y=\"760\" text-anchor=\"middle\" fill=\"#dce7ff\" font-size=\"34\">$safeAuthor</text></svg>".toByteArray())
        return writeEntries(file,entries,"_with_cover").copy(message="Cover berhasil dibuat. File asli tetap disimpan.")
    }
    private fun renameByTitle(file: File): Result { val e=readEntries(file).first { it.name.endsWith(".opf",true) }; val d=xmlDoc(e.bytes); val n=d.getElementsByTagNameNS("*","title"); val title=if(n.length>0)n.item(0).textContent.trim() else file.nameWithoutExtension; val safe=title.replace(Regex("[\\\\/:*?\"<>|]"),"_").trim().ifBlank { file.nameWithoutExtension }; val target=unique(File(file.parentFile,"$safe.epub")); if(!file.renameTo(target)) error("Nama file tidak dapat diubah."); return Result("Nama file berhasil diubah berdasarkan judul metadata.",target.absolutePath) }
    private fun bulkFindReplace(file: File, o: Map<String,String>, countOnly: Boolean): Result {
        val find=o["find"].orEmpty(); require(find.isNotEmpty()) { "Masukkan teks yang dicari." }; val flags=if(o["case_sensitive"]=="true")0 else Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE; var expr=if(o["regex"]=="true")find else Pattern.quote(find); if(o["whole_word"]=="true")expr="(?<![\\p{L}\\p{N}_])(?:$expr)(?![\\p{L}\\p{N}_])"; val pattern=Pattern.compile(expr,flags)
        if(file.extension.equals("txt",true)) { val text=file.readText(Charsets.UTF_8); val m=pattern.matcher(text); var count=0; while(m.find())count++; if(countOnly)return Result("Jumlah kecocokan: $count",null,count); if(count==0)return Result("Tidak ada teks yang cocok.",null,0); val out=unique(File(file.parentFile,file.nameWithoutExtension+"_replaced.txt")); out.writeText(pattern.matcher(text).replaceAll(java.util.regex.Matcher.quoteReplacement(o["replace"].orEmpty())),Charsets.UTF_8); return Result("$count penggantian. File asli tetap disimpan.",out.absolutePath,count) }
        val entries=readEntries(file); var count=0; entries.indices.forEach { i -> val e=entries[i]; val ext=e.name.substringAfterLast('.',"").lowercase(); if(ext in setOf("xhtml","html","htm","xml","opf","ncx","txt","css","svg")) { val text=e.bytes.toString(Charsets.UTF_8); val m=pattern.matcher(text); while(m.find())count++; if(!countOnly && m.reset().find()) entries[i]=e.copy(bytes=pattern.matcher(text).replaceAll(java.util.regex.Matcher.quoteReplacement(o["replace"].orEmpty())).toByteArray(Charsets.UTF_8)) } }; if(countOnly)return Result("Jumlah kecocokan: $count",null,count); if(count==0)return Result("Tidak ada teks yang cocok.",null,0); return writeEntries(file,entries,"_replaced").copy(message="$count penggantian. File asli tetap disimpan.",changed=count)
    }
    private fun unzip(file: File, password: String, destination: File?): Result {
        val target=(destination ?: file.parentFile).canonicalFile; if(!target.exists()) require(target.mkdirs()); require(target.isDirectory) { "Folder tujuan tidak valid." }; val zip=SecureZipFile(file,password.toCharArray()); var count=0
        zip.fileHeaders.forEach { h -> val normalized=h.fileName.replace('\\','/'); require(!normalized.startsWith("/") && normalized.split('/').none { it==".." || it=="." }) { "Arsip memiliki jalur yang tidak aman: $normalized" }; val parts=normalized.split('/').filter { it.isNotEmpty() }; if(parts.isEmpty()||h.isDirectory)return@forEach; val parent=parts.dropLast(1).fold(target){f,p->File(f,p)}.canonicalFile; require(parent==target || parent.path.startsWith(target.path+File.separator)) { "Jalur ekstraksi tidak aman." }; parent.mkdirs(); val name=parts.last(); val dot=name.lastIndexOf('.'); val base=if(dot>0)name.substring(0,dot)else name; val ext=if(dot>0)name.substring(dot)else ""; var candidate=name; var n=2; while(File(parent,candidate).exists()){candidate="${base}_$n$ext";n++}; zip.extractFile(h,parent.absolutePath,candidate);count++ }
        return Result("$count file berhasil diekstrak ke ${target.name}.",target.absolutePath,count)
    }
    private fun normalize(path:String):String { val s= mutableListOf<String>(); path.replace('\\','/').split('/').forEach { when(it){"","."->Unit;".."->if(s.isNotEmpty())s.removeAt(s.lastIndex);else->s.add(it)} }; return s.joinToString("/") }
    private fun serialize(doc:org.w3c.dom.Document):ByteArray { val t=javax.xml.transform.TransformerFactory.newInstance().newTransformer(); t.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,"UTF-8");t.setOutputProperty(javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION,"no");val out=java.io.ByteArrayOutputStream();t.transform(javax.xml.transform.dom.DOMSource(doc),javax.xml.transform.stream.StreamResult(out));return out.toByteArray() }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
}
