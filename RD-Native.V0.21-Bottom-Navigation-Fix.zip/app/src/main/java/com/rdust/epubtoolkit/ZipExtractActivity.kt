package com.rdust.epubtoolkit

import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.Toast
import net.lingala.zip4j.ZipFile
import java.io.File
import java.io.FileOutputStream

/** Native ACTION_VIEW handler for ZIP archives; preserves the V4 password and safe duplicate naming. */
class ZipExtractActivity : Activity() {
    private val zipPassword = "taiwanandnorthkorea"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent?.data
        if (uri == null || intent?.action != Intent.ACTION_VIEW) { finish(); return }
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("Izinkan All files access untuk mengekstrak ZIP"); finish(); return
        }
        Thread {
            val message = runCatching { extract(uri) }.getOrElse { "Ekstraksi ZIP gagal: ${it.message ?: it.javaClass.simpleName}" }
            runOnUiThread { toast(message); finish() }
        }.start()
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun displayName(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == ContentResolver.SCHEME_CONTENT) contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) { val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0) name=c.getString(i) } }
        return name ?: uri.lastPathSegment ?: "archive.zip"
    }
    private fun parentFolder(uri: Uri): File? {
        if(uri.scheme=="file") return File(uri.path ?: return null).parentFile
        if(uri.scheme==ContentResolver.SCHEME_CONTENT && uri.authority=="com.android.externalstorage.documents") return runCatching {
            val id=DocumentsContract.getDocumentId(uri); if(!id.startsWith("primary:")) return null
            val root=Environment.getExternalStorageDirectory().canonicalFile
            val f=File(root,id.substringAfter("primary:")).canonicalFile
            if(f.path.startsWith(root.path+File.separator)&&f.isFile)f.parentFile else null
        }.getOrNull()
        return null
    }
    private fun extract(uri: Uri): String {
        val name=displayName(uri); require(name.endsWith(".zip",true)){"File bukan ZIP"}
        val target=(parentFolder(uri) ?: Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)).canonicalFile
        if(!target.exists()&&!target.mkdirs()) error("Folder tujuan tidak dapat dibuat")
        val temp=File(cacheDir,"zip-open-${System.currentTimeMillis()}.zip")
        try {
            contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } } ?: error("File ZIP tidak dapat dibaca")
            val zip=ZipFile(temp,zipPassword.toCharArray()); var count=0
            zip.fileHeaders.forEach { h ->
                val normalized=h.fileName.replace('\\','/'); require(!normalized.startsWith("/") && normalized.split('/').none { it==".." || it=="." }) { "ZIP berisi jalur tidak valid: $normalized" }
                val parts=normalized.split('/').filter { it.isNotEmpty() }; if(parts.isEmpty())return@forEach
                val parentParts=if(h.isDirectory)parts else parts.dropLast(1); val folder=parentParts.fold(target){f,p->File(f,p)}.canonicalFile
                require(folder==target || folder.path.startsWith(target.path+File.separator)){"Lokasi ekstraksi tidak valid"}; if(!folder.exists()&&!folder.mkdirs())error("Folder gagal dibuat")
                if(h.isDirectory)return@forEach
                val original=parts.last();val dot=original.lastIndexOf('.');val base=if(dot>0)original.substring(0,dot)else original;val ext=if(dot>0)original.substring(dot)else ""
                var outName=original;var suffix=2;while(File(folder,outName).exists()){outName="${base}_$suffix$ext";suffix++}
                zip.extractFile(h,folder.absolutePath,outName);count++
            }
            return "ZIP selesai: $count file diekstrak ke ${target.name}"
        } finally { temp.delete() }
    }
}
