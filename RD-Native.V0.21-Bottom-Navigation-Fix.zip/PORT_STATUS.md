# RED DUST Native Android Port — V0.9

Baseline: V0.7 Native V4 Toolkit Port.

## V0.8 adjustments
- Android device Back while inside the reader returns to the Library instead of allowing the Activity to close.
- Search result snippets collapse repeated whitespace/blank lines and show up to five words before and after the first match in each chapter.
- Search results use tighter vertical spacing and smaller typography.
- The searched phrase is highlighted in each result snippet.

## Verification
- Source ZIP integrity is checked after packaging.
- Android Gradle compilation and device runtime testing must be verified by the project's GitHub Actions workflow and on-device test.


## V0.9 search stability fix
- Run full-book search on `Dispatchers.Default` so large EPUBs do not block the Android UI thread.
- Disable duplicate search submissions while a search is running and show a searching state.
- Replace the whole-chapter token-list allocation with bounded context scanning around the first match, reducing temporary memory use on large chapters.
- Preserve the V0.8 Back behavior and compact five-word context/highlight result presentation.
- Bump Android versionCode to 8 and versionName to 0.9.0-search-stability.


## V0.10 — Highlight search match in reader page
- Selecting a search result now carries the active search query into the reader.
- Reader jumps to the first paginated page in the selected chapter containing the query.
- Matching text is highlighted in yellow with dark bold text on the reading page.
- Search-result snippet highlighting remains unchanged.
- Based on V0.9; preserves the background search and Back-button fixes.


## V0.11 — Keep in-book search mode until Back
- Selecting a search result navigates to the matching chapter/page while retaining the active search query and highlight.
- The first device Back press exits search mode, clears the search highlight/query/results, and keeps the current reader chapter open.
- A subsequent Back press returns to the Library using the existing reader Back behavior.
- Search result dialog dismissal does not silently discard the active search mode.
- Based on V0.10; preserves asynchronous search and on-page match highlighting.


## V0.12 — Retain search history and selected result
- Tapping the reader search icon while an in-book search session is active reopens the existing results list instead of opening a blank search dialog.
- Preserve the query and result list until the user exits search mode with Android Back.
- Remember the last selected result, scroll it back into view, and visually mark it in the reopened results list.
- Selecting a result updates the remembered selection and navigates to its chapter while keeping the query highlight active.
- Android Back still exits search mode and clears the complete search session without leaving the reader.
- Based on V0.11; retains background searching and on-page highlighting.

## V0.13 performance optimization
- Moved reader chapter pagination/text measurement from synchronous Compose composition work to a cancellable `Dispatchers.Default` coroutine using `produceState`.
- Pagination yields between pages and checks coroutine cancellation, so navigating to another chapter or changing layout settings can stop obsolete pagination work promptly.
- Keeps existing pagination algorithm, visual layout, page navigation, reader settings, search session/history, selected search result, and on-page highlighting behavior.
- This is a targeted CPU/UI-responsiveness optimization, not a guarantee that the device will never warm; full-library scanning and other workloads may still consume CPU.
- ZIP integrity checked; Android/Gradle build not run locally.


## V0.14 — Library, cover and pagination efficiency pass
- Added a bounded in-memory EPUB metadata cache keyed by absolute path, file size and modification time. Repeated library refreshes/resume events no longer reopen and reparse unchanged EPUB ZIP metadata during the same app process.
- Batched first-seen `addedAt` preference writes into one SharedPreferences edit per library scan instead of one edit per book.
- Moved library cover thumbnail decoding off the UI thread and added a memory-bounded LRU bitmap cache. Thumbnails are sampled to a maximum 512-pixel longest edge and cached by the existing versioned cover path.
- Reduced reader pagination from repeatedly measuring every remaining suffix (quadratic work for long chapters) to measuring the chapter once and splitting the resulting line ranges into pages. Pagination remains cancellable and runs on `Dispatchers.Default`.
- Reduced progress preference writes to once per displayed integer percentage instead of once per page.
- Preserved library UI, reader layout/navigation, search session/history, selected result, highlighting, tools, and settings.
- ZIP integrity checked; Android/Gradle compilation and on-device thermal/battery measurements are not available in this environment.

## V0.15 build fix
- Fixed Kotlin delegated Compose state smart-cast failure in Library cover rendering.
- Snapshot `coverBitmap` into local immutable `displayedCover` before null check and Image call.
- Preserves V0.14 library cover loading and memory optimization behavior.
- ZIP integrity verified; Android build must be confirmed by GitHub Actions.

## V0.16 — V4-inspired lazy chapter loading and direct ZIP search
- Changed the native EPUB reader model to retain only spine chapter metadata after opening a book; chapter HTML and extracted text are no longer held for every chapter at once.
- Opening a chapter now reads and converts only that chapter from the cached EPUB archive. Moving to another chapter releases the previous chapter content from reader state and loads the newly selected chapter on `Dispatchers.IO`.
- Full-book search now reads XHTML entries directly from the EPUB ZIP, extracts visible text without constructing reader HTML or processing images, and returns compact five-word-before/five-word-after snippets. Search is capped at 1,000 chapter results.
- The temporary archive is deleted when leaving the reader, and is deleted immediately if opening/parsing fails.
- Preserves the V0.15 library/cover cache and pagination optimizations, reader settings, page navigation, chapter list, search history/selection, in-page highlighting, and Back behavior.
- Android versionCode 12 / versionName 0.16.0-lazy-chapter-loading.
- Kotlin reader-engine source passed a standalone syntax/type check using lightweight Android/Jsoup stubs. Full Android Gradle compilation and device testing still require the GitHub Actions build and installation test.

## V0.17 — Reader pagination cache
- Added a bounded LRU cache for already-paginated chapter layouts (maximum 8 layout variants and approximately 4 MiB of cached text, with oversized entries skipped).
- Cache keys include the EPUB path, chapter content, viewport dimensions, and all typography/spacing inputs that affect pagination; changes to those inputs naturally invalidate the cached layout.
- Preserves lazy chapter loading, direct ZIP search, asynchronous cancellable pagination, and existing reader behavior.

## V0.18 — Compact reader display controls
- Reorganized reader display settings into a compact two-column layout for font size, line spacing, paragraph spacing, and letter spacing.
- Placed font family and font thickness side by side; reduced labels, spacing, and button dimensions.
- Kept all existing setting ranges, values, persistence, theme choices, and immediate preview behavior unchanged.
- Added a Done action to close the settings panel; Android Back still closes the panel.
- Bumped Android versionCode to 13 and versionName to 0.18.0-compact-reader-controls.
- ZIP integrity checked. Full Android Gradle compilation and on-device layout testing still require GitHub Actions and device verification.

## V0.19 — Multiple search matches per chapter
- Changed in-book search from returning only the first occurrence in each chapter to returning each non-overlapping occurrence, up to 1,000 results across the book.
- Each result carries its chapter index and occurrence number, so selecting a later match in the same chapter navigates to that occurrence's page rather than always jumping to the first match.
- Search snippets remain compact with up to five words before and after each occurrence; the matched query remains highlighted in the result and reader page.
- Search and chapter loading now share the same plain-text extraction routine, keeping occurrence ordering aligned with the reader's paginated text.
- Search remains on `Dispatchers.Default`; existing search history, selected-result retention, Back behavior, lazy chapter loading, pagination cache, and compact reader controls are preserved.
- Android versionCode 14 / versionName 0.19.0-multiple-search-matches.
- ZIP structure and source consistency checks passed. Full Android Gradle compilation and device testing still require GitHub Actions and installation testing.

## V0.20 — Full-width reader page
- Removed the outer horizontal and vertical padding around the reader page container, eliminating the black frame that previously surrounded the page.
- Removed the rounded page-corner treatment so the selected Light/Sepia/Night page background fills the entire reader content area between the reader's top and bottom controls.
- Retained the inner text padding so reading text does not touch the physical screen edges.
- Based on V0.19; preserves multiple search occurrences, per-occurrence navigation/highlighting, five-word snippets, search history, lazy chapter loading, pagination cache, and compact display settings.
- Android versionCode 15 / versionName 0.20.0-full-width-reader-page.
- ZIP structure and source consistency checks performed; full Android Gradle build and device display verification remain to be confirmed through GitHub Actions and installation.
