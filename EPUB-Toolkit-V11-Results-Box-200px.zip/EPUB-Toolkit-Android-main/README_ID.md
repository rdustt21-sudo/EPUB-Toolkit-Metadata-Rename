# EPUB Toolkit V11 — Batch Edition

V11 melanjutkan baseline V9 yang sudah teruji: aplikasi Android standalone dan 100% offline.

## Fitur batch
- Batch Remove Cover, Fix No Preview, Cover Maker, Image Compressor
- Batch Find & Replace (hitung dan ganti) untuk EPUB/TXT
- Batch Compact Line Spacing, Remove Blank Spacing, Remove All Images
- Batch Rename from Metadata dan baca Cover Metadata secara batch
- Pilih beberapa file secara manual atau pilih semua file pada folder aktif
- Setiap file diproses sendiri-sendiri; kegagalan satu file tidak menghentikan file lain

## Tetap offline
- Tidak ada izin INTERNET
- Tidak ada HTTP server lokal, localhost, fetch, XMLHttpRequest, API, atau aset web eksternal
- Komunikasi langsung Android WebView JavaScript bridge ke Python yang tertanam
- APK Android standalone; tidak memerlukan Pydroid 3
- Operasi perubahan menimpa file EPUB/TXT asli; tidak membuat ZIP backup permanen

Build APK dengan workflow Android/Gradle yang sama seperti V9.


## Pembaruan V11

- Hasil pemrosesan ditampilkan dalam kartu per file, dengan status berhasil/gagal yang lebih jelas.
- Ringkasan tidak lagi menampilkan path cache sementara yang panjang.
- Versi Android: `1.6-v11` (versionCode `7`).

- Hasil batch kini ditampilkan dalam kotak berbingkai dengan tinggi terbatas dan scroll internal, serupa kotak daftar file.
