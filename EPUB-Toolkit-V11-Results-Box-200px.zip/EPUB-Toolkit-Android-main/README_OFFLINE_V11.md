# EPUB Toolkit V11 — Batch Edition (100% Offline)

V11 melanjutkan proyek V10.

## Pembaruan V11
- Daftar hasil batch ditampilkan dalam kotak berbingkai, sudut membulat, dan tinggi maksimum 200px.
- Jika hasil banyak, pengguna dapat menggulir daftar hasil di dalam kotak tanpa membuat halaman memanjang.
- Ringkasan jumlah berhasil/gagal tetap berada di bagian atas kotak hasil.
- Android app version: `1.6-v11` (versionCode `7`).

## Build
Gunakan workflow Android/Gradle yang sama seperti versi sebelumnya. APK belum dibangun atau diuji pada perangkat dalam pembaruan ini.
