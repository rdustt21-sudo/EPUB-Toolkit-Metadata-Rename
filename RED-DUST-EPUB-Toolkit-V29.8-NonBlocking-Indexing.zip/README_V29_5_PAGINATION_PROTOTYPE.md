# V29.5 Pagination Measurement Prototype

This prototype introduced isolated DOM chapter measurement and offset-to-page mapping.

## V29.6 Page Mapping Integration

- Search matches include chapter and normalized text offset.
- Search results now asynchronously measure chapters in a hidden DOM using the reader viewport, font size, line spacing, and paragraph spacing.
- Measured chapter page totals are accumulated to create book-wide page numbers.
- Search result cards display only the page number at the right, in 15px text matching the preview text size.
- Page-number cache keys include book, layout, and match offsets.
- The visible reader and its column navigation are not modified by measurement.

## Validation

Python syntax and embedded JavaScript syntax checks pass. This integration has not yet been built or tested in Android WebView on-device. Page measurements may differ for EPUB-specific styling, fonts, images, tables, or WebView rendering behavior; verify page numbers on-device before treating them as fully accurate.
