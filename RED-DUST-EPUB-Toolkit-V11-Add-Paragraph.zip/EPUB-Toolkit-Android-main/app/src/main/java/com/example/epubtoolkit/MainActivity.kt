package com.example.epubtoolkit

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val pythonLock = Any()

    inner class ToolkitBridge {
        @JavascriptInterface
        fun getFiles(): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_get_files").toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Gagal membaca daftar file").toString()
            }
        }

        @JavascriptInterface
        fun post(path: String, data: String): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_post", path, data).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Operasi gagal").toString()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        status = TextView(this).apply {
            text = "Menyiapkan EPUB Toolkit…"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(20, 14, 20, 14)
        }
        progress = ProgressBar(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ToolkitBridge(), "AndroidBridge")
        }
        root.addView(status)
        root.addView(progress)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            status.text = "Izinkan akses semua file agar EPUB di folder Download dapat diproses."
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startToolkit()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized && Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
            && web.url == null) startToolkit()
    }

    private fun startToolkit() {
        status.text = "Menjalankan mesin EPUB…"
        progress.visibility = View.VISIBLE
        thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val module = Python.getInstance().getModule("epub_app")
                val downloadDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                ).absolutePath
                module.callAttr("set_download_dir", downloadDir)
                val html = module.get("PAGE").toString()
                runOnUiThread {
                    status.text = "EPUB Toolkit siap · Offline"
                    progress.visibility = View.GONE
                    web.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Gagal menjalankan aplikasi: ${e.message}"
                }
            }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
