# V29.9 — Search Freeze Fix

- Replaced `/reader-search` call path that re-opened and rendered every EPUB chapter with a dedicated text-only extractor.
- Search chapter text is cached in memory by EPUB path, modification timestamp, and file size, so repeated queries do not re-parse the ZIP.
- Text extraction skips embedded-image data conversion and reader rendering.
- Search result page measurement is no longer triggered when Search is clicked; hidden-DOM pagination work is removed from the Search flow.
- Search payload capped at 300 matches; UI displays at most 150 result cards to prevent excessive DOM creation.
- Exact page numbers are temporarily omitted in search results until a complete page map is built outside the Search action.

This version prioritizes responsiveness and eliminating the Search-triggered page measurement freeze. Android build and device testing are not performed here.
