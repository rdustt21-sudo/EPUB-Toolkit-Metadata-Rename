# RED DUST - EPUB Toolkit

V11 melanjutkan baseline V9 yang sudah teruji: aplikasi Android standalone dan 100% offline.

## Fitur batch
- Batch Remove Cover, Fix No Preview, Cover Maker, Image Compressor
- Batch Find & Replace (hitung dan ganti) untuk EPUB/TXT
- Batch Compact Line Spacing, Remove Blank Spacing, Remove All Images
- Batch Rename from Metadata dan baca Cover Metadata secara batch
- Pilih beberapa file secara manual atau pilih semua file pada folder aktif
- Setiap file diproses sendiri-sendiri; kegagalan satu file tidak menghentikan file lain

## Tetap offline
- Tidak ada izin INTERNET
- Tidak ada HTTP server lokal, localhost, fetch, XMLHttpRequest, API, atau aset web eksternal
- Komunikasi langsung Android WebView JavaScript bridge ke Python yang tertanam
- APK Android standalone; tidak memerlukan Pydroid 3
- Operasi perubahan menimpa file EPUB/TXT asli; tidak membuat ZIP backup permanen

Build APK dengan workflow Android/Gradle yang sama seperti V9.


## Pembaruan V11

- Hasil pemrosesan ditampilkan dalam kartu per file, dengan status berhasil/gagal yang lebih jelas.
- Ringkasan tidak lagi menampilkan path cache sementara yang panjang.
- Versi Android: `1.6-v11` (versionCode `7`).

- Hasil batch kini ditampilkan dalam kotak berbingkai dengan tinggi terbatas dan scroll internal, serupa kotak daftar file.


## Pembaruan tampilan
- Nama utama aplikasi diubah menjadi RED DUST - EPUB Toolkit dan dipertahankan untuk versi berikutnya.
- Urutan halaman: Features 1–9, panel fitur, lalu Batch Processing.
- Daftar file batch dibatasi 200 px dan dapat digulir.

## V29.5.5 – Fix Internal EPUB Chapter Links
- Internal EPUB hyperlinks are intercepted inside the reader instead of being sent to the Android WebView asset path.
- EPUB spine chapter paths are included in reader chapter metadata for internal-link destination matching.
- Links to another chapter in the reading spine navigate to the mapped chapter; fragment links land at the target element after layout.
- External hyperlinks retain their original href behavior.
- ZIP integrity and Python/JavaScript syntax checks performed; Android Gradle build/device test not performed.
