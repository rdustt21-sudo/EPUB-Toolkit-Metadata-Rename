# Reader swipe response update

The horizontal EPUB page navigation now changes the scroll position immediately instead of using the browser default smooth-scroll animation. This removes the built-in easing delay and makes each swipe respond faster and more predictably on Android WebView. No extra animation is used, prioritizing reading responsiveness.

Updated in `app/src/main/python/epub_app.py` in `readerPageNext()` and `readerPagePrev()`.
