RED DUST – V26 Reader Text Search

Added Find in Book to the built-in EPUB reader. Search scans text across all readable spine chapters in the currently opened EPUB, highlights matching occurrences, and provides previous/next match navigation. Existing reader layout, tab icon colors, pagination, swipe/tap navigation, library, and tools are retained.
