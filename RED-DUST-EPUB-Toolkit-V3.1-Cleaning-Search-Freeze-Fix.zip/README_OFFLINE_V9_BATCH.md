# EPUB Toolkit V9 — Batch Edition (100% Offline)

V9 builds on the verified V8 offline Android standalone baseline.

## Batch features
- Batch Remove Cover, Fix No Preview, Cover Maker, Image Compressor
- Batch Find & Replace (count and replace) for EPUB/TXT
- Batch Compact Line Spacing, Remove Blank Spacing, Remove All Images
- Batch Rename from Metadata and batch read Cover Metadata
- Select multiple files manually, or select all files visible in the active folder filter
- Each file is processed independently; a failure on one file does not stop the rest

## Offline guarantees retained
- No INTERNET permission
- No local HTTP server, localhost endpoint, fetch, XMLHttpRequest, API, or external web assets
- Direct Android WebView JavaScript bridge to embedded Python
- Standalone Android APK; no Pydroid 3 dependency
- Original EPUB/TXT files are overwritten by mutating operations; no persistent backup ZIP is created

## Build
Build with the same Android/Gradle workflow used for V8.
