# EPUB Toolkit V10 — Batch Edition (100% Offline)

V10 builds on the verified V8 offline Android standalone baseline.

## Batch features
- Batch Remove Cover, Fix No Preview, Cover Maker, Image Compressor
- Batch Find & Replace (count and replace) for EPUB/TXT
- Batch Compact Line Spacing, Remove Blank Spacing, Remove All Images
- Batch Rename from Metadata and batch read Cover Metadata
- Select multiple files manually, or select all files visible in the active folder filter
- Each file is processed independently; a failure on one file does not stop the rest

## Offline guarantees retained
- No INTERNET permission
- No local HTTP server, localhost endpoint, fetch, XMLHttpRequest, API, or external web assets
- Direct Android WebView JavaScript bridge to embedded Python
- Standalone Android APK; no Pydroid 3 dependency
- Original EPUB/TXT files are overwritten by mutating operations; no persistent backup ZIP is created

## Build
Build with the same Android/Gradle workflow used for V8.


## V10 update

- Updated the processing result display: batch results are shown as readable per-file cards with success/failure indicators.
- Technical temporary-cache paths and backup-path noise are no longer shown in the result summary.
- Android app version: `1.5-v10` (versionCode `6`).
