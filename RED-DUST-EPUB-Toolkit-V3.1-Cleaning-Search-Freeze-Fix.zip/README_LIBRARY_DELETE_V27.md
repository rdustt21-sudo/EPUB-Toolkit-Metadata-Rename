# RED DUST V27 — Reader Search + Library Book Selection/Delete

This update is based on V26 and preserves its in-novel text search and all earlier app features.

## My Library selection and deletion
- Long-press an EPUB card to enter selection mode and select that book.
- Tap additional cards to select or deselect them.
- Use **Select all** to select all books currently shown by the library search filter.
- Use **Cancel** to leave selection mode.
- Use **Delete** to remove selected EPUB files from shared device storage. The app asks for confirmation first.
- Deleted books are removed from the library scan and their saved reading progress / library timestamps are cleared.
- The delete endpoint validates the relative path and restricts deletion to EPUB files within the configured shared storage root.

## In-novel text search
V26's search field remains in the reader controls. It searches the current EPUB's chapters, highlights matches, reports the total, and supports previous/next match navigation.

## Preserved
- Soft-grey Read Book and Tools icons (only icon treatment retained)
- Metadata-based batch cover maker
- Embedded EPUB covers in My Library
- Pull-down-to-rescan My Library
- Reader layout, page isolation, swipe/tap navigation, chapter navigation and Android Back behavior
- Existing library sort and book search
