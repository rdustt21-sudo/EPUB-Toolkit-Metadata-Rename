# RED-DUST EPUB Toolkit V3.1-Cleaning-Search-Freeze-Fix


## Search optimization
- Dedicated EPUB search now extracts plain text directly from EPUB spine XHTML.
- Search no longer runs the reader's full HTML renderer or embeds images as base64 during indexing.
- Internal link attributes are not processed during search; link labels remain searchable.
- Search results are capped at 1,000 matches to reduce memory pressure on books with very frequent terms.
- Search excludes script and style content.
- Existing reader navigation and rendering paths remain unchanged.


## Validation
- Python syntax validation passed.
- Synthetic EPUB containing linked TOC and internal chapter links successfully searched.
- ZIP archive integrity check passed.
- Android build and device performance testing not run.
