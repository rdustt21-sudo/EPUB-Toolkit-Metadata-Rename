package com.example.epubtoolkit

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import org.json.JSONArray
import net.lingala.zip4j.ZipFile
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var restoreReaderAfterWebViewBack = false
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val pythonLock = Any()

    inner class ToolkitBridge {
        @JavascriptInterface
        fun getFiles(): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_get_files").toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Gagal membaca daftar file").toString()
            }
        }

        @JavascriptInterface
        fun post(path: String, data: String): String = synchronized(pythonLock) {
            try {
                Python.getInstance().getModule("epub_app").callAttr("bridge_post", path, data).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Operasi gagal").toString()
            }
        }

        @JavascriptInterface
        fun unzipBatch(data: String): String = synchronized(pythonLock) {
            try {
                val input = JSONObject(data)
                val selected = input.getJSONArray("files")
                val destinationRel = input.getString("destination").replace("\\", "/")
                val password = input.optString("password", "").ifEmpty { "taiwanandnorthkorea" }
                val storageRoot = File(Environment.getExternalStorageDirectory(), "") .canonicalFile
                val destination = File(storageRoot, destinationRel).canonicalFile
                if (!destination.path.startsWith(storageRoot.path + File.separator)) throw IllegalArgumentException("Folder tujuan tidak valid.")
                if (!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder tujuan.")
                if (!destination.isDirectory) throw IllegalArgumentException("Tujuan bukan folder.")
                if (selected.length() == 0 || selected.length() > 500) throw IllegalArgumentException("Pilih 1 sampai 500 file ZIP.")
                val results = JSONArray(); var succeeded = 0
                for (i in 0 until selected.length()) {
                    val rel = selected.getString(i).replace("\\", "/")
                    try {
                        if (rel.startsWith("/") || rel.split("/").any { it == ".." || it.isEmpty() }) throw IllegalArgumentException("Lokasi ZIP tidak valid.")
                        val archive = File(storageRoot, rel).canonicalFile
                        if (!archive.path.startsWith(storageRoot.path + File.separator) || !archive.isFile || !archive.extension.equals("zip", true)) throw IllegalArgumentException("File ZIP tidak ditemukan.")
                        val zip = if (password.isNotEmpty()) ZipFile(archive, password.toCharArray()) else ZipFile(archive)
                        var extractedCount = 0
                        // Extract entries one by one so files from later archives never overwrite earlier ones.
                        for (header in zip.fileHeaders) {
                            val entryName = header.fileName.replace("\\", "/")
                            if (entryName.startsWith("/") || entryName.split("/").any { it == ".." || it == "." }) {
                                throw IllegalArgumentException("ZIP berisi lokasi file yang tidak valid: $entryName")
                            }
                            val parts = entryName.split("/").filter { it.isNotEmpty() }
                            if (parts.isEmpty()) continue
                            val parentParts = if (header.isDirectory) parts else parts.dropLast(1)
                            var parent = destination
                            for (part in parentParts) parent = File(parent, part)
                            val safeParent = parent.canonicalFile
                            if (!safeParent.path.startsWith(destination.canonicalPath + File.separator) && safeParent != destination.canonicalFile) {
                                throw IllegalArgumentException("Lokasi ekstraksi tidak valid: $entryName")
                            }
                            if (!safeParent.exists() && !safeParent.mkdirs()) throw IllegalStateException("Tidak dapat membuat folder: ${safeParent.name}")
                            if (header.isDirectory) continue

                            val originalName = parts.last()
                            val dot = originalName.lastIndexOf('.')
                            val base = if (dot > 0) originalName.substring(0, dot) else originalName
                            val extension = if (dot > 0) originalName.substring(dot) else ""
                            var outputName = originalName
                            var suffix = 2
                            while (File(safeParent, outputName).exists()) {
                                outputName = "${base}_${suffix}${extension}"
                                suffix++
                            }
                            zip.extractFile(header, safeParent.absolutePath, outputName)
                            extractedCount++
                        }
                        results.put(JSONObject().put("file", rel).put("ok", true).put("result", JSONObject().put("message", "Berhasil mengekstrak $extractedCount file ke ${destinationRel}")))
                        succeeded++
                    } catch (e: Exception) {
                        results.put(JSONObject().put("file", rel).put("ok", false).put("error", (e.message ?: e.javaClass.simpleName)))
                    }
                }
                JSONObject().put("total", selected.length()).put("succeeded", succeeded).put("failed", selected.length() - succeeded).put("results", results).toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "Ekstraksi gagal").toString()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        status = TextView(this).apply {
            text = "Menyiapkan EPUB Toolkit…"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(20, 14, 20, 14)
        }
        progress = ProgressBar(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (restoreReaderAfterWebViewBack) {
                        restoreReaderAfterWebViewBack = false
                        view.evaluateJavascript("restoreReaderAfterWebViewError()", null)
                    }
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ToolkitBridge(), "AndroidBridge")
        }
        root.addView(status)
        root.addView(progress)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            status.text = "Izinkan akses semua file agar EPUB di folder Download dapat diproses."
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startToolkit()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized && Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
            && web.url == null) startToolkit()
    }

    private fun startToolkit() {
        status.text = "Menjalankan mesin EPUB…"
        progress.visibility = View.VISIBLE
        thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val module = Python.getInstance().getModule("epub_app")
                val downloadDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                ).absolutePath
                module.callAttr("set_download_dir", downloadDir)
                val html = module.get("PAGE").toString()
                runOnUiThread {
                    status.text = "EPUB Toolkit siap · Offline"
                    progress.visibility = View.GONE
                    web.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Gagal menjalankan aplikasi: ${e.message}"
                }
            }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized) {
            // First let the reader UI consume Back (selection, popups, search, reader exit).
            // If the WebView is showing a failed local EPUB page, its JavaScript is no
            // longer available; fall back to native WebView history before exiting.
            web.evaluateJavascript("handleAndroidBack()") { result ->
                if (result != "true") {
                    if (web.canGoBack()) {
                        // Native WebView history may return to the toolkit shell after a
                        // broken EPUB resource. Reopen the last book/chapter afterward.
                        restoreReaderAfterWebViewBack = true
                        web.goBack()
                    } else {
                        super.onBackPressed()
                    }
                }
            }
        } else {
            super.onBackPressed()
        }
    }
}
