# EPUB Toolkit V8 — Offline

Versi ini menggunakan komunikasi langsung antara WebView dan Python melalui Android JavaScript bridge.

- Tidak meminta izin `android.permission.INTERNET`.
- Tidak menjalankan HTTP server lokal dan tidak menggunakan `127.0.0.1`.
- Tidak menggunakan `fetch`, XMLHttpRequest, API, atau aset web eksternal.
- Seluruh antarmuka dan mesin EPUB dijalankan dari paket aplikasi.
- Fitur pemfilteran folder, pemrosesan EPUB, overwrite file asli, dan tanpa backup dipertahankan dari Clean V7.

Build APK melalui workflow Android/Gradle seperti biasa. Setelah dipasang, fitur EPUB dapat digunakan tanpa koneksi Wi-Fi maupun data seluler.
