# RED DUST - EPUB Toolkit V28 — Batch Unzip

V28 adds Feature 10 — Batch Unzip — to the supplied V27 Reader/Search/Delete project. Existing toolkit tools and reader files are retained.

## Feature 10
- Select multiple `.zip` archives from the active folder filter.
- Enter one shared password for all selected archives, or leave it blank for unencrypted archives.
- Supports AES-encrypted and traditional ZipCrypto ZIP archives through Zip4j 2.11.5.
- Choose one existing folder as the destination; archive contents are extracted into that shared folder.
- Displays per-archive success/failure results and a batch summary.
- Original ZIP archives are not modified or deleted.
- Extraction runs locally on-device; no network service is used.

## Notes
- If two archives contain files with the same relative path, they target the same destination path; use separate destination folders if you need to keep both copies.
- The selected password is applied to every selected encrypted archive, so select archives that share the same password.
- The project uses the same shared-storage access model as V27.

## V28.1 visibility fix
- Batch Unzip now lists ZIP archives from all discovered shared-storage folders, even when the EPUB folder filter is set to a specific folder.
- The folder filter continues to apply to the other EPUB/TXT batch features.

## V28.2 duplicate filename protection
- Feature 10 now extracts ZIP entries individually rather than calling `extractAll()`.
- If a destination filename already exists, the new file is renamed with a numeric suffix before its extension (`book.epub`, `book_2.epub`, `book_3.epub`).
- Names remain unchanged when there is no conflict, and existing files in the destination folder are also protected from being overwritten.
- ZIP directory structure is retained, and unsafe `.` / `..` entry paths are rejected.
