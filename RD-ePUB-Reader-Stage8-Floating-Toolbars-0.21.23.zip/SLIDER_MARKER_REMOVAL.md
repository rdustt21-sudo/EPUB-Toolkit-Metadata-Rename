# Slider Marker Removal (Stage 8.1)

- Removed stepped slider configuration; sliders are continuous (`steps = 0`).
- Tick colors are explicitly transparent.
- Kept transparent thumb and existing track colors/functionality.
- Updated version to 0.21.21 / versionCode 36.
- No other UI or feature changes intended.
