# Stage 8 update — 0.21.23

- Reader top toolbar is now an overlay over the reading area.
- Reader bottom progress/hint bar is now an overlay.
- Reader content no longer reserves vertical space for top/bottom controls.
- Pagination height is based on the full available reader height minus user vertical padding.
- Toolbar visibility toggles do not change the content container height.
- Retains expanded Above & Below padding range (0–64 dp), continuous sliders, and marker-free slider styling.

Build status: ZIP structure checked. Android Gradle build not run in this environment (Gradle executable/wrapper not present). Runtime behavior requires device testing.
