# EPUB Toolkit V5.0.35 — Optimization Audit (Stage 1)

Base: V5.0.35 Single Feature / Quiet ZIP Extraction.

## Safe change applied
- Removed `androidx.compose.ui:ui-tooling-preview` from app runtime dependencies. No `@Preview` or tooling-preview imports were found in app source.
- No reader, navigation, ZIP, toolkit, UI behavior, storage scanning, cache sizing, signing, or package ID was modified.

## Findings for later optimization (not changed in Stage 1)
- `MainActivity.kt` contains the main UI and several rendering/search/pagination paths; large refactors should be split into smaller, testable steps.
- Toolkit screen scans external storage for ZIP/TXT files recursively when its screen is composed. This can create noticeable CPU and I/O load on large storage; optimize scan scope and timing only after preserving the file discovery behavior.
- EPUB search reads and scans chapter text; pagination measures/splits chapter content. These are likely workload-dependent hotspots and need profiling/benchmarking with large EPUBs before changing behavior.
- Cover cache is memory-bounded; reader pagination cache is bounded to 8 entries / 4 MiB. Avoid increasing these limits without device-memory evidence.
- Launcher assets include multiple density variants and a foreground asset; image optimization may reduce resources but should preserve icon quality.
- `material-icons-extended` is present and the source uses Material icon APIs; removing it safely requires auditing concrete icons and replacing only unused icon sets, not simply deleting the dependency.

## Build configuration
- No Gradle wrapper is included in this ZIP.
- Android build tooling is unavailable in this environment; Stage 1 change is source-audited but not compiled.

## Integrity
- ZIP source was extracted and inspected.
- Stage 1 is limited to dependency cleanup and audit documentation.
