# V5.0.24 Stable Baseline Audit

## Safe cleanup completed
- Removed one unused import (`BasicTextField`) from `MainActivity.kt`.
- No behavior, UI, EPUB engine, Reader, Library, navigation, app ID, version, or signing configuration changed.

## Verified source configuration
- `applicationId`: `com.rdustt21.epubtoolkit.nativeport`
- `versionCode`: 18
- `versionName`: `0.21.2-feature-name-ui-fix`
- V5.0.23 source also has the same application ID and versionCode 17.

## APK file comparison
- `app-debug(1).apk` and `app-debug(1)(1).apk` are byte-for-byte identical (SHA-256 `72af08335319b222308509569003e087b17c581783fb7c89d545c9d22ea9990f`).
- `app-debug.apk` is different.
- This comparison alone does not identify the installed app's signing certificate.

## Update-install failure
Still unresolved. The most likely cause remains signing-certificate mismatch, but it is not confirmed. Keep the current signing key and package ID unchanged until certificate fingerprints from the installed and update APKs can be compared.

## Build verification limitation
This environment does not have `apksigner` or the Android build tooling installed. Therefore, this cleanup was not compiled or APK-tested here. The change is limited to deleting a single unused import.

# V5.0.31 Reader spacing and slider appearance
- Paragraph spacing now preserves paragraph boundaries and renders a continuous Compose spacer between paragraph text blocks, using the spacing value in em (font-size-scaled dp) instead of rounding to whole blank lines.
- Line spacing continues to apply directly to the reader TextStyle lineHeight and remains adjustable in 0.01 increments.
- Letter spacing continues to apply directly to TextStyle letterSpacing; slider precision is now 0.01 and the displayed value uses two decimals.
- Slider active/inactive tracks and tick colors are uniform, with the thumb transparent, so no dot, inner progress line, or contrasting indicator is visible.
- Version incremented to versionCode 25 / versionName 0.21.9-slider-precision.
- Build not verified: Gradle is not installed in this environment.
