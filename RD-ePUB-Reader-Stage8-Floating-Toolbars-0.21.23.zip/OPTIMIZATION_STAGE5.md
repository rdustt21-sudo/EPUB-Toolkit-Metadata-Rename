# Optimization Stage 5 — Lifecycle Memory Cleanup

- Added `CoverImageCache.clear()` to release cached cover bitmaps.
- MainActivity clears disposable cover thumbnails when Android signals `TRIM_MEMORY_UI_HIDDEN` or stronger memory pressure.
- Covers are decoded again on demand; library cover display behavior is preserved.
- No reader rendering, pagination, image decoder, reading-position, extraction, or UI behavior changes.
- Version: 0.21.16 (versionCode 31).

Build was not run in this environment.
