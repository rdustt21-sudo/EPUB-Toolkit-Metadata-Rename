# EPUB Toolkit V5.0.35 — Optimization Stage 2


Base: Optimization Audit Stage 1.

## Change
- Removed redundant initial library scan from `LaunchedEffect(Unit)`. The library's initial refresh is already triggered by the Activity lifecycle `ON_RESUME` observer. This avoids initiating a second recursive storage scan on startup.
- Storage permission request remains in the initial effect when access is missing; after returning from the permission screen, `ON_RESUME` refreshes the library.
- Incremented Android version code 28 -> 29 and version name 0.21.13 -> 0.21.14.

## Not changed
- EPUB reader rendering, pagination, search behavior, reader position restore, toolkit operations, ZIP extraction, cover cache policy, signing, package ID, and permissions.

## Verification
- Source edit applied to the exact startup block and checked for expected lifecycle scan code.
- ZIP integrity checked.
- Android build/device thermal profiling not available; no claims of build success or measured temperature reduction.
