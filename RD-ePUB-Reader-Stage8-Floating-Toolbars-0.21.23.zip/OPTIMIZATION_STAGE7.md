# EPUB Toolkit V5.0.35 — Optimization Stage 7

Base: Stage 6 (version 0.21.17).

## Changes
- Metadata cache changed from a concurrent map that cleared all entries at capacity to a synchronized access-order LRU map with a 512-entry limit.
- Cache lookups and writes are synchronized; cached entries are bounded and hot entries are not discarded wholesale.
- Replaced launcher icon assets with the user-provided open-book icon for density-specific legacy icons and adaptive foreground.
- Version incremented to 0.21.18 / versionCode 33.

## Preserved
- Library scan behavior and file discovery.
- Reader, pagination, image extraction/decoding, reading-position, ZIP extraction, settings, package ID and signing setup.

## Verification
- ZIP integrity checked after packaging.
- Source changes inspected. Android Gradle build not run in this environment.
