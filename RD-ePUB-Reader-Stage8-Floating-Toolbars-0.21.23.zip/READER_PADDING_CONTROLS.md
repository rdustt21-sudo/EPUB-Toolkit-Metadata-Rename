# Reader Padding Controls

- Added linked horizontal padding slider: left and right adjust together.
- Added linked vertical padding slider: above and below adjust together.
- Settings persist using existing reader settings SharedPreferences.
- Defaults: 20dp horizontal and 8dp vertical.
- Horizontal range: 8dp to 40dp; vertical range: 0dp to 32dp.
- Pagination width and height calculations now use the configured paddings and account for the reader footer.
- Version: 0.21.20 (versionCode 35).
