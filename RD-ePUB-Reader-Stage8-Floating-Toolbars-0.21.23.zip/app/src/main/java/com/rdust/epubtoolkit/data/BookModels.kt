package com.rdust.epubtoolkit.data

import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File
import java.util.zip.ZipFile
import java.util.LinkedHashMap
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader

data class EpubBook(
    val uri: Uri,
    val displayName: String,
    val title: String,
    val author: String,
    val folder: String,
    val addedAt: Long = 0L,
    val lastOpenedAt: Long = 0L,
    val progress: Float = 0f,
    val coverPath: String? = null
)

object BookLibrary {
    private const val PREFS = "rd_v4_native"
    // EPUB metadata is expensive to parse. Keep a bounded process cache keyed by
    // file path, size and modification time so refresh/resume doesn't reopen every ZIP.
    private const val METADATA_CACHE_LIMIT = 512
    private val metadataCache = object : LinkedHashMap<String, Metadata>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Metadata>?): Boolean =
            size > METADATA_CACHE_LIMIT
    }

    fun markOpened(context: Context, uri: Uri) {
        context.getSharedPreferences(PREFS, 0).edit().putLong("opened:${uri}", System.currentTimeMillis()).apply()
    }

    fun saveProgress(context: Context, uri: Uri, progress: Float) {
        val prefs = context.getSharedPreferences(PREFS, 0)
        val key = "progress:${uri}"
        val safeProgress = progress.coerceIn(0f, 100f)
        // Library progress is displayed as a percentage; avoid a disk preference
        // write for every page when the visible integer percentage hasn't changed.
        if (prefs.getFloat(key, 0f).toInt() == safeProgress.toInt()) return
        prefs.edit().putFloat(key, safeProgress).apply()
    }

    fun delete(context: Context, uri: Uri): Boolean {
        val path = uri.path ?: return false
        return runCatching { File(path).delete() }.getOrDefault(false)
    }

    fun scan(context: Context): List<EpubBook> {
        val root = Environment.getExternalStorageDirectory()
        if (!root.exists() || !root.canRead()) return emptyList()
        val found = mutableListOf<EpubBook>()
        val prefs = context.getSharedPreferences(PREFS, 0)
        val visited = HashSet<String>()
        val addedUpdates = HashMap<String, Long>()
        fun walk(dir: File, depth: Int) {
            if (depth > 16 || !dir.canRead()) return
            val canonical = runCatching { dir.canonicalPath }.getOrNull() ?: return
            if (!visited.add(canonical)) return
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) {
                    if (file.name !in setOf("Android", ".thumbnails")) walk(file, depth + 1)
                } else if (file.isFile && file.name.endsWith(".epub", true)) {
                    val uri = Uri.fromFile(file)
                    val meta = runCatching { cachedMetadata(file, context) }.getOrNull()
                    val key = uri.toString()
                    val addedKey = "added:$key"
                    val added = prefs.getLong(addedKey, 0L).takeIf { it > 0L }
                        ?: file.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
                    if (!prefs.contains(addedKey)) addedUpdates[addedKey] = added
                    val relative = file.parentFile?.relativeToOrNull(root)?.path?.replace(File.separatorChar, '/') ?: ""
                    found += EpubBook(uri, file.name,
                        meta?.title?.takeIf { it.isNotBlank() } ?: file.name.removeSuffix(".epub"),
                        meta?.author.orEmpty(), relative, added, prefs.getLong("opened:$key", 0L),
                        prefs.getFloat("progress:$key", 0f), meta?.coverPath)
                }
            }
        }
        walk(root, 0)
        if (addedUpdates.isNotEmpty()) {
            prefs.edit().apply { addedUpdates.forEach { (key, value) -> putLong(key, value) } }.apply()
        }
        return found.sortedBy { it.title.lowercase() }
    }

    private data class Metadata(val title: String, val author: String, val coverPath: String?)

    private fun cachedMetadata(file: File, context: Context): Metadata {
        val key = "${file.absolutePath}:${file.length()}:${file.lastModified()}"
        synchronized(metadataCache) { metadataCache[key]?.let { return it } }
        val value = metadata(file, context)
        synchronized(metadataCache) {
            metadataCache[key]?.let { return it }
            metadataCache[key] = value
        }
        return value
    }

    private fun metadata(file: File, context: Context): Metadata {
        ZipFile(file).use { zip ->
            val containerEntry = zip.getEntry("META-INF/container.xml") ?: return Metadata("", "", null)
            val factory = secureFactory()
            val c = factory.newDocumentBuilder().parse(zip.getInputStream(containerEntry))
            val rootfile = c.getElementsByTagNameNS("*", "rootfile").item(0) as? org.w3c.dom.Element ?: return Metadata("", "", null)
            val opfPath = rootfile.getAttribute("full-path")
            val opf = zip.getEntry(opfPath) ?: return Metadata("", "", null)
            val doc = factory.newDocumentBuilder().parse(zip.getInputStream(opf))
            fun value(tag: String): String {
                val nodes = doc.getElementsByTagNameNS("*", tag)
                for (i in 0 until nodes.length) nodes.item(i).textContent?.trim()?.let { if (it.isNotEmpty()) return it }
                return ""
            }
            val manifest = doc.getElementsByTagNameNS("*", "item")
            var coverHref = ""
            var coverId = ""
            for (i in 0 until manifest.length) {
                val item = manifest.item(i) as? org.w3c.dom.Element ?: continue
                val properties = item.getAttribute("properties")
                if (properties.split(Regex("\\s+")).contains("cover-image")) { coverHref = item.getAttribute("href"); break }
                if (item.getAttribute("id").contains("cover", true) && item.getAttribute("media-type").startsWith("image/")) { coverHref = item.getAttribute("href"); coverId = item.getAttribute("id") }
            }
            if (coverHref.isBlank()) {
                val metas = doc.getElementsByTagNameNS("*", "meta")
                for (i in 0 until metas.length) {
                    val m = metas.item(i) as? org.w3c.dom.Element ?: continue
                    if (m.getAttribute("name").equals("cover", true)) coverId = m.getAttribute("content")
                }
                if (coverId.isNotBlank()) for (i in 0 until manifest.length) {
                    val item = manifest.item(i) as? org.w3c.dom.Element ?: continue
                    if (item.getAttribute("id") == coverId) coverHref = item.getAttribute("href")
                }
            }
            var coverPath: String? = null
            if (coverHref.isNotBlank() && !coverHref.endsWith(".svg", true)) {
                val parent = opfPath.substringBeforeLast('/', "")
                val entryPath = (if (parent.isBlank()) coverHref else "$parent/$coverHref").replace("\\", "/")
                val entry = zip.getEntry(entryPath)
                if (entry != null) {
                    val cache = File(context.cacheDir, "rd-cover-${file.length()}-${file.lastModified()}-${entry.name.hashCode()}.img")
                    if (!cache.exists()) runCatching { zip.getInputStream(entry).use { input -> cache.outputStream().use { output -> input.copyTo(output) } } }
                    if (cache.exists()) coverPath = cache.absolutePath
                }
            }
            return Metadata(value("title"), value("creator"), coverPath)
        }
    }

    private fun secureFactory() = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
        runCatching { isXIncludeAware = false }
        runCatching { isExpandEntityReferences = false }
        runCatching { setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) }
        runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
        runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") }
    }
}
