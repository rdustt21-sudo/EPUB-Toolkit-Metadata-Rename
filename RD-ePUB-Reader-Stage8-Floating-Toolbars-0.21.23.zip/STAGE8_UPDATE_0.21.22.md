# Stage 8 update — 0.21.22

- Expanded the Above & Below reader padding slider range from 0–32 dp to 0–64 dp, preserving continuous adjustment and the marker-free slider.
- App version updated to 0.21.22 (versionCode 37).

Note: Floating/overlay reader toolbar behavior is not implemented in this update. The reader's existing toolbar layout remains unchanged; the overlay conversion needs a broader Compose layout restructuring and is intentionally not represented as completed here.
