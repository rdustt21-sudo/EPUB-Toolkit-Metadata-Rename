# Reader Layout Adjustment

- Reclaim the unused 56dp toolbar placeholder when reader controls are hidden.
- Reduce vertical content margins to 8dp.
- Increase right margin to 24dp while keeping left margin 16dp.
- Align pagination line count with actual content area and footer instead of subtracting extra unused space.
- Version: 0.21.19 (versionCode 34).

No reader settings, reading position, chapter logic, image decoding, or library features changed.
