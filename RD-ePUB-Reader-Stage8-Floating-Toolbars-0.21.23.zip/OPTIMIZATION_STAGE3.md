# EPUB Toolkit V5.0.35 — Optimization Stage 3

Base: Optimization Stage 2 (version 0.21.14).

## Change
- Optimized EPUB chapter image extraction path lookup: exact ZIP entry lookup remains first; the case-insensitive fallback now builds one index instead of repeatedly scanning all ZIP entries for each image.
- Reuses extracted image paths within a chapter load when the same normalized asset is referenced multiple times.
- Streaming copy remains unchanged; no whole-image buffering was added.
- Version code 29 -> 30; version name 0.21.14 -> 0.21.15.

## Not changed
- Reader pagination and text layout, reading position restore, chapter navigation, search, slider settings, library scan, ZIP extraction UI, package ID, permissions, signing configuration.

## Verification
- Source change applied and ZIP archive integrity checked.
- Gradle build and device performance/thermal measurements were not available; no runtime performance claims are made.
